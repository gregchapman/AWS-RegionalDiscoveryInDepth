---
inclusion: auto
---

# ADR-0001: AWS-Native Services Over Third-Party Products

Date: 2026-08-06
Status: Accepted

## Context

Evaluated Teleport Enterprise, AppGate, and a home-grown approach for
replacing AD + VPN + JumpHosts in RGS FedRAMP environments. The key
criteria: 20x compliance (machine-readable evidence), cost, vendor
independence, and operational simplicity.

## Decision

Use AWS-native services (IAM Identity Center, SSM Session Manager,
CloudTrail, API Gateway, Lambda, Step Functions) as the access platform.
No third-party vendor in the critical access path.

## Consequences

- 20x evidence is native — CloudTrail, Config, IAM policies are already
  in formats assessors pull programmatically. No export/transform needed.
- Zero vendor license cost. Zero vendor lock-in.
- We own the code and the roadmap.
- Tradeoff: no session video recording (text logs only). Acceptable for
  FedRAMP Moderate. Add Teleport later if video is demanded.
- Tradeoff: no built-in chat approval workflow. Build if needed.
- Team must maintain the portal frontend (React SPA).
