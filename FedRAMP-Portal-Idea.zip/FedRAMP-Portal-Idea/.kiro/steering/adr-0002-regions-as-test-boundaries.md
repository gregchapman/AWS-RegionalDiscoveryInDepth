---
inclusion: auto
---

# ADR-0002: Regions as Security Boundaries for Testing

Date: 2026-08-06
Status: Accepted

## Context

Production architecture uses separate AWS accounts per customer (account
IS the isolation boundary). For POC testing, requiring multiple accounts
adds friction (org setup, cross-account roles, billing separation).

## Decision

Use a single AWS account with regions simulating different
customers/boundaries:
- us-east-1: RGS management (portal, API, Identity Center)
- us-east-2: Customer A simulation
- us-west-1: Customer B simulation

IAM policies + tags enforce "simulated" isolation within the single account.

## Consequences

- POC is deployable by one engineer in one account (low friction)
- Isolation is IAM-enforced, not account-enforced (weaker than production)
- Production migration requires moving to multi-account (Identity Center
  handles this natively — permission sets just point at different accounts)
- Test results prove the access model works; they do not fully prove
  account-level isolation (that's inherent in the production account structure)
