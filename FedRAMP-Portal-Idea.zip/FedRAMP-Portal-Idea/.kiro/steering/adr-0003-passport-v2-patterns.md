---
inclusion: auto
---

# ADR-0003: Adopt Passport V2 Patterns for Access Lifecycle

Date: 2026-08-06
Status: Accepted

## Context

Passport V2 (RSS-Engineering/passport) is a production-proven access
orchestration system already running in Rackspace's environment. It
handles ephemeral user provisioning, SSM-based tunneling, time-bound
sessions, and automatic cleanup via Step Functions.

## Decision

Adopt Passport V2's architectural patterns for the access lifecycle:
- Step Functions for provision → session → cleanup orchestration
- SSM Run Command for OS-level user creation/deletion
- DynamoDB for access request state
- Short-lived SSH certificates (Linux) and generated passwords (Windows)
- Automatic cleanup on session expiry

Reference implementation: `\\wsl.localhost\Ubuntu-20.04\home\greg\Chappies-Tools\passport\passport\`

## Consequences

- We don't reinvent the access lifecycle — patterns are proven at scale
- Step Functions provide auditable, retry-capable orchestration
- DynamoDB gives serverless state with no DB to manage
- We adapt (not copy verbatim) — our implementation is standalone,
  not dependent on Rackspace's internal infrastructure (Janus, Heimdall)
- SSM documents for user provisioning must be tested against both
  Amazon Linux 2023 and Windows Server 2019/2022
