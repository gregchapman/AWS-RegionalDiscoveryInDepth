---
inclusion: auto
---

# ADR-0004: Serverless Backend (API Gateway + Lambda)

Date: 2026-08-06
Status: Accepted

## Context

The portal backend needs to: list accounts, list instances, create access
requests, and check session status. Load is low (internal tool, tens of
concurrent users at most). Options: ECS Fargate (like Passport V2), Lambda,
or EC2.

## Decision

Use API Gateway + Lambda for the backend. Step Functions for the access
lifecycle orchestration.

## Consequences

- Scales to zero when unused (cost-efficient for POC and low-traffic production)
- No servers to patch, no containers to manage
- Cold starts are acceptable for an internal portal (sub-second with provisioned concurrency if needed)
- API Gateway provides built-in WAF integration, throttling, and request validation
- Lambda execution role handles cross-region assume for listing instances in customer regions
- Passport V2 uses ECS Fargate for its API — we diverge here because our
  traffic pattern is lighter and we don't need the persistent connection handling
