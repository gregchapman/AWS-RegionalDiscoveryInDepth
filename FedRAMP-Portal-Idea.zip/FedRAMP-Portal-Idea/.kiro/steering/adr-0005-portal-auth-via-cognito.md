---
inclusion: auto
---

# ADR-0005: Portal Authentication via Cognito (Federated to IdP)

Date: 2026-08-06
Status: Accepted

## Context

The React SPA needs to authenticate users (both Rackers and customers).
Options: direct SAML in the browser (complex), Cognito as a broker,
custom auth server, or IAM Identity Center OIDC.

## Decision

Use Amazon Cognito User Pools with SAML federation to the corporate IdP.
Cognito issues JWTs that the React app uses to call the API Gateway
(Cognito authorizer).

For testing (no IdP available): use Cognito's built-in user directory
with manual user creation.

## Consequences

- Clean separation: IdP handles identity, Cognito handles token issuance,
  API Gateway validates tokens. No custom auth code.
- Cognito supports SAML (for production) and username/password (for testing)
  without code changes — just swap the identity provider config.
- Customer vs. Racker distinction: separate Cognito User Pool groups or
  separate User Pools. Group membership determines portal view.
- Cognito is FedRAMP authorized (part of AWS).
- Tradeoff: Cognito has quirks (token refresh, custom UI limitations).
  Acceptable for an internal/partner portal.
