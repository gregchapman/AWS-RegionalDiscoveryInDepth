---
inclusion: auto
---

# ADR-0006: Zero Inbound Ports on Customer Instances

Date: 2026-08-06
Status: Accepted

## Context

Traditional access patterns require inbound SSH (22) or RDP (3389) on
security groups, creating attack surface even when restricted to VPN
CIDRs. SSM Session Manager provides an alternative path that requires
no inbound ports.

## Decision

Customer instances have NO inbound SSH or RDP security group rules. All
administrative access is via SSM Session Manager (which the agent
initiates outbound on 443) or via SSM-tunneled connections for RDP.

## Consequences

- Attack surface is dramatically reduced — port scanning finds nothing
- No VPN required for access (SSM communicates via AWS service endpoints)
- Security groups become simpler (only application-level rules remain)
- SSM agent health becomes critical — if agent dies, instance is
  unreachable until agent recovers (mitigated by systemd watchdog)
- Auditors see clean security groups with no management ports exposed
- Compliance evidence: security group rules are machine-readable via
  AWS Config and prove no inbound management access exists
