---
inclusion: auto
---

# ADR-0007: RGS Government Branding

Date: 2026-08-06
Status: Accepted

## Context

The portal serves FedRAMP government customers. It must convey
professionalism, security, and trust. Rackspace Government Solutions
branding is established at rackspace.com/industry/government.

## Decision

Portal uses RGS visual language:
- Dark navy (#1B2838) primary background
- White text and UI elements
- Red accent (#C8102E) for actions and alerts
- Clean, minimal design — no clutter
- Rackspace Government Solutions logo/wordmark
- Professional, federal tone in all copy

Built with Tailwind CSS for rapid development and consistent spacing.

## Consequences

- Portal looks purpose-built for government, not like a generic SaaS tool
- Tailwind utility classes enable rapid iteration without CSS bloat
- Branding can be updated via Tailwind config (colors, fonts) without
  touching component logic
- Accessibility: dark backgrounds require careful contrast ratios —
  enforce WCAG 2.1 AA minimum (4.5:1 for text)
