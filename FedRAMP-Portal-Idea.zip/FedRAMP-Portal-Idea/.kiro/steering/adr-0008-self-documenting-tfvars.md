---
inclusion: auto
---

# ADR-0008: Self-Documenting terraform.tfvars

Date: 2026-08-26
Status: Accepted

## Context

Each Terraform layer has a `variables.tf` with defaults, but the actual
values used for deployment (account-specific bucket names, user lists,
region targets) need to live somewhere. Options: environment variables,
`.auto.tfvars`, `terraform.tfvars`, or a shared vars file passed via
`-var-file`.

## Decision

Each layer gets its own `terraform.tfvars` with:
- A header comment block identifying the account, region, and purpose
- Every variable present (even if using the default)
- Inline comments explaining: what the variable does, what the default is,
  and what the valid/possible values are
- Account-specific values already filled in (e.g., bucket names with
  account ID suffix for global uniqueness)

## Consequences

- Any engineer can open a tfvars file and understand what every value
  means without cross-referencing `variables.tf` or documentation
- `terraform plan` shows exactly what will be applied — no mystery defaults
- Bucket names include the account ID (globally unique, no collisions)
- `backend.tf` files reference the account-specific state bucket name
- Slightly more maintenance when adding variables, but the clarity payoff
  is worth it for a compliance-oriented project where auditors review config
- tfvars files should NOT be in `.gitignore` (they contain no secrets,
  just configuration)

