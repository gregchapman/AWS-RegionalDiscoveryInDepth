---
inclusion: auto
---

# ADR-0009: Cross-Layer Dependencies via terraform_remote_state

Date: 2026-08-26
Status: Accepted

## Context

The project is split into 5 Terraform layers (00-04), each with its own
state file stored under a different key in the same S3 bucket. Layers
have dependencies: 03-api needs the CloudFront URL from 02-portal-hosting,
and the portal config needs Identity Center values from 01.

Options for passing values between layers:
1. Manual copy-paste into tfvars (error-prone, humans fat-finger things)
2. `terraform_remote_state` data sources (automatic, always current)
3. SSM Parameter Store or Secrets Manager (extra infrastructure)
4. Terragrunt dependency blocks (adds tooling dependency)

## Decision

Use `terraform_remote_state` data sources. Each layer that depends on
another gets a `remote-state.tf` file declaring the dependency, with
`try()` wrappers so the layer can still plan even if the upstream hasn't
been deployed yet.

Pattern:
- `remote-state.tf` declares the data sources
- `locals {}` block provides friendly names
- `main.tf` references `local.cloudfront_url` etc. (not the long data path)
- Variables still exist as manual override fallbacks

## Consequences

- No human copy-paste between layers — values flow automatically
- Deploy order still matters (02 before 03), but re-applying 03 after 02
  picks up the new values without editing tfvars
- `try()` wrappers mean `terraform plan` works even if upstream state is
  empty (falls back to variable or empty string)
- All layers share the same state bucket — a single S3 bucket + DynamoDB
  table serves as the coordination point
- Slightly harder to read than a flat tfvars, but the tradeoff is
  correctness over readability
- terraform.tfvars variables remain as escape hatches for overrides

