---
inclusion: auto
---

# ADR-0010: Security Baseline as Dedicated Terraform Layer

Date: 2026-08-26
Status: Accepted

## Context

FedRAMP Moderate requires multiple account-level security services:
GuardDuty (SI-4), Security Hub (CA-7), AWS Config (CM-6), CloudTrail
(AU-9), and SSM Session Manager logging (AU-12). These could be
scattered across existing layers or consolidated.

## Decision

Create `terraform/05-security-baseline/` as a dedicated layer containing
all account-level security services. Deploy once after layers 00-04.
Rarely changes after initial setup.

Contents:
- GuardDuty detectors (management + customer regions)
- Security Hub with NIST 800-53 v5 and AWS Foundational standards
- AWS Config recorder + delivery + compliance rules (required-tags,
  ec2-managed-by-ssm, restricted-ssh)
- CloudTrail (multi-region, S3 + CloudWatch, log file validation,
  365-day retention with Glacier transition at 90 days)
- SSM Session Manager preferences document (S3 + CloudWatch logging)
- Dedicated S3 buckets for each service (KMS encrypted, versioned,
  public access blocked)

## Consequences

- All security controls are auditable from a single `terraform plan`
- Deploy order: 00 → 01 → 02 → 03 → 04 → 05 (05 can go after 04)
- Assessors can review one layer for compliance evidence
- Security services don't create circular dependencies with app layers
- One more state file in the same bucket — acceptable tradeoff
- GuardDuty in multiple regions has a small cost (~$3-5/month per
  region with low event volume)

