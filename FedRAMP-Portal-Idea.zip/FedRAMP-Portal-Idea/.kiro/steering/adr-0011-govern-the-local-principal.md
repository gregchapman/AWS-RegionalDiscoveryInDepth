---
inclusion: auto
---

# ADR-0011: Govern the Local Principal (Don't Try to Eliminate It)

Date: 2026-08-27
Status: Accepted

## Context

The initial Passport implementation provisions a randomly-named ephemeral
local user (e.g. `p-a751a325`) with a generated password, blanket sudo, and
password-based SSH/RDP auth. Testing surfaced multiple compliance and
operational problems:

- Random usernames (`p-xxxx`) make OS-level audit logs (auditd, Windows
  Event Log) useless for attribution — you can't tell who did what from
  the instance itself.
- Passwords stored in DynamoDB and displayed in the portal (SC-28, IA-5).
- Blanket sudo violates least privilege (AC-6).
- No correlation between the session record and OS-level activity.

We explored eliminating the local user entirely (SSM `ssm-user`, STS-only
brokering). Conclusion: **privilege on any contemporary OS requires a local
security principal the kernel recognizes.** Cloud does not change this.
`ssm-user` exists but is shared across all users (breaks attribution) and
is all-or-nothing sudo (breaks least privilege). There is no privileged
action without a local user context.

## Decision

Accept that a local principal is unavoidable, and **govern it** rather than
try to avoid it. Every ephemeral access user must be:

1. **Identity-named** — username derived from the authenticated identity
   (e.g. `greg-racker`), NOT a random token. OS logs now attribute to the
   human.
2. **Role-scoped** — group membership / sudoers scope matches the portal
   role (admin vs. read-only). Restores AC-6 least privilege.
3. **Authenticated without shared passwords** where possible — short-lived
   SSH certificate for Linux. (Windows local accounts still require a
   password unless directory-joined; tracked as a staged item.)
4. **Ephemeral** — created at session start, removed at cleanup.
5. **Correlated** — the SSM session ID and STS RoleSessionName are stored
   alongside the OS username so session-level and OS-level audit trails
   join up (AU-2 / AU-3 / AU-12).

The portal brokers access via STS so end users do not need their own
AWS credentials configured (removes the fragile "user must have
SSM-authorized default creds" dependency observed in testing).

## Staging

- **Linux (now):** identity-named user + role-scoped sudo + SSH cert
  injection + ephemeral + correlated. Fully achievable in current arch.
- **Windows (later):** identity-named local account is achievable now, but
  passwordless auth requires directory-join (AD/Kerberos) or AWS Fleet
  Manager RDP. Until then, Windows keeps password auth (documented in
  ARCHITECTURE-WEAKNESSES.md).

## Consequences

- OS-level audit logs become attributable to real identities.
- Least privilege is enforceable per role.
- Password handling is eliminated for Linux; isolated to Windows pending
  directory-join.
- This is an evolution of the existing Step Function / provision-Lambda
  flow, not a rebuild: change username generation, add role→privilege
  mapping, swap password→cert for Linux, persist session/identity
  correlation.
- Full AAA still depends on OS audit subsystems (auditd / Sysmon) being
  configured and shipped to central logging — tracked separately.
- Revisit ADR-0001 (AWS-native over third-party) only if the native AAA
  build cost exceeds the value; this ADR assumes we continue native.
