---
inclusion: auto
---

# ADR-0012: CLI-Broker Access Pattern (No User AWS Credentials)

Date: 2026-08-27
Status: Accepted (supersedes the raw `aws ssm` approach in the SessionDrawer)

## Context

Our portal's SessionDrawer currently emits a raw `aws ssm start-session`
command that the user runs locally. Testing exposed a serious flaw: this
depends on the user having AWS credentials configured on their workstation
that are (a) present and (b) authorized for `ssm:StartSession` on the target
instance. During testing this caused confusing `403 Server authentication
failed` errors that turned out to be the wrong ambient credential context
(a `[default]` profile shadowing the intended one). A customer or Racker who
just wants to connect should not have to configure an AWS credentials file.

Investigation of production Passport (manage.rackspace.com, via Janus)
revealed the correct pattern: it does NOT hand users a raw `aws ssm`
command. Instead it ships a dedicated **`passport` CLI**:

    passport connect i-0b7079a48830f9c41

Installed via a Rackspace-hosted installer (Mac/*nix curl script; Win32/Win64
installers). The CLI is authenticated to the user's **Janus/portal identity**,
not to AWS. The Passport backend brokers the actual SSM session — the user
never possesses AWS credentials.

## Decision

Adopt the **CLI-broker pattern**. Instead of emitting raw `aws ssm` commands
that rely on the user's ambient AWS credentials, provide a purpose-built CLI
(or equivalent brokered mechanism) that:

1. Authenticates to the **portal identity** (Cognito/IdP), not AWS.
2. Brokers the SSM session on the backend — the backend holds/vends the AWS
   credentials (via STS with a RoleSessionName tied to the user's identity).
3. Requires **no AWS credentials file** on the user's machine — only the CLI
   and the SSM Session Manager plugin.
4. Carries the user's identity end-to-end so provisioning and session actions
   attribute to the real person (reinforces ADR-0011).

## Consequences

- Eliminates the fragile "user must have SSM-authorized default AWS creds"
  dependency that caused the 403 confusion in testing.
- Identity flows from portal login → CLI → brokered session, giving clean
  attribution (Accounting) without the user managing AWS identity.
- Requires building/distributing a CLI (or a browser-based session proxy as
  an alternative) — a larger effort than the current raw-command approach.
- The SessionDrawer's raw `aws ssm` command becomes a fallback / interim
  mechanism until the CLI-broker is built.
- STS brokering with an identity-bound RoleSessionName is the backend piece
  that makes this work; it also improves CloudTrail attribution.

## Open questions

- CLI vs. browser-based session proxy (in-portal terminal/RDP). Browser-based
  is the most FedRAMP-friendly (no local tooling, nothing on the endpoint) but
  is the largest build. CLI matches production Passport and is a middle ground.

## RESOLVED — credential-vending mechanism (2026-08-31, from Passport source)

The "credential vending mechanism" open question is ANSWERED by reading
production Passport source (`Chappies-Tools/passport/passport/`). The proven
pattern (which we will mirror per ADR-0003/0013):

- **Client** (`cli/connect/ssmtransport.go`): the CLI does NOT use the user's
  AWS creds. It calls a backend endpoint (`GetAWSCredentialsV3`) with the
  user's IDENTITY token + the access request, gets back short-lived STS creds,
  and builds the SSM client from them via `NewStaticCredentialsProvider`. The
  user configures no AWS credentials — ever.
- **Backend** (`internal/heimdall/heimdall.go` → `passportCLIPolicyDocument`):
  vends STS creds scoped by an **inline session policy** to the MINIMUM needed:
  - `ssm:StartSession` on ONLY the specific target instance ARN(s)
    (`arn:aws:ec2:*:*:instance/i-xxx`, or `.../managed-instance/mi-xxx` hybrid),
  - only the `AWS-StartPortForwardingSession` / `AWS-StartSSHSession` documents,
  - `DurationSeconds = 3600` (1h, auto-expires),
  - the STS session **name = the authenticated identity** (→ CloudTrail
    attributes every SSM call to the real person).

This is MORE 800-53-compliant than standing creds: AC-6/AC-6(1) (least
privilege — one instance, one action, 1h), AC-12 (expiry), AU-2/AU-3/AU-12
(identity-named STS session = attributable). It is the "portal login =
authentication; portal then vends scoped authorization" model.

**Decision:** implement an AWS-native equivalent — an API endpoint that does
`sts:AssumeRole` with an inline `Policy` scoped exactly as above, returning the
temp creds. No separate "heimdall" service needed (single-partition; do it in a
Lambda). The interim SessionDrawer raw-`aws ssm` command (which needs the
user's own creds — Racker-only) is the FALLBACK until this ships. This is what
makes access credential-less for CUSTOMERS, not just Rackers with personal-faws.

**Test discipline (ADR-0018):** prove it in a credential-SCRUBBED shell —
`aws sts get-caller-identity` must FAIL, yet the connect flow must still tunnel,
because the creds come from the endpoint, not the environment.

## IMPLEMENTED — in code, needs deploy + proof (2026-08-31, later)

The AWS-native equivalent is BUILT (not yet deployed — SoD, ADR-0018: greg runs
terraform + the proof):

- **Broker role** (`terraform/03-api/session-broker.tf`): `session_broker`,
  assumable ONLY by the portal `lambda_exec` role, `max_session_duration` 3600.
  Its identity policy is the full SSM-connect capability; every vend is NARROWED
  at `sts:AssumeRole` time by an inline session `Policy`. This relies on STS
  session-policy semantics: the effective session = INTERSECTION of the role's
  identity policy and the inline policy (a session policy can only narrow, never
  widen). Verified against the IAM UserGuide.
- **Endpoint** (`lambda/ssm_credentials/handler.py`, route
  `POST /api/session/{requestId}/ssm-credentials`): authN via Cognito JWT; authZ
  = ownership (caller owns the request, or is a Racker) else 403 — fail-closed
  tenant isolation (ADR-0021); status must be ACTIVE. The inline policy is
  COPIED from `passportCLIPolicyDocument` (not invented): `ssm:StartSession` on
  exactly the two AWS session-doc ARNs + the one target instance ARN, plus
  tag-conditioned Terminate/Resume. `RoleSessionName` = identity-derived
  username (CloudTrail attribution). `DurationSeconds` = min(remaining TTL,
  3600), floored at the STS 900s minimum.
- **Client** (`scripts/passport-connect.sh`) + **proof harness**
  (`scripts/prove-credential-less.sh`).

### Scoping detail that MUST be preserved
AWS-managed session documents (names starting `AWS-`) MUST be referenced with an
EMPTY account id — `arn:<partition>:ssm:<region>::document/AWS-StartPortForwardingSession`
(the `::`). Inserting an account id breaks `StartSession`. This matches
Passport's `arn:aws:ssm:*::document/...` exactly. Instance ARNs use the ec2
namespace for `i-` and the ssm `managed-instance` namespace for `mi-`; any other
prefix is rejected (never emit a wildcard instance, which would defeat scoping).

### Proof hardening — env-only scrubbing is INSUFFICIENT (the real trap)
ADR-0018 says prove it in a credential-scrubbed shell where
`aws sts get-caller-identity` FAILS first. Discovered on this box: unsetting the
four `AWS_*` env vars is NOT enough, because `~/.aws/credentials` has a
`[default]` profile the CLI falls back to. Today that default is expired (so it
happens to fail), but a refresh would make an env-only-scrubbed test FALSE-PASS
on the default profile — silently "proving" nothing. The proof (and the connect
script's tunnel subshell) therefore ALSO repoint `AWS_SHARED_CREDENTIALS_FILE`
and `AWS_CONFIG_FILE` at empty files. Only then is the environment genuinely
credential-less. Verified: scrubbed + isolated → "Unable to locate credentials".
Future sessions: do not "simplify" the proof back to env-only scrubbing.

## Refinements (2026-08-31, later #2) — validity model, 800-53, two-partition

Three refinements after review:

### Validity: 1-12h authorization, <=1h vended creds (and WHY 1h is a hard ceiling)
Passport separates the two clocks and so do we:
- Access-request `Duration`: 1-12h (Passport `accessRequest.go` `min=1,max=12`;
  extendable, also capped at now+12h). This is the AUTHORIZATION window.
- Vended STS creds: 3600s (Passport `passportCLIPolicyDocument` +
  `get_aws_credentials.go` both use 3600). This is the AUTHENTICATOR.

Our vend is capped at 1h and CANNOT be raised: the ssm-credentials Lambda runs
under an assumed execution role and calls `sts:AssumeRole` on the broker — that
is ROLE CHAINING, which AWS hard-caps at 1 hour for CLI/API sessions regardless
of `DurationSeconds` or the role's `max_session_duration`. Requesting >3600
FAILS. A long (e.g. 8h) window is served by RE-VENDING hourly, which is MORE
AC-12 compliant (auto-expiry every hour, re-minted only while window + ownership
hold). DO NOT "fix" a short tunnel by raising the cap — it will throw. The
broker's `max_session_duration=3600` is a documented floor, not the real limit.

### 800-53: no new gaps; one gap partially CLOSED; one small residual logged
- Delivers/strengthens AC-6, AC-6(1) (one instance, two docs, 1h), AC-12
  (expiry), AU-2/AU-3/AU-12 (identity RoleSessionName). No standing creds.
- CLOSES part of AC-6(5): the vend does an INDEPENDENT second authorization at
  connect time — re-validates the caller's `customer_id` claim against the
  target instance's live `Customer` EC2 tag, fail-closed, Rackers exempt. This
  is the exact remediation the gap register named. (Still open for RDP/browser
  paths that don't route through the vend.)
- NEW residual (logged in ARCHITECTURE-WEAKNESSES §2, Low): the broker role's
  own policy is account-wide StartSession; every vend narrows it, and the role
  is assumable only by the portal Lambda, but a policy-less assume path would be
  broad. Production hardening: condition the trust on a session tag, or split
  per-region/tenant broker roles.

### Two-partition (Commercial + GovCloud)
Offering may serve FedRAMP Moderate customers in the COMMERCIAL partition (CONUS
regions us-east-*/us-west-*) as well as GovCloud (us-gov-*, IL4+). The endpoint
derives the ARN partition from the TARGET INSTANCE's region
(`_partition_for_region`: us-gov-* -> aws-us-gov, else aws), so the inline
session policy emits correct ARNs in either partition. Terraform broker ARNs use
`local.partition` (deploy partition). `passport-connect.sh` is partition-agnostic
(aws CLI resolves partition from --region). Verified with unit checks that the
GovCloud policy renders `arn:aws-us-gov:...`. China (aws-cn) intentionally out of
scope.

## Proof scope + bearer-token caveat (2026-08-31, later #3)

VERIFIED end-to-end: deployed the endpoint and, in a credential-scrubbed shell
(`aws sts get-caller-identity` failing), the connect flow vended scoped STS creds
and opened a passwordless SSM+SSH session to one instance. A companion negative
test confirmed the vended creds are DENIED StartSession on a DIFFERENT instance
(instance-scoping works at runtime — AC-6/AC-6(1)).

IMPORTANT scope note so this is not over-claimed: the test REPLAYED a bearer
`access_token` lifted from an already-authenticated browser session; it did NOT
perform the Cognito login/MFA ceremony in the CLI. So we proved the
AUTHORIZATION/VENDING half using a STUB for AUTHENTICATION.

Consequence to design around: the portal identity token is a BEARER token — no
proof-of-possession. Whoever holds it can replay it (any shell, ~1h, no MFA
re-challenge). This is inherent to bearer tokens, not a defect in the vend
endpoint, but it defines a real threat (IA-2, SC-8, SC-23, AC-12) now logged in
ARCHITECTURE-WEAKNESSES §2. The interim `passport-connect.sh --token` is a test
harness; the production client (ADR-0016 Go CLI) MUST perform its own Cognito
auth + MFA and never accept a pre-obtained token. Candidate hardening:
short-lived access tokens, DPoP/mTLS-bound (proof-of-possession) tokens,
anomalous-use monitoring, per-session binding.