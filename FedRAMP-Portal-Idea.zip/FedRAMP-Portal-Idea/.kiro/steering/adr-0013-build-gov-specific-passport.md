---
inclusion: auto
---

# ADR-0013: Build a Gov-Specific Passport (Do Not Reuse Commercial Passport)

Date: 2026-08-27
Status: Accepted

## Context

Production Passport exists and works well (manage.rackspace.com / Janus,
commercial partition). It provides the exact access-request → brokered-CLI →
SSM-session flow we want. The question: should the FedRAMP/gov solution reuse
commercial Passport, or build a gov-specific implementation?

Key constraints:
- Commercial Passport runs in the **commercial partition** under Janus.
  FedRAMP/IL4 workloads require an authorization boundary that commercial
  Passport is not part of. Reaching into the gov/FedRAMP boundary from a
  commercial-partition control plane would violate the boundary.
- GovCloud is a separate partition (`aws-us-gov`) with separate IAM, separate
  endpoints, and no cross-partition trust with commercial. Even if we wanted
  to reuse the commercial service, it cannot natively operate across the
  partition boundary.
- FedRAMP requires the entire access path (identity, brokering, logging,
  data) to sit inside the authorized boundary. A gov-specific build keeps
  everything in-boundary.

## Decision

Build a **gov-specific Passport** — this project (the FedRAMP Portal) — rather
than extending or reusing commercial Passport. It will:

- Live entirely within the FedRAMP/gov authorization boundary (commercial
  partition for the current POC in 675405875014; GovCloud for production).
- Replicate the proven patterns of commercial Passport (access requests,
  CLI-broker per ADR-0012, ephemeral identity-named local users per ADR-0011,
  STS-brokered access) rather than inventing new ones.
- Use gov-appropriate identity (Cognito federated to a gov IdP, or Identity
  Center in the gov partition).

## Consequences

- Clean authorization boundary — nothing crosses from commercial into gov.
- We own the roadmap and can meet FedRAMP/IL4/800-53 controls natively
  (consistent with ADR-0001, AWS-native over third-party).
- We deliberately mirror commercial Passport's UX and patterns so Rackers have
  a familiar experience across partitions, and so we benefit from lessons
  already proven in production.
- Duplication of effort vs. commercial Passport is accepted as the cost of
  boundary isolation.
- Production target is GovCloud; the current single-account commercial POC
  (per ADR-0002) proves the pattern before the GovCloud port.

## Relationship to other ADRs

- ADR-0001 (AWS-native over third-party): consistent — we build, not buy.
- ADR-0011 (govern the local principal): the access model this gov Passport implements.
- ADR-0012 (CLI-broker access pattern): the connection mechanism, mirroring commercial Passport's `passport connect` CLI.
