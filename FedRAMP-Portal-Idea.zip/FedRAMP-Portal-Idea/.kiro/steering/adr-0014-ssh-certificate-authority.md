---
inclusion: auto
---

# ADR-0014: SSH Certificate Authority for Passwordless, Attributed Linux Access

Date: 2026-08-27
Status: Accepted

## Context

Our POC authenticates ephemeral Linux users with a generated password stored
in DynamoDB and displayed in the portal. This violates SC-28 (plaintext
credential at rest) and IA-5 (authenticator handling), and the password is a
weak, human-copied secret.

Study of production Passport (`Chappies-Tools/passport`) revealed a clean,
proven mechanism we should port: an **SSH Certificate Authority**. The client
generates a keypair, sends its PUBLIC key to a signing endpoint, and receives
a short-lived signed SSH certificate. No password is ever created, stored, or
transmitted. Reference implementation:
- Client: `cli/keymaker/keymaker.go`, `cli/sign.go`
- Server CA: `internal/cacertificate/signer.go`

## How it works (ported design)

**CA key (one-time setup):**
- Generate an SSH CA keypair. Store the PRIVATE key in AWS Secrets Manager
  (KMS-encrypted). The PUBLIC key is distributed to instances.
- Instances configure sshd: `TrustedUserCAKeys /etc/ssh/passport_ca.pub`.
  Any certificate signed by the CA, for a valid principal, within its validity
  window, is accepted — no per-session authorized_keys manipulation.

**Per-connection signing (replaces password provisioning):**
1. Client (CLI or portal-issued helper) generates an SSH keypair locally
   (ed25519 preferred; RSA >= 4096). Private key never leaves the client.
2. Client sends its PUBLIC key + identity + access-request-ID to the signing
   Lambda/endpoint.
3. Signing endpoint (holding the CA private key) issues an `ssh.Certificate`:
   - `CertType: UserCert`
   - `ValidPrincipals: [username, accessRequestID]` (binds cert to the user)
   - `ValidBefore`: now + min(session TTL, 3600s) — max 1 hour
   - `KeyId: passport_<username>_<timestamp>` — THIS is the accounting stamp;
     it appears in the instance's sshd auth logs, attributing the login to the
     real identity
   - Extensions: permit-pty, permit-port-forwarding, permit-agent-forwarding
4. Client uses the cert to SSH in — passwordless.

**Key validation:** reject RSA < 4096 bits, ed25519 != 256 bits.

## Decision

Port the SSH CA into our architecture:
- **CA private key** in Secrets Manager (KMS CMK), never leaves the signing Lambda.
- **New signing Lambda** (`sign_key`) behind an authenticated API route
  (`POST /api/sign`), using the Python `cryptography` library to produce
  OpenSSH user certificates (or a Go Lambda if Python SSH-cert support is
  insufficient — evaluate during implementation).
- **Instances trust the CA**: the provision step (or instance bootstrap /
  golden AMI) installs `passport_ca.pub` and sets `TrustedUserCAKeys`. The
  ephemeral user is still created (per ADR-0011, identity-named) but with NO
  password — the CA cert authorizes login.
- **Linux drops passwords entirely.** Windows RDP still needs a password or
  directory-join (tracked separately; SSH CA does not apply to RDP).

## Consequences

- Eliminates SC-28 plaintext-password weakness for Linux.
- Satisfies IA-5: authenticator is a short-lived (<=1h) cert, not a shared password.
- Native accounting: sshd logs the cert `KeyId` = identity (AU-2/AU-3).
- Time-boxed by cert validity, independent of the session TTL loop.
- No per-session authorized_keys race conditions — the CA trust is static.
- Requires: CA key management + rotation, instance-side trust config, a signing
  endpoint, and client-side keygen. Larger build than the password approach,
  but retires multiple weaknesses at once.
- The `provision_user` Lambda no longer sets a password; it ensures the
  identity-named user exists (and, if not using a golden AMI, installs CA trust).
- CONFIRMED: Python `cryptography` >= 40.0 provides `SSHCertificateBuilder`
  (native OpenSSH user-certificate creation + signing). The signing Lambda
  stays Python, consistent with our stack. `SSHCertificateBuilder` maps 1:1
  onto the Go `signer.go`: set type=user, valid_principals, validity window,
  key_id, extensions, then sign with the CA private key. (`sshkey-tools` on
  PyPI is a fallback if higher-level helpers are wanted.)

## Authorization window vs. authenticator lifetime (reconnect model)

Two distinct TTLs, mirroring production Passport:
- **Access request TTL (authorization)**: 1/4/8/12 hours. How long the user is
  authorized and the identity-named OS user exists. Stored on the DynamoDB record.
- **SSH certificate lifetime (authenticator)**: capped at 1 hour by sign_key.

The user may **reconnect any number of times** within the authorization window
by signing a fresh certificate (portal "Generate a new certificate" button, or
`passport connect` re-invocation). Long-lived authorization, short-lived
authenticators — the certs rotate, the access window persists. Cleanup runs at
access-request expiry, not per-connection.

## Staging

1. Stand up CA key (Secrets Manager) + instance trust config.
2. Build signing endpoint + Lambda.
3. Update provision to passwordless + ensure CA trust present.
4. Update client/SessionDrawer to generate keypair, call sign, use cert.
5. Remove password generation/storage/display for Linux (keep for Windows).
6. Support reconnect: re-sign a fresh cert within the access window (done —
   SessionDrawer "Generate a new certificate"). Access TTL raised to 12h max.
