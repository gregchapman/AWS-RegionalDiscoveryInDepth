---
inclusion: auto
---

# ADR-0015: Language Choice — Go for Crypto/CLI, Python for CRUD Glue

Date: 2026-08-27
Status: Accepted

## Context

The POC was built in Python (Lambdas) + TypeScript/React (portal). Python was
the fastest path to prove the flow. As we move toward production standard
(ADR-0013: build a gov-specific Passport mirroring the commercial one), the
question arose: is Python the most performant and reliable choice, especially
for the security-critical SSH Certificate Authority (ADR-0014)?

Findings:
- Production Passport is entirely **Go** — HTTP API (ECS Fargate), CLI, and
  Lambdas. Its SSH CA signer (`internal/cacertificate/signer.go`) is
  battle-tested and already solves subtle interop problems (e.g. hand-rolled
  RSA-SHA1 certificate signing for older sshd, borrowed from HashiCorp Vault).
- Go's `golang.org/x/crypto/ssh` is the reference-grade, decade-proven library
  for SSH certificate signing, exposing `AlgorithmSigner` for precise control
  over signature hash algorithms.
- Python `cryptography`'s `SSHCertificateBuilder` is newer (2023), heavier on
  Lambda (compiled C extension layer, larger cold start), and its control over
  RSA signature hashing for SSH certs is less certain — a potential interop
  landmine with older RSA-host sshd.
- Rust was evaluated: best-in-class on memory safety + performance + the
  federal "memory-safe language" narrative. But it diverges from production
  Passport (no code/pattern sharing, cannot port signer.go), the team's stated
  skills are "AWS + Go + React" (not Rust), and Rust's SSH-cert ecosystem is
  younger. Adopting Rust would be a whole-platform strategic bet, not a
  component choice.

## Decision

- **Go** for the security-critical and CLI components:
  - The SSH CA signing Lambda (port `signer.go` near-verbatim).
  - The `passport connect` CLI (ADR-0012), matching production Passport.
  Rationale: parity with production Passport (portable/shareable code, proven
  patterns, RSA-SHA1 interop already solved), team fluency, mature SSH-cert
  library, and excellent Lambda cold-start with tiny static binaries.
- **Python** retained for the CRUD/glue Lambdas (list_accounts, list_instances,
  create_access_request, get_session_status, list_sessions, terminate_session,
  provision_user, cleanup_user). These are I/O-bound AWS-API glue where the
  language is not the bottleneck and boto3 is first-class.
- **TypeScript/React** for the portal (unchanged).
- **Rust** considered and DEFERRED. Revisit only if RGS decides to standardize
  the gov platform on memory-safe languages as a strategic/compliance posture.

## Consequences

- The Python `sign_key` Lambda built under ADR-0014 is INTERIM. It proves the
  flow but should be rewritten in Go before production, porting `signer.go`.
  This retires the RSA-SHA1 interop risk and removes the cryptography layer /
  cold-start overhead.
- Introduces Go to the toolchain (build pipeline, CI). Acceptable — it matches
  production Passport and the team already uses Go.
- Mixed-language Lambda estate (Go + Python). Acceptable and common; each
  component uses the right tool.
- When/if the `passport connect` CLI is built, it is Go from the start.

## Migration note

The Python sign_key implementation and crypto layer remain in place for the
POC. Track the Go rewrite of sign_key (and the CLI) as production-hardening
work items. No functional behavior changes in the port — same cert shape
(UserCert, ValidPrincipals, KeyId, <=1h TTL, permit-pty/port-forwarding/
agent-forwarding extensions).

## IMPLEMENTED — Go CLI built (2026-08-31)

The Go CLI now exists in `cli/` (built + vetted + cross-compiled; live MFA
connect pending publish, SoD). Language choices held up in practice:
- Go for the CLI + crypto: ephemeral ed25519 keygen + SSH cert handling via
  golang.org/x/crypto/ssh (ssh.NewCertSigner), SSM via aws-sdk-go-v2, Cognito
  SRP+MFA via aws-sdk-go-v2/cognitoidentityprovider + alexrudd/cognito-srp.
  ed25519 (not RSA) means the OpenSSH<7.9 RSA-SHA1 signer workaround from
  Passport's getCertSigner was NOT needed — simpler than the reference.
- Toolchain: Go 1.24.5 (current aws-sdk-go-v2 requires >=1.24), GOTOOLCHAIN=local
  pinned for reproducible/audited builds. CGO_ENABLED=0 static binaries.
- Python sign_key Lambda (the server-side CA signer) remains as-is; the CLI is
  the CLIENT. A Go rewrite of sign_key is still a separate future item; the
  cert shape is unchanged and interoperates with the deployed Python CA.
