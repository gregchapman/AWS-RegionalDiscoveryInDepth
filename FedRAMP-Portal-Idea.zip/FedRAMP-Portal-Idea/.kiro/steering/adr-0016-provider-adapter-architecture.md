---
inclusion: auto
---

# ADR-0016: Provider/Adapter Architecture for Multi-Target, Multi-Identity Access

Date: 2026-08-27
Status: Accepted

## Context

The portal began as AWS SSH/RDP access. But production Passport already
supports "AWS, GCP, and Azure" (its README) and the platform comparison lists
multi-cloud + VCenter as a Home-Grown strength. RGS's real need is a SINGLE
access plane spanning many targets and identity sources:

- Connection targets: AWS EC2 (Linux/Windows), GCP, Azure VMs, VCenter/vSphere,
  AD-joined hosts, on-prem.
- Identity sources: Cognito, IAM Identity Center, Entra ID (Azure AD), customer
  SAML/OIDC IdPs, Active Directory.

If the Go rewrite hard-codes AWS/SSM/SSH-CA assumptions, every new target is a
rewrite. If it is built around clean interfaces, every new target is an additive
plug-in behind the same portal, CLI, and audit plane.

Production Passport already encodes this seam: `keymaker.go` forks on
`AccessRequest.Type` (AWS vs. non-AWS, `SignKey` vs. `SignKeyV3`). Mirroring
Passport (ADR-0013) means inheriting the cross-platform design, not inventing it.

## Decision

Structure the rewrite as two cloud-agnostic planes plus two pluggable
interface families.

**Cloud-agnostic planes (never change per target):**
1. Identity/authorization plane — access requests, portal, CLI (ADR-0012),
   audit/accounting, "who may reach what, for how long."
2. Orchestration + audit — request lifecycle, session correlation, CloudTrail/
   session logs.

**Pluggable interfaces (target/identity specific):**
1. `IdentityProvider` — abstracts the IdP / identity source. Implementations:
   Cognito, Identity Center, Entra ID, customer SAML/OIDC, AD. Concerns:
   authenticate the human, emit an identity token, supply role/group claims.
2. `ConnectionProvider` — abstracts a connection target type. One implementation
   per target. Common verbs (roughly):
     RequestAccess(identity, target, duration)
     Provision()            // create/enable the local principal, install trust
     IssueCredential()      // SSH cert | Kerberos ticket | AAD token | vSphere session
     Connect()              // SSM tunnel | IAP | Azure Bastion | network proxy
     Cleanup()              // remove/disable principal, revoke
   Implementations: aws-ec2 (Linux SSH-CA + Windows), gcp (OS Login/IAP),
   azure-vm (AAD/Bastion), vsphere (SSO/proxy), ad-host (Kerberos/smartcard).

Key separation: **identity source and connection target are DIFFERENT
interfaces.** Entra ID can be the front-door IdP while an AD-joined VCenter host
is the connection target — different concerns, independently pluggable.

The SSH Certificate Authority (ADR-0014) is the AWS-EC2 provider's
`IssueCredential` implementation — ONE credential mechanism among many, not a
universal assumption.

## First implementation

Implement only the **aws-ec2 ConnectionProvider** (SSH-CA + SSM, what we have)
and one **IdentityProvider** (Cognito) initially. But define the interfaces
first so later targets are additive.

## Consequences

- New targets (GCP, Azure, VCenter, AD hosts) are new `ConnectionProvider`
  implementations — no portal/CLI/audit changes.
- New identity sources (Entra ID, customer IdPs) are new `IdentityProvider`
  implementations.
- The Go rewrite must lead with these interfaces, even for a single provider.
  A little extra structure now; enormous leverage later.
- Positions the gov Passport as RGS's universal access plane, not a point tool —
  the strategic value in the platform comparison ("multi-cloud via existing
  Passport support").
- CLI dispatches on target metadata (mirroring Passport's AccessRequest.Type
  fork) to select the provider.
- Credential mechanisms generalize: `IssueCredential` returns whatever the
  target needs (SSH cert, Kerberos TGT, OAuth token, vSphere session cookie).

## Relationship to other ADRs

- ADR-0012 (CLI-broker): the CLI is the cloud-agnostic front door that dispatches to providers.
- ADR-0013 (build gov-specific): mirror Passport's already-multi-cloud design.
- ADR-0014 (SSH CA): the aws-ec2 provider's credential mechanism.
- ADR-0015 (Go): the language in which these interfaces are defined.

## IMPLEMENTED — Go CLI built to this shape (2026-08-31)

The interfaces are no longer just a plan; they exist in code under `cli/` (Go
module `github.com/rackspace/fedramp-portal/cli`, structured per this ADR):

- `internal/identity` — `Provider { Name(); Authenticate(ctx) (*Token, error) }`.
  First impl `internal/identity/cognito`: real USER_SRP_AUTH + SOFTWARE_TOKEN_MFA
  (SRP via github.com/alexrudd/cognito-srp/v4). The CLI authenticates the human
  itself; it does NOT accept a handed-over token (this is the ADR-0012
  proof-scope requirement, and it closes the bearer-replay ORIGIN).
- `internal/connection` — `Provider { Kind; RequestAccess; AwaitReady;
  IssueCredential; VendCredential; Connect; Cleanup }`. First impl
  `internal/connection/awsec2`: the SSH-CA (ADR-0014) `IssueCredential` + SSM
  tunnel `Connect`, ported from Passport ssmtransport.go, using ONLY portal-
  vended static creds (ADR-0018 isolation — never LoadDefaultConfig).
- Identity source and connection target remain DIFFERENT interfaces; the
  `connect` command dispatches on `Target.Kind` (only `aws-ec2` today).

Interfaces were defined FIRST (per this ADR) even though there is one impl each;
adding aws-eks / vsphere / azure-vm or Identity Center / Entra means a new
package implementing the interface, not a CLI reshape. Distribution: cross-
compiled (linux/darwin/windows), checksum-verified install (CM-5/SI-7). Built +
vetted + smoke-tested; live MFA connect pending publish (SoD). See todo.md
"later #5".
