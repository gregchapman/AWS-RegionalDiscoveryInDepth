---
inclusion: auto
---

# ADR-0017: Environment Portability by Configuration, Not Code

Date: 2026-08-27
Status: Accepted

## Context

The current build runs in a single commercial account (675405875014) using
regions-as-boundaries (ADR-0002) to simulate multi-tenant isolation. Real
deployments differ:

- Standard Rackspace: real AWS Organizations, many accounts, federated to
  Rackspace Identity (Janus), commercial partition.
- FedRAMP: GovCloud partition (aws-us-gov), separate accounts per boundary,
  federated to an agency IdP (PIV/CAC), FedRAMP-mandated in-boundary security
  services.

HARD REQUIREMENT (owner directive): moving from the single-account model to
these more representative environments must be achievable by **changing
Terraform variable values only** — NOT by writing additional code. We must not
incur development work simply because we began modeling patterns in a smaller
environment.

## Decision

Design every layer and component so that environment differences are expressed
as **configuration inputs**, never as branching code paths that only exist for
one environment. Specifically:

1. **No hard-coded account IDs, ARNs, regions, partitions, or endpoints.**
   Derive from `data.aws_caller_identity`, `data.aws_partition`,
   `data.aws_region`, and variables. (Partition matters: commercial `aws` vs.
   GovCloud `aws-us-gov` — never hard-code `arn:aws:`.)

2. **Environment is a variable set.** Each layer takes variables that fully
   describe the target: partition, region(s), org-vs-account Identity Center
   mode (already done in ADR: `instance_type`), identity provider selection,
   security-service enable flags (already done: `enable_guardduty` etc.),
   target regions, bucket suffixes. A new environment = a new `*.tfvars` file.

3. **Pluggable selections are variables, not forks.** Per ADR-0016, the
   IdentityProvider and ConnectionProvider are interfaces. Which implementation
   is active is a configuration value (e.g. `identity_provider = "cognito" |
   "janus" | "gov-idp"`), resolved at deploy time — not a code change.

4. **Partition-safe ARNs everywhere.** Use `arn:${data.aws_partition.current.partition}:...`
   in every policy/ARN construction. This alone is what lets the same code
   apply to GovCloud unchanged.

5. **No environment-specific resources baked into shared modules.** If a
   resource only exists in one environment, gate it with a boolean variable
   (like the security-baseline enable flags), don't fork the module.

## Consequences

- Promoting model -> commercial-org -> GovCloud is a tfvars swap + provider
  credentials swap, plus the out-of-band one-time steps that are inherently
  environmental (enabling Identity Center org instance, standing up the state
  bucket, running init-ssh-ca.sh). Those are operational steps, not code.
- Requires discipline in code review: reject any hard-coded account/region/
  partition/ARN; reject any `if environment == "x"` logic that changes behavior
  structurally rather than via config.
- Some environmental facts still require out-of-band setup (e.g. GovCloud
  account provisioning, agency IdP federation trust, org enablement). These are
  documented as prerequisites, not code. The line: anything that is
  *infrastructure we define* is variable-driven; anything that is *an external
  trust/enablement* is a documented prerequisite.
- The Go rewrite (ADR-0015/0016) inherits this rule: provider selection and all
  endpoints/regions/partitions are configuration, injected — never compiled-in.

## Retro-fixes needed to comply (tracked)

Current code has hard-coded values that violate this ADR and must be
parameterized before we claim portability:
- Hard-coded account ID `675405875014` in backend.tf keys, bucket names, and
  some resource names.
- Hard-coded `arn:aws:` prefixes in IAM policies (must become
  `arn:${partition}:`), which would break in GovCloud.
- Hard-coded region `us-east-1` in several clients/handlers (should derive or
  be injected).
- CloudFront URL, pool IDs, etc. already flow via remote_state/outputs (good).

These are remediation items, not a rewrite — parameterize in place.

## Relationship to other ADRs

- ADR-0002 (regions as test boundaries): the model this ADR promotes FROM.
- ADR-0008 (self-documenting tfvars): each environment is a documented tfvars file.
- ADR-0009 (remote state): cross-layer values already flow by config.
- ADR-0013 (gov-specific build): portability is what makes the same codebase
  serve commercial and gov by config.
- ADR-0016 (provider architecture): provider selection is configuration.
