---
inclusion: auto
---

# ADR-0018: Credential Context — Deploy WITH the Profile, Test WITHOUT It

Date: 2026-08-27
Status: Accepted

## Context

The `personal-faws` AWS profile is a set of **long-lived IAM access keys in the
owner's own account (675405875014)**. It is NOT a temporary/assumed-role
credential and it DOES NOT expire. This single fact cuts both ways and cost us
real debugging time, so it is recorded here as a hard rule.

**How it HELPED:** Terraform needs real administrative credentials to deploy
every layer (00–05). `personal-faws` provides them. All successful deployments
depend on this profile being the active AWS context.

**How it HURT (the trap):** The whole point of the portal is to broker access
for a user who has **no AWS CLI credentials of their own** (ADR-0012: the
broker holds the AWS identity; the customer/Racker does not). When we tested the
SSM tunnel to "emulate a customer with no creds," the ambient `personal-faws`
credentials in the shell environment were silently satisfying the AWS calls
(`aws ssm start-session`, etc.). We believed the passwordless / broker path was
working, when in reality an admin identity was quietly doing the work in the
background. The test was green for the wrong reason. The creds were "being
consumed" without us realizing it.

Because the keys never expire, nothing ever forced the failure that would have
revealed the leak. A temporary credential would have expired and exposed the
dependency; long-lived keys hid it indefinitely.

## Decision

Treat the two activities as having **opposite** credential requirements, and
make that explicit in every runbook, script, and test procedure:

1. **DEPLOYMENT requires `personal-faws`.**
   - `AWS_PROFILE=personal-faws` (or equivalent env) MUST be the active context
     for any `terraform apply`, `init-ssh-ca.sh`, S3 sync, CloudFront
     invalidation, or other admin/provisioning action.
   - This is expected and correct. Deployment is an administrative act.

2. **CUSTOMER/BROKER-PATH TESTING requires the ABSENCE of `personal-faws`.**
   - Any test that claims to validate the no-CLI-credential user experience
     (SSM tunnel via the portal, cert-based SSH, RDP over the broker) MUST run
     in a shell with **no ambient AWS credentials at all** — no `AWS_PROFILE`,
     no `AWS_ACCESS_KEY_ID`/`AWS_SECRET_ACCESS_KEY`, no default profile that
     resolves to `personal-faws`.
   - If the connection still succeeds with credentials scrubbed, the broker path
     is genuinely working. If it fails only when creds are scrubbed, we have
     found a hidden dependency — that is the signal we were missing before.

3. **Verify the credential context before trusting any broker-path test.**
   - Before such a test: `env | grep -i aws` should show nothing relevant, and
     `aws sts get-caller-identity` should FAIL (or be run in a clean shell where
     the AWS CLI is not even configured). Only then does a successful tunnel
     prove what we think it proves.

## Consequences

- Runbooks and `todo.md` must label each step as DEPLOY (needs profile) or
  BROKER-TEST (must scrub profile). The SSH CA deploy sequence is DEPLOY; the
  final "test the cert flow as a credential-less user" step is BROKER-TEST and
  must be run in a scrubbed shell.
- Recommended pattern for broker-path testing: a dedicated clean shell, e.g.
  `env -u AWS_PROFILE -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY -u AWS_SESSION_TOKEN bash`
  and confirm `aws sts get-caller-identity` fails before proceeding. Better yet,
  test from a machine/container that has never had the CLI configured.
- The eventual Go `passport connect` CLI (ADR-0012/0015) must be tested the same
  way: it should broker the connection using ONLY the token it receives from the
  portal/API, never ambient AWS creds. A scrubbed-shell test is the acceptance
  criterion.
- `403 Server authentication failed` on `start-session` during a DEPLOY-context
  action still means a credential/profile problem (creds missing when they
  should be present). During a BROKER-TEST, a `403`/credential failure from the
  raw AWS CLI is EXPECTED — the connection must instead succeed through the
  broker, not through ambient creds. Do not "fix" a broker test by adding the
  profile back; that re-hides the bug.

## Relationship to other ADRs

- ADR-0012 (CLI-broker access, no user AWS creds): this ADR is how we actually
  verify that property holds instead of assuming it.
- ADR-0017 (portability by config): related discipline — don't let the
  convenience of the local environment mask a dependency that won't exist in the
  target environment.
