---
inclusion: auto
---

# ADR-0019: Partition-Intersection Service Palette + Internet-Facing Boundary (no CloudFront for IL4)

Date: 2026-08-28
Status: Accepted

## Context

Two related realizations forced an architectural correction to the portal's
internet-facing tier (layer 02-portal-hosting), which the POC built on
CloudFront + S3 + WAF(CLOUDFRONT scope).

**1. CloudFront cannot be inside a GovCloud / IL4 authorization boundary.**
CloudFront is not a GovCloud-partition service. AWS's own guidance is explicit:
CloudFront is not available in AWS GovCloud (US); you may only run CloudFront in
the standard (commercial) partition pointed at GovCloud origins. That pattern
places the internet-facing front door — TLS termination, request/response
handling, WAF inspection, and access logging — in **commercial-partition,
globally-distributed edge infrastructure**, outside the GovCloud boundary and
outside CONUS-only, US-person-administered facilities. GovCloud regions are
administered exclusively by US citizens for ITAR/EAR; CloudFront's global PoPs
cannot make that guarantee, and `geo_restriction` only limits which viewers may
request — it does not control which PoP (or which country's infrastructure)
serves and terminates the connection.

For a system carrying IL4/CUI, that is a boundary violation, not a
configuration nuance. Relevant 800-53 / SRG controls:
- **SC-7 / SC-7 enhancements — Boundary Protection.** A commercial-partition
  edge terminating in-boundary traffic breaches the defined authorization
  boundary.
- **SC-8 / SC-8(1) — Transmission Confidentiality/Integrity.** Where TLS
  terminates determines where plaintext exists; terminating at a commercial
  edge puts the confidentiality boundary outside GovCloud.
- **SA-9 — External System Services.** Commercial CloudFront is external to the
  GovCloud boundary; it cannot be inherited into an IL4 boundary.
- **AU-2/AU-9/AU-12 — Audit.** CloudFront access logs are audit records
  produced and stored by commercial-partition infrastructure — audit data
  leaving the boundary.
- **PE-family + CUI/DFARS 252.204-7012 + DoD SRG IL4.** Physical location and
  personnel handling CUI must meet CONUS / US-person controls. Global edge
  cannot satisfy this.

**2. The service palette must be the INTERSECTION of commercial and GovCloud,
not the union.** (Owner directive, 2026-08-28.) Because we test in the
commercial partition but must serve IL4 from GovCloud, we restrict ourselves to
services, resources, and configurations that exist and behave **identically in
both partitions**. This yields one application pattern and one authorization
posture that runs unmodified in either partition — GovCloud for IL4, commercial
for customers who need only CONUS-class restrictions (FedRAMP Moderate without
IL4). Customer placement becomes a deployment choice, never an architecture
choice. There are NO partition-specific service selections or forks.

This strengthens ADR-0017: portability-by-config assumed the same code ports by
swapping tfvars. That holds ONLY if every service used exists in the target
partition. CloudFront is the first service that fails the intersection test, so
layer 02 is the one place "port by config" breaks — it must be REPLACED, not
ported.

## Decision

1. **Prohibit CloudFront (and any commercial-only edge service) anywhere in the
   product's authorized path.** CloudFront fails the partition-intersection test
   and cannot sit in an IL4 boundary. Do not use CloudFront, Lambda@Edge,
   CloudFront Functions, or any commercial-partition global edge service in the
   application pattern — in EITHER partition.

2. **Partition-intersection service palette is a hard design rule.** A service
   is permitted only if it is available and behaves equivalently in BOTH
   `aws` (commercial) and `aws-us-gov` (GovCloud). When in doubt, verify against
   the AWS GovCloud service-differences documentation before adopting a service.
   Reject, in review, any resource that exists in only one partition.

3. **Internet-facing front door = API Gateway (REGIONAL) + REGIONAL WAF + ACM
   + Shield + Route 53.** GovCloud-native, region-scoped, CONUS-bound, and
   identical in both partitions:
   - **Amazon API Gateway, endpoint type = REGIONAL** as the single front door
     for BOTH the SPA and the API. Chosen over ALB because the access API is
     already HTTP API Gateway v2 — unifying gives ONE boundary component, one
     WAF association, one TLS termination point, one access-log stream, which is
     the cleanest SC-7 boundary to authorize. (ALB + REGIONAL WAF + ACM is a
     valid fallback but splits SPA-vs-API into two front-door patterns.)
   - **RESOLVED (2026-08-28): ONE API Gateway, ONE custom domain (Option A),
     not two.** The SPA and the `/api/*` routes share a single regional API
     Gateway on a single custom domain. Rationale: this product is one team, one
     SPA consuming its own API, one deploy cadence — the two-gateway pattern's
     benefits (independent teams/cadences, API consumed by external clients,
     divergent scaling) do not apply. Single-gateway is SAME-ORIGIN, so CORS
     largely disappears (less attack surface, less to misconfigure), and it is
     the smallest SC-7 boundary. The cost — tighter coupling between SPA hosting
     (was layer 02) and the API (layer 03) — is a convenience/layering tradeoff
     (ADR-0009), not a compliance one, and is worth trading for a smaller
     same-origin boundary on an IL4 system.
   - **HARD CONSTRAINT — endpoint type REGIONAL, never EDGE-OPTIMIZED.**
     Edge-optimized API Gateway endpoints (and edge-optimized custom domain
     names) are fronted by an AWS-managed **CloudFront** distribution under the
     hood — that silently reintroduces the exact commercial-partition global
     edge this ADR bans. Use REGIONAL endpoints AND regional custom domain names
     only. This is a review checklist item.
   - **WAFv2 with `scope = "REGIONAL"`** associated to the API Gateway stage
     (not CLOUDFRONT scope).
     **CORRECTION (2026-08-28, verified at deploy time):** WAFv2 CANNOT be
     associated to an API Gateway **HTTP API (v2)**. AWS's supported regional
     WAF targets are: API Gateway **REST API (v1)**, ALB, AppSync, Cognito user
     pool, App Runner, Amplify, Verified Access. Associating the v2 stage ARN
     (`arn:...:/apis/<id>/stages/<name>`) fails with
     WAFInvalidParameterException. Since the chosen front door is HTTP API v2,
     the front door currently has **NO WAF** (the ACL exists but is
     unassociated). This is an OPEN SC-7 gap (tracked in
     ARCHITECTURE-WEAKNESSES.md). Options to close it: (a) front the HTTP API
     with an **ALB** (a supported WAF target) and put the REGIONAL WAF there —
     this is the strongest reason to revisit the ALB-vs-API-GW choice for the
     production/IL4 tier; (b) use a REST API (v1) for the WAF-bearing edge;
     (c) interim: rely on Cognito JWT auth + API Gateway throttling + Shield
     Standard. Do NOT reintroduce CloudFront. The earlier text below claiming
     "one WAF association" on the API Gateway was based on an incorrect
     assumption and is superseded by this correction.
   - **ACM (regional) certificate** on the regional custom domain.
   - **Route 53 public hosted zone** (public authoritative DNS available in
     GovCloud since 2025-04; alias targets include API Gateway, ALB/NLB/CLB, S3
     website endpoint, VPC endpoint — CloudFront is NOT among them, consistent
     with this ban).
   - **AWS Shield** for DDoS resilience IN-BOUNDARY: Shield Standard is
     automatic at no cost; Shield Advanced (opt-in) adds L7 auto-mitigation +
     SRT if the ATO wants it. This is the intersection-safe replacement for the
     "global/anycast edge" instinct — resilience at the regional front door, not
     at a global PoP layer.
   All TLS termination, WAF inspection, DDoS mitigation, and access logging
   occur inside the region — CONUS, US-person-administered — satisfying
   SC-7/SC-8/AU/PE.

   **SPA DELIVERY MECHANISM [RESOLVED via design proof, 2026-08-28].**
   How the single HTTP API v2 serves the static SPA from a private S3 bucket:
   - Design-proof finding (AWS docs): the clean "API Gateway is an S3 proxy"
     pattern is a **REST API (v1)** feature (generic AWS-service integration to
     S3 GetObject). Our API is **HTTP API (v2)**. HTTP API v2 supports Lambda-
     proxy, HTTP-proxy, and **first-class** AWS-service integrations — but the
     first-class list is a curated set of subtypes (SQS/SFN/EventBridge/etc.);
     **S3 GetObject is NOT among them.** So v2 cannot natively proxy S3.
   - Options weighed: (a) migrate the whole API to REST v1 to get native S3 proxy
     — large rewrite of layer 03, higher per-request cost, no; (b) run REST-for-SPA
     + HTTP-for-API — that's TWO gateways, breaks the single-origin decision, no;
     (c) keep HTTP API v2 and serve the SPA via a lightweight **Lambda proxy**
     on the catch-all route — yes.
   - DECISION: **(c).** A small Lambda on `$default` streams the requested asset
     from the private S3 bucket and returns `index.html` (HTTP 200) for any path
     that is not a real asset — the SPA client-side-routing fallback (replaces
     CloudFront custom-error-responses). `/api/*` routes are unchanged. One HTTP
     API, one custom domain, SAME-ORIGIN (CORS eliminated).
   - Cost/tradeoff: static asset requests traverse a Lambda (vs. a CDN edge). For
     an internal, low-traffic access portal this is negligible; it is a common
     serverless-SPA pattern. Intersection-safe (Lambda + HTTP API v2 + S3 are in
     both partitions, identical behavior) and inheritance-consistent (ADR-0020).
   - Route 53 + ACM placement [RESOLVED, 2026-08-28]: layer 03 OWNS the front
     door (custom domain on its HTTP API), so the ACM (regional) cert + Route 53
     public hosted zone live in the REBUILT layer **02** (which is being gutted
     of CloudFront anyway), and 03 consumes them via remote state. This honors
     the layering convention (ADR-0009): 02 < 03 (dependencies point backward),
     split-by-resource-kind (02 = hosting substrate: SPA asset bucket + zone +
     cert), no renumber, no new layer, directory name `02-portal-hosting` kept
     to avoid state-key churn. The Route 53 ALIAS record pointing at 03's API
     Gateway is created IN layer 03 (only 03 knows its own API GW target),
     written into the zone it reads from 02 — normal cross-layer behavior.
   - Domain [RESOLVED for POC, 2026-08-28]: **`takahe.click`** (host
     `portal.takahe.click`). `.click` is the cheapest Route 53-registrable,
     ACM-DNS-validatable TLD (~$3/yr). ACM public certs are domain-validated
     with NO TLD restriction, so any owned domain works. IMPORTANT: this is a
     COMMERCIAL-POC THROWAWAY domain ONLY. The production IL4 system requires a
     `.gov` / agency-issued domain — a separate, later decision. Do not conflate.
   - Domain registration is a PURCHASE + DEPLOY action (greg, per ADR-0018 SoD):
     register `takahe.click` manually once (~$3, Route 53 domain registration is
     us-east-1-only and awkward in TF); Kiro Terraforms everything downstream
     (hosted zone, ACM cert, DNS validation records, alias). Split keeps the
     spend in the owner's hands and the infra reproducible.
   - COST CONTROL (POC wallet): the ONLY recurring charge is the domain
     registration (~$3/yr). Mitigation = set registrar AUTO-RENEW OFF; the
     domain lapses at 1yr and everything downstream becomes moot. The ACM cert
     is FREE and auto-renews harmlessly; the hosted zone is ~$0.50/mo while it
     exists; the private SPA bucket is pennies. Explicit "retire the cert" lever
     (production or early teardown) = remove the ACM validation CNAME — this
     does NOT revoke the live cert (valid to its ~13-month expiry) but makes the
     next managed renewal fail, so the cert self-expires. Do NOT build teardown
     automation for the POC; auto-renew-off + let-it-lapse is sufficient.
   - CREATE-vs-CONSUME (ADR-0017): layer 02 has `manage_dns` / `manage_certificate`
     toggles (default true = POC creates zone+cert). Production sets both false
     and passes `existing_hosted_zone_id` + `existing_certificate_arn` (agency
     domain + IMPORTED cert). ACM does not auto-renew imported certs, so the
     "consume" path inherently satisfies "no AWS-managed renewal in production."

   **REJECTED — AWS Global Accelerator / any "global" fronting.** Global
   Accelerator is a global service (anycast IPs from global PoPs; control plane
   in us-west-2) and is NOT a GovCloud-partition service. It fails the
   intersection test for the same SC-7/SC-8/PE reasons as CloudFront — global,
   non-CONUS, commercial-partition edge. There is NO GovCloud CDN/global-edge
   analog; the compliant answer is "terminate in-region, protect with
   WAF + Shield, distribute via Route 53." An internal, CONUS-bound access
   portal does not need (and must not use) global edge distribution.

4. **Layer 02-portal-hosting is POC-only (commercial) and will be replaced.**
   The current CloudFront+S3+WAF(CLOUDFRONT) layer stays for the commercial POC
   (it still exercises the access model, which is the POC's purpose per
   ADR-0002). It is NOT the production hosting design. A new layer (e.g.
   `02-portal-hosting` rewritten, or `02b`) implementing the Route 53 + ALB/API
   GW + REGIONAL WAF + ACM pattern is the path to the IL4 ATO and is what runs
   in both partitions.

5. **Accept the loss of global CDN/caching.** A single-tenant, per-customer
   internal access portal does not need global edge caching; it needs to stay
   in-boundary. The tradeoff favors the regional pattern decisively for IL4.

## Consequences

- One ATO story and one codebase serve both partitions. A customer who needs
  only CONUS restrictions is hosted in commercial using the SAME pattern; an
  IL4 customer is hosted in GovCloud using the SAME pattern. No exceptions.
- Layer 02 must be re-authored to the Route 53 + ALB/API GW + REGIONAL WAF + ACM
  pattern before any IL4 claim. This is net-new work, not a tfvars swap — the
  one acknowledged exception to ADR-0017's "port by config."
- Every future service adoption must pass the intersection test first. This will
  occasionally rule out a convenient commercial-only service; that is the
  intended cost of a single, partition-agnostic pattern.
- The SPA delivery changes: instead of S3-origin-behind-CloudFront-OAC, the SPA
  is served via ALB→(S3/other origin) or API Gateway. OAC (a CloudFront
  feature) is dropped; origin protection is handled by the regional front door.
- Existing security posture (TLS 1.2 floor, WAF managed rule groups, US
  geo-restriction, access logging) all carry over — they are re-expressed on the
  regional front door rather than on CloudFront.

## Verification basis (2026-08-28 research)

- AWS GovCloud User Guide: CloudFront is not available in GovCloud; use it only
  in standard Regions pointing at GovCloud resources. (Confirms the prohibition.)
- AWS GovCloud User Guide: GovCloud is administered exclusively by US-citizen
  AWS personnel (ITAR/EAR). (Confirms the CONUS/US-person control CloudFront
  edge cannot meet.)
- AWS: Route 53 public authoritative DNS available in GovCloud (2025-04); alias
  targets = API GW, ALB, CLB, NLB, S3 website endpoint, VPC endpoint.
- ELB/ALB, WAFv2, ACM all present in GovCloud (GovCloud service docs).
- AWS API Gateway docs: EDGE-OPTIMIZED endpoints (and edge-optimized custom
  domains) are fronted by an AWS-managed CloudFront distribution; REGIONAL
  endpoints are not. => must pin REGIONAL to avoid reintroducing CloudFront.
- AWS Global Accelerator docs: described as a global service, control plane in
  us-west-2; not a GovCloud-partition service. => rejected (same class as
  CloudFront).
- AWS Shield docs: Shield Standard automatic/no-cost; Shield Advanced adds L7
  auto-mitigation + SRT and now protects ALB. => in-boundary DDoS posture.

Content from AWS documentation was rephrased for compliance with licensing
restrictions.

## Relationship to other ADRs

- Amends **ADR-0017**: portability-by-config now carries the explicit rule that
  the service palette is the commercial∩GovCloud intersection, and names layer
  02 (CloudFront) as the one component that must be replaced rather than ported.
- Reinforces **ADR-0013** (build gov-specific, in-boundary): the front door must
  be in-boundary, not a commercial edge pointed at gov.
- Reinforces **ADR-0006** (zero inbound on instances) and the overall
  boundary-protection posture (SC-7).
- Feeds **ADR-0016** (provider architecture): the ConnectionProvider/hosting
  choices must also honor the intersection rule.
