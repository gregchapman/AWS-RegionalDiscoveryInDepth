---
inclusion: auto
---

# ADR-0020: Prefer AWS-Managed Services to Inherit Control Coverage

Date: 2026-08-28
Status: Accepted

## Context

Under the FedRAMP/DoD-SRG shared responsibility model, AWS's authorized
services carry a large portion of the NIST 800-53 control set as *inheritable*
coverage (physical protection, environmental controls, hypervisor and host
hardening, service-level availability/resilience, and much of the media-,
maintenance-, and personnel-security families). Every control we can inherit
from an AWS-authorized service is a control we do NOT have to build, operate,
evidence, and defend ourselves at assessment time — and it is coverage that is
already assessed and continuously monitored by AWS's own P-ATO.

This is the deeper "why" behind ADR-0001 (AWS-native over third-party). This
ADR makes it a standing decision rule: when protecting our customers and our
ATO, inheriting control coverage from a managed AWS service is the DEFAULT, and
we should not hesitate to take it.

IMPORTANT nuance (shared responsibility): inheritance is never total. AWS
provides the *service/infrastructure* side of a control; we always retain the
*customer-responsibility* side (configuration, IAM/least-privilege, logging
enablement, key policy, data handling). "Inherit the control" means "inherit
AWS's portion AND correctly implement our portion" — it does not mean the
control is satisfied for free. Treating inheritance as total coverage is a
false-assurance trap and is explicitly rejected here.

## Decision

**Default to AWS-managed services so we inherit their FedRAMP Moderate / IL4
control coverage. Do not hesitate.** We only STOP to deliberate when one of two
conditions holds:

1. **There are two genuinely valid service options.** If more than one
   intersection-eligible (ADR-0019) managed service could do the job and both
   are defensible, then it is a real architectural choice: evaluate and record
   the decision (which, why, control/operational tradeoffs). Otherwise, pick the
   managed option and move on.

2. **Inheriting would move our posture NEGATIVE against 800-53 / FedRAMP
   Moderate / IL4.** If adopting the managed service would weaken our control
   story — e.g., it isn't in the authorization boundary, it pushes data or audit
   out of boundary (see ADR-0019), it removes a control we currently satisfy
   more strongly, or it reduces required granularity/attribution — then
   inheritance is OFF the table for that case and we choose the option that
   preserves or improves posture.

If NEITHER condition holds, inherit the managed service without further
deliberation.

### Ordering of tests (how this composes)

1. **Intersection test first (ADR-0019).** The candidate must exist and behave
   equivalently in BOTH commercial and GovCloud. A managed service that fails
   this is not eligible, no matter how much it would let us inherit.
2. **Then the inheritance preference (this ADR).** Among intersection-eligible
   options, prefer the managed service that maximizes inheritable coverage —
   unless condition (2) above (negative posture) applies.
3. **Always implement the customer-responsibility side.** Inheriting AWS's
   portion does not discharge our configuration/IAM/logging/data obligations.

### Layer boundary (reconcile with ADR-0016)

Apply inheritance preference at the **infrastructure / control layer** — KMS,
Shield, WAF, ACM, managed logging (CloudTrail/Config/SSM logging), managed
DB/state — where it is pure upside. Do NOT let it erode the **application /
provider abstraction layer** (ADR-0016): the IdentityProvider/ConnectionProvider
interfaces stay abstracted for portability. Inherit the plumbing; keep the
product logic pluggable. This bounds the lock-in tension that a blanket
"use every managed service" reading would create.

## Consequences

- Fewer controls to self-implement and self-evidence; a smaller System Security
  Plan surface we own; faster path to (and cheaper maintenance of) the ATO.
- Stronger customer protection: AWS's assessed, continuously-monitored coverage
  beats bespoke equivalents for the inheritable portion.
- Review discipline: for any new component, the reviewer asks (a) is there a
  managed AWS service in the intersection that does this? (b) does using it
  weaken any control? If no to (b), use it. Document only when condition (1) or
  (2) triggered.
- Guard against false assurance: every inherited control still needs its
  customer-responsibility configuration implemented and evidenced. A
  control-responsibility matrix (AWS-provided vs. customer-provided) is the
  artifact that keeps this honest — a candidate for the eventual 800-53
  analysis tooling (see Remaining Work automated-testing item).
- Accepted tension: greater reliance on managed services increases lock-in and
  reduces low-level control granularity. Bounded by the layer rule above
  (inherit plumbing, abstract product logic).

## Examples (illustrative, not exhaustive)

- **DDoS:** inherit AWS Shield (Standard automatic; Advanced opt-in) rather than
  building a DDoS story — pure inheritance win (ADR-0019).
- **Encryption at rest:** inherit KMS-backed SSE (SC-28) rather than app-side
  crypto where a managed option exists; we still own key policy and rotation.
- **WAF:** inherit AWS Managed Rule Groups (SC-7/SI) rather than authoring all
  rules; we still own rule selection and tuning.
- **Audit:** inherit CloudTrail/Config/SSM-session logging (AU family); we still
  own retention, protection, and review configuration.
- **Front door:** API Gateway (REGIONAL) inherits AWS's managed edge/API
  protections in-boundary; we own authorizer, WAF association, TLS policy
  (ADR-0019).

## Relationship to other ADRs

- Extends **ADR-0001** (AWS-native over third-party): control inheritance is the
  explicit standing rationale.
- Operates within **ADR-0019** (intersection palette): intersection eligibility
  is a precondition; inheritance preference chooses among eligible options.
- Bounded by **ADR-0016** (provider architecture): inherit at the
  infrastructure/control layer; keep the application/provider layer abstracted.
- Feeds the future **800-53 analysis tooling** (Remaining Work): the
  AWS-vs-customer control-responsibility matrix is the evidence artifact for
  what we inherited vs. what we implement.
