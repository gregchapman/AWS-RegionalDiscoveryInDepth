---
inclusion: auto
---

# ADR-0021: Product Vision, Users, and Scope

Date: 2026-08-28
Status: Accepted

## Context

The design ADRs (0001–0020) capture HOW the system is built and WHY each
technical choice was made, but no single record states WHAT problem the product
solves, WHO it serves, or WHERE it is going. New readers (engineers, auditors,
future sessions) were left to infer the business intent. This ADR fixes that: it
is the durable statement of product vision, users, and scope. Everything else
serves these goals.

## The problem we are solving

Privileged access to cloud workloads in regulated/government environments is
still dominated by a traditional model: **Active Directory + VPN + jump hosts**,
or a server-rendered management portal. That model is pervasive across the
industry and it is a poor fit for cloud, for three reasons:

1. **It will not satisfy FedRAMP 20x cleanly.** The move from Rev 5 to 20x
   emphasizes continuous, automated, machine-readable control evidence. Standing
   VPN tunnels, shared/weakly-bound identities, and jump-host fleets do not
   produce clean per-action attribution or continuous evidence without heavy
   bolt-on effort.
2. **It imposes cost and consumption penalties.** VPN concentrators, jump-host
   fleets, and AD infrastructure cost money to run, patch, and secure — and they
   limit WHICH parts of the cloud can be consumed and HOW they can be managed.
   In effect the traditional model **devalues engagement with the cloud**: the
   access layer becomes the bottleneck, not the enabler.
3. **It widens the attack surface.** A jump host is a server to breach; a VPN is
   a persistent network path that grants broad reachability once entered;
   standing access lingers after it is needed.

We can deliver equal-or-better functionality WITHOUT that baggage — including
**phishing-resistant MFA** — while producing exactly the attributable,
machine-readable evidence a 20x posture wants.

## The offering

A zero-trust, just-in-time, identity-attributed access portal, offered
**exclusively within the Rackspace Government Services (RGS) organization** — a
distinct entity from the rest of Rackspace. It is a gov-specific evolution of
Rackspace Commercial MSP's **Passport V2**: it mirrors Passport V2's proven
patterns (Step Functions + SSM + DynamoDB lifecycle, SSH Certificate Authority)
but is a SEPARATE, in-boundary build for FedRAMP/GovCloud (ADR-0013), not a reuse
of the commercial system. RGS being organizationally distinct is a feature, not
an accident: it keeps the gov authorization boundary clean.

## Users (three first-class perspectives)

This system is NOT a single-audience app. Three perspectives are each
first-class and shape the design:

1. **ATO auditors** — consume **machine-readable compliance evidence**. The
   audit trail (who accessed what, when, how, with what authenticator, and the
   control state of every resource) is a PRODUCT OUTPUT, not a byproduct. This
   directly serves the Rev 5 → 20x transition (continuous, automated evidence).
2. **Rackspace engineers / operators** — manage and support customers, usually
   driven by **ServiceNow tickets**. They need fast, attributable, least-
   privilege access to customer workloads to do support work, with every action
   tied back to a real person and (ideally) a ticket.
3. **Customers** — need a portal to **securely access their own EC2 instances**
   today, expanding over time (see below). A customer must be able to self-serve
   access within guardrails without holding AWS credentials or a VPN client.

## Hard invariant: tenant isolation

**Customer1 must NEVER see anything about Customer2, and vice versa.** This is an
inviolable requirement, not a feature toggle. It governs identity scoping
(customer_id), instance visibility (fail-closed filtering), session ownership
checks, and — in production — hard account/boundary separation. Any change that
could weaken cross-tenant isolation is rejected by default.

## Trajectory (why the architecture is built the way it is)

1. **ATO-additive, and built in anticipation of 20x.** Expansion of customer
   capability must be ADDITIVE to the existing RGS FedRAMP Moderate / IL4 ATO —
   ride within the authorized boundary, do not force a re-authorization. Growth
   happens through **SCN (Significant Change Notification)** processes. The
   system is also being built in anticipation of the Rev 5 → **FedRAMP 20x**
   change (significant new/automated evidence and control expectations) — which
   is why machine-readable evidence and inherited controls (ADR-0020) are
   foundational, not afterthoughts.
2. **Expand what customers can do — via SCN.** Today: shell/RDP sessions on
   their EC2 instances. Tomorrow (through SCN-driven ATO expansion): AWS console
   access and other AWS services, not just host sessions. The architecture must
   not preclude this.
3. **Multi-cloud and private cloud — the same managed model everywhere.** Just
   as Rackspace already manages commercial customers spanning OpenStack, Google,
   AWS, etc., RGS intends the same single managed access model across
   heterogeneous targets: other public clouds AND private cloud (VMware vCenter,
   OpenStack). This is precisely why the provider/adapter architecture (ADR-0016)
   exists — AWS-EC2 + SSH-CA is provider #1; a vCenter or OpenStack
   ConnectionProvider is additive, with the same portal, identity model, and
   audit posture.

## Decision

Adopt the above as the governing product vision and scope. Concretely:
- Serve all three perspectives (auditor, operator, customer) as first-class.
- Treat machine-readable audit evidence as a product output (20x readiness).
- Keep every capability expansion ATO-additive and SCN-driven; never break the
  existing authorization.
- Hold tenant isolation as an inviolable invariant.
- Keep the core cloud-agnostic (ADR-0016) so multi-cloud / private-cloud targets
  are additive, never a rewrite.
- Remain an RGS-org-exclusive, in-boundary build (ADR-0013).

## Consequences

- Design reviews weigh changes against all three perspectives and the tenant-
  isolation invariant, not just "does the feature work."
- Evidence generation is a requirement, not optional instrumentation.
- The provider abstraction (ADR-0016) is non-negotiable — AWS assumptions must
  not leak into the core, or the multi-cloud/private-cloud goal dies.
- Capability growth is gated on SCN/ATO process, which is an operational
  dependency the roadmap must respect (some features wait on authorization, not
  code).
- This ADR is the "north star"; if a later technical ADR conflicts with it, this
  vision wins unless this ADR is explicitly superseded.

## Relationship to other ADRs

- ADR-0013 (build gov-specific Passport): the org/boundary rationale.
- ADR-0016 (provider architecture): the mechanism for the multi-cloud trajectory.
- ADR-0019 (partition intersection / no CloudFront): the IL4 boundary posture.
- ADR-0020 (prefer inherited controls): the 20x-readiness / evidence posture.
- ADR-0011 (govern the local principal): the attribution that makes auditor
  evidence real.
