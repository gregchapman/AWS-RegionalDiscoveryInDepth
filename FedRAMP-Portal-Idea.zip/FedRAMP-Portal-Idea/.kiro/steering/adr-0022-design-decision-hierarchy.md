---
inclusion: auto
---

# ADR-0022: Design Decision Hierarchy (Passport prior art → 800-53 → lowest-risk tiebreak)

Date: 2026-08-31
Status: Accepted

## Context

Across this project we have repeatedly made the same *kind* of decision without
naming the rule behind it: how to choose when Passport V2's proven pattern, an
800-53 control, and usability all pull in different directions. We kept
re-deriving the answer ad hoc (SSH cert vs. password; role-chaining's forced 1h
credential; `StrictHostKeyChecking=no` over an authenticated SSM tunnel; storing
vs. vending a Windows password; Fleet Manager vs. tunnel+client). Those choices
were consistent, but the consistency lived only in our heads. A recurring
decision rule that future sessions must apply the same way is exactly what an
ADR is for. This ADR makes the rule explicit so it stops being tacit and so the
design docs show a single, defensible decision method to an auditor.

## Decision

Apply this ordered hierarchy to every access/architecture decision:

1. **Passport V2 is the default guide (prior art).** Where production Passport
   already solves a problem, MIRROR it rather than invent. Read the Passport
   source first; copy the mechanism (e.g. `passportCLIPolicyDocument` scoping,
   the SSM tunnel + native-client RDP flow, the CLI UX and installer shape).
   Prior art is the starting point, not the ceiling.

2. **Adapt the pattern to satisfy 800-53.** Passport was not built for FedRAMP.
   Where its pattern falls short of a required control, EXTEND it — do not
   discard the pattern, and do not ship the gap. Examples already applied: the
   CLI performs its own Cognito+MFA instead of accepting a handed-over token
   (IA-2); the vend endpoint adds an independent connect-time tenant re-check
   (AC-6(5)); artifacts are checksum-verified on install (CM-5/SI-7/SA-10).

3. **On conflict, choose the lowest-security-risk option and DOCUMENT it.**
   When two controls conflict, or a control conflicts with the Passport pattern
   or with usability, pick the option that leaves the lowest residual security
   risk, and record the tradeoff (what conflicted, what we chose, the residual)
   in ARCHITECTURE-WEAKNESSES.md and/or the relevant ADR. "Document it" is
   mandatory, not optional — an undocumented tradeoff is a finding waiting to
   happen. Prefer eliminating the risky element over mitigating it; prefer
   short-lived/vended over stored; prefer no-secret over secret.

This hierarchy is strictly ordered: 1 gives the starting design, 2 may modify
it, 3 breaks ties. A later rule always overrides an earlier one (a control
requirement beats "but Passport does it this way"; lowest-risk beats a control
reading that would increase risk).

## Worked example (the decision that prompted this ADR)

Windows/RDP. Prior art (1): Passport V2 = SSM tunnel to 3389 + native RDP client
+ username/password. Adapt (2): a stored plaintext password violates SC-28 and
weakens IA-5(1). Tiebreak (3): the password is intrinsic to the native-RDP
pattern, so we cannot eliminate it without abandoning prior art (or moving to
Fleet Manager/DCV, pending GovCloud + Identity-Center verification). Lowest-risk
adaptation that keeps the pattern: **vend a short-lived Windows password on
demand** (generated per session, never stored long-term) — the Windows analog
of the STS-credential and SSH-certificate vends — and document the residual
(a password is transiently handled by the user, unlike the SSH-cert path).

## Consequences

- Decisions become explainable with one sentence per level ("Passport does X;
  control Y required Z; we chose W as lowest-risk, residual R"). Good for
  auditors and for future sessions.
- Forces the tradeoff register (ARCHITECTURE-WEAKNESSES §2) to stay honest —
  every clause-3 choice must land there.
- Does not license gold-plating: clause 2 extends only to MEET controls, not to
  exceed them arbitrarily (respects ADR-0020 "prefer inherited controls" and the
  wallet constraints). Prior art (clause 1) keeps us from over-engineering.
- When Passport prior art does not exist for something (new target types under
  ADR-0016), clause 1 is vacuous and we start at clause 2 — design to the
  controls directly, still tiebreaking by lowest risk.

## Applied again (2026-08-31) — authoritative session termination

Second real use of the hierarchy, worth recording.
- Clause 1 (Passport prior art): the access-lifecycle Step Function waits for
  the session TTL, then cleans up — a single `Wait ttl_seconds`.
- Clause 2 (800-53): AC-12 (session termination) and AC-2(3) want ending to be
  RELIABLE. The prior-art design ended a session early only via a best-effort
  `stop_execution` call from the terminate Lambda; if that call was skipped
  (missing execution_arn) or failed, or the session ended by client-TTL /
  operator-revoke (which don't invoke that handler), the execution sat RUNNING
  as an orphan until TTL. Best-effort termination does not satisfy AC-12.
- Clause 3 (lowest-risk): make the state machine DETECT the end demand rather
  than depend on an external call reaching it. Replaced the single Wait with a
  poll-loop (Wait 30s -> getItem status -> Choice: status != ACTIVE OR past
  expiry -> cleanup; else loop). Terminate now just writes the status; the
  machine self-terminates within one interval. Residual: up to ~30s latency and
  one getItem per interval per active session (negligible, PAY_PER_REQUEST) —
  the lowest-risk trade vs. a whole class of orphaned/unterminated sessions.

This is the pattern the hierarchy is meant to produce: keep the Passport shape
(a TTL-bounded lifecycle), extend it to actually meet the control (reliable
termination), and when "just call stop_execution" conflicts with reliability,
choose the design where the machine is self-authoritative and document the small
residual.
