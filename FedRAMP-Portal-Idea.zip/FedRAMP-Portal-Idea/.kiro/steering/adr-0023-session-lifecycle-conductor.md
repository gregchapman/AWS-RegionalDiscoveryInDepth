---
inclusion: auto
---

# ADR-0023: Session Lifecycle — One Conductor, One Convergent Teardown

Date: 2026-09-03
Status: Accepted

## Context

The access-session lifecycle is executed by independent, asynchronous workers:
the portal API Lambdas, the Step Function, the cleanup Lambda (via SSM on the
instance), and the `passport` CLI on the user's machine. During bring-up we
found the session would not end cleanly — "end the session" took two clicks,
sessions stranded at `CLEANING_UP`, ephemeral users/profiles were orphaned, and
81 Step Function executions showed `Aborted`.

Root cause was not any single bug. It was the absence of a **conductor**: every
component read the same DynamoDB record ("the score") and assumed some other
component was keeping time. Concretely:

- `terminate_session` (a caller) ran its OWN cleanup AND called
  `states:StopExecution`, which **aborted the Step Function before it could
  write the terminal `COMPLETED`** — stranding the record at `CLEANING_UP`. The
  StopExecution only started "working" once its IAM permission was fixed, which
  is when the stranding began.
- No single end-trigger performs all four teardown concerns. Behavior is
  scattered: server-driven ends miss tunnel teardown; CLI-driven ends miss OS
  user/profile removal; a failed cleanup still reports `COMPLETED`.

A metaphor that guided the fix: we had an orchestra reading the same sheet music
but no conductor keeping time, so the output didn't sound like the song we
wanted. The Step Function was ALWAYS intended to be that conductor.

## Decision

### 1. Roles (who does what)

- **The Step Function is the CONDUCTOR.** It is the sole owner of session
  sequencing and the sole writer of phase transitions and terminal state. It
  honors process dependencies: it does not advance to the next action until it
  has confirmed the current worker's actual result (generalizing the existing
  `CheckProvisionResult` pattern to EVERY worker handoff — see §3).
- **DynamoDB is the SCORE / position marker.** It records where each session is
  in the piece. It performs NO actions. It informs the conductor what is ready
  and lets readers (portal, CLI) display position. It is the single source of
  truth for *recorded* state, but it does not *drive*.
- **The Lambdas / SSM / instance / CLI are MUSICIANS.** They play a part when
  cued and report their result. They never advance the score's phase.

### 2. Callers submit an END DEMAND; they never drive teardown

Every way a session can end is just a *request to the conductor*, written to the
score as an explicit end-demand, never a teardown the caller performs itself:

- `terminate_session` (portal End button, operator revoke) writes an end-demand
  status and returns. It does NOT run its own SSM cleanup, does NOT call
  `states:StopExecution`, does NOT claim `COMPLETED`.
- The CLI, on ANY local end (Ctrl-C, shell exit, RDP client exit), MUST submit
  the same end-demand to the portal (a terminate call) so the server side is
  torn down too — fixing the orphaned-user-on-CLI-exit divergence. The CLI still
  closes its own tunnel locally; it additionally signals the conductor.
- Operator/break-glass writes the same end-demand (or calls the terminate
  endpoint) rather than hand-running cleanup, so the conductor stays authoritative.

`states:StopExecution` is FORBIDDEN as a termination mechanism and its IAM grant
is removed. Aborting the conductor is what stranded sessions; the conductor must
be allowed to finish the phrase.

### 3. The conductor VERIFIES each worker before advancing (process dependencies)

The core principle for independent async workers: **confirm the worker's actual
state before issuing the next instruction.** Applied to teardown:

- `CleanupUser` must READ the cleanup Lambda's reported result. The Lambda
  already returns `verified: OK | INCOMPLETE`. The state machine must branch on
  it:
  - `OK` -> `UpdateStatusCompleted` (`COMPLETED`).
  - `INCOMPLETE` -> retry cleanup a bounded number of times; if still incomplete
    -> `CLEANUP_FAILED` (a real terminal state), not a silent `COMPLETED`.
- A failed cleanup MUST NOT report `COMPLETED`. `COMPLETED` means "verified: the
  connection is dropped, the OS user and profile are gone." Anything less is
  `CLEANUP_FAILED`, which surfaces as a residual for AU-6 monitoring.

### 4. One convergent teardown = all four concerns, every path

Every end path converges on the conductor running ONE teardown that guarantees,
and verifies, all four:
  (a) the connection/login session is dropped,
  (b) the ephemeral OS user is removed,
  (c) the profile / home dir is removed,
  (d) the SSM tunnel is torn down.

Concern (d) is currently only done by the CLI or SSM's idle timeout. The
conductor must own (d) too: cleanup should call `ssm:TerminateSession` on the
session id (recorded on the score at connect time) so a server-driven end does
not depend on the client noticing. The CLI closing its local tunnel remains a
belt-and-suspenders, not the only mechanism.

### 5. Convergence guarantee (no black holes)

- Every session reaches a TERMINAL state: `COMPLETED`, `CLEANUP_FAILED`, or
  `FAILED` (provision). `CLEANING_UP` is a transient the conductor is actively
  working — never a resting place.
- Termination latency is bounded. The end-demand is detected within one poll
  interval; the interval should be short enough that End Session feels immediate
  (target: a few seconds, not 30) — the exact mechanism (shorter Wait vs. task
  token / activity) is decided in §7.

### 6. Readers reflect the truth; reconciliation is the safety net

- The portal and CLI show the honest position: `ACTIVE` (connectable),
  `CLEANING_UP`/ending ("Ending…", not connectable, not re-endable — this kills
  the two-click by construction), and terminal states.
- Reconciliation-on-read safety net: if a reader sees a non-terminal record
  whose conductor execution is no longer RUNNING (aborted/died), it treats the
  session as terminal and can heal the record. This prevents a dead conductor
  from stranding the score again.

### 7. Open design choices (to resolve during implementation)

- **Convergence latency mechanism:** shorten the poll `Wait` (simple, cheap
  getItems) vs. a task-token/activity pattern (event-driven, instant) vs. an
  EventBridge signal. Leaning: shorten the Wait to make End feel immediate,
  since the poll-loop is already the proven authoritative mechanism.
- **Single cleanup source:** the inline cleanup copy in `terminate_session` is
  removed entirely (callers no longer clean up); `cleanup_user` becomes the ONE
  cleanup implementation. This also removes the "keep the two copies in sync"
  hazard.
- **DynamoDB native TTL** stays as record hygiene only; it must never be the
  session-teardown mechanism and must not delete a record out from under a
  running execution (verify `expires_at` is far enough beyond the window that
  the conductor always finalizes first).

## Consequences

- One teardown path, verified, for every end-trigger — the same song regardless
  of who cues the ending. Fixes: two-click, orphaned users/profiles, lingering
  tunnels, stranded `CLEANING_UP`, and `COMPLETED`-masking-a-residual.
- The conductor is never aborted; it always converges the score to a terminal
  state. Directly satisfies AC-12 (authoritative, reliable termination).
- `CLEANUP_FAILED` makes residuals visible (AU-6) instead of masked.
- The CLI must call terminate on local exit — a new dependency, but it makes
  CLI-exit and portal-End behave identically.
- Requires a one-time PURGE of the existing stranded `CLEANING_UP` records
  (debris from the aborted executions) as part of rollout.
- More conductor logic (verify-branch at each handoff) — but this is the
  explicit intent of choosing a state machine in the first place.

## Supersedes / relates to

- Extends ADR-0022 (authoritative termination via poll-loop): keeps the
  poll-loop as the mechanism, adds the "conductor verifies each worker + all
  ends converge on one teardown + no aborting the conductor" invariants.
