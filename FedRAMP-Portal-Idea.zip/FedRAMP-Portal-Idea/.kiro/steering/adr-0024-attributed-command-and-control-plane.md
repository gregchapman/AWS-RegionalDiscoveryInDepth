---
inclusion: auto
---

# ADR-0024: The Portal Is a Command-and-Control Plane — Every Action Is Attributed and Logged

Date: 2026-09-04
Status: Accepted

## Context

This portal is not a content app; it is a **command-and-control (C2) plane for
privileged access** to customer systems. Every operation it exposes is a
security event by nature:

- listing accounts/instances reveals a tenant's inventory (reconnaissance),
- connect mints a real, privileged, ephemeral OS identity on a live host,
- the credential vend hands out scoped AWS keys,
- terminate revokes live access,
- the operator lens (ADR-0025) lets a Racker see/end other users' sessions.

While hardening session termination (ADR-0023) we found terminate accepted no
body and wrote only a thin log line. Generalizing from the operator-revoke case,
greg identified the real invariant: an action that can occur WITHOUT an
attributed, logged record is indistinguishable from an intruder's action in the
evidence trail — and worse, the missing record makes the abuse *costless and
anonymous*. A caller who can trigger unattributed terminations could mass-revoke
every active session with no fingerprint (a novel DoS whose signature is the
absence of evidence). The audit gap does not merely weaken forensics; it enables
the attack.

The model to mirror is **AWS CloudTrail** (ADR-0020, prefer inherited patterns):
CloudTrail records every API call — reads and writes — attributes each to a
principal, stamps the source and time, and never lets an action happen
off-record. We follow that model for our own control plane.

## Decision

**Every action on the control plane is attributable and logged. No exceptions,
no anonymous actions — reads included.**

### 1. Mandatory attribution on every action

Every request handler (read OR write; invoked by a human, the CLI, the Step
Function conductor, or a scheduled/TTL path) MUST emit a structured audit record
containing at minimum:

- **who** — the principal identity (Cognito `sub` + email; for system actors, a
  named system principal e.g. `system:conductor`, `system:ttl`),
- **what** — the action (e.g. `list_instances`, `connect`, `vend_credentials`,
  `terminate`),
- **which** — the target(s) (request_id / instance_id / tenant `customer_id`),
- **when** — timestamp (UTC),
- **whence** — the source (`portal`, `cli`, `conductor`, `ttl`),
- **outcome** — allowed / denied (+ reason on deny).

Reads are logged too: on a C2 plane, enumeration IS the reconnaissance an
attacker performs, so a Racker listing a tenant's sessions is itself an audit
event (AU-2). This is the CloudTrail stance: management events cover reads and
writes alike.

### 2. Privileged / on-behalf-of actions additionally require JUSTIFICATION

When a principal acts on a resource they do not own — the archetype being a
Racker terminating or operating on another user's / a tenant's session
(ADR-0025) — the action MUST carry a human **justification** (free-text reason,
normally a customer ticket number). This is enforced **fail-closed**: absent or
empty justification on an on-behalf-of action returns 400 and the action does
NOT occur. Self-service actions on one's own resources do not require a
justification but are still fully attributed and logged (a system-generated
source string is recorded, e.g. `cli:exit`, `self:portal`, `system:ttl`).

### 3. Attribution is the substrate for detection, not a substitute for prevention

Mandatory attribution delivers: AU-2/AU-3/AU-12 evidence, dispute resolution
(a customer complaint is answered by the who/why/when record), and — critically
— the INPUT that makes AU-6 anomaly detection possible (e.g. alarm on one
principal terminating N sessions across M tenants in T seconds). It does NOT by
itself PREVENT an authenticated attacker who holds valid privileged credentials;
that residual is handled by authorization, tenant scoping (ADR-0021),
rate-limiting, and privileged-use monitoring (AC-2(7), tracked separately).
Attribution makes every action named and detectable — it raises cost and enables
alarms; it is not a claim of prevention.

## Consequences

- Every current and FUTURE endpoint inherits this: connect, list_*, vend,
  terminate, the coming AC-2(1) one-click revoke, and the IR-4 kill-switch all
  attribute + log by construction, and any on-behalf-of variant requires a
  reason. New endpoints do not re-litigate this — they comply.
- The API contract for on-behalf-of actions gains a required `reason`
  (fail-closed). Self/system paths auto-fill a source string so they are never
  blocked but never anonymous.
- More log volume (reads included) — accepted deliberately, matching CloudTrail;
  cost is negligible at POC scale and is the correct posture for a C2 plane.
- Enables the AU-6 alarms (anomalous mass-termination, cross-tenant access
  patterns) as a natural follow-on, because the attributed stream now exists.
- Directly serves AU-2, AU-3, AU-12; supports AC-2(7) privileged monitoring and
  IR-4 by making privileged actions visible.

## Supersedes / relates to

- Mirrors the CloudTrail model per ADR-0020 (prefer inherited/managed patterns).
- Provides the attribution + justification requirements that ADR-0025 (session
  model + operator lens) depends on for its operator-revoke path.
- Extends the audit posture referenced by ADR-0023 (residuals must surface).
