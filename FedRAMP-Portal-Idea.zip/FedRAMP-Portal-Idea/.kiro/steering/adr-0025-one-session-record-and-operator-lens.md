---
inclusion: auto
---

# ADR-0025: One Authoritative Session Record per Connect + Operator Visibility & Revoke Within Tenant Scope

Date: 2026-09-04
Status: Accepted

## Context

Two problems surfaced during live testing of the ADR-0023 conductor:

**(1) Two records for one intended session.** Clicking "Connect" in the portal
calls `POST /api/connect`, which mints an access request (record A) AND
provisions a real ephemeral OS user — purely to display the `passport connect`
command in the drawer. The user then pastes that command; the CLI authenticates
(its own Cognito+MFA) and calls `POST /api/connect` AGAIN, minting a SECOND
record (record B) with its OWN ephemeral user and the tunnel actually used.
Proven from the C2 log: the portal "End" button terminated record A
(`dc28541d…`) while the live RDP tunnel belonged to record B (`2eedcb1d…`),
which kept running. Net harm: the End acted on the wrong record (looked like a
persistent two-click bug), AND every portal-Connect-then-CLI-connect left an
unused, unlogged-into ephemeral PRIVILEGED account on the host until its TTL — an
orphaned-privilege footprint (AC-6/AC-2) and hidden state (AU-6).

**(2) No operator lens.** `list_sessions` queries the user-index GSI keyed on
the CALLER's `user_id`, so it only ever returns the caller's OWN sessions. A
Racker asked to revoke "Customer1 / Joe" sees NOTHING — there is no view of
another user's live sessions. You cannot reliably terminate (AC-12) or manage
accounts (AC-2/AC-2(1)) for access you cannot see. The operator is a first-class
user (ADR-0021) with no control surface.

## Decision

### 1. One authoritative session record per connect (the CLI owns it)

A connect produces exactly ONE access request — the authoritative "score"
(ADR-0023). The `passport` CLI, which does the real authentication and owns the
tunnel, is the session creator. The portal "Connect" button STOPS minting a
provisioning record; it hands off the install + `passport connect` command and
then REFLECTS whatever live session the CLI creates (via the operator/self list
path).

KEY DISTINCTION (this resolves the "should the portal show a pre-connect state?"
question — do not re-litigate it): opening the drawer and copying the
`passport connect` string is NOT an action on the control plane. It grants
nothing, provisions nothing, exposes nothing — it is a pure UI convenience. The
security event begins only when the CLI authenticates and requests real access.
Therefore there is genuinely NOTHING for the plane to record or the portal to
reflect until the CLI connects. "No live card until the CLI actually connects"
is not a gap to paper over with an intent/placeholder record — it is the honest
truth: no ephemeral privileged user exists until access truly happens.
(Considered and rejected: an INITIATED/AWAITING_CLI marker written on
drawer-open — that would create a plane record for a non-plane act,
reintroducing exactly the phantom state this ADR eliminates.)

(Considered and rejected: (b) CLI attaches to a portal-created request via an
embedded request_id — keeps the portal as mandatory initiator, more moving
parts; (c) End fans out to all records for the user+instance — preserves the
duplication and hides it, fails AC-6/AU-6. Chosen: the CLI is the single
session-creating authority.)

### 2. Operator visibility within tenant scope

`list_sessions` gains an OPERATOR mode: a Racker may enumerate LIVE sessions
across ALL users, returning full detail (principal, instance, tenant, start
time, status) for the audit story. Non-Rackers still see only their own
sessions. Scope is bounded by tenant `customer_id` so a Racker viewing
Customer1's sessions never sees Customer2's — ADR-0021 tenant isolation remains
an inviolable invariant even for operators. (For now ALL Rackers may operate;
narrowing to a dedicated non-admin operator role is future work — AC-2(7).)

REQUIREMENT this exposes: the session record must carry the TARGET tenant
(`customer_id`, from the instance's `Customer` tag at create time) so operator
queries can be tenant-scoped server-side, fail-closed. If the record does not
already store it, adding it is part of implementing this ADR.

### 3. Operator revoke is attributed AND justified (per ADR-0024)

Ending a session you own: attributed + logged, no reason required
(`end_source = self:portal` / `cli:exit`). Ending ANOTHER user's session
(operator revoke): attributed + logged AND a **reason (ticket #) is mandatory,
fail-closed** — enforced per ADR-0024. The record persists `ended_by`,
`end_source`, and `end_reason`; the conductor still runs the one verified
teardown (ADR-0023). This settles customer disputes (who/why/when) and denies
the anonymous-mass-termination vector.

## Consequences

- One session = one record = one ephemeral user = one thing to end. The
  wrong-record two-click and the orphaned-privilege footprint both disappear.
- The portal becomes an honest mirror of real sessions (self view) plus an
  operator console (Racker view, tenant-scoped) with per-session revoke.
- AC-2/AC-2(1): operators can now SEE and end a target user's sessions — the
  precondition the operator runbook assumed but the portal never provided.
- AC-12: reliable termination now includes "the operator can find the session
  to terminate," not just "the owner can."
- Depends on ADR-0024 for the attribution + mandatory-reason enforcement.
- Touch points: `create_access_request` (portal Connect stops provisioning;
  stamp `customer_id`), `list_sessions` (operator mode, tenant-scoped),
  `terminate_session` (reason + attribution fields), the SPA (operator table +
  reason dialog; card reflects the real CLI record), the CLI (single request;
  auto-reason on exit).
- Residual: an authenticated Racker with valid creds can still act within scope;
  bounded by ADR-0024 logging + future AC-2(7) monitoring/rate-limits, not by
  this ADR alone.

## Supersedes / relates to

- Builds on ADR-0023 (one conductor, one convergent teardown): keeps the
  conductor; fixes what it operates on (one record) and who can trigger it (owner
  or scoped operator).
- Relies on ADR-0024 (attributed C2 plane) for attribution + justification.
- Upholds ADR-0021 (tenant isolation) as the hard bound on the operator lens.
