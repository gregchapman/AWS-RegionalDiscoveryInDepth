---
inclusion: auto
---

# ADR-0026: Contract-First Platform — the Consumer API Is the Product Surface; the Portal Is a Reference Client

Date: 2026-09-08
Status: Accepted (target-state; Phase 1 not yet built)

## Context

The POC is a serverless access broker with one React portal bolted to its API.
The business needs the CONSUMER model to vary — the RGS portal, a customer's own
front end, a mobile client, a ServiceNow integration, an auditor's evidence
puller — all against the same platform (see `docs/TARGET-ARCHITECTURE.md`). If
the UI and backend stay implicitly coupled (private endpoints, UI-only
assumptions, backend features shaped to the current SPA), every new consumer is a
backend change and the UI stays inside the ATO control scope.

## Decision

**The platform's surface is a published, versioned Consumer API (OpenAPI). Every
consumer is a client of it. The default RGS portal is a REFERENCE CLIENT, not a
privileged component.**

1. **Versioned OpenAPI, `/api/v1/`.** Published as `api/openapi/consumer-api.v1.yaml`
   with companion JSON schemas (resource model — ADR-0027; identity assertion —
   ADR-0028). SDKs are generated from it; a consumer developer needs no knowledge
   of Lambda, Step Functions, Cognito, SSM, or any provider.
2. **The portal holds no privilege a third-party consumer could not obtain.**
   There are NO portal-only backdoor endpoints and no auth path the UI uses that
   the contract doesn't expose. This keeps the abstraction honest and prevents
   private coupling from accreting; it also drops the UI out of much of the
   authorization-boundary control scope (the API is the enforcement point).
3. **Async by default for state changes.** Any mutating action returns
   `202 Accepted` + a job handle (`GET /api/v1/jobs/{id}`), with SSE/WebSocket
   events later. A slow vCenter operation and a fast AWS one look identical to
   the consumer. (Maps onto the existing Step Functions substrate.)
4. **The contract is authoritative over the implementation.** When the backend
   changes (new provider, new IdP, workflow refactor), the contract holds; a
   breaking change is a new API version, not a silent shift.

## Consequences

- Any front end / integration that conforms to Consumer API v1 can replace the
  supplied UI — the replaceable-consumer goal, by construction.
- The API Gateway JWT authorizer is THE enforcement boundary; the UI is untrusted
  like any client (defensible for the ATO).
- Requires discipline: features are added to the CONTRACT first, then implemented
  — not shipped as UI+backend pairs that skip the contract.
- Phase 1 (contract extraction) formalizes the CURRENT endpoints behind this
  contract before any new provider/consumer is added.

## Relates to

- Framed by `docs/TARGET-ARCHITECTURE.md` (§3.1, B4, B5).
- Depends on ADR-0027 (resource model) and ADR-0028 (identity assertion) for the
  contract's data shapes. Attribution/logging of every API call is ADR-0024.
