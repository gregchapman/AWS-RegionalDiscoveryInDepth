---
inclusion: auto
---

# ADR-0027: Provider Abstraction — Canonical Resource Model, Provider-Defined Connection, Per-Provider Boundary

Date: 2026-09-08
Status: Accepted (target-state; AWS is the only provider today)

## Context

The POC manages AWS EC2 via SSM. The strategy requires managing vCenter (today's
revenue base), then Azure/GCP, through ONE consumer experience
(`docs/TARGET-ARCHITECTURE.md`). vCenter has no SSM, different resource
semantics, its own ATO, and a different connection mechanism. If the AWS resource
model or the SSM transport leaks into the platform contract, no other provider
can implement it.

## Decision

**Providers implement a common contract that emits a canonical resource model and
defines connection abstractly. Each provider lives in its own authorization
boundary.**

1. **Canonical Resource + Capability model.** Every managed thing is
   `{ id, provider, provider_resource_id, resource_type, name, tenant, location,
   state, capabilities: [...] }`. The consumer renders and acts from
   `capabilities` (`start`, `stop`, `console`, `connect`, `metrics`, `cost`,
   `compliance`, ...), never from provider-specific semantics. AWS's resource
   model does NOT become the platform's resource model.
2. **The Provider contract:** `List / Get / Start / Stop / Resize / Connect /
   GetCompliance / GetCost / GetAuditEvents`. `Connect` is ABSTRACT — "establish
   an attributed, brokered ephemeral session to this resource" — satisfied
   per-provider (AWS = SSM tunnel; vCenter = its own broker; Azure = Bastion/Arc).
   **Nothing SSM-shaped may appear in the contract** (B1). The existing
   `ConnectionProvider`/`IdentityProvider` Go interfaces (ADR-0016) are the seed;
   the target extends them into server-side subsystems.
3. **Per-provider authorization boundary.** Each provider (AWS, vCenter, Azure,
   GCP) runs in its OWN boundary with its OWN authorization package and connects
   to the core only through the contract — a controlled, audited interface, never
   a shared network. The existing vCenter ATO stays intact; a reach into a
   commercial cloud never contaminates the AWS IL4 boundary (see ADR-0029).
4. **Provider modules deploy the ADAPTER + permissions, not customer resources.**
   Terraform for a provider stands up its adapter runtime and its scoped access,
   not the tenant's workloads.

## Consequences

- The consumer treats a vCenter VM, an EC2 instance, and an Azure VM uniformly;
  provider-specific differences surface only through `capabilities`.
- New providers are additive — a new adapter behind the contract, not a platform
  change.
- The connection abstraction is the load-bearing one: it must express "brokered,
  attributed, ephemeral, verifiably-terminable session" (ADR-0023 semantics)
  without naming SSM.
- v1 of the Provider contract is PROVISIONAL and shaped from the two known
  realities (AWS today, vCenter next); freeze after the vCenter implementation
  proves it (ADR-0031).

## Relates to

- Extends ADR-0016 (provider/adapter interfaces) from CLI-only to server-side.
- Connection semantics inherit ADR-0023 (verified teardown) and ADR-0011
  (govern the local principal) — but expressed provider-neutrally.
- Boundary rules are ADR-0029; the consumer-facing shape is ADR-0026.
