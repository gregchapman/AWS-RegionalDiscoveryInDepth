---
inclusion: auto
---

# ADR-0028: Identity by Assurance, Not Mechanism

Date: 2026-09-08
Status: Accepted (target-state; Cognito+TOTP is the only implementation today)

## Context

The POC authenticates against a standalone Cognito user pool with TOTP MFA. The
strategy requires the identity SOURCE and the MFA TYPE to vary without
re-architecting: a known RGS IdP, a customer's SAML/OIDC, CAC/PIV, Swissbit
FIPS hardware tokens, and — critically for the vCenter revenue base — a
transitional AD trust (the current customer-AD-to-RGS-AD model). Two failure
modes to avoid: (a) making Cognito synonymous with identity (lock-in), and
(b) hard-coding either "no directory" (breaks vCenter's AD reality) or "AD trust"
(drags AD into the deliberately directory-less AWS boundary, contra ADR-0011).

## Decision

**The platform authorizes on ASSURANCE and ATTRIBUTION, never on the
authentication mechanism.** All identity sources normalize to one assertion:

```
{ subject, issuer, tenant, authn_method, authn_assurance, mfa, groups, session_id }
```

- **Authorization references `authn_assurance` (e.g. `phishing-resistant`),
  `tenant`, and `groups` — never `authn_method`.** Whether the ceremony was
  Cognito+TOTP, RGS-IdP+Swissbit, customer SAML/OIDC, CAC/PIV, or an AD trust is
  an implementation BELOW the contract.
- **Cognito is ONE `IdentityProvider` implementation** (ADR-0016 seam), not the
  identity layer itself. Adding an IdP is a new module behind the assertion, not
  a platform change.
- **MFA is a source of assurance, not a fixed step.** TOTP / FIDO2 / PIV /
  Swissbit each raise the asserted assurance; policy states the REQUIRED assurance
  and the provider decides how to satisfy it.
- **The vCenter AD trust is expressible transitionally** as
  `authn_method: ad-trust` with its honest assurance level — so vCenter keeps its
  current auth INITIALLY (don't break revenue) and migrates credential-less
  behind the same assertion later.
- A source that CANNOT assert an assurance level does not satisfy the contract
  (this is one of the ways the contract refuses control-weakening — the platform
  promise in `platform/README.md`).

## Consequences

- "Not married to Cognito" becomes real: RGS IdP / customer IdP / hardware tokens
  are configuration + a module, not a rebuild.
- Authorization logic is written once against assurance/tenant/groups and does
  not change when the IdP changes.
- Reconciles ADR-0011 (no directory on the AWS plane) with the vCenter AD reality:
  AD is simply one mechanism below the assertion, confined to its own provider
  boundary (ADR-0029).
- The assertion schema is PROVISIONAL until a second real IdP proves it (ADR-0031).
- The automated-test posture uses a seeded test identity with a REAL TOTP secret
  (no bypass) — see `docs/ARCHITECTURE.md` §8 IA-2 note; this ADR is why that
  fits (the test identity is just another source emitting a valid assertion).

## Relates to

- Extends ADR-0016 (IdentityProvider seam) to a server-side normalized assertion.
- Reconciles ADR-0011 (govern the local principal / no directory).
- Consumed by the Consumer API (ADR-0026) and enforced within provider boundaries
  (ADR-0029). Attribution of the resulting actions is ADR-0024.
