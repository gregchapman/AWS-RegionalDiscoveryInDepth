---
inclusion: auto
---

# ADR-0029: One Core, Many Authorization Boundaries, Many Compliance Profiles

Date: 2026-09-08
Status: Accepted (target-state)

## Context

The platform must simultaneously: hold an 800-53 ATO (FedRAMP Moderate, target
IL4 in GovCloud) on the AWS plane; reach the vCenter estate, which already has
its OWN ATO; later reach Azure/GCP; and open an 800-171 market across all of
them. These pull in opposite directions. The IL4 story (ADR-0019) rests on the
commercial∩GovCloud service intersection and US-person administration — the moment
the control plane reaches into Azure/GCP/vCenter it introduces outbound
connections, foreign credentials, and cross-boundary audit flows that would
contaminate that IL4 boundary if everything shared one boundary. A naive single
"multi-cloud control plane" diagram hides this.

## Decision

**One shared CORE; each provider in its OWN authorization boundary; compliance
expressed as PROFILES, not forks.**

1. **Shared core, separate provider boundaries.** The core (Consumer API,
   identity plane, workflow, audit/evidence) is built once. Each provider (AWS,
   vCenter, Azure, GCP) runs in its OWN authorization boundary with its OWN
   authorization package and connects to the core ONLY through the Provider
   contract (ADR-0027) — a controlled, audited interface, never a shared network.
   Consequences: the existing vCenter ATO stays intact; a reach into a commercial
   cloud never widens or contaminates the AWS IL4 boundary; a provider can be
   in-scope for one profile and out-of-scope for another.
2. **Compliance PROFILES, not code forks.** 800-53 Moderate, IL4, and 800-171 are
   *configuration of which controls apply and which partition/services are in
   scope*, selected per `live/<profile>/` deployment — NOT
   `takahe-commercial/` vs `takahe-fedramp/` codebases (that fork would hurt,
   contra ADR-0017/0019). 800-171 is largely a subset of 800-53 Moderate — a
   different authorization package over the same core, not a different product.
3. **The IL4 boundary is explicitly scoped.** "IL4 ATO" applies to the AWS
   (GovCloud) plane and the core that serves it. Multi-cloud management is a
   commercial-plane capability; it does not enter the IL4 boundary. This may mean
   the offering is "one product, two authorization stories" — stated openly, not
   hidden in a clean diagram.
4. **The core carries the baseline everywhere.** Whatever the profile, the
   `_baseline/` security/compliance module (ADR-0026 required module) is composed
   — attributed C2 plane (ADR-0024), tenant isolation (ADR-0021), verified
   teardown (ADR-0023), zero-inbound (ADR-0006). Profiles ADD control scope; they
   never SUBTRACT the baseline.
5. **Inheritance is legible and auditable.** Each deployment emits which controls
   the adopter INHERITS vs. which are customer-responsibility (ADR-0020, no false
   assurance). This accounting is kept EXHAUSTIVE and CODE-TRACEABLE — every
   "satisfy / inherit / customer-controls" claim cross-references the actual
   implementation and the §8 control matrix — so the responsibility boundary for
   any control resolves to a specific, evidenced answer rather than an assertion.
   Controls the customer solely owns (identity, branding, MFA, domain) are ones
   the platform deliberately has NO reach into — a posture strength, and stated
   as such. The boundary is a matter of record.

## Consequences

- Adopters can target 800-171 (commercial AWS/Azure/vCenter) without touching the
  IL4 build, and vice versa — same core, different profile.
- vCenter is a first-class provider from day one without endangering the AWS ATO.
- The honest cost: "multi-cloud management" and "IL4 ATO" may be two authorization
  stories sharing a core — a boundary/scope decision to make explicitly per
  offering, not a single all-in-one boundary.
- Partition-safe modules (ADR-0017) are a hard requirement for profiles to work.

## Relates to

- Builds on ADR-0019 (partition intersection), ADR-0017 (portability by config),
  ADR-0020 (inherited controls / no false assurance).
- Depends on ADR-0027 (provider contract as the only cross-boundary interface).
- The `_baseline/` required module and profiles live in `platform/` (README).
