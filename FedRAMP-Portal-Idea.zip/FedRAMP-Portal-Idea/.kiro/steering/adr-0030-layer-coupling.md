---
inclusion: auto
---

# ADR-0030: Layer Coupling — Remote-State for the Stable Core, Published Contract at the Seams

Date: 2026-09-08
Status: Accepted (target-state; reconciles ADR-0009)

## Context

The POC couples Terraform layers via `terraform_remote_state` (ADR-0009), chosen
deliberately for plan-time, typed, auditable dependency validation. The
platform's target layout (many independently-stated layers, providers that come
and go, a replaceable portal) raised the alternative of publishing a
configuration CONTRACT (SSM Parameter Store / a deployment manifest) so layers
are loosely coupled instead of state-coupled. The two approaches trade off:
remote-state gives determinism + a visible dependency graph (an asset for a
FedRAMP change-management story); published-contract gives independent lifecycle
(deploy/destroy a provider or the portal without other layers reading its state).
This must be resolved explicitly rather than silently flipping ADR-0009.

## Decision

**Hybrid, split by layer stability.**

1. **Remote-state (`terraform_remote_state`) for the STABLE lower core** —
   `bootstrap → foundation → identity → security(_baseline)`. These change rarely,
   their dependencies are load-bearing for compliance, and plan-time typed
   validation + an auditable graph are exactly what a FedRAMP change process
   wants. ADR-0009 stands for this tier.
2. **Published contract (SSM / manifest) at the INDEPENDENT-LIFECYCLE seams** —
   provider adapters (`50-providers/*`), the portal (`60-portal`), and observability.
   These are added/removed/replaced frequently and should NOT force other layers
   to read their state. The producing layer publishes boring facts
   (`/<profile>/network/vpc-id`, `/<profile>/api/endpoint`, `/<profile>/audit/bus`);
   consumers read them. Enabling "GCP for Customer X" or swapping the portal must
   not make Terraform plan the identity or security layers.
3. **Direction of coupling is one-way and down.** Upper/edge layers consume core
   facts; the core never depends on a provider or the portal.

## Consequences

- The compliance-critical core keeps ADR-0009's determinism and auditable graph.
- Providers and consumers gain true independent lifecycle (the ADR-0032
  non-disruptive-deploy goal leans on this).
- Two coupling mechanisms in one repo — a documented, intentional seam, not
  accidental inconsistency. The boundary is "does this layer need independent
  lifecycle?" → published contract; else → remote-state.
- Slightly more moving parts (a published-facts convention) — accepted for the
  loose coupling it buys at the seams.

## Relates to

- Reconciles ADR-0009 (remote-state) rather than overriding it.
- Enables ADR-0032 (non-disruptive parallel deploy) and the `live/<profile>/`
  layer layout (ADR-0029, `platform/live/README.md`).
