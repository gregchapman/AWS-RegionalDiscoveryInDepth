---
inclusion: auto
---

# ADR-0031: Phased Capability Delivery; Contracts Provisional Until a Second Implementation

Date: 2026-09-08
Status: Accepted (target-state)

## Context

The platform ambition is large (multi-provider, multi-IdP, multi-profile,
IL4 + 800-171). Two opposite risks: (a) over-abstracting on speculation —
building a grand plugin framework before a second real implementation exists,
then finding the abstraction was shaped wrong; and (b) under-planning — baking
AWS-only assumptions into Phase 1 so the later phases require re-architecture.
The resolution is to fix the BOUNDARIES now while STAGING the capabilities, and
to treat the contracts as provisional until reality tests them.

## Decision

**Deliver in phases; shape Phase 1's contracts KNOWING the later phases exist;
freeze contracts only after a second real implementation.**

Phases:
- **Phase 0 — current POC.** AWS/SSM + Cognito + one provider + one consumer.
  Make its BOUNDARIES contract-shaped; capability completeness is not the goal.
- **Phase 1 — contract extraction.** Publish the four contracts (ADR-0026/0027/
  0028); refactor the current AWS implementation to sit cleanly behind them. No
  new providers/IdPs — prove the AWS path works THROUGH the contracts. Mostly
  formalizes what exists; de-risks everything downstream.
- **Phase 2 — identity optionality.** A second IdP (RGS/customer SAML/OIDC) +
  Swissbit/FIDO2 assurance behind the identity contract (ADR-0028).
- **Phase 3 — vCenter provider (the revenue play).** Implement vCenter behind the
  Provider contract, initially leaning on the existing AD trust, in its own
  boundary (ADR-0027/0029). This is the second real provider implementation.
- **Phase 4 — expansion.** Azure/GCP providers; 800-171 profile; the
  Security-Hub-as-one-source evidence plane.

**Provisional-until-proven rule:** contract v1 is drafted from the two KNOWN
realities (AWS today, vCenter next) and marked PROVISIONAL. It is FROZEN (v1.0
stable) only after the first vCenter implementation (Phase 3) — the second
implementation — has pressure-tested it. Do not abstract beyond what those two
realities require. The identity assertion freezes similarly after a second IdP
(Phase 2).

## Consequences

- We build to the strategy now (boundaries) without speculative over-engineering
  (frozen abstractions before proof).
- Phase 1 is cheap and high-leverage; the expensive phases are deferred but not
  blocked by wrong early assumptions.
- A stakeholder can see a coherent phased roadmap (the "when can we have it?"
  pitch) with honest sequencing.
- Expect churn in the contracts between v1-draft and v1.0-frozen; consumers built
  against v1-draft accept that.

## Relates to

- Governs the whole cluster (ADR-0026–0030) and `docs/TARGET-ARCHITECTURE.md` §5–6.
- The freeze-after-second-implementation discipline is why the contracts in
  `platform/contracts/` are marked DRAFT/PROVISIONAL.
