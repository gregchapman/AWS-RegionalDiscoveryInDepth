---
inclusion: auto
---

# ADR-0032: Non-Disruptive Parallel Deployment; Terraform as Consumable Modules

Date: 2026-09-08
Status: Accepted (target-state)

## Context

The running POC (root `cli/`, `portal/`, `scripts/`, `terraform/`) is a live,
demonstrable system and must KEEP RUNNING untouched while the contract-first
platform is built. Separately, the current `terraform/03-api` is a monolithic
layer; the target is reusable modules composed by per-profile root deployments.
Refactoring the live layer IN PLACE would move Terraform state and change
resource addresses — risking destroy/recreate of the running demo. We need
module-first structure AND an undisturbed POC.

## Decision

**Build the platform as NEW, independently-stated artifacts beside the POC;
author modules FRESH by extracting POC patterns, never by moving POC state.**

1. **The POC is frozen-as-deployed.** No directory moves, no in-place refactor of
   the root `terraform/`, no `terraform apply` against it during platform work.
   It stays deployed and runnable exactly as-is. (If the POC ever must be touched
   again, its relative-path/script assumptions are reconciled first — but that is
   out of scope for platform work.)
2. **`platform/` is a sibling, not a move.** All new work lives under
   `platform/` (contracts, modules, live). Some duplication of pattern between
   POC and platform is expected and ACCEPTED — the POC is the "try it" reference;
   `platform/` is the "build your own" product.
3. **Modules are authored fresh from patterns, not from state.** `platform/
   modules/*` are written by extracting the PROVEN patterns from the POC (the
   conductor state machine, Lambda-behind-route, the DynamoDB table, the Cognito
   pool, the KMS + zero-inbound posture, the observability layer) — NOT by
   `terraform state mv` from the live stack. The POC's state is never touched.
4. **`platform/live/poc-commercial/` stands up ALONGSIDE the POC.** Own Terraform
   state, DISTINCT resource names; same account/region is acceptable for now
   (separate account is the production-honest target). Building/testing the
   platform never collides with or disturbs the running POC.
5. **Required baseline is composed automatically** in every `live/<profile>/`
   (ADR-0026 `_baseline/`), so "beside the POC" never means "without the
   compliance posture."

## Consequences

- POC demo integrity is guaranteed during platform development.
- Module-first structure from day one; the platform consumes modules rather than
  us refactoring later.
- Deliberate, bounded duplication between POC and platform (accepted tradeoff).
- Cutover (or long-term coexistence as "demo" vs "platform") is a later, explicit
  decision — not a side effect of building.

## Relates to

- Enables the `platform/` layout (README) and the phased delivery (ADR-0031).
- Leans on ADR-0030 (published-contract seams) for the portal/provider
  independent lifecycle. Consistent with ADR-0009 for the stable core.
