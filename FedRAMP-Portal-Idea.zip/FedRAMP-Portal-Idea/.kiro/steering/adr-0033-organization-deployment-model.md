---
inclusion: auto
---

# ADR-0033: Organization Deployment Model (control plane vs member accounts)

Date: 2026-09-08
Status: Accepted

## Context

The POC — and the first cut of `platform/` extracted from it — is a
SINGLE-ACCOUNT design in which AWS **regions stand in for tenants**. A caller
"picks an account" by picking a region; tenant isolation is enforced by EC2 tags
(`Customer` / `CustomerAccess`) *within one account*; every runtime Lambda uses
the deploying account's ambient credentials and varies only `region_name`.

The next real deployment is different in kind: a **third-party adopter standing
this up inside an AWS Organization** (many member accounts), coming to the code
COLD, in an environment the author cannot reach. "Regions as tenants" does not
survive that move — in an Org, **accounts are the tenant boundary**, and target
instances live in *member* accounts, not in other regions of the control-plane
account.

A code investigation (2026-09-08) confirmed the single-account assumption is
baked into the RUNTIME, not just config:

- `list_instances`, `provision_user`, `cleanup_user`, and the `ssm_credentials`
  tenant re-check all build `boto3.client("ssm"|"ec2", region_name=region)` with
  ambient credentials — **no cross-account `sts:AssumeRole`**. They can only see
  the control-plane account.
- The only runtime `AssumeRole` (`ssm_credentials` → session-broker role) is
  **same-account role chaining** to narrow privileges, not to cross an account.
- The session-broker role can only reach `arn:...:${account_id}:...` resources.
- `list_accounts` has a dev/simulated path (fake accounts from a region list)
  vs a live `organizations:ListAccounts` path, switched by `ENVIRONMENT`; it
  defaults to simulated.
- `live/poc-commercial/` parameterizes only regions + `name_prefix`; the account
  is discovered from `data.aws_caller_identity`. No account/OU/Org inputs, no
  cross-account providers, no per-member-account role.
- `_baseline` `enable_*` flags default OFF (the POC's Org already owns
  GuardDuty/Config/Security Hub); CloudTrail is a single-account trail, NOT an
  organization trail.

## Decision

**1. Adopt an explicit control-plane / data-plane split as the target model.**
- The **control plane** (portal SPA, Consumer API + authorizer, Cognito/IdP,
  DynamoDB score, KMS, the conductor Step Function, the access-broker Lambdas)
  deploys into ONE account — the **portal/control account** (may be the Org
  management account, a delegated-admin account, or a dedicated tooling account).
- The **data plane** is every **member account** that holds target EC2 instances.
- The tenant boundary is the **account**, not the region. `customer_id` in the
  identity assertion resolves to a real member **account id** (or an OU), not a
  region.

**2. Reaching member accounts is a published contract: the "target-account
role".** Each member account must contain an IAM role (the platform's
`target-access` role) that the control-plane Lambdas assume before any SSM/EC2
call. Its trust policy admits only the control-plane account's Lambda role(s);
its permissions are exactly what provision/cleanup/list/ssm-credentials need
(SSM SendCommand/GetCommandInvocation/StartSession/DescribeSessions/Terminate,
EC2/SSM describe, Parameter Store read for the CA pubkey). Roll it out with
CloudFormation StackSets (Org-managed) or an Org-level Terraform stack. This role
is the data-plane half of the Provider contract (ADR-0027) for the AWS provider.

**3. The single-account, region-as-tenant model is retained as a PROFILE, not
deleted.** It is the honest "getting started / demo / no-Org-access" profile
(`live/poc-commercial/`). The Org model is a distinct profile
(`live/org-*/`, to be authored) that supplies account/OU inputs and the
cross-account role. This matches ADR-0029 (profiles, not forks) and ADR-0031
(contracts provisional until a second implementation proves them).

**4. What ships TODAY vs what is DEFERRED (stated honestly, not hidden):**
- SHIPS: the design (this ADR), the *input seams* (account/org variables + the
  target-account-role contract documented), the cold-start `ADOPTER-GUIDE.md`,
  and truthful status docs. The single-account profile remains fully validated.
- DEFERRED (real engineering, must not be faked): the in-Lambda
  assume-and-fan-out across member accounts in the four runtime handlers; the
  StackSet that creates the target-access role; cross-account provider wiring;
  turning `customer_id` into an account id in the IdP; the org-trail decision in
  `_baseline`. A half-built cross-account path that silently returns empty
  results is WORSE than a clearly-documented boundary — so it is documented, not
  half-implemented.

## Consequences

Positive:
- An adopter gets a truthful map on day one: what works single-account now, what
  the Org model requires, and exactly which seams to fill — no false "it's
  multi-account" assurance.
- The target-account role as a *contract* keeps the cross-account trust explicit
  and least-privilege (AC-6), and keeps the AWS provider swappable (ADR-0027).
- The single-account profile still stands up for demos without an Org.

Negative / carried risk:
- The platform is **not** end-to-end multi-account functional yet. Until the
  deferred items are built, an Org adopter can deploy the control plane but
  cannot reach member-account instances. This is the top backlog item.
- `customer_id`-as-account-id requires IdP work (Cognito pre_token_generation or
  the federated IdP's claim mapping) that is not done.
- The control-plane account needs Organizations read (management or
  delegated-admin) for `list_accounts`; running it elsewhere returns AccessDenied.

## Follow-ups (backlog, in order)

1. Author `live/org-commercial/` (and GovCloud variants) with account/OU/Org-id
   inputs + cross-account provider or in-Lambda assume config.
2. Add the target-access role module + StackSet rollout.
3. Retrofit the four runtime handlers to assume the target-account role and
   fan out per member account.
4. Map `customer_id` → member account id in the identity assertion.
5. Decide `_baseline` per-account ownership + organization CloudTrail.
