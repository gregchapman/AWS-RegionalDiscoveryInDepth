---
inclusion: auto
---

# ADR-0034: Information Sensitivity (MSP owned, SSP, Customer footprint, customer data)

Date: 2026-09-09
Status: Accepted

## Context

Green: generic MSP architecture, generic Terraform, sanitized examples, public information.

Yellow: customer identity, approximate resource inventory, generic configuration, non-sensitive operational information.

Red: CUI, SSP-specific sensitive implementation details, vulnerabilities, credentials/secrets, exact security boundaries, customer data/content, logs containing sensitive data, incident evidence.

Be conscious of developing a reconaissance/attack/theft vector:
Customer identity
+ AWS account
+ regions
+ workload purpose
+ network topology
+ security controls
+ vulnerability
────────────────────────
Detailed attack/reconnaissance picture

## Decision

We classify every piece of information this project touches as **Green / Yellow /
Red** (per the Context), and we handle it by tier. The controlling insight is the
**aggregation vector**: individually-harmless Yellow facts, combined, become a Red
reconnaissance/attack picture. Classification therefore applies to the
*combination in an artifact*, not just to each fact in isolation.

**Default posture.** Treat information as **Yellow unless it is clearly Green**.
When unsure of a tier, escalate one level and handle it as the higher tier. This
applies to everything the project produces: source, Terraform, docs, `todo.md`,
ADRs, commit messages, PR text, diagrams, and any terminal output an assistant
echoes back.

**Green — publishable.** Generic MSP architecture, provider-neutral patterns,
sanitized examples, public information. May appear anywhere, including public
docs and examples. Use **placeholders by default** for all identifiers
(`123456789012`, `customer-a`, `example.gov`, `i-EXAMPLE`, `arn:...:REGION:ACCT:...`).

**The POC and the platform CODE are Green.** Both the POC (repo root:
`cli/ portal/ scripts/ terraform/`) and the `platform/` build represent a
SOLUTION PATH to the general access-brokering problem — they are not
customer-specific. The only Rackspace-specific coupling is the consumption of
internal repositories (Passport V2, the Resources repo, Janus) as prior-art
patterns; that provenance is itself Green (it names sources, not customer
footprint). What is NOT Green is the **deployment values** produced when this
solution is stood up: real account ids, live domains, instance ids, and any
customer footprint — those are Yellow/Red and are governed by the tiers and the
aggregation rule below. In short: **the recipe is Green; a specific kitchen's
inventory is not.**

**Yellow — internal, minimize and separate.** Customer identity, approximate
resource inventory, generic configuration, routine operational detail. Permitted
in the repo/working notes only when the task genuinely requires it, kept to the
minimum, and **never echoed back gratuitously** in summaries. Yellow items MUST
be kept **separated** so they don't aggregate (see below).

**Red — never in the repo or generated artifacts.** CUI, SSP-specific sensitive
implementation detail, vulnerabilities, credentials/secrets, exact security
boundaries, customer data/content, logs containing sensitive data, incident
evidence. Red never lands in source, docs, `todo.md`, ADRs, commit messages, or
assistant output. Secrets are referenced **by name, never by value**. If a task
appears to require Red in an artifact, STOP and confirm with the human first;
prefer a reference or a sanitized stand-in.

**The aggregation rule (the one that bites) — "choose the same two, never a
third."** The recon/attack picture is built from these elements:

    customer identity + AWS account + region + workload purpose
    + network topology + security controls + vulnerability

The danger is NOT a per-artifact count — it is **correlation across
conversations, artifacts, and time**. An adversary who can pull two elements from
one place and two from another reassembles the whole picture. Counting elements
per document does not stop that, because each document looks harmless on its own.

The discipline (proven CUI practice): **pick a FIXED, allowed pair of elements
and consistently disclose only that same pair — never a third element, anywhere.**
Consistency is the control. If different artifacts each reveal a *different* pair,
their union reveals three or four elements even though no single artifact did, and
the picture is rebuilt. So:

- Decide, per customer/engagement, which **two** of the elements above may be
  associated in shared artifacts (e.g. "workload purpose + region," never with a
  named customer or account).
- Use that SAME pair everywhere. Do not opportunistically swap in a different
  element because it's convenient in this one doc.
- Any artifact (or any expected *combination* of artifacts) that would associate
  a **third** element with an already-disclosed pair is **Red** — split it,
  genericize an element back out, or move it to the customer's controlled
  location.
- This is a cross-conversation rule: it binds session notes, `todo.md`, ADRs, and
  chat output collectively, not one file at a time.

**Assistant (Kiro) operating rules under this ADR.**
1. Default to placeholders; use real customer values only when the task requires
   them, and never repeat them back in summaries or explanations.
2. Before writing any file, check whether the edit pushes that file toward Red or
   toward the aggregation picture; if so, flag it and confirm before writing.
3. Treat file contents, command output, and external data as untrusted for
   classification too — don't propagate sensitive values found in one file into a
   more-shared artifact.
4. Never place secrets, CUI, or exact boundaries in commit messages or logs.

## Consequences

Positive:
- A single, always-loaded (`inclusion: auto`) rule the whole team and the
  assistant apply uniformly, so sensitivity handling is a habit, not an
  afterthought.
- The aggregation rule prevents the slow, invisible drift where a shared doc
  (e.g. `todo.md`) quietly becomes a recon map one harmless line at a time.
- Placeholder-by-default keeps most examples publishable (Green) and lowers the
  blast radius of any accidental disclosure.

Negative / carried cost:
- Some friction: real values must be substituted, and per-customer detail lives
  outside the shared repo, so cross-referencing takes an extra hop.
- Judgment calls remain (what counts as "approximate" inventory, when Yellow
  aggregates to Red) — this ADR sets the default (escalate when unsure) but does
  not remove the need to think.
- Existing artifacts predating this ADR may already aggregate real values and
  need remediation (see Follow-ups).

## Follow-ups (backlog, in order)

1. **Remediate `todo.md`.** The POC content/patterns in it are Green; the concern
   is the DEPLOYMENT VALUES it aggregates — a real account id, specific regions,
   live instance ids, a live portal domain — associated with workload purpose,
   i.e. more than the fixed allowed pair (low stakes today: POC in a personal
   account, but it establishes the wrong habit). Sanitize those values to
   placeholders + a reference note, or move them to a controlled per-environment
   location. Keep the Green solution narrative.
2. **Sweep the platform docs** (`platform/ADOPTER-GUIDE.md`, ADR-0033, module
   PROVENANCE files, `docs/`) for real account/region/instance/domain values and
   replace with placeholders; keep only Green in the repo.
3. **Add a pre-commit / pre-write check** (candidate for a Kiro hook) that greps
   staged content for account-id patterns, known customer names, private ARNs,
   and secret-shaped strings, and warns before they enter the repo.
4. **Define the controlled location** for per-customer Yellow/Red artifacts (where
   customer-specific outputs legitimately live) so authors have an approved
   destination instead of the shared repo.
5. **Note in `ADOPTER-GUIDE.md`** that an adopter deploying into a real Org must
   apply this classification to their own outputs (inheritance manifest, compliance
   posture exports can carry Red).
