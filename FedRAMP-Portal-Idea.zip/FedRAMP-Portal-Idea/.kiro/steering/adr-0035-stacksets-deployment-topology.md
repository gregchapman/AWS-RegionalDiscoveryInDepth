---
inclusion: auto
---

# ADR-0035: StackSets Deployment Topology + Template Separation

Date: 2026-09-09
Status: Accepted

## Context

The platform (ADR-0026..0033) was authored/validated as Terraform. Terraform and
CDK optimize for "one team, one product, few state files" — the DevOps shape. An
AWS **Organization** manager operating an enterprise-of-enterprises needs the
opposite: a PUSH model — define once in a management/delegated-admin account,
distribute to N member accounts by OU, auto-enroll accounts on join, manage drift
centrally. **CloudFormation StackSets** (service-managed, delegated-admin /
`OrganizationAccountAccessRole`-equivalent) is purpose-built for that; Terraform
is not. This is a fit-for-scope judgment, not a preference.

ADR-0033 already split the system into a **control plane** (one account) and a
per-member-account **target-access role** the control plane assumes. That role is
exactly the kind of homogeneous, wide, per-account artifact StackSets exists to
distribute. This ADR names the deployment topology that follows.

Two operational hazards drive the structure:

1. **StackSets + named IAM resources produce "already exists" failures.** IAM
   resources need DETERMINISTIC names here (ADR-0033 constructs the target-access
   role ARN without reading it back, so no CFN random suffix is allowed). But
   deterministic names remove CFN's natural collision-avoidance. When permissions
   change, a new `AWS::IAM::*` resource type is added to a template, or a
   service's API/privilege surface shifts, a template that CREATES an
   already-existing role/policy fails with "IAM ... already exists." StackSet
   operations are NOT transactional across accounts — the operation fans out,
   some accounts succeed and some fail, and you are left chasing the offending
   failed operation instances account-by-account. This is painful and it clusters
   on exactly the occasions you evolve IAM.
2. **Blast radius / capability coupling (secondary).** IAM-with-compute forces
   `CAPABILITY_NAMED_IAM` re-acknowledgement on every compute change, and a failed
   compute update can roll back IAM that other stacks depend on. It also welds the
   slow, security-reviewed IAM change cadence to the fast compute cadence.

## Decision

### 1. Two planes, two tools (not a wholesale swap)

- **Data plane — wide, replicated:** CloudFormation **StackSets**, service-managed,
  targeting OUs, run from the management or delegated-admin account. Distributes
  the per-member-account footprint (the target-access role, cross-account log
  wiring, any per-account baseline) and auto-enrolls new accounts.
- **Control plane — deep, singular:** a single, cohesive application deployed
  ONCE into the control-plane account (API, the conductor Step Function, Lambdas
  + layers, DynamoDB score, KMS, Cognito/IdP, SPA). This is the "one product"
  shape; it may remain Terraform, or be CFN/CDK if the Org team mandates one IaC
  language — either way it is a single-account app deploy, NOT a StackSet concern.

### 2. Four template families (two orthogonal axes)

Axis A — distribution scope: **Single-stack** (control account only) vs
**StackSet** (member accounts by OU).
Axis B — change class: **IAM** vs **Resources**.

|                         | IAM layer                                             | Resource layer                                                        |
|-------------------------|-------------------------------------------------------|-----------------------------------------------------------------------|
| **Control account (single stack)** | control-plane roles (broker-handler, provisioner, sfn-exec, session-broker, Lambda/API exec) | the application: API, Step Functions conductor, Lambdas + layers, DynamoDB score, KMS, Cognito, SPA, the unified dashboard |
| **Member accounts (StackSet by OU)** | the **target-access role** (trusts the control account); cross-account log-destination / subscription IAM | per-account footprint: CloudWatch Logs config, log forwarders/subscription filters, any local baseline |

Every template lands in exactly one cell. Nothing spans cells.

### 3. IAM is NEVER in the same template as resources — and WHY (do not get lazy)

**Primary reason:** the StackSet "already exists" failure above. If IAM lives with
compute, EVERY compute iteration re-runs the IAM create path across the whole
fleet and re-exposes the collision — and re-exposes it at fleet scale, per
operation instance. Isolating IAM into its own StackSet means (a) the IAM template
changes rarely and deliberately, so the fragile create-surface is touched far less
often; (b) when a collision does happen, the blast radius is one thin IAM StackSet
to remediate in isolation, not a role wedged inside the compute stack now blocking
a Lambda deploy; (c) compute churns freely because it never touches an
`AWS::IAM::*` resource.

**Secondary reason:** the capability/rollback coupling in Context §2.

**Mitigations (mandatory, not optional):**
- Keep IAM templates **additive and slow-changing**; review them on their own clock.
- Use **stable, deterministic IAM names** (required by ADR-0033) — and therefore
  manage collisions by PROCESS, not by random naming: prefer **importing** an
  existing role/policy into the StackSet over recreating it; expect and plan for
  "already exists" during IAM evolution.
- Never introduce a new `AWS::IAM::*` resource type into a resource template as a
  shortcut — it belongs in the IAM family, always.

### 4. Deterministic target-access role name

The member-account target-access role MUST have a fixed name
(`<name_prefix>-target-access`, no CFN-generated suffix), because the control
plane constructs its ARN per member account (`arn:${partition}:iam::${member}:role/<name_prefix>-target-access`)
without reading it back (ADR-0033 cycle-break). This is precisely what removes
CFN's collision-avoidance, which is why §3's discipline is mandatory rather than
nice-to-have.

### 5. CloudTrail consolidation — inherit by reference, do NOT rebuild

Consolidated CloudTrail is a solved, common pattern (an organization trail, or
turnkey via **Control Tower**). Per ADR-0020 (inherit the plumbing), we do NOT
rebuild it — the ADOPTER-GUIDE links to how to configure an org trail / Control
Tower and treats it as an inherited control. It is out of scope for our templates.

### 6. What we DO bake (product features of the C2 plane, not Org hygiene)

These are ours because they are the attributed command-and-control view spanning
accounts, not generic Org plumbing:
- **CloudWatch Logs consolidation** and **cross-account log-stream aggregation**
  to the control account (log-destination policy + subscription filters — the IAM
  half lands in the member-account IAM StackSet; the sink lands in the control
  account).
- A single **"rule them all" operational dashboard** in the control account.

### 7. Sequenced deploy ordering (a principle — IN this ADR, not just the guide)

StackSets have no cross-stack `DependsOn`, so ordering is an explicit, documented
sequence. The one-directional dependency is: **a role must exist before anything
that assumes/references it.** The order:

1. **Member-account IAM StackSet** — create the target-access role + log-wiring
   IAM in every member account (by OU). Slow, deliberate, security-reviewed.
2. **Member-account resource StackSet** — per-account log config/forwarders that
   reference the roles from step 1.
3. **Control-account IAM stack** — the control-plane roles (which trust / are
   trusted by the member roles).
4. **Control-account resource stack** — the application (Lambdas/conductor/API/
   score/KMS/Cognito/SPA/dashboard), referencing step 3's roles and constructing
   the step-1 role ARNs per member account.
5. **Log-aggregation wiring last** — connect member subscription filters to the
   control-account sink + light up the dashboard.

New accounts joining an OU inherit steps 1–2 automatically (service-managed
StackSets); the control plane picks them up because it constructs their
target-access ARN from the deterministic name — no control-plane redeploy needed.

The literal command-by-command runbook lives in `platform/ADOPTER-GUIDE.md`; the
ORDER and its rationale live here so they cannot be lazily reordered.

## Consequences

Positive:
- Fits the Org manager's real tooling (delegation, StackSets, OU targeting,
  auto-enroll) instead of forcing DevOps-shaped Terraform onto enterprise scope.
- IAM isolation minimizes exposure to the "already exists" trap and shrinks its
  blast radius to a thin, importable StackSet.
- Deterministic role naming + auto-enroll means new member accounts need no
  control-plane change.
- Control plane stays a clean single-account app deploy in whatever IaC the team
  prefers.

Negative / carried cost:
- Two tools and (at least) four template families to maintain — more moving parts
  than a single Terraform root.
- Ordering is manual/documented (no cross-StackSet DependsOn); getting it wrong
  fails predictably (a resource can't find its role) but still fails.
- "Already exists" during IAM evolution is reduced, not eliminated; operators must
  know the import-over-recreate remediation.
- The control-plane app authored as Terraform (ADR-0032) may need a CFN/CDK
  re-expression IF an Org team mandates one IaC language — a known, scoped
  follow-up, not done here.

## Follow-ups (backlog, in order)

1. Draft the four template families as skeletons under `platform/` (e.g.
   `platform/stacksets/{member-iam,member-resources}/` and
   `platform/control-plane/{iam,resources}/`), each with a header stating its cell
   and that IAM/resources never mix.
2. Author the ordered deploy runbook (steps 1–5) in `platform/ADOPTER-GUIDE.md`
   with the import-over-recreate remediation for IAM "already exists."
3. Decide the control-plane IaC: keep Terraform vs re-express as CFN/CDK for
   single-language Org teams (informs whether the control plane also becomes CFN).
4. Design the cross-account log-aggregation IAM (member subscription-filter role →
   control-account log destination) and the unified dashboard.
5. Reference org-trail / Control Tower CloudTrail setup in the guide (inherited).
