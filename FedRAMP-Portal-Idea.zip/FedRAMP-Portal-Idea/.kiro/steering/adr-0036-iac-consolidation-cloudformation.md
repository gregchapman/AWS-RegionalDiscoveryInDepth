---
inclusion: auto
---

# ADR-0036: IaC Consolidation to CloudFormation (supersedes the Terraform-first packaging)

Date: 2026-09-09
Status: Accepted

Supersedes-in-part: ADR-0032 (module-first authored in Terraform) and ADR-0035 §1
(which left the control-plane IaC language open). Those ADRs remain the record of
WHY the platform was decomposed the way it was; this ADR changes only the IaC
LANGUAGE the packaging is expressed in.

## Context

The platform modules + `live/poc-commercial` were authored in Terraform (ADR-0032)
to meet popular demand and to prove the module/contract decomposition. ADR-0035
then established that an AWS Organization manager — our paramount operator, since
this is a GOVERNANCE posture — needs the CloudFormation push model (StackSets,
service-managed, OU-targeted, auto-enroll) for the member-account data plane, and
left the control-plane language open.

Running two toolchains (Terraform control plane + CFN StackSet data plane) forces
the operator into two state models and two mental models. In a governance context,
operator fit and a single auditable substrate outweigh reuse of the Terraform
packaging.

Critically, the reuse rule (ADR-0032) already classified Terraform packaging as
the DISPOSABLE layer: "reuse code + bug fixes verbatim, re-author only packaging."
The proven, hard-won assets are IaC-AGNOSTIC — the Lambda handlers (carrying I8/I10
and the ADR-0023 verified-teardown contract), the Step Functions ASL, the four
contracts (OpenAPI + schemas), the IAM POLICY SHAPES, the KMS key policy, and the
Cognito configuration. Moving to CloudFormation re-authors only the packaging, in
the language the operator actually runs; it does not re-solve anything expensive.

## Decision

**1. The entire delivery is CloudFormation.** Both planes (ADR-0035):
- Member-account data plane → CFN StackSets (already mandated by ADR-0035).
- Control-plane application → CloudFormation, deployed once into the control
  account. Terraform is NOT used for new work.

Terraform is treated as cattle, not a prized cow: it served its purpose (demand +
decomposition proof) and is retired for delivery.

**2. Authoring form.** Raw CloudFormation YAML for everything StackSet-distributed
(member templates MUST be plain CFN, consumed natively by StackSets). The control
plane is also CloudFormation; CDK-synth-to-CFN is permissible for the control plane
IF the operator wants it, but the shipped artifact is CFN either way. Default to
raw YAML unless a team explicitly adopts CDK.

**3. The existing Terraform is LEFT IN PLACE, marked superseded — not deleted.**
`platform/modules/` and `platform/live/poc-commercial/` remain as (a) a validated
reference for the CFN translation and (b) provenance. They are cattle still
grazing, not slaughtered — deletion is irreversible cleanup with no upside now. A
short note in `platform/README.md` marks them superseded-for-delivery by CFN.

**4. What does NOT change (explicitly):**
- The contract-first product thesis (ADR-0026) and the four contracts — IaC-
  independent, untouched.
- The three-class module taxonomy, the control-plane/member split (ADR-0033), the
  four template families + IAM-never-with-resources + sequenced order (ADR-0035).
  Those were substrate-neutral; CFN inherits them wholesale.
- All reused application code + bug fixes (ADR-0032 reuse rule still governs; the
  ASL, handlers, policy shapes port verbatim).

## Consequences

Positive:
- One IaC language, one substrate, native to StackSets/Control Tower/delegated
  admin — the operator runs a single toolchain.
- No Terraform state to host/secure/back-up inside the boundary (TF state is itself
  a Yellow artifact under ADR-0034 — removing it removes a compliance surface).
- The CFN template families map 1:1 onto ADR-0035's matrix.

Negative / carried cost:
- Re-authoring the packaging layer in CFN is real (if mechanical) work; the
  validated TF does not deploy the delivery.
- CFN is more verbose than HCL; the DRY'd api-edge route `for_each` becomes CFN
  loops (or CDK) — a translation watch-item.
- Two representations coexist during transition (retired TF + new CFN) until the
  CFN is complete; the superseded note must be unambiguous to avoid confusion.

## Follow-ups (backlog, in order)

1. Mark the Terraform superseded in `platform/README.md` (pointer to this ADR); do
   NOT delete it.
2. Re-express ADR-0035's four template families as CFN skeletons:
   `platform/cfn/{member-iam,member-resources,control-iam,control-resources}/`,
   each header stating its cell + IAM/resources-never-mix + this ADR.
3. Port the reused assets into the CFN control-plane templates verbatim (handlers,
   ASL, policy shapes, KMS/Cognito config) — packaging only is new.
4. Ordered deploy runbook (ADR-0035 §7) into `platform/ADOPTER-GUIDE.md`.
5. Revisit whether `platform/live/` (TF) should eventually be archived once CFN
   reaches parity.
