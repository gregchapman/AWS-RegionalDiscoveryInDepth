---
inclusion: auto
---

# ADR-0037: Evidence and Assurance Plane — Prove the Control Claim, Not Just the Mechanism

Date: 2026-09-29  
Status: Accepted (build-now decision)  
Primary control: **CA-7 Continuous Monitoring**  
Supporting controls: **CA-2, AU-2, AU-3, AU-6, AU-9, AU-12, CM-6, RA-5, SI-4,
AC-2, AC-6**

## Context

The platform's product promise is not merely that it can open an SSM session.
It is that a customer, operator, auditor, or assessor can determine whether the
managed access capability is operating securely at a defined point in time.

The current ADR set establishes the ingredients:

- ADR-0020 prefers inherited AWS controls but rejects false assurance.
- ADR-0021 makes machine-readable evidence a first-class product output.
- ADR-0024 requires every command-and-control action to be attributable and
  logged.
- ADR-0029 requires explicit provider boundaries, profiles, and inheritance.
- ADR-0026 and the Consumer API reserve `/audit` and `/compliance` for consumers.

Those decisions do not yet define the thing an assessor will actually inspect:
the claim, its scope, its source, its freshness, its reviewer, its exceptions,
and its tamper-evident evidence references. A dashboard that says "secure" is
not proof. Missing telemetry must not become "compliant," inherited controls
must not become "our control," and a customer-specific exception must not be
hidden by a fleet-level aggregate.

The project therefore needs an explicit assurance plane before broader
enterprise consumption. "Prove customers are secure" is deliberately narrowed
to a defensible statement:

> For a named tenant/resource/provider and compliance profile, the platform can
> produce a current, attributable, integrity-protected assessment of each
> applicable control, including evidence, responsibility, exceptions, and
> human review state.

This is aligned to CA-7 rather than treated as a marketing feature. CA-7 is the
continuous-monitoring control; AU-6/AU-12 provide review and generation; CA-2
provides assessment discipline; AU-9 provides evidence protection; CM-6, RA-5,
SI-4, AC-2, and AC-6 provide the operational signals.

## Decision

Build an **Evidence and Assurance Plane** as part of the invariant Class 2 core.
It is required in every deployment profile and cannot be disabled by a portal,
provider, or customer integration.

### 1. Claims are scoped and typed

Every published security result MUST identify:

- control/framework/profile, for example `nist-800-53/moderate/CA-7`;
- authorization boundary and provider;
- tenant, resource, or fleet scope;
- responsible party: platform, AWS/inherited, organization, customer, or shared;
- result: `satisfied`, `not_satisfied`, `unknown`, `not_applicable`, or
  `exception`;
- observed time and validity/freshness deadline;
- evaluation rule and version;
- evidence references and source systems;
- reviewer/attestor, review time, and review state when human review is
  required;
- exception/POA&M reference when the result is not satisfied.

`unknown` is a real result. Absence, stale data, scope ambiguity, collector
failure, or an unverified inheritance assertion MUST NOT produce `satisfied`.

### 2. Evidence uses a canonical envelope

The platform will publish a versioned evidence schema under
`platform/contracts/schemas/`. An evidence item MUST be independently
traceable and include at least:

```json
{
  "evidence_id": "uuid",
  "control_id": "CA-7",
  "profile": "nist-800-53-moderate",
  "boundary_id": "aws-control-plane",
  "provider": "aws",
  "tenant_id": "tenant-reference",
  "resource_refs": ["arn:..."],
  "claim": "SSM-managed targets are continuously evaluated",
  "result": "satisfied",
  "source": "aws-config",
  "observed_at": "2026-09-29T12:00:00Z",
  "valid_until": "2026-09-29T13:00:00Z",
  "collector_version": "sha256:...",
  "evidence_refs": ["s3://evidence/.../object"],
  "evidence_hash": "sha256:...",
  "review": {"state": "automated", "reviewed_at": null},
  "exception_ref": null
}
```

The example is illustrative. Real tenant identifiers, account IDs, customer
data, credentials, and sensitive logs remain subject to ADR-0034. Evidence
storage MUST use encryption, retention, access control, versioning, and
tamper-evident integrity controls. The public/customer-facing view MUST be a
redacted projection, never a direct log bucket or unrestricted CloudTrail view.

### 3. Separate collection, evaluation, review, and publication

The plane has four explicit stages:

1. **Collection:** ingest CloudTrail, Config, Security Hub, GuardDuty, SSM,
   IAM, vulnerability, deployment, identity, and session-lifecycle facts.
2. **Evaluation:** apply versioned control tests against a named profile and
   scope; record pass, fail, unknown, and not-applicable results.
3. **Review:** route exceptions, ambiguous inheritance, high-impact failures,
   and human-procedure evidence to an accountable reviewer with a reason and
   expiration.
4. **Publication:** expose assessor export, operator operations, and customer
   summary views through distinct least-privilege projections.

The evaluator MUST retain the input facts and rule version used to produce a
claim. Re-running a rule after a control definition changes must not silently
rewrite historical evidence.

### 4. Define the human control chain

Automation proves machine-observable facts; it does not replace accountable
humans. Each control claim MUST identify the human or organizational owner for
the customer-responsibility portion. The workflow must support:

- control-owner assignment;
- reviewer approval for inherited-control and exception assertions;
- required justification and ticket/reference for privileged overrides;
- expiration and re-review of attestations;
- separation between the person changing configuration and the person accepting
  the risk where the profile requires it;
- an immutable history of claim, evidence, reviewer, decision, and supersession.

This directly addresses assessor heuristics: "who owns this?", "how do you know
this is current?", "what happens when collection fails?", "who accepted the
exception?", and "can the customer see the scope of the claim?"

### 5. Make freshness policy explicit per evidence class

Freshness is part of the profile, not an informal dashboard convention. The
initial implementation MUST define policy for at least:

- access/session events: near real time;
- configuration and identity posture: short periodic window;
- vulnerability and dependency posture: scheduled assessment window;
- human procedures and inherited controls: attestation expiry and review cycle.

The exact windows are profile inputs and must be visible in each claim. A claim
past `valid_until` becomes `unknown` until refreshed or explicitly re-attested.

## Required Build Now

Before publishing for broader enterprise consumption, implement these in order:

1. `evidence.schema.json` and `control-claim.schema.json`, versioned beside the
   existing resource and identity contracts.
2. A control catalog/profile registry mapping each claim to 800-53, owner,
   inheritance status, evidence sources, evaluator, freshness, and exception
   policy.
3. Structured audit events for every API read/write and system actor, as
   required by ADR-0024, with correlation IDs and durable retention.
4. Collectors for the initial AWS profile: CloudTrail, Config, Security Hub,
   GuardDuty, SSM session/command history, IAM/configuration, deployment
   artifacts, vulnerability results, and session teardown outcomes.
5. A versioned evaluator that emits `satisfied`, `not_satisfied`, `unknown`,
   `not_applicable`, and `exception` without fail-open behavior.
6. An append-only/evidence-integrity store with encryption, retention,
   cross-account protection, object/version hashes, and export manifests.
7. Three access-controlled views: assessor export, operator remediation, and
   customer security summary. Implement the `/audit` and `/compliance` contract
   paths only when backed by these stores.
8. Alerting and workflow for stale evidence, failed collection, failed controls,
   cleanup residuals, anomalous privileged actions, and expired exceptions.
9. Automated tests that intentionally create missing, stale, conflicting,
   cross-tenant, and tampered evidence and prove the result is denial or
   `unknown`, never false compliance.
10. A sample assessor package generated from a disposable deployment, including
    an inheritance manifest, evidence index, signed export, POA&M/exception
    references, and a reproducible generation record.

## What This Does Not Claim

- It does not create a FedRAMP authorization or replace an SSP, POA&M, or
  assessor judgment.
- It does not prove that every customer is secure in the abstract; it proves
  scoped control claims about defined resources and responsibilities.
- It does not treat AWS inheritance as total coverage.
- It does not expose customer-sensitive evidence to other tenants or make a
  customer responsible for platform-owned controls.
- It does not make the `/audit` or `/compliance` endpoints real merely by
  documenting them.

## Consequences

Positive:

- The platform can answer assessor questions with machine-readable, scoped,
  time-bounded evidence instead of narrative assurance alone.
- Trust-center content can be generated from the same evidence used by operators
  and assessors, reducing contradictory representations.
- `unknown` and exception states make control weakness visible instead of
  rewarding stale or incomplete telemetry.
- The evidence plane reinforces CA-7, AU-6, AU-9, AU-12, CM-6, RA-5, SI-4,
  AC-2, and AC-6 while preserving the profile/boundary model in ADR-0029.

Negative:

- This becomes a product subsystem with its own schema, storage, privacy,
  retention, availability, and incident-response requirements.
- Evidence collection can increase cost and cross-account integration work.
- A customer-facing summary must be carefully redacted and cannot be treated
  as the assessor package.
- The platform must maintain rule and schema compatibility across upgrades.

## Relationships

- Extends ADR-0020: inheritance must be recorded as a responsibility claim with
  evidence, not assumed.
- Implements the evidence product requirement in ADR-0021.
- Operationalizes ADR-0024's attributed C2 event stream.
- Supplies the audit/evidence plane named by ADR-0026 and ADR-0029.
- Complements ADR-0033: member-account evidence must be collected and retained
  across the control-plane/data-plane boundary.
- Preserves ADR-0034: evidence is classified and redacted before publication.