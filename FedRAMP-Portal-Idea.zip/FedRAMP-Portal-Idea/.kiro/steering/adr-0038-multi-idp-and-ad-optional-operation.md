---
inclusion: auto
---

# ADR-0038: Multi-IdP Federation and AD-Optional Operation

Date: 2026-09-29  
Status: Accepted (target-state; implementation staged)  
Controls: **IA-2, IA-4, IA-5, AC-2, AC-3, AC-6, AU-2, AU-3, CA-7**

## Context

The reference deployment currently uses a standalone Cognito user pool with
software-token MFA. That is a valid POC identity source, but it is not the
enterprise identity story. Customers may have a SAML IdP, an OIDC IdP, a
hardware-backed identity provider, or an existing AD-backed identity service.
Some customers may require more than one identity store during migration or
because different populations use different providers.

The AWS SSM access path does not require customer AD. It authenticates the
person through the portal identity boundary, maps the identity to a tenant and
assurance level, then creates a short-lived local host principal and brokers
the connection through SSM. AD trust is therefore a provider-specific
compatibility option, not a prerequisite for AWS access.

ADR-0028 already establishes identity by assurance rather than mechanism. This
ADR makes the deployment and lifecycle consequences explicit so that "multi-IdP
capable" does not become an unsupported marketing claim.

## Decision

The platform is **identity-provider neutral and AD-optional**.

1. The identity contract is the normalized assertion in ADR-0028. Authorization
   uses `issuer + subject`, tenant, groups, MFA, and `authn_assurance`; it never
   authorizes on email alone or on provider type.
2. A deployment may configure multiple SAML and/or OIDC providers. Cognito is
   the reference broker today; provider registration and claim mapping are
   configuration and adapter concerns behind the identity boundary.
3. Each provider MUST define mappings for subject, tenant, groups, MFA, and
   assurance. Missing or ambiguous mappings fail closed.
4. Provider registration MUST prevent accidental account linking. Two issuers
   producing the same email do not automatically represent the same principal.
5. Deprovisioning and disablement from every configured provider MUST be
   represented in the account-management and evidence workflows. Existing
   access sessions remain subject to authoritative session termination.
6. The AWS/SSM profile MUST operate without customer AD domain join, AD trust,
   VPN, or jump-host infrastructure. AD trust may be implemented inside a
   legacy provider boundary, such as transitional vCenter or Windows support,
   but it is not part of the AWS core.
7. The evidence plane records issuer, subject, provider, authentication method,
   assurance, tenant mapping, and provider lifecycle events without exposing
   raw upstream identity data to other tenants.

## Current status

- **Implemented:** Cognito reference provider, normalized identity contract,
  tenant/group authorization seams, SSM access independent of AD.
- **Designed:** multiple-provider contract, SAML/OIDC extensibility, assurance
  mapping, issuer-plus-subject identity keying, AD-optional AWS operation.
- **Not yet implemented:** federated provider resources, two-provider reference
  deployment, provider lifecycle synchronization, account-linking workflow, and
  phishing-resistant production IdP configuration.

The platform may be described as **extensible to multiple IdPs** now. It may be
described as **supporting multiple IdPs in production** only after at least one
SAML and one OIDC integration are exercised with cross-tenant and assurance
tests.

## Consequences

Positive:

- Customers can eliminate local AD from the AWS access path without giving up
  the option to use an existing enterprise identity store.
- Multiple identity stores can coexist during migration without changing the
  SSM broker or host authorization model.
- Identity assurance and attribution remain consistent across providers.

Required follow-up:

- Add provider registration resources and claim-mapping configuration.
- Add issuer-plus-subject lifecycle records and link/merge protections.
- Add SAML and OIDC integration tests, including disabled-provider and stale-
  session behavior.
- Require phishing-resistant assurance for production privileged roles.

## Relationships

- Extends ADR-0028 (identity by assurance, not mechanism).
- Implements the identity optionality phase in ADR-0031.
- Supports ADR-0021's customer access goal and ADR-0029's provider boundaries.
- Feeds ADR-0037 evidence claims and CA-7 continuous monitoring.