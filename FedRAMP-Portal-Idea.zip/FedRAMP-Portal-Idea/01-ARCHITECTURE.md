# Rackspace FedRAMP Portal ZTA Proof of Concept— Architecture, Design Rationale, and 800-53 Alignment

## Document Purpose

This document is the authoritative reference for another human (engineer,
auditor, assessor, or future-you) to understand:
- What this system is and what problem it solves.
- How it is built, deployed, and secured.
- Why each design choice was made (tracing to ADR numbers).
- How each deployed resource aligns to NIST 800-53 controls at FedRAMP
  Moderate / DoD SRG IL4, distinguishing AWS-inherited coverage from
  customer-implemented controls (per ADR-0020).

It is NOT a substitute for reading the ADR files (`.kiro/steering/adr-*.md`,
auto-included in every Kiro session) but provides the narrative and structure
those point-decisions lack on their own.

---

## 1. Problem, Goals, and Users (the "why")

*Full statement in ADR-0021. Summarized here so this document opens with why
before what.*

### 1.1 The problem

Privileged access to cloud workloads in regulated/government environments is
still dominated by the traditional model: **Active Directory + VPN + jump
hosts**, or a server-rendered management portal. That model is pervasive across
the industry, and it is a poor fit for cloud:

- **It will not satisfy FedRAMP 20x cleanly.** The Rev 5 → 20x transition
  emphasizes continuous, automated, machine-readable control evidence. Standing
  VPN tunnels, shared or weakly-bound identities, and jump-host fleets do not
  produce clean per-action attribution or continuous evidence without heavy
  bolt-on effort.
- **It imposes cost and consumption penalties.** VPN concentrators, jump-host
  fleets, and AD infrastructure cost money to run, patch, and secure — and they
  constrain WHICH parts of the cloud can be consumed and HOW they are managed.
  The access layer becomes a bottleneck, not an enabler: the traditional model
  effectively **devalues engagement with the cloud**.
- **It widens the attack surface.** A jump host is a server to breach; a VPN is
  a persistent network path granting broad reachability once entered; standing
  access lingers past its need.

We deliver equal-or-better functionality WITHOUT that baggage — including
**phishing-resistant MFA** — while producing exactly the attributable,
machine-readable evidence a 20x posture wants. (See §2 for how the Single-Page
Application model and the zero-trust broker together replace the VPN/jump-host
model.)

### 1.2 The offering

A zero-trust, just-in-time, identity-attributed access portal, offered
**exclusively within the Rackspace Government Services (RGS) organization** — a
distinct entity from the rest of Rackspace. It is a gov-specific evolution of
Rackspace Commercial MSP's **Passport V2**: it mirrors Passport V2's proven
patterns (Step Functions + SSM + DynamoDB lifecycle, SSH Certificate Authority)
but is a SEPARATE, in-boundary build for FedRAMP/GovCloud (ADR-0013), keeping the
government authorization boundary clean.

### 1.3 Three first-class users

This is not a single-audience app. Each perspective shapes the design:

| User | Needs | Design impact |
|------|-------|---------------|
| **ATO auditors** | Machine-readable compliance evidence | Audit trail is a PRODUCT OUTPUT (who/what/when/how/which authenticator + resource control state). Directly serves Rev 5 → 20x. |
| **Rackspace engineers / operators** | Fast, attributable, least-privilege access to support customers — usually driven by **ServiceNow tickets** | Every action tied to a real person (ADR-0011), ideally to a ticket; ephemeral, just-in-time. |
| **Customers** | A portal to securely access their own resources without AWS creds or a VPN | Self-service within guardrails; scoped strictly to their own tenant. |

### 1.4 Hard invariant — tenant isolation

**Customer1 must NEVER see anything about Customer2, and vice versa.** Inviolable,
not a toggle. Enforced via customer_id scoping, fail-closed instance-visibility
filtering, session-ownership checks, and (in production) hard account/boundary
separation. Any change that could weaken cross-tenant isolation is rejected by
default.

### 1.5 Trajectory

- **ATO-additive + 20x-anticipating.** Capability expansion is ADDITIVE to the
  existing RGS FedRAMP Moderate / IL4 ATO — ride within the authorized boundary,
  never force re-authorization; growth flows through **SCN (Significant Change
  Notification)** processes. Built in anticipation of the Rev 5 → **FedRAMP 20x**
  change, which is why machine-readable evidence and inherited controls
  (ADR-0020) are foundational.
- **Expand what customers can do (via SCN).** Today: shell/RDP sessions on their
  EC2 instances. Tomorrow: AWS console access and other AWS services. The
  architecture must not preclude this.
- **Multi-cloud and private cloud.** As Rackspace already manages commercial
  customers spanning OpenStack, Google, AWS, etc., RGS intends the same single
  managed access model across heterogeneous targets — other public clouds AND
  private cloud (VMware vCenter, OpenStack). This is why the provider/adapter
  architecture (ADR-0016) exists: AWS-EC2 + SSH-CA is provider #1; a vCenter or
  OpenStack ConnectionProvider is additive, with the same portal, identity
  model, and audit posture.

---

## 2. What the Portal Is

A **zero-trust access portal** replacing AD + VPN + jump hosts for RGS FedRAMP
environments. It brokers just-in-time, identity-attributed access to virtual
machines (and eventually multi-account console) for two audiences:

- **Racker engineers** (multi-account, multi-region) — full SSM + console.
- **Customers** (scoped to their own resources) — VM access, expandable.

The portal does not hold long-lived credentials or maintain persistent sessions
to target hosts. It provisions ephemeral, identity-named OS users and issues
short-lived SSH certificates — so every action is attributable to a real person
in OS logs, CloudTrail, and SSM session history.

---

## 3. What "SPA" (Single-Page Application) Means, and Why It Beats the VPN Model

**SPA = Single-Page Application.** The portal's user interface is a React
application (TypeScript, Vite, Tailwind CSS) that ships as a set of static
files (HTML, JavaScript, CSS, images) and runs entirely in the user's browser.
There is no server-side rendering, no application server serving HTML — the
browser downloads the static shell once, then communicates with the backend API
exclusively via authenticated JSON REST calls.

### Why this matters architecturally:
1. **The SPA is PUBLIC — the API is PRIVATE.** The static shell (`index.html` +
   hashed JS/CSS) must be available to unauthenticated browsers so users can
   reach the login page. All *data* flows through JWT-authorized `/api/*`
   routes. This split drives the authorization model on the front door: the
   `$default` route (SPA assets) is `authorization_type = NONE`; the `/api/*`
   routes are `JWT`.
2. **Same-origin eliminates CORS (ADR-0019).** By serving the SPA and the API
   from a single host (`portal.<domain>`), the browser treats them as same-
   origin — no cross-origin requests, no CORS headers, no pre-flight OPTIONS.
   That is less attack surface, less to misconfigure, and a cleaner SC-7
   boundary.
3. **Client-side routing requires SPA fallback.** Routes like `/racker`,
   `/customer`, `/callback` are not real files on disk — they exist only in
   the JavaScript router. The server (our SPA-serving Lambda) must return
   `index.html` (HTTP 200) for any extensionless path that isn't a real asset,
   so the client router can render the correct view. This replaces CloudFront's
   custom-error-response trick.
4. **Static assets are immutable once built.** Vite produces content-hashed
   filenames (e.g. `assets/index-abc123.js`). These can be cached indefinitely
   (`max-age=31536000, immutable`). Only `index.html` must never be cached
   (it references the current hashed assets).
5. **Unlike a VPN client, there is no locally installed application** to maintain.
    Interactions are HTTPS only and use Layer 7 encapsulation and cryptography 
    client/server communications. No direct SSH tunneling, etc.

### 3.1 SPA is NOT a VPN — and that is the point

It is easy to conflate two different things. Be precise:

- **Single-Page Application (SPA)** is a *UI-delivery model*: how the user
  interface reaches the browser (static files, rendered client-side).
- The **zero-trust broker** (Cognito auth → API Gateway → Step Functions → SSM
  → SSH-CA) is the *access model*: what actually replaces the VPN + jump host.

They are different claims, and they reinforce each other. This document keeps
them distinct so an assessor is not misled.

A **VPN** establishes a persistent, authenticated **network path**: once
connected, the client is "on the network" and can reach whatever that network
segment exposes (often far more than the one host it needs). A jump host is a
long-lived server sitting in that path — something to patch, harden, monitor,
and ultimately breach. Access tends to be standing (granted, then lingering).

The **SPA + broker** model grants **no network path at all**:
- The UI is a static Single-Page Application. There is **no application server
  and no jump host to VPN *into*** — nothing persistent to breach. The browser
  holds only a short-lived JWT and talks to an authenticated API.
- Access to a host is **brokered per session**, not via a tunnel: the portal
  provisions an identity-named ephemeral OS user, issues a short-lived SSH
  certificate, and opens an SSM Session Manager tunnel to exactly one instance.
  There is no "on the network" — only "authorized to this one host, right now,
  as this person, for this long."
- Authentication uses Cognito with **phishing-resistant MFA** — a materially
  stronger authenticator posture than the shared-secret / OTP-over-VPN norm.

### 3.2 Why this is a significant improvement over the traditional model

Baseline = the pervasive **AD + VPN + jump host** (or server-rendered portal)
model. The SPA + broker approach is better on every axis that matters for a
government cloud offering:

| Dimension | Traditional (AD + VPN + jump host) | SPA + zero-trust broker |
|-----------|-----------------------------------|------------------------|
| Attack surface | Jump host + VPN concentrator + AD to breach; broad network reach once in | No server/jump host to breach; zero inbound ports; access scoped to one host per session |
| Standing access | Common (tunnels + accounts persist) | None — just-in-time, auto-expiring |
| Attribution | Often shared/weakly bound; hard to tie an action to a person | Identity-named ephemeral users + cert KeyId = the person (ADR-0011) |
| Authenticator | Passwords / OTP; phishing-prone | Phishing-resistant MFA; passwordless SSH certs (ADR-0014) |
| Evidence for 20x | Bolt-on, manual, incomplete | Machine-readable, per-action, continuous (a product output) |
| Cost | VPN concentrators + jump-host fleet + AD infra to run/patch | Serverless; scales to zero; no fleet |
| Cloud consumption | Access layer constrains what/how of the cloud is used → devalues cloud | Access is an enabler; expands safely (via SCN) to console + services |
| Patching burden | Continuous (servers, concentrators, AD) | Managed services; little/nothing to patch |

The net: **we deliver equal-or-better functionality, at lower cost, with a
smaller attack surface, and with the attributable machine-readable evidence that
FedRAMP 20x rewards** — instead of the traditional model that penalizes cloud
consumption and produces evidence only with heavy effort.

---

## 4. System Architecture

### 4.1 High-Level Flow

```
User's Browser
     │
     ▼
Route 53 (public DNS, portal.takahe.click)
     │  A-alias
     ▼
API Gateway HTTP API v2 (REGIONAL endpoint, TLS 1.2)
│   (no edge WAF — WAFv2 can't attach to HTTP API v2; SC-7 gap, see §8)
├── $default route → serve_spa Lambda → private S3 bucket (SPA assets)
│                     └─ 302-redirects CLI binary requests to a presigned S3 URL
│                        (cli/releases/…; binaries exceed the 6MB Lambda cap)
├── /api/* routes  → [JWT authorizer (Cognito)] → handler Lambdas
│   ├── GET  /api/accounts       → list_accounts
│   ├── GET  /api/instances      → list_instances (parallel, multi-region)
│   ├── POST /api/connect        → create_access_request → Step Functions
│   ├── GET  /api/session/{id}   → get_session_status
│   ├── GET  /api/sessions       → list_sessions
│   ├── POST /api/sign           → sign_key (SSH CA — ADR-0014)
│   ├── POST /api/credentials    → ssm_credentials → session-broker role
│   │                              (vends short-lived, single-instance STS creds —
│   │                              ADR-0012; re-validates customer_id vs the live
│   │                              instance Customer tag, fail-closed — AC-6(5))
│   └── POST /api/session/{id}/terminate → terminate_session (writes end-demand
│                                          status; the state machine acts on it)
└── Custom domain (portal.takahe.click) + ACM regional cert
     │
     ├─────────────► passport CLI (Go): its OWN Cognito SRP + MFA login
     │               (never accepts a handed-over token — IA-2, ADR-0016);
     │               `passport connect` (SSH) / `--rdp` (SSM tunnel to 3389)
     ▼
Step Functions (access lifecycle state machine — ADR-0022 poll-loop)
├── Provision user (region-aware Lambda → SSM SendCommand)
│   ├── Linux: identity-named, passwordless, CA-trust installed
│   └── Windows: identity-named, generated password
├── Poll loop: Wait 30s → getItem(status) → Choice
│   │   • status != ACTIVE (terminate/revoke wrote it)  → Cleanup
│   │   • now ≥ expires_at_iso (TTL)                     → Cleanup
│   │   • else                                           → loop
│   └── makes termination AUTHORITATIVE (AC-12): the machine DETECTS the end
│       demand instead of relying on a best-effort stop_execution call
└── Cleanup user (region-aware Lambda → SSM SendCommand; idempotent)
     │
     ▼
Target EC2 Instances (private subnets, SSM-only, zero inbound ports)
├── us-east-2: customer1 (Linux + Windows)
└── us-west-1: customer2 (Linux + Windows)
```

### 4.2 SSH Certificate Flow (ADR-0014)

```
Browser                    API (/api/sign)              Instance
  │                              │                         │
  ├─ Generate ed25519 keypair    │                         │
  ├─ POST /api/sign {pubkey} ──► │                         │
  │                              ├─ Load CA privkey from   │
  │                              │   Secrets Manager       │
  │                              ├─ Look up access-request │
  │                              │   (DynamoDB; validates  │
  │                              │    ownership, TTL, type)│
  │                              ├─ Build OpenSSH cert:    │
  │                              │   ValidPrincipals=[user,│
  │                              │   request_id]           │
  │                              │   KeyId=passport_<user> │
  │                              │   _<epoch>              │
  │                              │   TTL=min(remaining,1h) │
  │                              ├─ Sign with CA key       │
  │  ◄── cert (OpenSSH format) ──┤                         │
  │                              │                         │
  ├─ ssh -i <privkey> -o CertificateFile=<cert> ──────────►│
  │                              │                         ├─ sshd validates
  │                              │                         │  cert against
  │                              │                         │  TrustedUserCAKeys
  │                              │                         │  (CA pubkey installed
  │                              │                         │   at provision time)
  │                              │                         ├─ Login as identity-
  │                              │                         │  named user (no pwd)
```

### 4.3 Terraform Layer Structure

| Layer | Purpose | Blast-radius isolation |
|-------|---------|----------------------|
| 00-backend | S3 state bucket + DynamoDB lock | State infrastructure — never changes after bootstrap |
| 02-portal-hosting | Private SPA bucket + Route 53 zone + ACM cert | DNS/hosting substrate — changes rarely (prevent_destroy on zone/cert/bucket) |
| 03-api | HTTP API Gateway (front door), Cognito, Lambdas, DynamoDB, Step Functions, KMS, SSH CA | Application logic — most frequent changes |
| 04-test-environment | VPC + EC2 (multi-region) + SSM VPC endpoints | Test infra — changes only when adding regions/instances |
| 05-security-baseline | CloudTrail, SSM session logging (GuardDuty/SecurityHub/Config org-gated) | Security services — deploy once, rarely touch |

Dependencies flow backward only (02 < 03, etc.) per ADR-0009.

---

## 5. How We Decide Under Conflicting Controls (ADR-0022)

Access-control design routinely produces conflicts: Passport V2's proven pattern,
an 800-53 control, and usability pull in different directions (SSH cert vs.
password; role-chaining's forced 1h credential; storing vs. vending a Windows
password; best-effort vs. authoritative session termination). Rather than
re-deriving an answer ad hoc each time, every such decision in this system is
resolved by one **strictly-ordered hierarchy** (ADR-0022). A later rule always
overrides an earlier one.

| Rule | What it says | Applied here |
|------|--------------|--------------|
| **1. Passport V2 is the default (prior art)** | Where production Passport already solves a problem, MIRROR it — read the source, copy the mechanism. Prior art is the starting point, not the ceiling; it also prevents over-engineering. | SSM tunnel + native-client RDP; CLI UX + installer shape; Step-Functions/SSM/DynamoDB lifecycle. |
| **2. Adapt the pattern to satisfy 800-53** | Passport was not built for FedRAMP. Where the pattern falls short of a required control, EXTEND it — never discard the pattern, never ship the gap. | CLI does its OWN Cognito+MFA instead of accepting a handed-over token (IA-2); vend endpoint adds an independent connect-time tenant re-check (AC-6(5)); artifacts checksum-verified on install (CM-5/SI-7/SA-10). |
| **3. On conflict, choose lowest residual risk — and DOCUMENT it** | When two controls conflict, or a control conflicts with the pattern or usability, pick the option with the lowest residual security risk and record the tradeoff in `ARCHITECTURE-WEAKNESSES.md` and/or the ADR. Prefer **eliminating** the risky element over mitigating it; prefer **short-lived/vended over stored**; prefer **no-secret over secret**. "Document it" is mandatory — an undocumented tradeoff is a finding waiting to happen. | See the two worked examples below. |

This is the single, defensible decision method an assessor can trace: every
non-obvious choice reduces to one sentence per level — *"Passport does X; control
Y required Z; we chose W as lowest-risk, residual R."*

### 5.1 Worked example — Windows/RDP password (SC-28 / IA-5(1))

- **(1) Prior art:** Passport RDP = SSM tunnel to 3389 + native client + username/password.
- **(2) Control conflict:** a stored plaintext password violates SC-28 and weakens IA-5(1).
- **(3) Lowest-risk tiebreak:** the password is intrinsic to the native-RDP pattern, so it can't be eliminated without abandoning prior art (Fleet Manager/DCV is a roadmap item pending GovCloud + Identity-Center reconciliation). Lowest-risk adaptation that keeps the pattern: **vend a short-lived Windows password on demand** (the Windows analog of the STS-credential and SSH-cert vends), never stored long-term. **Interim residual (documented):** the password is still read from the stored record and the vend-on-demand backend is not yet built — tracked in §8 and `ARCHITECTURE-WEAKNESSES.md`. The SPA drawer no longer displays it; the CLI is the single source of truth.

### 5.2 Worked example — authoritative session termination (AC-12)

- **(1) Prior art:** the lifecycle Step Function waits for the TTL, then cleans up — a single `Wait ttl_seconds`.
- **(2) Control conflict:** AC-12 / AC-2(3) want termination to be RELIABLE. Ending early relied on a best-effort `stop_execution` call; if that call was skipped or the session ended via client-TTL or operator-revoke (which don't invoke that handler), the execution sat RUNNING as an orphan. Best-effort termination does not satisfy AC-12.
- **(3) Lowest-risk tiebreak:** make the machine DETECT the end demand instead of depending on an external call reaching it. Replaced the single Wait with a **poll-loop** (Wait → getItem status → Choice: status != ACTIVE OR past expiry → cleanup; else loop). Terminate now just writes status; the machine self-terminates within one interval.
- **(4) Refinement (ADR-0023) — one conductor, one convergent teardown:** the poll-loop was right, but responsibility was still scattered. `terminate_session` also ran its own cleanup AND called `states:StopExecution`, which *aborted the state machine before it wrote the terminal state* — stranding records at `CLEANING_UP` (81 `Aborted` executions). Fixed structurally: the Step Function is the **sole conductor** — it verifies each worker's actual result before advancing (cleanup must report `verified: OK`; `INCOMPLETE` after bounded retry becomes the terminal `CLEANUP_FAILED`, never a silent `COMPLETED`) and it owns all four teardown concerns including the SSM tunnel (`ssm:TerminateSession`). Every end-trigger (portal End, operator revoke, CLI local exit, TTL) writes the SAME end-demand and converges on the SAME verified teardown. `states:StopExecution` is forbidden and its IAM grant removed. Poll `Wait` shortened to 10s. **Residual (documented):** ≤~10s detection latency + one cheap getItem per interval per active session — traded against orphaned sessions, orphaned users/profiles/tunnels, and cleanups that masked failure as success.

---

## 6. ADR Posture Summary (0001–0025)

| # | Decision | One-line rationale |
|---|----------|-------------------|
| 0001 | AWS-native over third-party | Inheritable controls, zero vendor cost, own the roadmap |
| 0002 | Regions as test boundaries | Single account POC; proves access model without org complexity |
| 0003 | Passport V2 patterns | Step Functions + SSM + DynamoDB, proven at scale |
| 0004 | Serverless backend | Scales to zero, no servers to patch, managed-service control inheritance |
| 0005 | Cognito for portal auth | JWT authorizer on API GW. POC: standalone pool (test users). Production: federate to a real IdP (SAML/OIDC) — see §8 IdP-federation row |
| 0006 | Zero inbound ports | SSM outbound only, attack surface eliminated |
| 0007 | RGS Government branding | Navy/white/red, WCAG 2.1 AA |
| 0008 | Self-documenting tfvars | Auditor-readable, no mystery defaults |
| 0009 | Cross-layer remote state | Auto-reads outputs, backward deps only |
| 0010 | Security baseline as layer 05 | Deploy once, single ownership surface |
| 0011 | Govern the local principal | Identity-named, role-scoped, cert-auth, ephemeral, correlated |
| 0012 | CLI-broker access pattern | Users need no AWS creds; portal brokers SSM |
| 0013 | Build gov-specific Passport | In-boundary; don't reuse commercial Passport |
| 0014 | SSH Certificate Authority | Passwordless, attributed, kills SC-28/IA-5 for Linux |
| 0015 | Go for crypto/CLI, Python for CRUD | Mature x/crypto/ssh, prod parity |
| 0016 | Provider/adapter architecture | IdentityProvider + ConnectionProvider interfaces |
| 0017 | Portability by config, not code | tfvars swap for any environment |
| 0018 | Credential context: deploy WITH, test WITHOUT | personal-faws discipline |
| 0019 | Partition-intersection palette + no CloudFront | One pattern in both partitions; no global edge |
| 0020 | Prefer inherited controls | Default to managed AWS; deliberate only when two valid options or posture goes negative |
| 0021 | Product vision, users, and scope | RGS-exclusive Passport-V2 evolution; three users (auditor/operator/customer); ATO-additive + Rev5→20x; SCN expansion; multi-cloud via providers; tenant isolation is an inviolable invariant |
| 0022 | Design decision hierarchy | Passport prior art (mirror) → adapt to satisfy 800-53 (extend, don't ship the gap) → on conflict choose lowest residual risk AND document it. Strictly ordered; a later rule overrides an earlier one. This is the decision method in §5. |
| 0023 | Session lifecycle — one conductor, one convergent teardown | Step Function is the sole conductor: verifies each worker before advancing, owns all four teardown concerns; every end-trigger submits an end-demand (no caller teardown); `states:StopExecution` forbidden; `CLEANUP_FAILED` surfaces residuals instead of masking them. Extends 0022 §5.2. |
| 0024 | Command-and-control plane: every action attributed + logged | The portal is a C2 plane; every action (reads included, CloudTrail-style) is attributed (who/what/which/when/whence) and logged — no anonymous actions. Privileged on-behalf-of actions additionally require a fail-closed justification. Attribution enables AU-6 detection; it is not itself prevention. |
| 0025 | One authoritative session record per connect + operator lens | The CLI creates the single session record (portal Connect provisions nothing); every live session is visible to and terminable by an authorized operator within tenant scope (ADR-0021), with a mandatory reason on operator revoke. Relies on 0024; builds on 0023. |

Full text in `.kiro/steering/adr-NNNN-*.md` (auto-included in sessions).

---

## 7. FedRAMP Moderate / IL4 Boundary Rationale (ADR-0019)

### The governing principle

Use ONLY services that exist and behave identically in BOTH `aws` (commercial)
AND `aws-us-gov` (GovCloud). This gives one ATO story and one codebase that
runs unmodified in either partition — customer placement (commercial for
CONUS-only, GovCloud for IL4) is a deployment choice, never an architecture
fork.

### What is PROHIBITED and why

| Banned service | Reason |
|---------------|--------|
| Amazon CloudFront | Not a GovCloud service; global edge PoPs are non-CONUS, non-US-person administered → violates SC-7 (boundary), SC-8 (transmission confidentiality), SA-9 (external system), PE (physical), AU (audit data leaves boundary) |
| AWS Global Accelerator | Same class: commercial-only global-edge anycast |
| API Gateway edge-optimized endpoints | Uses CloudFront under the hood (AWS docs confirm) — silently reintroduces the banned service |

### What replaces them (intersection-safe)

API Gateway (REGIONAL) + ACM regional cert + AWS Shield + Route 53 public DNS.
All in-region, CONUS-administered (in GovCloud). DDoS resilience comes from Shield
(not a global edge). WAFv2 REGIONAL is in this intersection palette too, but note
it can only attach to a WAF-capable edge (ALB or REST API v1), NOT to the HTTP
API v2 front door — that is the SC-7 gap tracked in §8.

---

## 8. 800-53 Control Compliance Status (design-scoped)

This is the single, authoritative control view for this system. It lists ONLY
the controls that this design actually implements, touches, or must reason about
— not the full FedRAMP Moderate baseline. Controls whose entire burden is carried
by AWS's P-ATO are summarized once at the end (Inherited) rather than enumerated.

Each control carries one **Status**:

- **Compliant** — implemented and working in the POC (commercial account
  675405875014); production-hardening may still apply but the control is met.
- **Inherited** — satisfied by AWS (commercial FedRAMP / GovCloud P-ATO). We
  still own the configuration side, noted where relevant (ADR-0020).
- **Traded-off** — a conflict was resolved deliberately under the ADR-0022
  hierarchy (Passport prior art -> 800-53 -> lowest residual risk). We chose the
  lowest-risk option and DOCUMENTED the residual. This is a *decision*, not an
  oversight.
- **Needs-development** — a real gap with a known solution path; not yet built.
  POC-vs-production scope is called out.

The full narrative gap register (with severities) lives in
`ARCHITECTURE-WEAKNESSES.md`; the decision method behind every "Traded-off" row
is §5 (ADR-0022).

**POC scope (read this before the matrix).** This is an ADVANCED POC that proves
the access model and the control mechanisms — it is not a production target as
built. Several elements are demonstration-only and are expected to change in a
production build: the standalone Cognito user pool (production federates to a
real IdP — customer or Rackspace — via the ADR-0016 `IdentityProvider` seam); the
React portal UX (experimental; a production front end may differ, and the
Teleport-style clientless-RDP option is tracked in `feature-requests.md`);
regions-as-tenant-boundaries (production uses account-based isolation, ADR-0002);
and the single-account log/monitoring plane. The whole design is deliberately
MODULAR and provider-abstracted (ADR-0016) so these swap without re-architecting.
Where a control is "proven in POC, production requires X," the row says so inline.
"Compliant (POC)" therefore means the control MECHANISM is demonstrated in the
commercial POC account, not that this deployment is production-ATO-ready.

### 8.1 Access Control (AC)

| Control | What it demands here | Status | Basis / residual / path |
|---------|----------------------|--------|-------------------------|
| **AC-2** Account Management | Portal-user lifecycle (create/disable/delete) + ephemeral OS-account cleanup | Compliant (POC) | Cognito user pool is the identity store; onboard/revoke/delete procedures in `docs/OPERATOR-RUNBOOK.md`. Ephemeral OS users/profiles (ADR-0011) are now removed by the conductor's VERIFIED teardown (ADR-0023) — a cleanup that can't confirm removal becomes `CLEANUP_FAILED`, not a silent success, so orphaned accounts surface instead of hiding. Automated single-action management is AC-2(1) below. |
| **AC-2(1)** Automated Account Management | One action to onboard/revoke, not a manual sequence | Partially compliant (Traded-off) | The operator lens (ADR-0025) now gives a Racker a tenant-scoped view of every live session and a one-click, attributed + justified revoke (mandatory ticket #, fail-closed) — the SESSION side of revoke is now a portal action, not a runbook. Verified in code: `list_sessions ?scope=all` (Rackers-only, 403 for non-Rackers), `terminate_session` requires a reason for operator revoke. STILL Needs-development: the account side (disable/delete the Cognito user) is NOT folded into the same action — no `cognito-idp` AdminDisable/Delete call exists; it remains the runbook — and Cognito-token-invalidation latency (~1h) remains. **Caveat (tenant-scope completeness):** the session's tenant tag (`customer_id`) is stamped at connect time FAIL-OPEN — if the instance Customer-tag lookup fails, the record carries `customer_id=""` and a tenant-filtered operator query won't match it (the session still appears in an unfiltered Racker view). This is a visibility-completeness gap, not an access gap (access is gated fail-closed at list + vend time). Path: extend the operator action to also disable Cognito + an IR-4 "revoke ALL" fan-out; consider making the tenant stamp reconcilable. |
| **AC-2(7)** Privileged Account Monitoring | Monitor/alert on privileged (Racker) use | Needs-development | No break-glass alarm on broad Racker access yet. Path: CloudTrail alarm on privileged actions + intermediate (non-admin) Racker roles. |
| **AC-3** Access Enforcement | Every data route authorized | Compliant | API Gateway JWT authorizer on all `/api/*`; only the public SPA shell (`$default`) is unauthenticated. |
| **AC-4** Information Flow | Constrain network paths | Compliant | Zero-inbound SGs; SSM outbound 443 only; no VPN network path. Inherited fabric: VPC isolation. |
| **AC-5** Separation of Duties | No single actor authorizes AND self-grants top privilege | Compliant (by scope) | Enforced operationally (ADR-0018 deploy-vs-test split) and by the DC-provisioning prohibition (auto-minting domain admin is denied by default). Automated SoD tooling is future. |
| **AC-6 / AC-6(1)** Least Privilege | Scoped identities and IAM | Compliant | Identity-named ephemeral OS users (ADR-0011); per-Lambda scoped policies; session-broker vends single-instance STS creds (ADR-0012). |
| **AC-6(5)** Second Authorization Check | Independent re-check at connect time | Partially compliant (Traded-off) | The credential-vend path (`ssm_credentials`) re-validates the caller's `customer_id` claim vs the instance's LIVE `Customer` tag, fail-closed (missing claim, tag mismatch, or a lookup error all deny; Rackers exempt) — independent of the request record, at the last gate before AssumeRole. The vended STS session policy is further scoped to `ssm:StartSession` on the ONE target instance plus tag-conditioned Terminate/Resume, so the holder can only touch THEIR session (AC-6/AC-6(1) least privilege at runtime). **Open:** RDP/browser paths that don't route through the vend endpoint don't get this second check. Path: enforce the same re-check in a shared authorizer. (Note: `create_access_request` also stamps `customer_id` on the record now, but that stamp is fail-OPEN and is for operator-lens scoping, NOT an access gate — the access gates are list-time + this vend-time check.) |
| **AC-12** Session Termination | Ending a session is RELIABLE, not best-effort, and VERIFIED | Compliant | ADR-0023 conductor: the Step Function self-detects an end-demand (status != ACTIVE) or TTL and runs ONE teardown within ~10s. It advances to `COMPLETED` only on a confirmed `verified: OK`; an unverifiable cleanup becomes terminal `CLEANUP_FAILED` (surfaced for AU-6), never a silent `COMPLETED`. **Precisely what `verified` gates:** the login session, the ephemeral OS user, and the profile/home — all three must be confirmed gone (Windows: account + profile folder + no lingering session; the hardened script force-logs-off disconnected RDP sessions and unloads the profile hive, then verifies — the fix for the I10 orphaned-account bug). **SSM tunnel teardown is best-effort and does NOT gate verification** — a lingering tunnel is harmless once the OS user is gone, so it is torn down and logged but never fails the cleanup. Every end-trigger (portal End, operator revoke, CLI local exit, TTL) converges on the same teardown. `states:StopExecution` is forbidden (aborting the conductor was the prior stranding cause). ADR-0025 makes termination reliable for operators too: a Racker can SEE and end any user's live session (tenant-scoped), so "find the session to terminate" is no longer owner-only. Every end is attributed (`ended_by`/`ended_by_id`/`end_source`/`end_reason`); operator revoke requires a mandatory reason (fail-closed). Extends the ADR-0022 §5.2 poll-loop. |
| **AC-17** Remote Access | Authorized, encrypted, attributed remote access | Compliant | SSM Session Manager (encrypted, no inbound ports) + short-lived SSH certs; every session attributed to a person. |

### 8.2 Identification & Authentication (IA)

| Control | What it demands here | Status | Basis / residual / path |
|---------|----------------------|--------|-------------------------|
| **IA-2 / IA-2(1)** User ID + MFA | MFA on access | Compliant (POC) | Cognito `mfa_configuration = ON` with `software_token_mfa` (TOTP) enforced for all users; the `passport` CLI performs its OWN Cognito USER_SRP_AUTH + SOFTWARE_TOKEN_MFA (no handed-over token). **Note:** POC uses TOTP; production target is phishing-resistant MFA via a real IdP (see the IdP-federation row). **Automated-testing posture (planned):** functional tests will authenticate as a dedicated test identity holding a KNOWN TOTP seed (stored in Secrets Manager) and compute REAL, valid codes — MFA stays fully enforced; there is deliberately NO MFA-bypass code path in the product (a stored/fake-code bypass was considered and rejected as an IA-2 control weakening). This makes the test suite itself positive evidence that MFA works end-to-end unattended. |
| **IA-4** Identifier Management | Unique, attributable identifiers | Compliant | Identity-named ephemeral OS users (ADR-0011); KeyId on the SSH cert = the person; RoleSessionName = identity. |
| **IA-5** Authenticator Management | Manage secrets/keys | Compliant (Linux) | Linux is passwordless via the SSH CA; CA key in Secrets Manager (KMS). RDP is the exception -> IA-5(1). |
| **IA-5(1)** Password-Based Auth (RDP only) | Avoid/protect passwords | Traded-off | ADR-0022 §5.1: native-RDP requires a password. We keep the Passport tunnel+client pattern and the drawer no longer shows the password (CLI prints it). **Residual:** the password is still stored (see SC-28). **Path:** vend-on-demand (never stored) or passwordless RDP (Fleet Manager/DCV). |
| **IdP federation** | Enterprise identity (e.g. EntraID) with phishing-resistant MFA | Needs-development (by design — POC boundary) | Today Cognito is a STANDALONE user pool (built-in directory, test users) — a deliberate POC choice, not a production target. Production is intended to federate to a real IdP (customer IdP or Rackspace IdP) with phishing-resistant MFA. The `IdentityProvider` seam exists by design (ADR-0016) precisely so this swaps in without re-architecting; no federation module is built yet. This is the primary example of the "modular, reusable architecture" intent: identity source, MFA type, and even the front-end UX are meant to be replaceable at the provider boundary. |

### 8.3 Audit & Accountability (AU)

| Control | What it demands here | Status | Basis / residual / path |
|---------|----------------------|--------|-------------------------|
| **AU-2 / AU-3 / AU-12** Event logging + content + generation | Who/what/when/outcome across the stack | Compliant (session lifecycle); attribution principle set (ADR-0024) | CloudTrail (multi-region, log-file validation), SSM session logs, API GW / Step Functions / Lambda logs, and a DynamoDB access-request record per session with full attribution. Session END is now attributed on the record itself (`ended_by` / `ended_by_id` / `end_source` / `end_reason`), with operator revoke carrying a mandatory reason (ADR-0025). The `end_source` taxonomy is specific — `self:portal` / `operator:portal` / `cli:exit` / `system:ttl` — so the record shows not just WHO but by which path the session ended (AU-3 content). Attribution integrity: `get_user_from_event` resolves identity via a fallback chain (email → custom:email → cognito:username → sub) so attribution degrades to the immutable Cognito `sub` rather than to "unknown" (IA-4). **ADR-0024** sets the plane-wide stance — the portal is a command-and-control plane, so EVERY action (reads included, CloudTrail-style) must be attributed + logged, and privileged on-behalf-of actions must carry a fail-closed justification. **Open (Needs-development):** the ADR-0024 attribution/logging retrofit is not yet applied uniformly across all endpoints (currently ad-hoc per handler + the one structured audit log in `ssm_credentials` and the attributed terminate); the shared audit-emit helper + read-path logging is the tracked follow-up. |
| **AU-6** Audit Review / Alerting | Logs actively watched, not just stored | Partially compliant (POC) | An operator single-pane-of-glass CloudWatch dashboard exists (layer `06-observability`): a unified Logs Insights timeline of all portal actions + lifecycle/API/Lambda metrics. **Open:** no alarms/SIEM feed yet, and the POC dashboard is single-account/single-region scoped. **Production path:** a dedicated **monitoring account** with CloudWatch **cross-account observability** (query source accounts in place) — because prod uses **account as the base tenant boundary, region next** — plus CloudWatch Alarms + SNS on failed auth / anomalous API / unexpected-instance sessions, and a subscription-filter fan-in (or OpenSearch) for durable machine-readable 20x evidence. |
| **AU-9** Audit Log Protection | Logs an admin cannot tamper with | Needs-development (production) | Single-account POC: an account admin could delete a trail. Path: production sends to an Organization trail in a separate log-archive account. |
| **AU-9 / AU-11** Record retention vs. operational TTL | Terminal/failure states must remain evidenced | Compliant (audit) / Needs-development (operational view) | IMPORTANT distinction: the DynamoDB session record is OPERATIONAL state and is reaped by its `expires_at` TTL. A `CLEANUP_FAILED` (or any terminal) record can therefore disappear from the live operator view once its TTL fires — this is how the I10 orphaned Windows accounts came to have no record. The PERMANENT audit evidence does NOT disappear: the cleanup Lambda logs `CLEANUP RESIDUAL: ...` to CloudWatch Logs, and the SendCommand + full Step Function execution are in CloudTrail — both retained independent of the DynamoDB TTL. So this is a MONITORING/RECONCILIATION gap (a failure drops off the live view before it's necessarily actioned), not an audit-loss gap. Path (under 800-53 review): do not TTL-reap non-terminal records, and/or retain terminal records for the audit window; add an AU-6 alarm on `CLEANUP_FAILED` so a residual is actioned before its record ages out. |

### 8.4 System & Communications Protection (SC)

| Control | What it demands here | Status | Basis / residual / path |
|---------|----------------------|--------|-------------------------|
| **SC-5** DoS Protection | Absorb/mitigate DDoS | Inherited | AWS Shield Standard (automatic L3/L4). Shield Advanced is an opt-in production option. |
| **SC-7** Boundary Protection (edge WAF) | A WAF inspecting traffic at the front door | Needs-development | The WAFv2 ACL was REMOVED from the code: WAFv2 cannot associate to an API Gateway **HTTP API (v2)**. **Path:** front the HTTP API with an ALB or a REST API (v1) edge (a supported WAF target) and attach a REGIONAL WAF. Interim protection: Cognito JWT + API GW throttling + Shield Standard. Do NOT reintroduce CloudFront (ADR-0019). |
| **SC-7** Boundary (network) | No standing network path; scoped reach | Compliant | Zero inbound ports; SSM brokers access to exactly one host per session; no VPN. |
| **SC-7(5)** Deny by Default (IP allowlist) | Restrict source ranges at the edge | Needs-development | No IP allowlist today (needs a WAF-capable edge first — see SC-7). Path: WAFv2 IP-set on the ALB/REST edge restricting to Rackspace/agency CIDRs. |
| **SC-8 / SC-8(1)** Transmission Confidentiality | TLS everywhere | Compliant | TLS 1.2 floor on the custom domain (ACM); SSM tunnels encrypted. |
| **SC-12 / SC-13** Crypto / Key Management | Approved crypto, managed keys | Compliant / Inherited | KMS CMKs (separate keys for credentials vs SSH CA), rotation on; FIPS-validated HSMs are inherited. |
| **SC-23** Session Authenticity | Resist token replay | Traded-off | ADR-0016 closes the ORIGIN for the CLI (no handed-over token; CLI does its own MFA). **Residual:** a minted bearer token is replayable for its ~1h life. **Path:** DPoP/mTLS proof-of-possession + shorter TTL + anomalous-use monitoring (AU-6). |
| **SC-28** Protection at Rest | Encrypt stored data/secrets | Compliant, except RDP password (Traded-off) | S3 SSE-KMS, EBS encrypted, CA key in Secrets Manager. **Exception:** the RDP `temporary_password` is stored plaintext in DynamoDB (ADR-0022 §5.1). **Path:** vend-on-demand (don't store) or KMS-encrypt the field. Linux stores no password at all. |

### 8.5 Configuration Management & System Integrity (CM, SI)

| Control | What it demands here | Status | Basis / residual / path |
|---------|----------------------|--------|-------------------------|
| **CM-3 / CM-5** Change Control | Auditable, controlled change | Compliant | All infra is Terraform, layered for blast-radius isolation (ADR-0009); `prevent_destroy` on stateful resources; change via code review. |
| **CM-5(1)** Signed/controlled provisioning logic | Provisioning is versioned + integrity-checked | Partially compliant | CLI artifacts are checksum-verified on install (SI-7/SA-10). **Open:** provision/cleanup scripts are inline in the Lambdas. Path: move to versioned `aws_ssm_document` resources. |
| **CM-6 / CM-8** Config Settings / Inventory | Enforced baseline + inventory | Compliant / Inherited (org) | IMDSv2 required on all EC2; Config rules (required-tags, ssm-managed, restricted-ssh) deploy when the org enables Config. POC defers to the org recorder. |
| **SI-4** System Monitoring | Detect anomalies | Needs-development | Ties to AU-6 (no alarms yet) and SC-7 (no WAF telemetry at the edge). Same remediation paths. |
| **SI-7** Software/Info Integrity | Detect unauthorized changes | Partially compliant | CLI install is download-verify-checksum. Broader integrity monitoring (Config/GuardDuty) is org-managed; enable in production. |

### 8.6 Contingency & Availability (CP)

| Control | What it demands here | Status | Basis / residual / path |
|---------|----------------------|--------|-------------------------|
| **CP-9 / CP-10** Backup / Recovery | Durable state, recoverable service | Compliant / Inherited | DynamoDB PITR + TTL; S3 versioning + lifecycle; API GW / DynamoDB are managed multi-AZ. Single-region management plane is a documented reliability limit (production: multi-region). |

### 8.7 Incident Response (IR)

| Control | What it demands here | Status | Basis / residual / path |
|---------|----------------------|--------|-------------------------|
| **IR-4** Incident Handling (kill switch) | Terminate all sessions / revoke on compromise | Needs-development | Per-session terminate IS authoritative (AC-12), and a MANUAL operator revoke procedure exists (`docs/OPERATOR-RUNBOOK.md`). **Open:** a one-click "revoke everything" break-glass. Path: an emergency-revoke endpoint (stop all executions + cleanup + disable tokens). |

### 8.8 Risk Assessment (RA)

| Control | What it demands here | Status | Basis / residual / path |
|---------|----------------------|--------|-------------------------|
| **RA-5** Vulnerability Scanning | Scan deps + hosts | Needs-development | No scanning of Lambda deps or EC2 yet. Path: Inspector for EC2; `pip-audit`/`safety` (Python) and `govulncheck` (Go) in CI. |

### 8.9 Tenant Isolation (ADR-0021 hard invariant)

| Concern | What it demands here | Status | Basis / residual / path |
|---------|----------------------|--------|-------------------------|
| Instance visibility scoping | Customer1 never sees Customer2 | Compliant (POC, code-verified) | `list_instances` fail-closed: a customer with no `customer_id` sees nothing; otherwise filtered to `CustomerAccess=true AND Customer==customer_id`. SPA routes customers to a customer-only view. (Live customer-login proof pending — SoD.) |
| Hard account boundary | Isolation enforced by account, not just tags/code | Needs-development (production) | POC uses regions + tags + IAM as boundaries (ADR-0002). Path: per-tenant account/boundary separation in production. |
| Tag integrity | Scoping tags cannot be forged/altered | Needs-development | No enforcement that `Customer`/`CustomerAccess` tags can't be changed. Path: SCP + Config rule protecting tag integrity. |

### 8.10 Physical & Personnel (PE, PS) — fully Inherited

| Controls | Status | Basis |
|----------|--------|-------|
| PE-2…PE-20, PS-1…PS-8 | Inherited | Fully carried by AWS's P-ATO in both commercial FedRAMP and GovCloud. GovCloud adds US-person-only administration (ITAR/EAR). Customer responsibility is limited to choosing the correct partition (ADR-0019). |

---

## 9. Where to Find Gap Status

There is deliberately no second list of gaps here — a competing table would
drift out of sync with §8. Per-control status (Compliant / Inherited /
Traded-off / Needs-development) is the matrix in **§8**. The full narrative gap
register, with severities and remediation detail, is **`ARCHITECTURE-WEAKNESSES.md`**.
The decision method behind every "Traded-off" verdict is **§5** (ADR-0022).

---

## 10. Deployment Model

### POC (current, commercial partition, account 675405875014)

- Domain: `takahe.click` (portal host: `portal.takahe.click`).
- Partition: `aws` (commercial). Regions: us-east-1 (management), us-east-2 +
  us-west-1 (customer simulation per ADR-0002).
- Layer 02: creates zone + cert (`manage_dns=true`, `manage_certificate=true`).
- Layer 03: API Gateway front door serves SPA + API; SSH CA; credential-vend
  endpoint (ADR-0012). No edge WAF (WAFv2 can't attach to HTTP API v2 — the
  SC-7 remediation is an ALB/REST edge; see §8).
- Cost: ~$3/yr domain; everything else scales to zero or pennies.
  Auto-renew OFF on domain (wallet protection).

### Production (future, GovCloud partition)

- Domain: agency-issued `.gov` or equivalent.
- Partition: `aws-us-gov`. Regions: GovCloud CONUS.
- Layer 02: `manage_dns=false`, `manage_certificate=false` — consumes a
  pre-existing hosted zone + imported (non-auto-renewing) ACM cert.
- Same code, different tfvars (ADR-0017). Provider selection via config
  (ADR-0016). Partition-safe ARNs throughout.

---

## 11. Glossary

| Term | Definition |
|------|-----------|
| SPA | Single-Page Application — a client-side-rendered web app shipped as static files; runs in the browser, calls a backend API for data. |
| Same-origin | The SPA and the API share one host/port/protocol; the browser does not require CORS for the API calls. |
| SSM | AWS Systems Manager — specifically Session Manager (encrypted tunnels to instances without inbound ports). |
| SSH CA | SSH Certificate Authority — signs short-lived OpenSSH user certificates so access is passwordless and attributed via KeyId. |
| Ephemeral user | An OS-level user account created at connect time and destroyed at session end; identity-named per ADR-0011. |
| Authorization window | The access-request TTL (15min–12h); within this window the user can reconnect by re-signing a fresh cert. |
| Authenticator | The SSH certificate itself (max 1h); short-lived, re-issued within the authorization window. |
| Partition intersection | The set of AWS services available in BOTH commercial and GovCloud — the only services this system is allowed to use (ADR-0019). |
| Inherited control | A 800-53 control whose service/infrastructure portion is satisfied by AWS's P-ATO; customer still owns configuration/operation (ADR-0020). |
