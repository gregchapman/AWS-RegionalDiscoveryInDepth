# AI Compliance Development Priorities

**Assessment date:** October 1, 2026  
**Purpose:** Consolidate the four supplied assessments into a product development and assurance roadmap, checked against current platform source and official guidance.  
**Conclusion:** The platform has a credible architecture and substantial AWS access and evidence code. It has not yet delivered the complete production security contract. Keep SSM Agent, Session Manager and the client SSM Plugin as the mandatory shell/RDP access core. Complete tenant isolation, role-scoped privilege, identity assurance and machine evidence retrieval; then prove the same core against EC2 and VMware-hosted guest VMs. The current record supports continued development, not a production compliance or vendor-exit claim.

---

## Executive Summary for the Funding Decision

*This summary is written for a go/no-go investment decision. It states what exists, what is proven versus authored-but-unproven, and what remains. It deliberately avoids optimistic language; the detailed grades and evidence anchors are in the sections below.*

**What was built.** A working AWS proof of concept that gives an authenticated user time-limited, identity-attributed shell/RDP access to a private EC2 instance with no VPN, no jump host, no customer Active Directory, and no standing cloud credentials — using AWS SSM as the access channel. On top of that POC, a substantial, contract-first **platform** was authored as CloudFormation (the shipping delivery form): the access broker, the session-lifecycle conductor with verified teardown, KMS/DynamoDB/Cognito foundation, an HTTP API with a published contract, and an **evidence/assurance plane** (machine-readable control claims, collectors, evaluator, durable storage, audit stream, and tenant-safe compliance/audit projections). The architecture and its decision records (ADRs) are a genuine strength and have survived four independent AI technical reviews.

**What is actually proven.** The AWS/EC2 access path is exercised end-to-end in the POC. The platform code is authored and statically validated (handlers compile, templates lint, the evaluator's regression tests pass). **Nothing in the platform has been deployed or exercised in a live AWS Organization.** "Validated" here means the code is structurally sound, not that its runtime behavior or security effectiveness has been demonstrated.

**The honest gap between promise and runtime.** Four independent reviews converged on the same conclusion: the design is sound; the risk is enforcement and proof, not feasibility. Specific, confirmed code-level gaps the next funded work must close:
1. **Privilege is not yet least-privilege** — provisioned accounts currently receive blanket administrator/root rights; the approved role is not carried through to provisioning.
2. **Operator accountability is incomplete** — an operator can act on another user's session on some paths without a mandatory justification as part of the session request.
3. **Durable audit is not wired on two key paths** (credential vending, inventory) — a code defect, not a design gap.
4. **Tenant isolation is single-account/tag-based today**; the production account-boundary model is designed (ADR-0033) but not wired end-to-end for cross-account reach as a compromise because of lack of Organization access.
5. **Identity is Cognito/TOTP in the reference profile** — the multi-IdP, phishing-resistant assurance model is designed (ADR-0038) but not yet proven with a real federated IdP. Cognito is used as a compromise that also tests openness to use of IdP of choice.

**What this means for compliance claims.** The work maps credibly to many NIST 800-53 control outcomes and aligns well with the FedRAMP 20x direction (just-in-time access, machine-readable evidence). It does **not** constitute a FedRAMP authorization, a completed 20x certification, or a validated vendor-exit (RSA/AD/VPN) claim. Those require a defined boundary, deployed evidence, and independent assessment that have not been performed. Describe the platform as *aligned with and building toward* these outcomes, not as meeting them.

**The remaining runway.** The ordered work packages in Section 6 (P0-1 through P1-5) define the path: fix and test the authorization/entitlement kernel and audit (P0-1, P0-2); make evidence evaluation truthful (P0-3); finish and prove cross-account tenant isolation (P0-4); prove identity neutrality with real IdPs (P0-5); deliver unattended machine evidence retrieval (P0-6); then deploy and exercise the whole thing in a production-shaped test Organization (P0-7). A second provider (VMware) is the strategic milestone that proves the "any cloud" claim (P1-5). The companion AGILE charter (`AGILE/access_platform_delivery_proposal.md`) turns this into gated increments (G0–G4) with a 48-story backlog for execution planning and cost estimation.

**The decision in front of leadership.** This is a well-architected, substantially-implemented initiative at the boundary between "proven AWS POC" and "deployed, assessable product." Continued funding buys the enforcement, multi-account, identity, and evidence-proof work that turns a strong design into a demonstrable, assessable service. The most efficient first-funded increment is the authorization-and-audit kernel plus a live Organization deployment, which converts the largest share of unproven claims into tested behavior. The record supports a decision to continue; it does not support presenting the current state as production-ready or certified.

---

## 1. Scope and evidence discipline

This revision grades progress against [ARCHITECTURE.md](docs/ARCHITECTURE.md), [ONE-PAGER.md](docs/ONE-PAGER.md), and [TARGET-ARCHITECTURE.md](docs/TARGET-ARCHITECTURE.md). These documents define the goals; current platform code determines implementation grades. The user’s clarified requirement controls the transport boundary: **all supported shell/RDP access uses SSM; provider adapters do not replace that path.**

The current product baseline is `platform/cfn`, supported by `platform/contracts`, governing ADRs, and product architecture documents. The assessment excludes root `terraform/`, `portal/`, POC scripts, and superseded `platform/modules` / `platform/live` implementations from current-product grades. The CLI interfaces were inspected only to understand integration boundaries; their historical implementation is not used to rate the CloudFormation product.

The consolidation uses all four requested reports:

| Source | Contribution | Treatment in this consolidation |
|---|---|---|
| [AmazonQ analysis](AmazonQ-analysis-of-POC.md) | Historical deployment observations and possible control concerns | Explicitly a POC assessment. No reported POC pass/fail, account configuration, or remediation is carried forward as a current product finding. |
| [Claude project audit](Claude-proj-audit.md) | Architecture strengths, delivery maturity, evidence-plane inventory, operational gaps | Retain product-relevant findings after checking the CFN implementation; qualify claims that relied on POC behavior. |
| [Codex architecture and evidence audit](Codex-analysis-FedRAMP-Access-Platform-Architecture-Implementation-Evidence-Audit-2026-09-30.md) | Security-outcome decomposition, contract boundaries, assurance model, invariant-based roadmap | Primary architectural synthesis; target-state claims remain distinct from implemented enforcement. |
| [Tenant authorization assessment](Tenant-Authorization-Pilot-Assessment.md) | Current CFN authorization defects and bounded remediation proposal | Primary current implementation findings, independently corroborated in source where discussed below. |

Evidence labels in this document mean: **designed** = contract/ADR intent; **implemented** = inspected authored code or templates; **locally verified** = a check run during this consolidation; **operationally proven** = deployed behavior with retained evidence. No new AWS deployment, account inspection, external integration, or live access test was performed. Earlier reports' deployment observations do not establish the current platform's deployed effectiveness.

This assessment checks the current platform against the stated goals. It does not calculate a compliance completion percentage. This is a focused repository verification of the access, identity, evidence, and delivery boundaries, not an exhaustive control assessment. No application or infrastructure code was changed.

## 2. Product goals and architectural strength

The intended product supplies an attributable, authorized, time-bounded administrative session to a specific resource, then verifies removal of the granted authority and publishes evidence of the result. Consumers should choose their identity system, authenticators, UI, and downstream evidence tools through documented contracts.

The target chain is:

`trusted identity and assurance → tenant/entitlement decision → JIT lifecycle → scoped provider and host authority → connection → verified termination → correlated evidence`

The most valuable architectural choices are:

- **Identity by assurance:** policies depend on verified security properties and stable identity rather than an authenticator brand.
- **Resource-specific access:** the user receives authority for an approved target and period rather than general network placement.
- **Ephemeral authority:** short-lived credentials and temporary host principals reduce standing access.
- **Authoritative lifecycle:** termination is a demand to the conductor, with verified cleanup and visible failure semantics.
- **Separate boundaries:** providers and deployment profiles identify their own dependencies and assurance responsibilities.
- **Evidence as a product surface:** observations, claims, freshness, scope, ownership, and exceptions can be exposed to consumers and assessors.

These choices provide a credible security model. Their value depends on enforcing the contracts throughout the actual request path and proving the resulting behavior under failure, revocation, and adversarial conditions.

### Replacement of traditional access patterns

| Traditional function | Product replacement | Scope and remaining qualification |
|---|---|---|
| AD identity and group lookup for administrative access | External IdP assertion, normalized identity, tenant and entitlement policy | AWS access is designed to be AD-optional. This does not replace AD's application authentication, domain policy, device management, or other enterprise functions. |
| VPN network reachability | Target-scoped SSM management channel | Can remove VPN dependence for supported administrative sessions. SSM agent registration, IAM, and outbound service connectivity remain required. It does not replace every use of a VPN. |
| Jump-host administrative choke point | Broker authorization, temporary credentials, lifecycle control, audit correlation | Can remove the AWS administrative bastion. Equivalent attribution, privilege restriction, termination, and activity telemetry must be evidenced. |
| Fixed MFA product or gateway | Customer-selected IdP/authenticator satisfying the required assurance | MFA remains necessary where the profile requires it. The product replaces dependence on a particular MFA stack, not the authentication security function. |
| Standing local/domain administrator credentials | Temporary local principal, SSH certificate or Windows session credentials | Present CFN provisioning grants blanket administrator membership; role-scoped privilege is still required. Windows also uses a generated password, so universal passwordless access is not implemented. |
| Periodic manual evidence assembly | Automated collection, evaluation, and programmatic publication | Authored foundation exists; complete, fresh, safely retrievable certification data remains unfinished. |

AWS documents Session Manager's ability to manage nodes without inbound ports or bastion hosts. The product's SSH/RDP tunnel still uses the relevant host protocol, with the listener reachable through SSM. “No inbound administrative exposure” means no administrator-to-target network ingress requirement, not absence of a host listener. [AWS Session Manager](https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager.html).

The AWS implementation provides a credible mechanism for replacing this administrative access pattern. The product must carry that same SSM pattern to supported non-EC2 guests. Different hosting providers may require different discovery, registration and authorization integrations; every supported guest still needs SSM Agent and approved connectivity to Session Manager.

## 2a. Grades against the stated architecture goals

These grades measure delivery against the project’s own goals, not certification. **Design alignment** assesses whether the approach addresses the goal. **Delivery grade** identifies the strongest evidence in the current product: **Implemented foundation** means code expresses the principal mechanism but deployment proof remains; **Partial** means code exists but omits or contradicts a required property; **Designed** means contracts or decisions establish the approach without a working integration; **Unverified** means the record cannot establish the outcome. No grade represents a percentage of FedRAMP controls satisfied.

| Goal and source | Design alignment | Current delivery grade | Assessment and completion gate |
|---|---|---|---|
| Remove VPN, jump hosts and inbound guest administrative exposure — Architecture §§1–3; One-Pager claim | Strong | Implemented foundation | CFN provisions temporary guest identities and vends SSM access. Verify target ingress, permitted SSM connectivity and complete Linux/Windows access in the current deployment. |
| Keep SSM as the invariant access core — Target §1a; clarified requirement | Strong in required architecture; conflicting contract text | Partial | AWS code uses SSM. Contract/ADR passages allow other transports. Align those contracts, then prove non-EC2 guest access through SSM rather than introducing another broker. |
| Remove customer AD deployed solely for VM access — Architecture §1; One-Pager claim | Strong | Implemented foundation | Local guest identities and SSH certificates remove the access path’s domain-membership requirement. Validate Windows and Linux behavior; retain AD where applications or unrelated customer functions need it. |
| Permit customer-selected IdPs and MFA; avoid mandatory RSA or equivalent — Target §§1a, 3.3 | Strong | Designed | Assurance contract supports the goal; current CFN identity processing remains Cognito-specific and does not enforce normalized assurance. Prove two real IdPs and adequate MFA without changing the SSM core. |
| Give operators least-privilege, attributable, ticket-driven access — Architecture §1.3 | Strong | Partial | Requests identify users and termination requires an operator reason. Provisioning grants blanket administrator membership; sign/vend permit ownership bypass without required justification. Deliver entitlement enforcement and actor/subject auditing. |
| Prevent customers from seeing or reaching other tenants — Architecture §1.4; Target §1a | Strong | Partial | Create-time tenant checks deny before provisioning. Account scope, consistent reauthorization and complete negative tests remain unfinished. The invariant is mandatory but not operationally proven. |
| End authority reliably and expose residual access — Architecture §8; Target invariant core | Strong | Implemented foundation | Conductor/cleanup code distinguishes verified removal from failure. SSM tunnel termination remains best effort. Prove the entire residual-authority outcome under expiry, revoke and failure; do not promise zero orphaned access from code alone. |
| Serve auditors, operators and customers as first-class users — Architecture §1.3 | Strong | Partial | Access, operator termination and evidence APIs represent the three roles. Missing evidence-reader service identities, incomplete retrieval and audit defects prevent complete delivery. |
| Produce fresh, machine-readable evidence without per-pull human intervention — Architecture §1.5; Target ADR-0037 requirement | Strong | Partial | Schemas, storage, collectors and evaluator tests exist. Runtime freshness evaluation, full artifact retrieval, reader authorization and completeness still need implementation and proof. |
| Reuse one access core for EC2 and VMware guests — Architecture §1.5; Target §§2–4 | Strong with SSM hybrid registration | Designed | No current VMware integration proves the shared core. EC2-specific discovery and authorization must resolve hybrid managed-node identities without losing tenant/account binding. |
| Let independent consumers use the published API — Target §§3.1, 4 B5 | Strong | Partial | OpenAPI exists, but routes/models still diverge from the target contract. An independent client must complete access and evidence workflows without private UI privileges. |
| Handle slower operations asynchronously — Target §4 B4 | Strong | Partial | Connect starts a workflow and returns 202. The record does not establish the general jobs/capability contract across provider operations. |
| Reuse code across profiles while preserving boundaries — Architecture §7; Target §2 | Strong as a reuse strategy | Designed | CFN supplies configurable partition/account inputs. No deployed GovCloud/VMware profile comparison proves equivalent behavior or authorized data flows. Shared source does not confer shared authorization. |
| Add capabilities within existing authorization governance — Architecture §1.5 | Conditional | Unverified | The documents describe an additive change strategy. The record lacks the deployed boundary/change assessment needed to promise preservation of the existing ATO. |
| Reduce operating cost and patching burden — Architecture §3.2; One-Pager cost discussion | Plausible | Unverified | Removing dedicated access appliances removes their upkeep where customers can retire them. AWS usage, agents, dependencies, host baselines and assurance operations remain. No comparable cost or workload study supports a savings figure. |

**Leadership assessment:** The team has implemented much of the AWS mechanism and has chosen useful boundaries for the platform. It has made less progress on enforcement consistency, replaceable identity integrations and operational evidence. The main delivery risk is the gap between the promised security contract and the current runtime, rather than the feasibility of SSM access. The next milestones must close that gap and prove reuse on VMware guests.

### How well we track Rev 5 and 20x

**Rev 5: control-outcome-driven design throughout; implementation consistency and assessment evidence still partial.** 800-53 control outcomes were a continuous design input, not a late mapping. The architecture, the decision records, and the §8 control table were developed against access, identity, and audit objectives from the start, and that control-first approach survived four independent technical reviews. The POC also *demonstrated* several control-relevant behaviors end to end — no inbound administrative exposure (AC-17, SC-7), identity-attributed sessions (IA-2, AU-3), ephemeral target-scoped authority (AC-6, AC-12), and conductor-verified teardown with visible failure (AC-12, AU-6) — rather than only asserting them on paper. What remains is implementation *consistency* and *assessment* evidence, not design intent: blanket guest administrator privilege undercuts least privilege (AC-6); the current ten-control registry is a working subset, not the full applicable baseline; and because nothing is yet deployed in a target Organization, there is no 800-53A examine/interview/test evidence of effectiveness. These gaps prevent a defensible statement that the method *preserves every required control* — but they are proof-and-polish steps on a control-aligned foundation, not a reversal of it. Produce scoped implementation statements, responsibility/inheritance records, organization-defined parameters, and repeatable assessments for the actual offering. [Official Rev5 package guidance](https://www.fedramp.gov/2026/agencies/use/packages/rev5/).

**20x: strong design alignment; partial evidence delivery.** The architecture makes JIT authorization and machine evidence product functions rather than separate reporting tasks. The code already contains evidence infrastructure. However, current runtime claims can outlive their evidence and the API cannot yet demonstrate complete unattended package retrieval. Until those defects and integration gates close, describe the platform as implementing 20x-oriented assurance capabilities, not meeting the entire ruleset. Section 5 identifies the applicable official rules; section 6 supplies acceptance criteria.

Neither legacy AD/VPN access nor this architecture determines compliance by topology alone. A well-controlled legacy system can satisfy security outcomes. This product must demonstrate narrower access, shorter standing authority and better evidence in its own deployment rather than assume a legacy comparator lacks them.

## 2b. RSA independence and reuse across EC2 and VMware

### Vendor independence without weakening authentication

The intended contract makes **authentication assurance mandatory and the MFA vendor optional**. A customer can keep RSA, move to another suitable authenticator, or use its IdP’s supported hardware/passkey capabilities if the integration supplies trusted evidence of the required ceremony. The product evaluates assurance and authorizes SSM access; it does not depend on an RSA-specific login or licensing interface.

The current implementation has not completed that separation. To prove it, run the same grant/session/cleanup workflow with two independent identity integrations and show that changing the MFA provider does not alter target authorization, SSM transport, audit semantics or required assurance. Test insufficient assurance, disablement and revocation as well as successful login.

This creates a technical path to leaving an MFA vendor relationship. The repository contains no RSA contract, usage inventory or commercial migration analysis, so it cannot establish termination rights, savings, replacement licensing needs or readiness to retire a deployed RSA service. Identity portability also requires account mapping, recovery procedures, user enrollment and support planning.

### One codebase, one SSM pattern, different resource integrations

For EC2, the adapter resolves an EC2 identity and its tenant/account/region. For VMware-hosted guests, the adapter must resolve a vCenter guest identity to an SSM hybrid managed-node identity and its trusted ownership record. Both then use the same authorization, credential, guest-principal, session, cleanup and evidence semantics.

AWS supports SSM registration of non-EC2 VMs through hybrid activations. That supports the proposed VMware guest access path; it does not establish that this repository has implemented it. [AWS hybrid activation documentation](https://docs.aws.amazon.com/systems-manager/latest/userguide/hybrid-activation-managed-nodes.html).

The remaining VMware work includes guest enrollment and deregistration, protected activation handling, supported guest OS/agent versions, approved outbound connectivity, stable guest-to-node mapping, resource authorization and scoped managed-instance ARNs. Current support for an `mi-` ARN in credential-policy construction is only one component: EC2 lookup cannot authorize a VMware guest. Guest deletion, recreation, cloning and node re-registration must not transfer a previous tenant’s access rights.

**Guest shell/RDP access and hypervisor management are different capabilities.** SSM can provide access to an enrolled guest; vCenter APIs provide discovery and operations such as VM power or resize. Expose only implemented capabilities. A guest without an installed, registered and reachable SSM Agent cannot receive the promised access path.

Reuse the security core and add provider-specific adapters, configuration and tests. Do not promise identical deployment artifacts or no provider-specific code. The boundary review must cover AWS service connectivity, credentials and telemetry for VMware environments; a separate adapter does not automatically preserve an existing authorization.

### Security improvement and future value

The architecture can reduce dedicated inbound management exposure, broad administrator network reach and standing guest credentials. It can also give customers the same attributed access and evidence model across hosting estates. Those improvements follow from the proposed mechanisms; the team must verify them against a measured baseline.

Retiring VPN/jump-host infrastructure creates value only where that infrastructure has no remaining required use. Root-equivalent ephemeral access still carries substantial privilege, and a compromised broker can affect multiple targets. Complete entitlement restrictions, effective IAM tests, audit integrity and failure reconciliation before claiming an overall security improvement for the deployed offering.

The durable investment is a common SSM authorization/lifecycle/evidence core with independent identity and resource adapters. That architecture supports additional eligible estates and consumers while keeping one security contract. It also retains AWS service dependence, supported-guest prerequisites and profile-specific assurance work; those are explicit product constraints.

## 2c. Architecture statements leadership should qualify

These corrections address goal and claim language in the three documents. They do not reassess the historical POC.

| Existing statement | Evidence-based interpretation |
|---|---|
| One-Pager calls the access method “800-53-compliant” and says it preserves every control | The code supplies several relevant mechanisms; current gaps and absent deployment assessment prevent that conclusion for the product. |
| Architecture describes phishing-resistant MFA as delivered | Current CFN reference enables software-token MFA; normalized phishing-resistant assurance enforcement remains unfinished. Passwordless guest SSH does not establish phishing resistance of human login. |
| Architecture says there is no network path and describes access as not using a tunnel | SSM creates a controlled session/tunnel without placing the administrator on a general customer network. The product still requires service connectivity. |
| One-Pager says users never hold credentials | Users need no standing AWS keys. The client receives temporary STS credentials, SSH material and, for the Windows path, session password material. |
| Architecture/One-Pager imply SSM logs record all session activity | SSM connection API evidence differs from host command/activity evidence. SSH and port-forwarded content require host-side telemetry for that claim. |
| Target §1a mandates SSM while §3.4/ADR-0027 permit other transport implementations | The clarified requirement fixes SSM for supported guest access. Update the latter passages; keep hosting-provider abstraction below the shared security contract. |
| Architecture promises additive growth will never force reauthorization; Target says provider separation keeps existing ATOs intact | Treat this as a change-governance objective, not an architectural guarantee. Document actual information flows and obtain the applicable boundary/change disposition. |
| Architecture describes little or nothing to patch and lower cost | Managed services reduce some infrastructure maintenance. Agents, guests, dependencies, secrets and monitoring still need lifecycle work; quantify costs before claiming savings. |
| Architecture marks physical and personnel controls fully inherited | Confirm each inherited portion against the actual service package. The organization still owns its personnel/access processes and relevant customer responsibilities. |

## 3. Product contract and consumer choice

The product-owned boundary should guarantee identity validation, required assurance, tenant/resource/entitlement authorization, bounded credentials, attributable lifecycle, verified teardown, and truthful scoped evidence. Integrations supply inputs and capabilities under explicit contracts; the product must deny unsafe access or mark dependent assurance claims unknown when those inputs cannot be trusted.

| Boundary | Consumer choice | Platform obligation | Current maturity |
|---|---|---|---|
| Identity | Enterprise/customer IdP; SAML or OIDC federation | Trusted issuer registration, signature/audience/time checks, issuer-plus-subject identity, claim mapping, tenant binding, disablement/revocation | ADR-0038 defines the goal. CFN uses Cognito and Cognito-specific claims; real multi-IdP normalization is unfinished. |
| Authentication | Hardware FIDO2 keys, PIV/CAC, authenticator applications, other suitable mechanisms | Validate the assurance of the actual ceremony, its freshness, and required policy properties | Identity contract exists; runtime helper does not consume `authn_assurance`. CFN reference enables software-token MFA. |
| Consumer/API | Supplied client or independently developed UI/CLI/service | Versioned API, equivalent permissions, documented lifecycle, compatibility tests | OpenAPI is provisional; contract `/api/v1` and deployed `/api` routes require convergence. |
| Connection/provider | Supported resource provider | Attributed, brokered, ephemeral session with verifiable termination | AWS implementation exists; second-provider behavior remains a design/proof task. |
| Host telemetry/SIEM | Customer host audit and centralized monitoring products | Stable correlation identifiers, telemetry contract, freshness/coverage evaluation | Host activity evidence is a declared external dependency requiring implementation and operational proof. |
| Trust center/evidence consumer | Product projection, customer GRC/trust center, agency automation | Authorized complete retrieval, schema/version documentation, provenance and meaningful current claims | Evidence store and projection handlers exist; complete machine retrieval and package publication are unfinished. |

The product fixes SSM as the access mechanism while adapters translate hosting-provider inventory, resource identities, tenant ownership and optional management operations. The consumer can use a canonical resource model without selecting or bypassing the transport. The current [provider contract](platform/contracts/provider-contract.md) and ADR-0027 describe alternative transports; those passages conflict with the clarified product requirement and need revision. This assessment does not adopt them as the delivery goal. Optional operations such as resize or stop require separate provider capabilities; a draft API entry does not prove runtime support.

**Openness today is architectural and partial in implementation.** Parameterized deployment names do not make identity replaceable. The CFN authorizer imports a Cognito issuer; `get_user_from_event` derives `user_id` from `sub`, reads `cognito:groups` and `custom:customer_id`, and returns no issuer or normalized assurance. An IdP may eventually federate through Cognito, or a replaceable adapter may normalize it independently. The supported topology must be selected and tested before promising either path.

For SSM access, AWS SSM/STS/IAM, managed-node prerequisites, and the AWS provider's connection tooling remain genuine dependencies. The consumer should not need a particular enterprise IdP, AD domain, MFA vendor, or proprietary UI. The present implementation does not yet prove that freedom. Hosting-provider independence means the same SSM access core can reach eligible guests across estates. It does not remove the AWS service dependency or permit a transport bypass.

### Authentication acceptance must depend on properties

A hardware token that emits OTP and a hardware FIDO2 key do not provide identical assurance. An authenticator application using TOTP, ordinary push, or a passkey also represents different ceremonies. A vendor name, `mfa=true`, or “hardware-backed” alone must not imply phishing resistance.

The existing assurance enum is a useful beginning, but should become explicit, testable properties rather than an assumed linear ranking. Add authentication time, trusted assurance mapping/version, phishing resistance, key protection, and relevant session context. Apply profile-specific freshness and step-up rules. Reject missing, untrusted, ambiguous, or insufficient assertions; record the evaluated properties in authorization and evidence.

This extends [the identity contract](platform/contracts/schemas/identity-assertion.md) and ADR-0028/0038 without requiring an authenticator brand. A lower-assurance integration may be usable under another supported profile; it must not silently inherit the stronger profile's claims.

## 4. Current product findings that determine priorities

### Authorization and attribution

The CFN create handler authorizes a customer target before writing the request or starting the workflow. Missing tenant, lookup failure, tenant mismatch, and disabled customer access deny creation. This is a substantive implemented control.

The remaining defects are current platform behavior, not POC carryovers:

1. **Unconditional host privilege:** `provision_user/handler.py` adds Linux principals to `sudo`/`wheel` and Windows principals to `Administrators`. No entitlement is passed through the create/workflow input.
2. **Inconsistent reauthorization:** create requires `CustomerAccess=true` and normalizes tenant case; vending checks the `Customer` tag with different case handling and omits the customer-access flag. The live check does not implement the full initial policy.
3. **Operator attribution gap:** sign/vend permit ownership bypass without mandatory reason. Vending names the AWS role session after the stored owner's principal, obscuring actor-versus-subject attribution.
4. **Disconnected region configuration:** `TargetRegions` reaches inventory but not the create function, whose helper has a different implicit fallback.
5. **Incomplete account boundary:** `target_client` exists, but create/provision and relevant records do not carry and consistently use authoritative target account context. A helper plus StackSet templates is not end-to-end multi-account isolation.
6. **Audit installation defects:** vend and inventory place their `audited(...)` assignment after the handler return; the wrapper is unreachable. The shared wrapper catches durable-write failures and continues, so mandatory-audit failure policy also needs an explicit decision.

Evidence anchors: [shared utilities](platform/cfn/control-resources/lambda/shared/python/portal_utils.py), [create](platform/cfn/control-resources/lambda/create_access_request/handler.py), [provision](platform/cfn/control-resources/lambda/provision_user/handler.py), [vend](platform/cfn/control-resources/lambda/ssm_credentials/handler.py), [sign](platform/cfn/control-resources/lambda/sign_key/handler.py), [inventory](platform/cfn/control-resources/lambda/list_instances/handler.py), [application template](platform/cfn/control-resources/application.yaml).

Termination already enforces a reason for an operator ending another user's request. Extend that explicit pattern to other on-behalf-of operations rather than treating operator status as unrestricted authority.

### Evidence and trust-center foundations

Implemented components include JSON schemas, a provisional control registry, conservative evaluator code, scheduled AWS collectors, KMS-encrypted/versioned storage, ledger and audit tables, evidence routes, operator review, and alarms. This is substantial authored capability.

Source inspection also establishes important limits:

- The collector materializes single-source claims directly from source status. It does not invoke the contract evaluator to combine required sources.
- The compliance API reads stored claims and counts their stored results without reevaluating expiry or integrity. A previous `satisfied` value can remain visible after `valid_until`.
- GuardDuty with no detector can return `satisfied`; Config results other than explicit noncompliance can be overinterpreted. Absence of serious findings does not establish source enablement or coverage.
- Several source calls are not fully paginated. Collection is ambient-account/region scoped rather than a proven Organization inventory.
- Collector claims use `fleet#...` scope, while tenant projections query `tenant#...`. An explicit authorized fleet-to-tenant projection is needed before expecting tenants to see those claims.
- The audit endpoint returns a `next_cursor` but does not consume an input cursor. Claims retrieval likewise lacks a complete traversal contract. First-page retrieval cannot demonstrate completeness.
- Current routes expose claim/audit projections and review but lack authenticated download of every referenced raw artifact and human-readable certification material.
- `ObjectLockEnabled: true` establishes bucket capability, but the inspected template does not set default retention and the collector does not supply object retention. It is insufficient proof of protected retention.
- The Moderate registry contains ten provisional controls, not the complete baseline or a 20x certification ruleset. It does not drive the complete collector/evaluator pipeline.

Evidence anchors: [collector](platform/cfn/control-resources/lambda/evidence_collector/handler.py), [evidence API](platform/cfn/control-resources/lambda/evidence_api/handler.py), [evaluator](platform/contracts/evidence/evaluator.py), [registry](platform/contracts/controls/nist-800-53-moderate.json), [foundation](platform/cfn/control-resources/foundation.yaml).

The nine evaluator regression tests passed during this consolidation. They establish useful local behavior for missing, stale, tampered, scoped, failed, and exception evidence. They do not establish that the deployed collector/API uses those guarantees.

## 5. NIST 800-53 and FedRAMP 20x alignment

Treat NIST control outcomes and FedRAMP 20x rules/KSIs as separate, versioned mappings. They are related assurance models; a 20x KSI is not automatically an implementation of every related 800-53 control. The access platform contributes to a defined offering's assurance and cannot establish compliance for every attached VM or external service.

The NIST catalog supports technology-neutral security outcomes; it does not prescribe an AD/VPN/jump-host topology for this access design. Assess effectiveness through examine/interview/test evidence under the applicable assessment plan. AC-6(5) concerns restriction of privileged accounts to defined personnel or roles; a second authorization check does not close it. [NIST SP 800-53 Rev. 5, including Release 5.2.0](https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final), [NIST SP 800-53A Rev. 5](https://csrc.nist.gov/pubs/sp/800/53/a/r5/final).

| Outcome / relevant controls | Product contribution | Proof still required |
|---|---|---|
| AC-2, AC-3, AC-6, AC-6(5) | JIT request, target gate, temporary authority | Role-scoped host privilege, unified reauthorization, account isolation, effective IAM tests |
| AC-12, AC-17 | Brokered remote access and conductor termination | Live expiry/revoke/failure cleanup and residual-authority checks |
| IA-2, IA-4, IA-5 | Identity assertion, short-lived credentials/certificates | Trusted issuer/subject, assurance enforcement, revocation, CA lifecycle, Windows secret handling |
| AU-2/3/6/8/9/11/12 | Structured events and correlated evidence storage | Complete actor/subject/target/reason events, time correlation, host activity feeds, review, protected retention |
| CA-7, CM-2/3/6/8 | Evidence collection and configuration intent | Defined invariants, deployed coverage, freshness, artifact provenance and drift validation |
| SC-7/8/13/28 | Reduced target ingress and protected transport/storage | Profile-specific edge, cryptographic, endpoint, key-policy and retention evidence |
| SI-2/4/7, RA-5, IR-4 | Posture inputs and alarms | Vulnerability/remediation, supply-chain, incident delivery/response and recovery integrations |

These are engineering mappings, not pass/fail certifications. Do not import the AmazonQ report's generic retention periods, automatic VPC requirements, CMK interpretations, or control ratings without applicable current-profile requirements and current-product evidence.

SSM API logs demonstrate connection events, not every action inside a tunneled SSH/RDP session. AWS explicitly excludes session-content logging for SSH and port-forwarding sessions. Require host-side audit/recording and protected forwarding when the profile claims command/activity accountability; missing telemetry must affect that claim. [AWS logging limitation](https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager.html).

The current Class C KSI model emphasizes automated account lifecycle, passwordless methods where feasible or strong passwords with phishing-resistant MFA, persistent least privilege, and JIT authorization. These match the architecture's direction but remain incomplete in current enforcement. [Official Class C KSIs](https://www.fedramp.gov/2026/reference/20x/c/key-security-indicators/).

For Class C, FRC-CSX-VVK requires at least two automated verification/validation methods per KSI; FRC-CSX-MOT requires six months of historical validation status, with an initial-certification provision for services lacking that operating history. Rules with associated FedRAMP schemas require conforming JSON unless otherwise specified. Select and pin the actual certification class/path before generating obligations; do not assume every class has identical requirements or that OSCAL alone is the required 20x format. [Official certification rules](https://www.fedramp.gov/2026/reference/20x/c/fedramp-certification/).

### Meaning of on-demand evidence without human intervention

The requested goal is **an authorized agency system retrieving trust-center evidence on demand without a human preparing or approving each retrieval**. Human policy ownership, exception handling, independent assessment, and authorization decisions may remain.

The reviewed official rules do not name a CISA-specific retrieval tool. Design for authorized FedRAMP/agency systems, including CISA if appropriately authorized, using a documented protocol rather than inventing an agency-specific interface.

For the Class C data-sharing rules reviewed: CDS-TRC-USH requires uninterrupted sharing; CDS-TRC-PAC requires documented programmatic access to all certification data, including human-readable materials; CDS-TRC-AAI requires agency user/system access history; CDS-TRC-ACL requires access logs and six months of summaries. CDS-CSO-CBF requires automated consistency between formats. CDS-CSO-HAD requires report-aligned historical snapshots. CDS-TRC-HMR and CDS-TRC-SSM are SHOULD provisions for dual-format access and self-service management. Applicability and effective dates must be captured for the chosen profile. [Official certification data-sharing rules](https://www.fedramp.gov/2026/reference/20x/c/certification-data-sharing/).

A JWT-protected dashboard and JSON claim list do not yet meet the intended retrieval contract. Non-human readers need a supported authentication flow, evidence-only authorization, artifact discovery/download, complete traversal, and stable historical references. Such readers must never inherit workload provisioning, credential vending, or operator review powers merely to retrieve evidence.

## 6. Ordered development work and acceptance criteria

Priorities express dependency and release importance, not estimated dates. Evidence semantics and retrieval-contract design should start alongside access correction; broad UI expansion and additional providers should not delay a trustworthy AWS release.

| Priority | Work package | Reviewable completion criteria |
|---|---|---|
| **P0-1** | Unified authorization and entitlement kernel | Versioned actor/issuer/subject/tenant/account/region/resource/entitlement/owner/reason input; shared policy at create, provision, sign, vend and terminate; deny unknown entitlements; narrow host privilege; consistent region/tenant rules. Negative vectors prove denial before any write, workflow, SendCommand, signing or STS side effect. |
| **P0-2** | Attribution and durable audit | Repair wrapper placement/imports; separate actor from subject and target tenant; mandatory operator justification; correlate request, AWS/SSM and host identities; explicitly handle audit-write failure for sensitive actions. Import/runtime tests cover allow, deny, error and exception on every deployed handler and system actor. |
| **P0-3** | Truthful evidence evaluation | Replace broad source-status claims with named measures; require coverage/enablement, complete pagination and exact scope; run versioned evaluator in runtime; expiry/tampering/missing inputs affect published current status. Deliberate source loss and contradictions cannot produce a supported pass. Preserve historical results separately. |
| **P0-4** | Organization tenant boundary | Carry authoritative account/region/resource through records and every target-touching operation; finish assume-role paths and StackSets; bind tenants to trusted account/OU inventory; constrain IAM/trust and exact target ARNs. Two member tenants pass lifecycle tests and deny cross-tenant reads, mutation, credentials, session control and evidence access. |
| **P0-5** | Identity neutrality and strong assurance | Register a real SAML and real OIDC integration, concurrently; key identities by issuer+subject; normalize trusted claims; enforce assurance/freshness before grants; support a phishing-resistant privileged profile. Test duplicate subjects, missing assurance, disabled IdP/user, changed groups, replay/session expiry and tenant mapping. |
| **P0-6** | On-demand machine evidence access | Document evidence-reader service identity flow, least-privilege scope, discovery manifest, artifact download, pagination, schema versions and historical snapshots. An independent authorized script retrieves the declared complete package repeatedly without human assistance and cannot call access-broker or review operations. |
| **P0-7** | Deployed AWS lifecycle and assurance proof | Deploy versioned CFN artifacts to an isolated production-shaped test Organization; exercise Linux and Windows paths, effective IAM, credential bounds, reconnect, TTL, explicit revoke, worker/network failure and residual cleanup. Verify log correlation, alarms and evidence freshness; retain reproducible test artifacts and failures. |
| **P1-1** | Certification package/profile publication | Pin official rule/schema versions and applicability; generate overview, SDR and applicable ongoing/incident/assessment references from authoritative records; validate JSON and render matching human materials. Identify each claim's owner, inherited dependency, exception and supporting method. |
| **P1-2** | Protected history and operational response | Enforce selected retention and deletion controls, including actual object retention; separate archive ownership where required by profile; test integrity, backup/restore, alert delivery and response. Establish historical metrics at the start rather than reconstructing them later. |
| **P1-3** | External API conformance and adopter delivery | Converge runtime routes with the versioned OpenAPI; test an independent client through the lifecycle and complete evidence traversal; publish supported CFN artifacts, hashes, inputs, upgrade/rollback procedures and limitations; remove contradictory Terraform-first delivery guidance. |
| **P1-4** | Host activity and secret lifecycle integration | Contract and verify host telemetry, SIEM correlation, missing-stream behavior, CA rotation/revocation, Windows password redaction/deletion, and target baseline drift. Prove secret material is not exposed through logs, command output/history or state beyond the approved design. |
| **P1-5** | VMware guest access through the same SSM core | Register supported VMware-hosted Linux/Windows guests as hybrid managed nodes; bind vCenter UUID, SSM node ID, tenant and AWS registration account/region; replace EC2-only target lookup with trusted resource resolution. Prove shell/RDP, scoped credentials, guest privilege, revocation, teardown and evidence using the common core. Keep hypervisor operations separate. Freeze the revised SSM-required provider contract only after this proof. |
| **P2-2** | Consumer and adapter ecosystem | Publish tested IdP/assurance mappings, integration examples and compatibility/version rules; expand supported providers and user experiences using the same contracts. |

The most efficient first bounded change is **P0-1 plus P0-2**: fix the authorization path and ensure every decision can be evidenced. P0-3 and P0-6 should be designed immediately because evidence correctness and machine access are central product goals. Keep every release gate even when engineering work proceeds concurrently. Treat the VMware SSM proof as a strategic P1 milestone, after correcting the shared security core and before broader provider expansion.

### Security invariant catalog

Create a versioned catalog connecting each narrow guarantee to enforcement, responsibility, evidence, freshness, failure semantics, related control/KSI, verification and validation. Initial invariants should cover:

- Trusted issuer+subject and sufficient fresh assurance are bound to each grant.
- Target account/tenant/resource is authorized before side effects and rechecked before new authority is issued.
- Host privilege matches the approved entitlement; credential scope/lifetime never exceeds the grant.
- On-behalf-of actions preserve actor, subject and justification.
- Expiry/revocation removes target authority within a declared bound; failures remain visible.
- Required target ingress restrictions and host telemetry are independently measured.
- Missing, stale, tampered or incompletely scoped evidence cannot support a current satisfied claim.
- An authorized machine can retrieve the complete declared certification package without per-request human action.

For an AWS no-inbound-access invariant, configuration analysis and a functional permitted/denied access probe provide different kinds of evidence. For teardown, workflow output and an independent residual-account/session check do likewise. These are proposed engineering methods; selecting two methods does not by itself prove the entire corresponding KSI.

## 7. Release claims and stakeholder wording

**Appropriate current description:**

> The platform is designed to replace VPN, jump-host and AD-dependent administrative access for the AWS SSM profile using attributable JIT access and temporary authority. It has substantial CloudFormation access and evidence implementations and provisional integration contracts. Production account isolation, role-scoped privilege, multi-IdP assurance enforcement, complete machine evidence access, VMware guest integration and operational effectiveness remain development and validation gates.

Describe IdP/MFA independence as the intended contract and prove it with integrations. Describe 800-53/20x as alignment and evidence support until the defined offering has the applicable assessment and certification/authorization evidence. Do not claim universal passwordlessness, complete command recording, immutable retention, deployed multi-cloud support, or a finished compatible trust center from authored templates alone.

## 8. Validation and unresolved decisions

The consolidation inspected current CFN handlers/templates, contract schemas/OpenAPI, evaluator/registry, and relevant governance records. This revision also evaluated the goals and claims in all three named architecture documents and checked AWS hybrid registration guidance. The existing nine evaluator tests passed locally. The work did not contact or change AWS resources. The validation record does not treat prior reports' build/lint results as newly rerun checks.

Decisions to record before freezing a production profile:

1. Certification type/path/class and pinned applicable rules, schemas, dates and boundaries.
2. Supported federation topology: replaceable identity adapter, Cognito federation, or both.
3. Required human assurance/freshness and separate machine evidence-reader authentication.
4. Tenant/account authority, permitted entitlements and operator on-behalf-of policy.
5. Credential, revoke/cleanup, telemetry and evidence freshness bounds.
6. Mandatory-audit failure behavior, evidence/secret retention and archive ownership.
7. Built-in trust-center delivery versus integration with an external trust center, with the same retrieval and completeness guarantees.

The filename uses “AI Compliance” as requested. These sources support an access-and-assurance platform roadmap; they do not establish a separate AI governance, model-risk, or autonomous AI decision-making capability.
