# Universal Zero-Trust Access & Continuous Assurance
## Product delivery charter and Agile execution baseline
**Prepared:** 1 October 2026  
**Status:** Proposed execution baseline; architecture and weaknesses documents reviewed; repository, live AWS accounts and complete ADR set **not** independently inspected.  
**Purpose:** Give sponsors a defensible case that the product has an implemented foundation, a bounded next release, a traceable backlog, and objective demonstration gates.

### Executive decision requested
Authorize a short **baseline-and-proof inception** followed by three incremental delivery tracks. Assign one accountable product owner, a platform technical lead, a security/control owner and an ATO liaison. Fund the first increment only after the existing code, deployment and ADRs are reconciled against this backlog. Avoid committing a production-ATO date until boundary and assessor requirements are confirmed.

### Product proposition
One identity-attributed, policy-driven broker delivers time-limited shell/RDP access to workloads without requiring users to hold cloud credentials or enter a VPN/jump-host network. AWS SSM is the first connection transport, not an assertion of transport neutrality. The access platform emits structured operational and security evidence that authorized machines can retrieve independently. The platform supports regulated and commercial policy profiles without making tenant isolation, auditability or least privilege optional.

### Scope and boundaries
**In the initial release:** AWS commercial and GovCloud reference topology, Linux SSH, Windows native-client RDP, external identity federation, policy/least privilege, tenant account isolation, verified session lifecycle, evidence collectors, versioned trust-center API, alerting, automated security regression and assessor rehearsal. **Subsequent increment:** SSM hybrid-activated non-AWS VMs, interchangeable provider conformance and broader UX. **Explicitly not promised:** removing AWS as a dependency while SSM remains the only transport; complete SSH command or RDP screen capture merely because an SSM tunnel is logged; automatic FedRAMP 20x certification; zero downtime or zero residual risk; customer AD removal for unrelated enterprise functions.

### Source-grounded starting position
The architecture describes an advanced commercial POC with a Go CLI, Cognito authentication, ephemeral identity-named OS users, SSH CA, scoped STS credential vending, Step Functions lifecycle and tenant-aware connection checks. ADR-0023/0025 describe one authoritative conductor and verified teardown, although the architecture text also says SSM tunnel termination is best-effort rather than a verification gate. The 29 September weaknesses register says the CloudFormation evidence plane is authored and statically validated but **not deployed and exercised in an Organization**; Cognito is the only implemented identity provider; production tenant account isolation and cross-account logging remain open; the Windows RDP temporary password is stored plaintext in the operational record. These are source assertions, not independent code or runtime validation.

**Documentation conflict to resolve at G0:** The older architecture matrix contains stale statements about fail-open tenant stamping and the weakness register contains some contradictory remediation history (including a WAF described as both added and subsequently removed). Use latest dated ADR and code/deployment evidence to adjudicate; never promote a historical 'compliant POC' label directly to production acceptance.

### Architecture invariants
1. Fail-closed cross-tenant isolation at discovery, request, credential vending, session management and evidence retrieval.
2. Every privileged action is attributable to immutable identity and justification; every session is bounded and independently terminable.
3. The policy decision is centralized and enforced independently of the browser or connection adapter.
4. Endpoint activity evidence is separate from SSM transport/session metadata; unsupported recording claims are disclosed.
5. Evidence includes provenance, timestamp, scope, coverage, integrity and freshness, and missing evidence is visible as failure.
6. No emergency or recovery path silently bypasses attribution, time bounds or retrospective review.
7. Provider replacement cannot bypass central authorization, audit emission or tenant boundaries.

### Delivery method
Use 2-week sprints as an **initial planning assumption**, not a duration commitment. At inception, run a code-and-deployment inventory, ADR reconciliation, risk review, dependency mapping and story estimation. Each sprint should close a vertical slice: behavior, deny-case, telemetry, proof retrieval and demo. Maintain two boards: **delivery state** (Proposed → Ready → In progress → Implemented → Verified → Deployed) and **assurance state** (Not mapped → Mapped → Evidence produced → Independently reproduced → Assessor accepted). A story is not complete merely because a pull request merged.

### Release and investment gates
| Gate | Demonstration | Go/no-go evidence |
|---|---|---|
| G0 — Baseline | Walk code, IaC, deployed accounts and latest ADRs; dispose of every existing gap | Source-to-story mapping; accepted scope; owners; estimates; dependency graph |
| G1 — Secure access | Two federated IdPs; cross-tenant deny; scoped SSH/RDP; TTL and operator revoke; Windows secret protection | End-to-end traces, negative tests, endpoint checks, operational runbook |
| G2 — Automated proof | Independent assessor machine retrieves scoped, fresh, integrity-checked access and posture evidence | Versioned schema, machine credentials, manifest, verifier, stale-data failure demo |
| G3 — Hybrid and portability | SSM hybrid VM and second IdP use same policy, session and evidence model | Adapter contract tests and cross-environment comparison |
| G4 — Production authorization decision | Recovery and IR drills; boundary/SCN review; independent rehearsal | ATO liaison disposition, shared-responsibility matrix, residual-risk decisions |

### Increment sequence and critical dependencies
**Increment 1: trustworthy access.** Identity federation + assurance, canonical policy, least-privilege roles, Windows secret handling, production account isolation, protected logs, GovCloud reference deployment, controlled CI/CD and end-to-end teardown verification. First demo is two tenants, two IdPs, Linux and Windows, with intentionally denied requests. **Increment 2: independent proof.** Exercise the authored collector in an Organization, canonicalize evidence, protect archive, route alerts, publish API and machine credentials, run unattended assessor test. **Increment 3: hybrid and resilience.** Activate non-AWS targets, test provider substitution, recovery, emergency revoke, tenant policy profiles and a formal assessment rehearsal. Increments overlap where dependencies allow; G0 sets actual dates.

### Definition of ready
A story has an identified user and value; a reproducible starting state; owner; dependency disposition; explicit acceptance and deny-case tests; candidate control/ADR links; expected evidence fields; representative test environment; and a bounded estimate. An assessor-only requirement must have a named reviewer.

### Definition of done
Behavior and negative tests pass; least-privilege and tenant invariants hold; observability and machine-readable evidence are verified; deployment/recovery paths are documented; applicable controls and ADRs are updated; residual risks are accepted by an authorized owner; the demo is reproducible by someone other than the author. Assessor acceptance remains a separate milestone.

### Program risks and decisions requiring owners
| Risk / decision | Required action | Owner role |
|---|---|---|
| 20x evidence criteria may evolve; control alignment does not itself confer authorization | Confirm current applicable FedRAMP and agency/DoD requirements and document approved evidence formats | ATO liaison |
| Existing POC status may differ from documentation | Reconcile current branch, infrastructure and latest ADR-0037/0038 against source claims | Technical lead |
| SSM is AWS control-plane lock-in | Approve whether replaceable transport is a later objective or a release requirement | Product owner |
| Port forwarding does not record encrypted SSH/RDP activity | Set explicit endpoint-audit and recording coverage requirements by customer policy | Security lead |
| Windows password and bearer-token exposure | Choose accepted secret-vending / passwordless and token-binding risk treatment | Security lead |
| Control-plane/IdP outages can block emergency access | Approve independently attributable break-glass and recovery objectives | Operations lead |
| Commercial vs GovCloud feature/authorization differences | Validate actual partition support and authorization boundary for each deployment | Platform + ATO |

### Measurable demonstration scorecard (targets to agree at G0)
- **Access:** median and 95th-percentile time-to-connect; failed connections; proportion without manual support.
- **Security:** unauthorized cross-tenant attempts denied; percentage of sessions with verified endpoint cleanup; max revocation latency; privileged actions with full identity/justification.
- **Proof:** required evidence sources collected on time; percent of proof bundles passing integrity/coverage checks; unattended assessor retrieval success; stale-data alert latency.
- **Reliability:** recovery-time objective, successful canary connections, orphaned-account backlog and incident acknowledgment latency.
- **Portability:** provider conformance pass rate and number of cloud target types reached through the same policy and evidence model.
**Do not set artificial numerical success claims before a baseline measurement and assessor requirements are agreed.**

### How to use the companion workbook
The **Executive view** shows scope and priority counts. **Epics** provides capability outcomes. **Stories** contains 48 candidate stories with initial status, acceptance criteria, negative tests, evidence, controls, ADRs, dependencies and editable owner/estimate/proof fields. **Release gates** describes stakeholder demos. Story IDs are stable internal keys; the CSV has the same stories for import/mapping into Jira, Azure DevOps or another tracker. Control mappings are **candidates for confirmation**, not assessor-validated determinations. In the first planning session, identify which stories are already done and attach the code/test/deployment proof instead of reopening completed work.

### What would establish the proposal is real
At G0, present the current CLI connecting to an existing test VM, an attributed session record, the teardown trace, the relevant ADR and the corresponding open weakness. At G1, demonstrate denial and recovery rather than only a successful connection. At G2, hand a machine identity and API specification to someone outside the engineering team and have them retrieve and verify proof without human mediation. These three demonstrations distinguish an operating product initiative from a compliance slide deck.

---
## Epic register
### E01 — Identity federation and assurance
**Outcome:** Federate independent IdPs with verifiable MFA and identity lifecycle.

**E01-01 — SAML federation (P0, Increment 1)**  
Starting point: Designed, not implemented.  
Acceptance: External SAML issuer and immutable subject map to tenant; login and logout exercised  
Negative test: Reject missing tenant, unsigned assertion and email collision  
Proof: Signed-in event with issuer, subject, MFA assurance and decision  
Candidate controls: IA-2;IA-4;AC-2; references: ADR-0016;ADR-0038; dependencies: E02-01.

**E01-02 — OIDC federation and concurrent providers (P0, Increment 1)**  
Starting point: Designed, not implemented.  
Acceptance: OIDC and SAML users coexist with stable provider-qualified identities  
Negative test: Reject ambiguous account linking and untrusted issuers  
Proof: Two-provider test results and normalized claims  
Candidate controls: IA-2;IA-4;AC-2; references: ADR-0038; dependencies: E01-01.

**E01-03 — Phishing-resistant assurance enforcement (P0, Increment 1)**  
Starting point: POC TOTP; production target unverified.  
Acceptance: Privileged roles require policy-defined phishing-resistant assurance; step-up tested  
Negative test: Reject insufficient or unverifiable assurance claims  
Proof: Authentication-method evidence and enforcement tests  
Candidate controls: IA-2;IA-5; references: ADR-0038; dependencies: E01-01;E02-01.

**E01-04 — Identity disable and revocation (P1, Increment 2)**  
Starting point: Manual runbook / partial session revoke.  
Acceptance: Disabling user prevents new access and revokes active access within approved objective  
Negative test: Reject cached token or active-session bypass after revocation  
Proof: Revocation timeline, denied request and terminated-session event  
Candidate controls: AC-2;AC-12;IR-4; references: ADR-0023;ADR-0025; dependencies: E04-01.

### E02 — Policy, least privilege and JIT
**Outcome:** Constrain every access to person, tenant, target, purpose and time.

**E02-01 — Canonical authorization policy contract (P0, Increment 1)**  
Starting point: Partial target checks implemented.  
Acceptance: Evaluate identity, tenant, target, requested action, justification and duration in one decision interface  
Negative test: Deny absent context, cross-tenant target and stale approval  
Proof: Policy decision event with inputs, rule version and reason  
Candidate controls: AC-3;AC-6; references: ADR-0012;ADR-0024; dependencies: E05-01.

**E02-02 — Least-privilege operator roles (P0, Increment 1)**  
Starting point: Broad RGS-Admin/operator lens.  
Acceptance: Separate customer operator, support operator, security responder and admin grants  
Negative test: Prove ordinary operators cannot self-elevate or access unrelated tenants  
Proof: Role policy test matrix and privileged-action audit  
Candidate controls: AC-5;AC-6;AC-2(7); references: ADR-0025; dependencies: E02-01.

**E02-03 — JIT access approval and expiry (P0, Increment 1)**  
Starting point: Single-instance STS and TTL demonstrated.  
Acceptance: Request contains purpose, target, permission and max lifetime; grants auto-expire  
Negative test: Reject expired request and unsupported requested duration  
Proof: Request/approval/grant/expiry correlation chain  
Candidate controls: AC-2;AC-6;AC-12; references: ADR-0012;ADR-0023; dependencies: E02-01.

**E02-04 — Active-session policy re-evaluation (P1, Increment 2)**  
Starting point: Not demonstrated.  
Acceptance: Permission/tenant revocation reaches active sessions within defined objective  
Negative test: Test IdP outage, role removal and changed target ownership  
Proof: Decision and termination latency trace  
Candidate controls: AC-3;AC-12; references: ADR-0023;ADR-0024; dependencies: E01-04;E04-01.

### E03 — Connection broker and hybrid reach
**Outcome:** Connect workloads without VPN, jump host or customer AWS credentials.

**E03-01 — AWS EC2 SSH and RDP reference path (P0, Increment 1)**  
Starting point: Functional commercial POC.  
Acceptance: Run full CLI→broker→SSM→SSH/RDP flow in commercial and approved GovCloud test settings  
Negative test: Reject missing agent, unapproved target and incorrect partition  
Proof: Connection trace with target, identity, partition and outcome  
Candidate controls: AC-17;SC-7;AU-12; references: ADR-0006;ADR-0012;ADR-0019; dependencies: E02-01.

**E03-02 — ConnectionProvider contract (P0, Increment 1)**  
Starting point: Adapter architecture specified.  
Acceptance: Define discovery, capability negotiation, connect, disconnect, health, audit hooks and errors  
Negative test: Provider cannot bypass central authorization or evidence emission  
Proof: Versioned schema and contract test report  
Candidate controls: AC-3;AC-17;AU-12; references: ADR-0016; dependencies: E02-01;E06-02.

**E03-03 — SSM hybrid non-AWS VM pilot (P1, Increment 3)**  
Starting point: Roadmap only.  
Acceptance: Activate and connect one supported non-AWS Linux and one Windows VM; document hybrid agent lifecycle  
Negative test: Deny wrong tenant activation and revoked hybrid target  
Proof: Hybrid target session and agent-health proof  
Candidate controls: AC-17;CM-8;AU-12; references: ADR-0016;ADR-0021; dependencies: E03-02;E05-01.

**E03-04 — Alternate transport demonstration (P2, Increment 3)**  
Starting point: Not implemented.  
Acceptance: Replace SSM adapter in isolated test without changing policy or UI contract  
Negative test: Transport must fail closed when it cannot emit required audit fields  
Proof: Cross-transport contract and parity report  
Candidate controls: AC-17;AU-12; references: ADR-0016; dependencies: E03-02;E10-01.

### E04 — Session and endpoint lifecycle
**Outcome:** Enforce session bounds and prove endpoint cleanup and actions.

**E04-01 — Convergent verified teardown (P0, Increment 1)**  
Starting point: POC implemented; production proof outstanding.  
Acceptance: Exercise portal end, CLI exit, operator revoke, expiry and failure; verify endpoint account/profile and report tunnel result separately  
Negative test: Force cleanup failure and verify CLEANUP_FAILED, alert and reconciliation  
Proof: End-to-end lifecycle trace and endpoint-state inspection  
Candidate controls: AC-12;AC-2;AU-6; references: ADR-0023;ADR-0025; dependencies: E06-01.

**E04-02 — Remove stored plaintext RDP password (P0, Increment 1)**  
Starting point: Open gap.  
Acceptance: Implement approved ephemeral credential vending or passwordless RDP; secrets not persisted in session record  
Negative test: Attempt log, API, DB and client secret extraction after expiry  
Proof: Credential-handling tests and no-plaintext scans  
Candidate controls: IA-5;SC-28; references: ADR-0022; dependencies: E03-01.

**E04-03 — Endpoint session activity evidence (P0, Increment 2)**  
Starting point: Identity logs exist; content coverage unproven.  
Acceptance: Collect SSH command/audit and Windows logon/privilege events with session correlation; document blind spots  
Negative test: Port-forwarding alone must not be accepted as command or screen recording  
Proof: Host audit events, coverage matrix and gap declaration  
Candidate controls: AU-2;AU-3;AU-12; references: ADR-0011;ADR-0024; dependencies: E06-02.

**E04-04 — Orphan reconciliation and record retention (P1, Increment 2)**  
Starting point: Known cleanup/TTL monitoring gap.  
Acceptance: Scheduled scanner identifies residual users, sessions and stale records; retains failures until actioned  
Negative test: Simulate execution abort, lost event and TTL crossing  
Proof: Reconciliation report, alert and verified remediation  
Candidate controls: AC-2;AU-6;AU-11; references: ADR-0023;ADR-0025; dependencies: E04-01;E08-01.

### E05 — Tenant isolation and policy
**Outcome:** Enforce non-bypassable customer separation and configurable policy.

**E05-01 — Production account-based isolation (P0, Increment 1)**  
Starting point: POC regions/tags only.  
Acceptance: Demonstrate account-scoped customer deployment and independent cross-account role policies  
Negative test: Prove discovery, connect and logs cannot cross tenant boundary  
Proof: Account policy tests and cross-tenant deny trace  
Candidate controls: AC-3;AC-6;SC-7; references: ADR-0002;ADR-0021; dependencies: E11-02.

**E05-02 — Tag and ownership integrity (P0, Increment 1)**  
Starting point: Connect-time checks; tag protection open.  
Acceptance: Protect authorization-critical tags from unauthorized mutation; verify consistency on every connection  
Negative test: Tamper tag, omit tag, stale cache and unavailable DescribeInstances  
Proof: Config/IAM test results and rejected connect event  
Candidate controls: AC-3;CM-3;CM-6; references: ADR-0012;ADR-0021; dependencies: E05-01.

**E05-03 — Automated cross-tenant test suite (P0, Increment 1)**  
Starting point: Partial checks, negative tests needed.  
Acceptance: Automate denial across listing, request, credential vend, session view, termination and evidence  
Negative test: Fuzz missing tenant claim, record and resource mismatch  
Proof: Signed test report linked to each deployment  
Candidate controls: AC-3;AC-6;AU-9; references: ADR-0021;ADR-0025; dependencies: E05-01;E07-02.

**E05-04 — Tenant policy profiles (P1, Increment 3)**  
Starting point: Not implemented.  
Acceptance: Set per-tenant allowed IdP, assurance, session TTL, approval and retention within platform guardrails  
Negative test: Reject configuration weakening platform minimums  
Proof: Versioned policy export and policy test matrix  
Candidate controls: AC-3;AC-6;IA-2; references: ADR-0016;ADR-0021; dependencies: E01-03;E02-01.

### E06 — Continuous evidence pipeline
**Outcome:** Collect attributable, durable, fresh, tamper-evident evidence.

**E06-01 — Live organization evidence-plane exercise (P0, Increment 1)**  
Starting point: Authored/statically validated; not deployed.  
Acceptance: Deploy collector in test Organization and observe two complete scheduled cycles  
Negative test: Disable permissions and collector; alarm and recovery both verified  
Proof: Collector run IDs, output objects, failure and recovery logs  
Candidate controls: CA-7;AU-6;AU-12; references: ADR-0037; dependencies: E11-02.

**E06-02 — Canonical evidence envelope and provenance (P0, Increment 1)**  
Starting point: Structured ingestion authored; schema acceptance pending.  
Acceptance: Define schema for control, tenant, actor, target, timestamps, source, collection method, version, result and integrity  
Negative test: Reject missing provenance, invalid signature and unscoped record  
Proof: Schema contract tests and sample evidence bundle  
Candidate controls: AU-3;AU-9;CA-7; references: ADR-0024;ADR-0037; dependencies: E06-01.

**E06-03 — Cross-account immutable retention (P0, Increment 1)**  
Starting point: POC logs same account.  
Acceptance: Deliver to isolated log archive with tested KMS, retention, integrity and access restrictions  
Negative test: Attempt deletion/alteration from tenant administrator  
Proof: Archive-policy tests, integrity check and retention manifest  
Candidate controls: AU-9;AU-11;SC-28; references: ADR-0010;ADR-0020; dependencies: E05-01.

**E06-04 — Evidence freshness and completeness alerts (P0, Increment 2)**  
Starting point: Collector alarms authored, unexercised.  
Acceptance: Define freshness SLA per source; detect missed cycles and incomplete tenant/control coverage  
Negative test: Silence source or drop one required event and confirm failure state  
Proof: Coverage report, stale alert and incident ticket  
Candidate controls: AU-6;CA-7; references: ADR-0037; dependencies: E06-01;E08-01.

### E07 — Machine-readable trust center
**Outcome:** Deliver authorized, unattended, reproducible proof retrieval.

**E07-01 — Versioned evidence retrieval API (P0, Increment 2)**  
Starting point: /audit and /compliance handlers authored; not exercised.  
Acceptance: Machine client discovers schemas and retrieves paginated evidence by tenant/control/time  
Negative test: Reject unsupported version, invalid pagination and missing proof  
Proof: OpenAPI/schema tests and scripted assessor retrieval  
Candidate controls: CA-7;AU-12;AC-3; references: ADR-0037; dependencies: E06-02.

**E07-02 — Assessor-scoped service identities (P0, Increment 2)**  
Starting point: Not demonstrated.  
Acceptance: Issue read-only scoped machine identity; rotate and revoke credentials; log every retrieval  
Negative test: Cross-tenant evidence access and write attempt return deny  
Proof: M2M authorization and retrieval audit trace  
Candidate controls: AC-3;AC-6;IA-5;AU-12; references: ADR-0024;ADR-0037; dependencies: E07-01;E05-03.

**E07-03 — Proof manifest and integrity verification (P0, Increment 2)**  
Starting point: Evidence storage designed; proof validation pending.  
Acceptance: Return provenance, coverage, timestamps, digest and missing-source flags for each evidence package  
Negative test: Corrupt record or omit source and confirm verification failure  
Proof: Reproducible proof package and verifier output  
Candidate controls: AU-9;CA-7; references: ADR-0037; dependencies: E06-03;E07-01.

**E07-04 — Unattended assessor acceptance drill (P0, Increment 2)**  
Starting point: Not demonstrated.  
Acceptance: Independent test client retrieves and validates selected controls without engineer intervention  
Negative test: Test stale evidence, unauthorized tenant and unavailable source  
Proof: Assessor script run and documented exceptions  
Candidate controls: CA-7;AU-6;AC-3; references: ADR-0037; dependencies: E07-02;E07-03.

### E08 — Detection and incident response
**Outcome:** Detect misuse and execute verified response.

**E08-01 — Production alert routing (P0, Increment 2)**  
Starting point: SNS alarms authored; SIEM workflow not connected.  
Acceptance: Connect alerts to incident queue with ownership, acknowledgment and escalation  
Negative test: Drop collector, revoke sessions repeatedly and force cleanup failure  
Proof: Alert-to-ticket drill with timestamps  
Candidate controls: AU-6;IR-4; references: ADR-0037; dependencies: E06-01.

**E08-02 — Privilege and anomalous access detections (P0, Increment 2)**  
Starting point: Not exercised.  
Acceptance: Detect admin use, unusual authentication, cross-tenant attempts and bulk operator revocation  
Negative test: Generate synthetic suspicious events; prove no silent failure  
Proof: Detection test suite and alert samples  
Candidate controls: AC-2(7);AU-6;SI-4; references: ADR-0024;ADR-0025; dependencies: E08-01.

**E08-03 — Emergency revoke all and credential invalidation (P1, Increment 2)**  
Starting point: Per-session revoke implemented; bulk action open.  
Acceptance: Terminate all selected tenant sessions through conductor and invalidate relevant tokens  
Negative test: Simulate partial outage; verify every unresolved session remains visible  
Proof: Incident drill and residual report  
Candidate controls: IR-4;AC-12;AC-2; references: ADR-0023;ADR-0025; dependencies: E01-04;E04-01.

**E08-04 — Security tabletop and live failure exercise (P1, Increment 3)**  
Starting point: Not demonstrated.  
Acceptance: Run identity compromise, evidence outage and tenant isolation incident scenarios  
Negative test: Confirm documented escalation on failed remediation  
Proof: Runbook exercise report and corrective backlog  
Candidate controls: IR-4;CP-4;AU-6; references: ADR-0021;ADR-0037; dependencies: E08-02;E08-03.

### E09 — Operator and customer UX
**Outcome:** Make authorized shell and RDP access fast and understandable.

**E09-01 — One-command CLI access journey (P0, Increment 1)**  
Starting point: Go CLI implemented; UX measurement absent.  
Acceptance: Operator can discover and connect to one permitted SSH/RDP target with own MFA  
Negative test: Unhealthy target, expired grant and auth failure yield actionable errors  
Proof: Timed usability run and anonymized error rates  
Candidate controls: AC-17;IA-2; references: ADR-0012;ADR-0016; dependencies: E03-01.

**E09-02 — Operator session and history view (P1, Increment 2)**  
Starting point: Live operator lens; history missing.  
Acceptance: Show own and authorized tenant sessions with purpose, expiry, status and termination  
Negative test: Non-owner cannot see unrelated tenant sessions  
Proof: UI acceptance and RBAC tests  
Candidate controls: AC-3;AU-3; references: ADR-0025; dependencies: E05-03.

**E09-03 — RDP credential and native-client UX (P1, Increment 2)**  
Starting point: CLI prints password.  
Acceptance: Complete secure native-client launch without exposing credentials in logs, browser or persistent files  
Negative test: Expired password and missing client handled without leakage  
Proof: Windows usability test and secret-scan results  
Candidate controls: IA-5;SC-28; references: ADR-0022; dependencies: E04-02.

**E09-04 — ServiceNow-optional justification adapter (P1, Increment 3)**  
Starting point: Ticket linkage desired, not built.  
Acceptance: Associate request with validated ticket when tenant policy requires; permit generic justification elsewhere  
Negative test: Reject missing/closed ticket under ticket-required policy  
Proof: Approval/justification evidence and adapter tests  
Candidate controls: AC-2;AC-6;AU-3; references: ADR-0024; dependencies: E02-03;E10-01.

### E10 — Replaceable provider contracts
**Outcome:** Keep identity, transport, evidence and UI interfaces replaceable.

**E10-01 — Versioned provider interfaces (P0, Increment 1)**  
Starting point: Identity/connection seams designed.  
Acceptance: Publish identity, transport, policy, evidence and frontend callback contracts with compatibility policy  
Negative test: Unknown provider cannot bypass required fields  
Proof: Interface specs and sample provider implementation  
Candidate controls: SA-8;AC-3;AU-12; references: ADR-0016;ADR-0017; dependencies: E03-02.

**E10-02 — Provider contract and conformance suite (P1, Increment 3)**  
Starting point: Not demonstrated.  
Acceptance: Run identical success/failure tests against SAML/OIDC and each supported transport  
Negative test: Reject incompatible assurance mapping and missing audit events  
Proof: Adapter certification report  
Candidate controls: IA-2;AC-3;AU-12; references: ADR-0016;ADR-0038; dependencies: E10-01;E01-02.

**E10-03 — Transport and identity substitution demo (P2, Increment 3)**  
Starting point: Not demonstrated.  
Acceptance: Swap one IdP and one transport without modifying central policy or trust-center schema  
Negative test: Regression tests catch provider-specific leakage into core  
Proof: Before/after architecture and regression suite  
Candidate controls: SA-8;AC-3; references: ADR-0016;ADR-0017; dependencies: E10-02;E03-04.

**E10-04 — Commercial policy profile (P2, Increment 3)**  
Starting point: Deployment by tfvars designed.  
Acceptance: Deploy less-regulated profile without weakening enforced baseline invariants  
Negative test: Prove regulated profile cannot select disallowed settings  
Proof: Configuration-diff and control-invariant report  
Candidate controls: CM-2;CM-6; references: ADR-0017;ADR-0021; dependencies: E05-04;E10-02.

### E11 — Deployment and resilience
**Outcome:** Deploy, operate and recover within documented boundaries.

**E11-01 — Secure CI/CD and artifact provenance (P0, Increment 1)**  
Starting point: Manual Terraform; partial CLI checksums.  
Acceptance: Implement review gates, IaC scans, dependency checks, artifact verification and rollback  
Negative test: Block unsigned build and policy-breaking IaC change  
Proof: Pipeline run and supply-chain attestation  
Candidate controls: CM-3;CM-5;RA-5;SI-7; references: ADR-0009;ADR-0015; dependencies: none.

**E11-02 — GovCloud and tenant deployment topology (P0, Increment 1)**  
Starting point: Commercial POC only.  
Acceptance: Deploy partition-safe stack with tenant accounts, central logs and approved regional services  
Negative test: Fail if unsupported partition service or global-edge dependency introduced  
Proof: Deployment manifests, boundary diagram and service inventory  
Candidate controls: SC-7;AU-9;CM-2; references: ADR-0019;ADR-0021; dependencies: E11-01.

**E11-03 — Recovery, canaries and reconciliation (P1, Increment 3)**  
Starting point: Single-region control plane; canaries missing.  
Acceptance: Set recovery objectives, synthetic connect canary and failed-workflow reconciliation  
Negative test: Inject collector, Lambda and state-machine failures  
Proof: Recovery test report and service health timeline  
Candidate controls: CP-2;CP-10;SI-4; references: ADR-0023;ADR-0037; dependencies: E04-04;E11-02.

**E11-04 — Emergency access and runbooks (P1, Increment 3)**  
Starting point: Operator runbook exists; break-glass incomplete.  
Acceptance: Exercise alternate authorized recovery when portal or primary IdP unavailable  
Negative test: Reject unaudited or unbounded emergency access  
Proof: Break-glass drill with retrospective approval and audit  
Candidate controls: CP-2;AC-2;AU-12; references: ADR-0024;ADR-0025; dependencies: E11-02;E08-03.

### E12 — Compliance assurance and ATO
**Outcome:** Link requirements to executable tests, evidence and assessor review.

**E12-01 — Requirements-to-evidence traceability (P0, Increment 1)**  
Starting point: Architecture control table and ADRs exist.  
Acceptance: Every in-scope requirement maps to owner, implementation, test, evidence, residual and responsibility  
Negative test: Flag control claims with no test or source evidence  
Proof: Exportable traceability matrix with gaps  
Candidate controls: CA-2;CA-7;PL-2; references: ADR-0020;ADR-0037; dependencies: E06-02.

**E12-02 — Automated security regression gates (P0, Increment 2)**  
Starting point: Some validation; live tests incomplete.  
Acceptance: CI and deployed tests cover identity, tenancy, grant scope, teardown, logging and evidence  
Negative test: Inject regression that passes functional happy path but violates invariant  
Proof: Per-build security verification package  
Candidate controls: CA-7;SA-11; references: ADR-0021;ADR-0023; dependencies: E05-03;E11-01.

**E12-03 — Inherited/shared responsibility and SCN review (P0, Increment 2)**  
Starting point: ADR-0020 stance documented.  
Acceptance: Document deployment-specific inheritance and customer obligations; classify significant changes with ATO team  
Negative test: Reject unsupported blanket inheritance or automatic ATO assertion  
Proof: Responsibility matrix and change-impact decision record  
Candidate controls: CA-3;CA-6;SA-9; references: ADR-0013;ADR-0020; dependencies: E11-02;E12-01.

**E12-04 — Independent assessor rehearsal (P1, Increment 3)**  
Starting point: Not performed.  
Acceptance: Assessor independently reproduces selected identity, access, tenant, evidence and recovery proofs  
Negative test: Capture gaps, disputed assertions and remediation ownership  
Proof: Assessment rehearsal report and closure backlog  
Candidate controls: CA-2;CA-7; references: ADR-0037; dependencies: E07-04;E12-02;E12-03.

---
## Source documents and verification boundary
- User-supplied *FedRAMP Portal — Architecture, Design Rationale, and 800-53 Alignment* (architecture, ADR summary, design-scoped control table).
- User-supplied *FedRAMP Portal — Improvements Delivered & Remaining Gaps*, dated 2026-09-29 (current stated implementation and residuals).
- Complete ADR source files, repository code, cloud account configuration, assessor criteria and live evidence were **not supplied for independent verification**. G0 explicitly closes that limitation. No assertion here is a formal 800-53, FedRAMP 20x or DoD IL4 certification decision.
