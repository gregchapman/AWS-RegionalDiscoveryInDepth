# FedRAMP Portal — Improvements Delivered & Remaining Gaps

**Date:** 2026-09-29 (re-audited against the current design and ADR-0037/0038)
**Scope:** As-built — layers 00–05 + React SPA + SSH Certificate Authority +
same-origin API Gateway front door (CloudFront removed).
**Purpose:** Honest register of (A) what this evolution has already FIXED
relative to the traditional model and earlier drafts, and (B) the gaps that
GENUINELY remain. Companion to `docs/ARCHITECTURE.md` (authoritative design +
800-53 alignment) and ADR-0021 (product vision). This file is deliberately
skeptical — but it no longer lists weaknesses the current architecture has
already resolved.

> **Current-status note (2026-09-29):** The platform track now contains an
> authored evidence plane: durable KMS/S3/DynamoDB evidence storage, a scheduled
> AWS posture collector, structured audit ingestion, failure alarms, and runtime
> `/audit`/`compliance`/review handlers in the CloudFormation delivery. These
> components are statically validated but not yet deployed and exercised in a
> real Organization. They close the design/code gap, not the live operational
> evidence gap. Multi-IdP and AD-optional operation is formalized in ADR-0038;
> Cognito remains the only implemented provider today.
>
> **This is a re-audit, not the old gap list.** Earlier versions accreted fixes
> in the remediation log without pruning the gap tables, so they listed problems
> that were already solved (MFA optional, no WAF on API, CORS localhost, no VPC
> endpoints, plaintext Linux password, no continuous monitoring, etc.). Those
> are moved to §1 "Improvements Delivered." §2 onward lists only what is still
> open.

---

## 1. Improvements Delivered (what this architecture already solves)

These are resolved in the current build. Listed so a reader does not mistake
them for open gaps, and so the evolution's value is visible.

| Area | Improvement | Controls | Ref |
|------|-------------|----------|-----|
| Front-door boundary | CloudFront removed; single same-origin API Gateway (REGIONAL) — no commercial global edge, in-boundary, CONUS-safe for IL4 | SC-7, SC-8, SA-9, PE | ADR-0019 |
| WAF decision made honest | The unassociable WAFv2 ACL was REMOVED from the code (it could never attach to HTTP API v2). The edge-WAF need is now tracked as an explicit SC-7 gap (§2) with an ALB/REST-edge remediation, not shipped as shelfware. | SC-7, SI-4 | ADR-0019 |
| CORS | Eliminated — SPA + API are same-origin; no cross-origin surface to misconfigure | SC-7 | ADR-0019 |
| Linux authenticator | Passwordless SSH certificate auth — no password created, stored, or shown; cert TTL ≤1h; KeyId = identity | IA-5, IA-5(1), SC-28, AU-2, AU-3 | ADR-0014 |
| Attribution | Ephemeral OS users are identity-named (e.g. `greg-racker-a751`), not random tokens; SendCommand Comment stamps the human | AC-2, AU-2, AU-3, IA-4 | ADR-0011 |
| MFA | Cognito MFA REQUIRED (not optional) | IA-2(1) | — |
| Zero inbound | Instances have no inbound ports; SSM outbound only; SSM VPC endpoints keep traffic on the AWS backbone | SC-7, AC-17 | ADR-0006 |
| Audit generation | CloudTrail (multi-region, log-file validation, 365d, CW streaming) + SSM session logging (S3 + CW) + API GW/SFN/Lambda logs | AU-2, AU-9, AU-12 | ADR-0010 |
| Continuous monitoring | GuardDuty + Security Hub + Config (org-managed in this account; org-level P-ATO covers them) | CA-7, SI-4, CM-6 | ADR-0010 |
| Encryption | KMS CMKs (credentials + SSH CA), S3 SSE-KMS on all buckets, encrypted EBS, IMDSv2 required | SC-13, SC-28, CM-6 | — |
| Tenant scoping (v1) | `customer_id` claim enforced fail-closed in list-instances; session-ownership checks in get/list-session | AC-3, AC-6(5) | ADR-0021 (invariant) |
| Credential-less access (vend) | `POST /api/session/{id}/ssm-credentials` vends STS creds scoped by an inline session policy to ONE instance + only the port-forward/SSH docs, <=1h, RoleSessionName=identity. User holds NO AWS creds. Broker role assumable only by the portal Lambda. | AC-6, AC-6(1), AC-12, AU-2, AU-3, AU-12, IA-2 | ADR-0012 |
| Tenant scoping (v2 — second check) | The vend endpoint re-validates the caller's `customer_id` against the target instance's live `Customer` EC2 tag at connect time (independent of the list-time filter), fail-closed. Closes the AC-6(5) "no independent second authorization" gap for the connect path. | AC-6(5) | ADR-0012 |
| Production CLI with self-contained MFA auth | Cross-platform Go CLI (`passport connect`) replaces the interim shell script. It performs its OWN Cognito SRP + MFA login (no handed-over token), brokers the credential-less SSM/SSH flow, and is distributed as a checksum-verified binary (download-verify-install, not curl\|bash). Closes the bearer-token-replay ORIGIN for the CLI path. | IA-2, IA-2(1), SC-23, CM-5, SI-7, SA-10 | ADR-0015, 0016 |
| Authoritative session termination (conductor) | The access-lifecycle state machine is the SOLE conductor: it polls the session record (~10s) for an end-demand and self-terminates on terminate/operator-revoke (status != ACTIVE) OR TTL, then runs ONE teardown that it VERIFIES before declaring the session `COMPLETED`. An unverifiable cleanup becomes the terminal `CLEANUP_FAILED` (surfaced for AU-6), never a silent success. Every end-trigger (portal End, operator revoke, CLI local exit, TTL) converges on the same verified teardown of all four concerns — connection, OS user, profile, and SSM tunnel (`ssm:TerminateSession`). `states:StopExecution` is forbidden and removed — aborting the conductor was the prior cause of ~81 stranded `CLEANING_UP` records. Replaces the ADR-0022 best-effort/stop-execution shape. | AC-12, AC-2, AC-2(3), AU-6 | ADR-0023 |
| Portability / evidence posture | Partition-safe code (intersection palette) + inherited-controls stance → cleaner, more machine-readable evidence for the Rev 5 → 20x transition | (20x readiness) | ADR-0017, 0019, 0020 |

---

## 2. Remaining Gaps — Security & Compliance

Only genuinely-open items. Resolved items are in §1.

| Control | Gap | Severity | Remediation |
|---------|-----|----------|-------------|
| **AC-2(7)** Privileged Role Monitoring | RGS-Admin permission set grants broad access with no session monitoring / break-glass alert. Note (ADR-0025): ALL Rackers currently share the operator lens (see + revoke any user's session, tenant-scoped) — there is no intermediate, non-admin operator role yet, and operator revoke, while attributed + justified (ADR-0024), is not yet alarmed. | High | CloudTrail alert on RGS-Admin usage; time-bound escalation requiring justification; intermediate (non-admin) Racker permission sets; AU-6 alarm on anomalous operator revoke (e.g. one principal ending N sessions across tenants). |
| **AC-6(5)** Least Privilege (secondary check) | **CLOSED for the current connect path (2026-09-29):** `create_access_request` now authorizes the target instance fail-closed before writing the session record or starting Step Functions. Customer callers must have a matching `customer_id`, `CustomerAccess=true`, and an allowed target region; operators retain their intended broader scope. The credential-vend endpoint continues to perform an independent live-tag re-check. | Low residual | Keep the vend-time re-check and add negative tests proving unauthorized requests never invoke SSM. Production still requires hard account boundaries and cross-account authorization. |
| **AU-6** Audit Review / Alerting | **PARTIALLY CLOSED in the CFN platform code (2026-09-29, ADR-0037):** structured audit events, evidence collector/API failure alarms, and an SNS alert topic now exist. The alert topic has not yet been connected to a production incident/SIEM workflow, and the evidence plane has not been deployed or exercised in an Organization. | High (production) | Subscribe the alert topic to the approved incident/SIEM path; add anomalous-auth, cross-tenant, operator-revoke, cleanup-residual, and stale-evidence detections; execute a live review/response drill. |
| **AU-9** Audit Log Protection (cross-account) | In the single-account POC, an account admin could delete CloudTrail logs. | High (production) | Production: send to an Organization trail in a separate log-archive account. Table-stakes for ATO; not solvable in the single-account model. |
| **IA-5(1)** Password-Based Auth (RDP only) | Windows/RDP still uses a generated password (Linux resolved via SSH CA). The password is stored in DynamoDB (see SC-28) and printed to the user by the `passport` CLI at connect time — it is no longer surfaced in the SPA drawer (SC-28 win). | Medium | Vend the RDP password on-demand instead of storing it (the ADR-0022 clean fix; backend not yet built), or Directory-join / Fleet Manager RDP for passwordless; interim: field-level KMS encryption of the stored password. |
| **SC-28** Protection at Rest (RDP password) | The RDP `temporary_password` is stored plaintext in DynamoDB — written by the state machine's `UpdateStatusActiveRDP` (the raw value `provision_user` returns), KMS encrypt-side deferred; the CLI reads it from the record at connect time. The SPA drawer no longer displays it. Linux stores no password at all. NOTE: a `portal_utils.encrypt_field()` helper already EXISTS but is never called — the field-encryption remediation is partially scaffolded (one call-site in the state-machine write path + the existing `decrypt_field` on read). | Medium (RDP) | Vend the password on-demand (never store it — ADR-0022 clean fix), or encrypt the field (wire the existing `encrypt_field` into the ASL write + confirm `decrypt_field`'s length heuristic handles the ciphertext), or eliminate it via passwordless RDP. |
| **IR-4** Incident Handling | No one-click automated "kill switch" to terminate all active sessions / revoke ephemeral users on compromise. PARTIAL: a manual operator revoke procedure exists (`docs/OPERATOR-RUNBOOK.md`), and per-session terminate is authoritative + verified (conductor, ADR-0023). | Medium | Automated emergency-revoke endpoint that writes an end-demand to EVERY live session record and lets each conductor converge (NOT `states:StopExecution` — aborting conductors is forbidden per ADR-0023, it strands records), plus Cognito token invalidation. The per-session verified teardown already exists; this is the fan-out + token-revoke on top. |
| **RA-5** Vulnerability Scanning | No scanning of Lambda dependencies or EC2. | Medium | Inspector for EC2; `pip-audit` / `safety` in CI for Lambda deps. |
| **SC-7** No WAF at the front door | **OPEN.** WAFv2 canNOT associate to an API Gateway HTTP API (v2) — supported regional targets are REST API (v1), ALB, AppSync, Cognito, App Runner, Amplify, Verified Access. The chosen front door is HTTP API v2, so there is no WAF inspection at the edge. The unassociable WAF ACL was REMOVED from the code (2026-09-01) rather than left as shelfware. | High | Front the HTTP API with an **ALB** (a supported WAF target) and attach a REGIONAL WAF there — strongest reason to revisit ALB-vs-API-GW for the IL4 tier (ADR-0019). Or use a REST API (v1) edge. Interim: Cognito JWT + API GW throttling + Shield Standard. Do NOT reintroduce CloudFront. |
| **SC-7(5)** Deny by Default (IP allowlist) | Front door has no IP allowlisting; any internet source can reach it (API GW throttling only, since WAF is not associated — see above). | Medium | Once a WAF-capable edge exists (ALB/REST), add a WAFv2 IP-set restricting to Rackspace/agency CIDRs. |
| **CM-5(1)** Inline provisioning scripts | Provision/cleanup scripts are inline in the Lambdas, not versioned SSM Documents. Harder to audit / change-control. | Medium | Move to versioned `aws_ssm_document` resources. |
| **AU-9 / AU-11** Operational record reaped before failure is actioned (NEW, ADR-0023/0025) | The DynamoDB session record is reaped by its `expires_at` TTL independent of teardown outcome, so a `CLEANUP_FAILED` (or any terminal) record can drop off the LIVE operator view before anyone acts on it — this is how the I10 orphaned Windows accounts ended up with no record. NOT an audit-loss: the permanent evidence survives in CloudWatch Logs (`CLEANUP RESIDUAL: ...`) and CloudTrail (SendCommand + full execution), which are retained independent of the DynamoDB TTL. It is a monitoring/reconciliation gap. | Medium | (Under 800-53 review, greg.) Do not TTL-reap NON-terminal records; retain terminal records for the audit window; add an AU-6 alarm on `CLEANUP_FAILED` so a residual is actioned before its operational record ages out. |
| **AC-2(1) / tenant-scope completeness** Fail-open tenant stamp (NEW, ADR-0025) | **CLOSED for new requests (2026-09-29):** target lookup and tenant stamping now fail closed in the POC, platform module, and CloudFormation connect handlers. Missing/unreadable targets and untagged targets cannot create a session request. Existing historical records require normal reconciliation/retention handling. | Low residual | Add automated negative tests and retain the independent vend-time re-check; production still needs account-level tenant boundaries. |
| **IA-2 / SC-23** Bearer-token replay (portal identity token) | ~~Anyone who captures the token can replay it from any shell~~ **ORIGIN CLOSED for the CLI path (2026-08-31, ADR-0016):** the production Go CLI (`passport connect`) performs its OWN Cognito SRP + MFA login — it never accepts a handed-over token, so there is no browser-minted token to lift into a shell for the CLI flow. The SPA drawer no longer exposes a "copy token" button. RESIDUAL (still open): once minted, the access token is a bearer token for its ~1h life with no proof-of-possession; a token exfiltrated from memory in that window is still replayable, and attribution would still read as the real user. | Low (was Medium) | Add DPoP / mTLS-bound (proof-of-possession) tokens so a stolen token is unusable without the client key; shorten access-token TTL; monitor for token use from anomalous IP/UA (AU-6); per-session binding. The interim `scripts/passport-connect.sh --token` remains a TEST tool only — not the production auth path. |
| **AC-6** Session-broker role blast radius (NEW residual, ADR-0012) | The `session_broker` role's OWN identity policy allows `ssm:StartSession` on `instance/*` in-account; every vend narrows it to one instance via an inline session policy, but a code path that assumed the role WITHOUT passing that policy would get account-wide StartSession. Mitigated: the role is assumable ONLY by the portal Lambda (trust policy), which always passes the policy; role chaining caps any session at 1h. | Low | Belt-and-suspenders: (a) add a `Condition` on the broker trust requiring a session-policy-derived tag, or (b) split per-region/per-tenant broker roles so the standing blast radius is smaller. Track for production hardening. |
| **SC-8 (enhancement)** Request signing | API is JWT-authenticated but not request-signed; a valid-token holder could replay. | Low/Medium | For High/IL5 consider mTLS or request signing. Acceptable at Moderate. |
| **SC-28 (enhancement)** SSM session-log CMK | Session logging encryption uses default keys (session doc `kmsKeyId` empty). | Low | Point the SSM session document at a dedicated CMK. |
| **DNSSEC** | Not enabled on the POC domain (`takahe.click`). | Low (POC) / Medium (prod) | Enable DNSSEC on the production hosted zone (KMS KSK + registrar DS record). |
| **No IdP federation (Cognito standalone)** | The reference runtime still authenticates against a STANDALONE Cognito user pool. **ADR-0038 now formalizes multi-IdP SAML/OIDC extensibility and AD-optional AWS operation.** The normalized identity contract exists, but federated provider resources, issuer/subject lifecycle, account-linking protections, and two-provider tests are not implemented. | Critical (production) | Implement at least one SAML and one OIDC provider, map tenant/groups/MFA/assurance fail-closed, prevent email-based account collisions, and require phishing-resistant assurance for privileged production roles. |

### NIST 800-171 (CUI) — remaining

| Requirement | Gap |
|-------------|-----|
| 3.1.12 Monitor/control remote access | SSM sessions are logged but not monitored in real-time; no live session recording review. |
| 3.13.8 Protect CUI in transit | TLS everywhere (compliant); no certificate pinning on the SPA (enhancement). |

---

## 3. Remaining Gaps — Tenant Isolation (ADR-0021 hard invariant)

Customer1 must NEVER see Customer2. Current scoping is functional but not
defense-in-depth. Treat every item here as high priority — this is an inviolable
invariant, not a feature.

| Issue | Severity | Detail | Remediation |
|-------|----------|--------|-------------|
| Single account = soft isolation | Critical (production) | POC uses IAM + tags + regions as boundaries (ADR-0002). A misconfigured policy could cross tenants. | Production: hard account/boundary separation per tenant. |
| Tag-integrity dependence | High | Instance visibility depends on the `Customer` / `CustomerAccess` tags being correct. No enforcement that they can't be altered. | Config rule + SCP to protect tag integrity; connect-time re-validation (see AC-6(5)). |
| Filtering in Lambda code | Medium | list-instances filters by `customer_id` in Python, fail-closed, but a code bug is the only thing between tenants. | Add the independent connect-time authorization check; unit/integration tests asserting cross-tenant denial (candidate for the automated 800-53 test suite). |
| Shared DynamoDB table | Low | All tenants share one access-requests table; ownership check guards reads. | Acceptable with ownership checks; revisit if isolation requirements harden. |

---

## 4. Remaining Gaps — Reliability

| Issue | Severity | Detail |
|-------|----------|--------|
| Single-region management plane | High | API/Cognito/DynamoDB/Step Functions in one region. Regional outage = portal down (CLI-level SSM still works). |
| Forced execution kill bypasses cleanup | Low | RESOLVED for the normal paths (2026-08-31, ADR-0022): the state machine now POLLS and self-terminates on end-demand or TTL, and terminate runs immediate SSM cleanup — so client-TTL expiry, portal terminate, and operator revoke all clean up. Residual: a hard `stop-execution` (operator abort) still skips the machine's cleanup, but terminate already removed the OS user in that path; a stray ephemeral user only lingers if someone aborts an execution out-of-band. | Low | EventBridge on execution-ABORTED → cleanup Lambda closes the out-of-band-abort edge. |
| No dead-letter / failure cleanup | Medium | Failed executions don't trigger cleanup. Add EventBridge on execution-failure → cleanup Lambda. |
| No health checks / canary | Medium | No Route 53 health check or synthetic canary on the front door. |
| NAT single-AZ | Medium | One NAT per customer VPC; AZ loss affects other-AZ instances' egress. (SSM itself rides the VPC endpoints, so session access is more resilient than OS-update egress.) |
| serve_spa in the hot path | Low | The SPA-serving Lambda handles every static asset request. Fine for an internal low-traffic portal; note for scale. |
| No polling backoff | Low | Connect polling has no exponential backoff. |

---

## 5. Remaining Gaps — Operational Maturity (Well-Architected)

| Area | Gap |
|------|-----|
| Operational Excellence | No runbooks; manual `terraform apply` (no CI/CD, approval gates, rollback); no feature flags; no observability dashboard (SPoG dashboard is a tracked future item). |
| Cost | Test EC2 always-on (add start/stop schedule); NAT cost; no cost-allocation-by-customer tags. |
| Performance | Lambda cold starts; no caching on list-instances; background token refresh missing (1h token expiry causes re-auth). |
| Sustainability | 4 test instances 24/7 (schedule them); no formal right-sizing. |

---

## 6. Remaining Gaps — User Experience

| Issue | Detail |
|-------|--------|
| No session history page | "My Sessions" via the existing user-index GSI. (Note: session persistence across reload IS implemented; a dedicated history view is not.) |
| No graceful re-connect UX | On cert/session expiry, UX could guide re-issue more clearly (mechanism exists via "Generate a new certificate"). |
| Racker quality-of-life | No bulk connect, favorites, instance health dashboard, "who else is connected," or ServiceNow ticket linkage (ticket linkage matters for the operator perspective — ADR-0021). |
| No mobile story | Deprioritized; add a "best on desktop" notice. |

---

## Priority Matrix (remaining only)

| Priority | Items |
|----------|-------|
| **P0 — Blocking for production** | GovCloud partition move + agency domain/cert (ADR-0019 code done, partition pending); hard tenant isolation (separate accounts); AU-9 cross-account log protection; Identity Center → real IdP federation; RDP password encryption-or-elimination |
| **P1 — Required for assessor** | Live evidence-plane deployment and review drill; AU-6 alert/SIEM integration; multi-IdP assurance evidence; RA-5 scanning; deployment pipeline; DNSSEC (prod) |
| **P2 — Should fix** | Dead-letter queue + failure cleanup; NAT HA; inline scripts → SSM Documents; IR-4 kill switch; SC-7(5) IP allowlist; SSM session-log CMK |
| **P3 — Nice to have** | Session history page, bulk ops, favorites, health dashboard, ServiceNow linkage, cost/perf/sustainability, mobile notice |

---

## Remediation Log

| Date | Control | What was done |
|------|---------|---------------|
| 2026-08-26 | IA-2(1) | Cognito MFA set to ON (required). |
| 2026-08-26 | SC-7 | WAF WebACL added for the API (REGIONAL scope). Rate limit + managed rules. |
| 2026-08-26 | SC-28 | KMS CMK created for credential encryption; decrypt wired in get-session-status. |
| 2026-08-26 | AC-6(5) | customer_id claim enforced in list-instances Lambda. Fail-closed if missing. |
| 2026-08-26 | SC-7 | VPC endpoints for SSM (ssm, ssmmessages, ec2messages) added to customer VPCs. |
| 2026-08-26 | SI-4 / CA-7 / CM-6 | GuardDuty, Security Hub (NIST 800-53 v5 + AWS Foundational), AWS Config rules (org-managed in this account). |
| 2026-08-26 | AU-9 / AU-12 | CloudTrail (dedicated bucket, log-file validation, Glacier@90d, 365d) + SSM session logging (S3 + CW streaming). |
| 2026-08-27 | AC-2/AU-2/AU-3 | Ephemeral users identity-named (e.g. `greg-racker-a751`); SendCommand Comment stamps the identity (ADR-0011). |
| 2026-08-27 | SC-28 / IA-5 (Linux) | **Linux RESOLVED.** SSH Certificate Authority (ADR-0014): passwordless, short-lived (≤1h) CA-signed user certs; CA key in Secrets Manager (KMS); TrustedUserCAKeys; KeyId=identity in sshd logs. Windows/RDP still password-based (tracked). |
| 2026-08-28 | SC-7 / SC-8 / SA-9 / PE | **CloudFront REMOVED (ADR-0019).** Partition-intersection rule established. Front door rebuilt: same-origin API Gateway (REGIONAL) + WAFv2 REGIONAL (stage) + ACM + Shield + Route 53. CloudFront + Global Accelerator prohibited for IL4. Layer 02 rebuilt (private SPA bucket + zone + cert; create-vs-consume toggles). |
| 2026-08-28 | SC-7 (WAF) | **CORRECTION / NOT resolved.** An earlier entry here claimed WAF was associated to the HTTP API v2 stage — that is FALSE. Deploy-time testing proved WAFv2 does NOT support HTTP API v2 as a target (WAFInvalidParameterException); the prior POC belief was correct. The association resource was REMOVED. The WAF ACL exists but is UNASSOCIATED → OPEN SC-7 gap (see §2). CORS removal stands (SPA + API same-origin). |
| 2026-08-28 | Docs / 20x | Authored `docs/ARCHITECTURE.md` (design + per-resource 800-53 alignment, AWS-inherited vs customer-implemented per ADR-0020, SPA rationale, IL4 boundary). ADR-0021 (product vision, users, tenant-isolation invariant, 20x posture). This file re-audited to Improvements + honest remaining gaps. |
| 2026-09-29 | AC-6(5) / AC-2(1) | **Pre-provisioning target authorization CLOSED.** POC, platform-module, and CloudFormation connect handlers now fail closed on target lookup, region, `CustomerAccess`, and customer claim mismatch before DynamoDB or Step Functions side effects. Vend-time live-tag re-validation remains as defense in depth. |
| 2026-09-29 | CA-7 / AU-6 / AU-9 / ADR-0037 | **Evidence plane authored.** CFN adds KMS/S3/DynamoDB evidence storage, scheduled Config/Security Hub/GuardDuty/SSM collection, structured audit writes, `/audit` and `/compliance` projections, operator review, and collector/API alarms. Deployment and live Organization exercise remain open. |
| 2026-09-29 | IA-2 / IA-4 / AC-2 / ADR-0038 | **Multi-IdP/AD-optional target formalized.** The identity contract is provider-neutral; AWS SSM access does not require customer AD. Cognito remains the only runtime provider until SAML/OIDC resources and two-provider tests are delivered. |

## Summary

The current build is a **functional POC** that proves the access pattern
end-to-end and has already closed the biggest early gaps (MFA, WAF on the API,
CORS, passwordless Linux, identity attribution, audit generation, encryption,
in-boundary front door). It is **not yet production-ready** and would not pass a
FedRAMP assessment as-is. The genuine remaining blockers are structural, not
design flaws:

1. **GovCloud partition + hard tenant isolation** — the single-account model is
   for the POC only; production needs the partition and per-tenant account
   separation (the ADR-0021 invariant demands defense-in-depth here).
2. **Audit review / alerting** — we generate strong logs but don't yet watch
   them; this is also the core of 20x machine-readable-evidence maturity.
3. **Production identity federation** — real IdP with phishing-resistant MFA.
4. **RDP credential handling** — Linux is passwordless; Windows still needs it.
5. **Operational maturity** — CI/CD, runbooks, dead-letter cleanup, dashboards.

The architecture is sound and the direction (ADR-0019/0020/0021) is deliberately
built for the Rev 5 → 20x transition. The remaining work is operational and
environmental, not architectural.
