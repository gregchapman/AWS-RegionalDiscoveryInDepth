# FedRAMP Access Portal — Client Instructions

Instructions for developers, Rackers, and customers to run and use the
FedRAMP Access Portal.

---

## For Developers (Running Locally)

### Prerequisites

- Node.js >= 20
- npm
- AWS CLI v2 (for SSM port-forwarding after connecting)
- Git access to this repo

### First-Time Setup

```bash
# 1. Clone and enter the portal directory
cd FedRAMP-Portal-Idea/portal

# 2. Install dependencies
npm install

# 3. Generate environment config (requires deployed infrastructure)
cd ..
./scripts/collect-outputs.sh
# This creates portal/.env.local with Cognito + API values

# 4. Start the dev server
cd portal
npm run dev
# Portal is now running at http://localhost:5173
```

### If collect-outputs.sh hasn't been run (or infra isn't deployed)

Create `portal/.env.local` manually with values from your terraform outputs:

```bash
VITE_COGNITO_USER_POOL_ID=us-east-1_XXXXXXXXX
VITE_COGNITO_CLIENT_ID=xxxxxxxxxxxxxxxxxxxxxxxxxx
VITE_COGNITO_DOMAIN=fedramp-portal-675405875014
# SAME-ORIGIN (ADR-0019): in a deployed build the SPA and the API share one
# host, so VITE_API_URL is EMPTY and the client uses a relative /api path.
# Leave it defined-but-empty. (An UNSET var falls back to a localhost dev API.)
VITE_API_URL=
VITE_IDENTITY_CENTER_START_URL=
```

Get these values by running in the terraform/03-api directory:
```bash
terraform output portal_env_config
```

> **Local dev note:** `npm run dev` serves the SPA on `http://localhost:5173`.
> Calling a *deployed* same-origin API from localhost requires a dev proxy
> (Vite `server.proxy`) because there is no CORS on the deployed API. This is a
> dev-workflow concern only; the deployed portal is same-origin end to end.

---

## For Rackers (Using the Portal)

### Logging In

1. Navigate to the portal URL (`https://portal.takahe.click` for the POC, or `http://localhost:5173` for dev)
2. Click **"Sign In with SSO"**
3. You'll be redirected to the Cognito hosted login page
4. Enter your credentials (email + password)
5. Complete MFA (TOTP authenticator app)
6. You'll be redirected back to the **Racker Console** at `/racker`

### First-Time Login (Setting Up MFA)

On your first login after account creation:
1. You'll be prompted to change your temporary password
2. Set a password (minimum 12 chars, upper + lower + number + symbol)
3. You'll be prompted to set up MFA — scan the QR code with your authenticator app (Google Authenticator, Authy, etc.)
4. Enter the 6-digit code to confirm

### Navigating the Racker Console

- **Customer Accounts** — cards showing each customer environment (region-based in test mode)
- **Console button** — opens AWS Console via Identity Center (requires org-level Identity Center)
- **Region filter** — click a region to filter instances
- **Instance Table** — all SSM-managed instances across target regions
- **Connect button** — initiates ephemeral access to an instance

### Connecting to an Instance

1. Find the instance in the table (filter by name, ID, region, or platform)
2. Confirm the instance shows **Online** status (green dot)
3. Click **Connect (SSH)** or **Connect (RDP)** depending on OS
4. Wait for provisioning (~10-15 seconds) — the button shows a spinner
5. When the **Session Drawer** opens, you'll see:
   - **Username** — the ephemeral user created on the instance. It is
     **identity-derived** (named for you, e.g. `greg-racker-a751`), not a random
     token, so OS logs, CloudTrail, and SSM session logs attribute to a real
     person (ADR-0011).
   - **SSH (Linux):** a **Generate SSH Certificate** button — SSH is
     **passwordless** (ADR-0014). There is no password field for Linux.
   - **RDP (Windows):** a **Password** field — click "Show" / "Copy" (RDP is
     still password-based until directory-join lands).
   - **Connect Command** — the SSM port-forwarding command
   - **Countdown Timer** — time remaining before auto-cleanup (the
     *authorization window*; you can re-generate a cert any time within it).

### Using the Connection (SSH/Linux — passwordless, certificate-based)

Linux access uses a short-lived SSH certificate signed by the portal's SSH CA.
No password is ever created or entered.

```bash
# 1. In the Session Drawer, click "Generate SSH Certificate". The browser
#    generates a keypair locally and receives a signed certificate (valid up
#    to 1 hour). The drawer gives you the private key + certificate to save,
#    e.g. ~/.ssh/portal_key and ~/.ssh/portal_key-cert.pub.

# 2. Start the SSM port-forward (command is in the drawer):
aws ssm start-session --target i-0123456789abcdef0 \
  --document-name AWS-StartPortForwardingSession \
  --parameters portNumber=22,localPortNumber=2222 \
  --region us-east-2

# 3. In another terminal, SSH through the tunnel using the key + cert
#    (no password prompt — the certificate authorizes you):
ssh -i ~/.ssh/portal_key \
    -o CertificateFile=~/.ssh/portal_key-cert.pub \
    <your-identity-username>@localhost -p 2222
```

If the certificate expires while your access window is still open, click
**Generate a new certificate** in the drawer and reconnect (long-lived
authorization window, short-lived authenticator — ADR-0014).

### Using the Connection (RDP/Windows — password-based)

```bash
# 1. Copy the port-forward command from the drawer and run it:
aws ssm start-session --target i-0123456789abcdef0 \
  --document-name AWS-StartPortForwardingSession \
  --parameters portNumber=3389,localPortNumber=33389 \
  --region us-east-2

# 2. Open your RDP client and connect to:
#    Host: localhost
#    Port: 33389
#    Username: .\<your-identity-username>   (the .\ forces LOCAL account context;
#              Windows otherwise prepends a domain and the login fails)
#    Password: (from the Session Drawer)
```

### Session Lifecycle

- Sessions have a default TTL of **60 minutes**
- The countdown timer in the Session Drawer shows time remaining
- When the timer expires:
  - Your SSH/RDP connection is terminated
  - The ephemeral user is automatically deleted from the instance
  - The session status changes to COMPLETED
- There is no way to extend a session — start a new one if needed

---

## For Customers (Using the Portal)

### Logging In

1. Navigate to the portal URL provided by your RGS account team
2. Click **"Sign In with SSO"**
3. Enter your credentials + MFA code
4. You'll be redirected to the **Customer Dashboard** at `/customer`

### What You Can See

- **My Instances** — only instances tagged for your account are visible
- You will NOT see other customers' instances or Racker tools
- If you see zero instances, contact your RGS account team (your customer_id may not be configured)

### Connecting to Your Instances

Same process as Rackers (see above). The Connect button, Session Drawer,
and port-forwarding workflow are identical. The only difference is you
see only your own instances.

### What You Cannot Do

- View other customer environments
- Access the Racker Console or account selector
- Open AWS Console via Identity Center (this is Racker-only in test mode)
- Extend sessions beyond the configured TTL
- Connect to instances not tagged for your account

---

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| "Sign In" redirects but nothing happens | Cognito callback URL mismatch | Ensure your URL (localhost or `https://portal.takahe.click`) is in the Cognito app client's callback list. The portal is same-origin, so the callback is `<portal-host>/callback`. |
| MFA setup QR code won't scan | Screen too small or camera issue | Use the manual setup key (text code) instead of QR |
| "No instances found" | Instances not tagged or SSM agent offline | Check EC2 tags (`CustomerAccess=true`, `Customer=<name>`) and SSM agent status |
| Connect button disabled (greyed out) | Instance SSM agent is offline | Wait for agent to come online or check instance's internet connectivity |
| "Connecting..." spinner never resolves | Step Function failed | Check the API response at `/api/session/<requestId>` for error details |
| Port-forward command fails | AWS CLI not configured or wrong region | Run `aws sts get-caller-identity` to verify creds, check the --region flag |
| `403 Server authentication failed` on start-session | Intermittent SSM session-broker flakiness (NOT a real auth problem if `aws sts get-caller-identity` works) | Simply re-run the same command. It typically succeeds on the second attempt. |
| "Access denied" on session status | You're not the session owner | Customers can only view their own sessions |
| Password shows "[decryption failed]" | KMS key permissions issue | Contact the platform team — Lambda may lack KMS Decrypt permission |

---

## Requirements for Each User Type

| Requirement | Racker | Customer |
|-------------|--------|----------|
| Cognito account | Yes (Rackers group) | Yes (Customers group) |
| MFA configured | Yes (required) | Yes (required) |
| AWS CLI installed | Yes (for port-forwarding) | Yes (for port-forwarding) |
| AWS credentials | Yes (any profile, for SSM CLI) | Yes (for SSM CLI) |
| `custom:customer_id` attribute | Not needed | Required (set by admin) |
| Network access to portal URL | Yes | Yes |
| Network access to AWS SSM endpoints | Yes (for port-forwarding) | Yes (for port-forwarding) |

---

## Admin: Creating Users in Cognito

To give someone portal access:

```bash
# Create user
aws cognito-idp admin-create-user \
  --user-pool-id us-east-1_XXXXXXXX \
  --username user@example.com \
  --user-attributes Name=email,Value=user@example.com \
  --temporary-password "TempPass123!" \
  --region us-east-1

# Add to group (Rackers or Customers)
aws cognito-idp admin-add-user-to-group \
  --user-pool-id us-east-1_XXXXXXXX \
  --username user@example.com \
  --group-name Rackers \
  --region us-east-1

# For customers, also set the customer_id attribute:
aws cognito-idp admin-update-user-attributes \
  --user-pool-id us-east-1_XXXXXXXX \
  --username customer@example.com \
  --user-attributes Name=custom:customer_id,Value=customer1 \
  --region us-east-1
```

The `custom:customer_id` value must match the `Customer` tag on the EC2
instances the customer should be able to see and access.

---

## Architecture Quick Reference

```
You (browser) → portal.<domain> (Route 53)
                     ↓
              API Gateway (REGIONAL, one same-origin host) + WAF
              ├── $default → serve_spa Lambda → private S3 (React SPA)
              └── /api/*   → [Cognito JWT] → Lambda → DynamoDB / Step Functions
                                                          ↓
                                                    SSM RunCommand → EC2 Instance
                                                          ↓
              You (terminal) → SSM Port Forward → Instance
                                                    ├── SSH: cert-based (no password)
                                                    └── RDP: password
```

No CloudFront (ADR-0019). The SPA and API share ONE origin. All traffic is
encrypted (TLS 1.2). No inbound ports are open on instances. Linux access is
passwordless (SSH certificate). Access is ephemeral and auto-cleaned-up.

For the full design and 800-53 alignment, see `docs/ARCHITECTURE.md`.
