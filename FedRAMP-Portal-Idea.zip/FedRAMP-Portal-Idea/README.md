# RGS FedRAMP Access Portal

Zero-trust access portal for Rackspace Government Services (RGS). Replaces
AD + VPN + JumpHosts with Cognito auth + SSM Session Manager +
Passport-V2-style ephemeral, identity-attributed access.

## Why this exists (short version)

The traditional access model — Active Directory + VPN + jump hosts (or a
server-rendered portal) — is pervasive but a poor fit for cloud: it won't
satisfy **FedRAMP 20x** cleanly (no clean continuous, machine-readable
evidence), it imposes cost/consumption penalties that **devalue cloud
engagement**, and it widens the attack surface (a jump host to breach, a VPN
path granting broad reach, standing access). This portal delivers equal-or-
better functionality without that baggage — including **MFA in the reference
POC, with phishing-resistant assurance required for production federation** —
while producing the attributable, machine-readable evidence a 20x posture
wants.

It is an **RGS-org-exclusive**, in-boundary evolution of Rackspace Commercial
MSP's **Passport V2** (ADR-0013). It serves three first-class users:
**ATO auditors** (machine-readable evidence), **Rackspace engineers/operators**
(support work, usually via ServiceNow), and **customers** (secure access to
their own resources). Growth is **ATO-additive via SCN** (e.g. later: AWS
console + other services), and the provider architecture (ADR-0016) extends the
same managed model to other clouds and **private cloud (vCenter, OpenStack)**.
**Tenant isolation — Customer1 never sees Customer2 — is an inviolable
invariant.** Full statement: ADR-0021 and `docs/ARCHITECTURE.md` §1.

> **Read `docs/ARCHITECTURE.md` first** for the in-depth design, the meaning of
> "SPA" (Single-Page Application) and why it beats the VPN model, the ADR
> posture (ADR-0001 through ADR-0021), and the per-resource NIST 800-53
> alignment (FedRAMP Moderate / DoD SRG IL4), including which controls are
> AWS-inherited vs. customer-implemented.

## Architecture (current — CloudFront removed, ADR-0019)

The portal is fronted by a SINGLE, same-origin **API Gateway (REGIONAL)** that
serves both the SPA and the API. CloudFront is banned for IL4 (commercial-only
global edge — see ADR-0019).

```
┌──────────────────────────────────────────────────────────┐
│  User's Browser — React SPA (static, client-rendered)     │
│   /racker  → Racker view (all accounts)                   │
│   /customer → Customer view (their account only)          │
└───────────────────────────┬──────────────────────────────┘
                            │ HTTPS / TLS 1.2 (same origin)
┌───────────────────────────▼──────────────────────────────┐
│  Route 53 (public) → portal.<domain>                      │
└───────────────────────────┬──────────────────────────────┘
                            │
┌───────────────────────────▼──────────────────────────────┐
│  API Gateway HTTP API v2 (REGIONAL, TLS 1.2)              │
│   $default   → serve_spa Lambda → private S3 (SPA assets) │
│   /api/*     → [Cognito JWT] → handler Lambdas:           │
│      /accounts /instances /connect /session /sessions     │
│      /sign (SSH CA) /session/{id}/terminate               │
└───────────────────────────┬──────────────────────────────┘
                            │
┌───────────────────────────▼──────────────────────────────┐
│  Step Functions — access lifecycle                        │
│   provision (region-aware Lambda → SSM) → wait TTL →      │
│   cleanup (region-aware Lambda → SSM)                     │
└───────────────────────────┬──────────────────────────────┘
                            │
┌───────────────────────────▼──────────────────────────────┐
│  Target EC2 (private subnets, SSM-only, zero inbound)     │
│   Linux : identity-named, passwordless, SSH-CA trust      │
│   Windows: identity-named, generated password             │
└──────────────────────────────────────────────────────────┘
```

## Project Structure

```
FedRAMP-Portal-Idea/
├── README.md                          (this file — start here, then docs/ARCHITECTURE.md)
├── docs/
│   └── ARCHITECTURE.md                (authoritative design + 800-53 alignment + SPA definition)
├── ARCHITECTURE-WEAKNESSES.md         (honest gap register + remediation log)
├── Client-Instructions.md             (end-user how-to for the portal)
├── todo.md                            (session state and build tracker)
├── .kiro/
│   └── steering/                      (ADR-0001 through ADR-0022, auto-loaded)
├── terraform/
│   ├── 00-backend/                    (S3 state bucket + DynamoDB lock)
│   ├── 02-portal-hosting/             (private SPA bucket + Route 53 zone + ACM cert)
│   ├── 03-api/                        (API Gateway front door + Cognito + Lambdas + DynamoDB + Step Functions + KMS + SSH CA)
│   │   ├── front-door.tf              (serve_spa Lambda, custom domain, Route 53 alias)
│   │   ├── ssh-ca.tf                  (SSH CA: KMS key, Secrets Manager, SSM param)
│   │   ├── lambda/                    (Python handlers, serve_spa, sign_key, shared layer, crypto layer)
│   │   └── state-machine/             (access-lifecycle.asl.json)
│   ├── 04-test-environment/           (VPCs + EC2 in multiple regions)
│   │   └── modules/customer-vpc/      (reusable VPC + instances + SSM VPC endpoints)
│   └── 05-security-baseline/          (CloudTrail + SSM session logging; GuardDuty/SecurityHub/Config org-gated)
├── portal/                            (React SPA — Vite + TypeScript + Tailwind)
│   └── src/{components,pages,api,auth,styles}
└── scripts/
    ├── collect-outputs.sh             (pulls terraform outputs; generates portal/.env.local same-origin)
    ├── create-test-users.sh           (creates Cognito test users — Rackers + Customers)
    ├── init-ssh-ca.sh                 (one-time: populate the SSH CA keypair)
    └── verify-deployment.sh           (post-deploy smoke tests)
```

## Testing Model (Single Account, Multi-Region — ADR-0002)

| Region     | Simulates            | What's Deployed              |
|------------|---------------------|------------------------------|
| us-east-1  | RGS Management      | Portal front door, API, Cognito, CloudTrail, SSM logging |
| us-east-2  | Customer 1 (module customer_1) | VPC + EC2 (Linux + Windows) + SSM VPC Endpoints |
| us-west-1  | Customer 2 (module customer_2) | VPC + EC2 (Linux + Windows) + SSM VPC Endpoints |

## Prerequisites

- AWS CLI v2 configured with admin access to account 675405875014
- Terraform >= 1.5
- Node.js >= 20 (for portal build)
- Python 3.9+ available in the shell (for building the SSH-CA crypto layer)
- A registered public domain (POC uses `takahe.click`; see deploy step 0)

## Quick Start

> Full ordered runbook with credential context (DEPLOY vs BROKER-TEST) lives in
> `todo.md` under "NEXT SESSION — START HERE". Summary:

```bash
# 0. Register the portal domain (one-time, ~$3). Route 53 Domains is simplest
#    (auto-delegates). Set registrar AUTO-RENEW = OFF (only recurring cost).

# 1. State backend (already bootstrapped; skip unless standing up fresh)
cd terraform/00-backend && terraform init && terraform apply

# 2. Portal hosting: private SPA bucket + Route 53 zone + ACM cert.
#    Cert validates via CNAME (near-instant, same-account zone).
cd ../02-portal-hosting && terraform init && terraform apply

# 3. Build the SSH-CA crypto layer (creates lambda/layers/crypto/)
../03-api/lambda/layers/build-crypto-layer.sh   # path relative to layer 02; adjust as needed

# 4. API + front door (reads cert/zone/bucket from layer 02 via remote state;
#    SSH CA + same-origin SPA serving ride along). Stop any RUNNING Step
#    Function executions first (state-machine replace hangs otherwise).
cd ../03-api && terraform init && terraform apply

# 5. Populate the SSH CA keypair (one-time)
AWS_PROFILE=personal-faws ./scripts/init-ssh-ca.sh   # run from repo root

# 6. Create the Cognito test users (Rackers + Customers; needs layer 03 deployed)
./scripts/create-test-users.sh

# 7. Test environment + security baseline
cd terraform/04-test-environment && terraform init && terraform apply
cd ../05-security-baseline && terraform init && terraform apply

# 8. Collect outputs + generate same-origin portal/.env.local
cd ../.. && ./scripts/collect-outputs.sh

# 9. Build + upload the SPA to the PRIVATE bucket (no CloudFront invalidation)
cd portal && npm install && npm run build
/home/greg/.local/bin/aws s3 sync dist/ \
  s3://$(cd ../terraform/02-portal-hosting && terraform output -raw spa_bucket_name)/ --delete

# 10. Verify + access
cd .. && ./scripts/verify-deployment.sh
echo "Portal URL: $(cd terraform/02-portal-hosting && terraform output -raw portal_url)"
```

## Compliance Controls Addressed

The authoritative, design-scoped 800-53 control compliance status
(Compliant / Inherited / Traded-off / Needs-development) is the matrix in
**`docs/ARCHITECTURE.md` §8**. The full narrative gap register is
**`ARCHITECTURE-WEAKNESSES.md`**. This README intentionally does not duplicate
that table (it would drift).

## Key Design Decisions (ADRs)

The full decision log is in `.kiro/steering/adr-*.md` and summarized in
`docs/ARCHITECTURE.md` §4. The two most load-bearing for the current design:

- **ADR-0019** — Partition-intersection service palette + no CloudFront for IL4.
  Use only services present in both commercial and GovCloud; the internet front
  door is API Gateway (REGIONAL) + ACM + Shield + Route 53. (An edge WAF needs an
  ALB/REST-v1 tier — the SC-7 gap; see `docs/ARCHITECTURE.md` §8.)
- **ADR-0020** — Prefer AWS-managed services to inherit control coverage;
  deliberate only when two valid options exist or posture goes negative.
