# FedRAMP Portal — Release Notes

Chronological log of changes. No version numbers yet — entries are keyed by
timestamp (newest first). Each entry notes what changed, why, the affected
components, and its state:

- **FIX-READY** — code complete + compiled/verified; awaiting deploy (SoD).
- **DEPLOYED** — applied to the POC (account 675405875014) and, where noted,
  live-verified.

Cross-refs: bugs in `issues.md`, gaps in `ARCHITECTURE-WEAKNESSES.md`, per-control
status in `docs/ARCHITECTURE.md` §8, decision method in ADR-0022.

---

## 2026-09-04 — One session record per connect + operator lens (ADR-0025) (FIX-READY)

Live testing after the ADR-0023 fixes revealed a deeper structural issue: portal
End could act on the WRONG record. The portal Connect minted its own access
request + ephemeral user just to show the `passport connect` command, and the
CLI then minted a SECOND request + user — two records (and two orphan-prone
privileged accounts) for one intended session. End hit the portal's record while
the CLI's tunnel lived on. Separately, a Racker had NO way to see or revoke
another user's sessions (list only ever returned the caller's own). Resolved as
one coherent change per ADR-0025 (with ADR-0024 recording the broader
attributed-C2-plane principle). Attribution retrofit across ALL endpoints
(ADR-0024) is a SEPARATE follow-up, intentionally not bundled here.

- **One authoritative session record per connect.** Portal Connect provisions
  NOTHING — it opens an instructions drawer with the install + `passport
  connect` command. The CLI's authenticated request is the single session
  record. Opening the drawer is not a control-plane action; running the CLI is.
  Eliminates the duplicate ephemeral user and the wrong-record End.
  _Components:_ `portal/src/components/ConnectButton.tsx`, `SessionDrawer.tsx`.

- **Target tenant stamped on the record.** `create_access_request` reads the
  instance's `Customer` tag (region-aware, fail-open + logged) and stores it as
  `customer_id`, so the operator lens can scope by tenant server-side.
  _Component:_ `terraform/03-api/lambda/create_access_request/handler.py`.

- **Operator lens (Rackers).** `GET /api/sessions?scope=all` (Rackers only,
  fail-closed; optional `&customer_id=` tenant scope, ADR-0021) enumerates every
  user's live/ending sessions via the status-index GSI — full detail, but NO
  session secret (least privilege). New "Active Sessions (All Users)" console in
  the Racker dashboard with per-session End.
  _Components:_ `terraform/03-api/lambda/list_sessions/handler.py`,
  `portal/src/components/OperatorSessions.tsx`, `pages/RackerDashboard.tsx`,
  `portal/src/api/types.ts`.

- **Attributed + justified termination (ADR-0024 slice).** Every terminate now
  records `ended_by` / `end_source` / `end_reason`. An OPERATOR revoke (a Racker
  ending another user's session) REQUIRES a reason (ticket #), enforced
  fail-closed (400). Self-terminate (`self:portal`) and CLI exit (`cli:exit`)
  are auto-attributed with no prompt. A reason dialog gates operator End in the
  console.
  _Components:_ `terraform/03-api/lambda/terminate_session/handler.py`,
  `portal/src/components/OperatorSessions.tsx`, `SessionDrawer.tsx`,
  `cli/internal/api/client.go`, `cli/internal/command/connect.go`.

_Verification:_ py_compile (3 lambdas); `terraform validate` (03-api);
SPA `npm run build` (tsc -b + vite); CLI `go vet` + linux/windows/darwin builds.
No new API routes (reused `GET /api/sessions` with `?scope=all`; the terminate
route now accepts a JSON body). **Deploy:** 03-api apply (3 lambdas) + SPA
(hard-reload) + CLI publish/reinstall — see `todo.md`.

---

## 2026-09-03 (later 3) — Session lifecycle "conductor" redesign (ADR-0023) (FIX-READY)

Live testing showed the earlier incremental fixes still left sessions stranded
at `CLEANING_UP` and 81 Step Function executions `Aborted`. Root cause was
structural, not a single bug: `terminate_session` called `states:StopExecution`,
which aborted the conductor (the Step Function) BEFORE it could write a terminal
state — so records never converged. Rather than patch again, this is the one
coherent redesign per **ADR-0023**: the Step Function is the sole conductor that
verifies each worker and converges every session to a terminal state; all
end-triggers submit an end-demand (no caller-side teardown); one verified
teardown covers all four concerns (connection, OS user, profile, tunnel).

- **terminate_session is now a pure END DEMAND.** It writes `END_REQUESTED`
  (guarded by a ConditionExpression so it can't clobber a status the conductor
  already advanced) and returns. No inline SSM cleanup, no `states:StopExecution`.
  Owner-or-Racker check retained (Rackers = operator-revoke path).
  _Component:_ `terraform/03-api/lambda/terminate_session/handler.py`.

- **The state machine verifies each worker before advancing.** `CleanupUser` now
  branches on the cleanup Lambda's `verified` result: `OK` -> `COMPLETED`;
  `INCOMPLETE` -> bounded retry (3x, 10s) -> new terminal `CLEANUP_FAILED`. The
  old silent `Catch -> COMPLETED` (which masked failed cleanups) is removed. Both
  end paths (end-demand and TTL) route through `CLEANING_UP` so the score always
  shows teardown honestly. Poll `Wait` 30s -> 10s so End feels near-immediate.
  _Component:_ `terraform/03-api/state-machine/access-lifecycle.asl.json`.

- **The conductor owns tunnel teardown (concern d).** `cleanup_user` now
  enumerates active SSM sessions for the instance+user (`ssm:DescribeSessions`)
  and terminates the port-forward tunnels (`ssm:TerminateSession`) before the
  user/profile cleanup — so a server-driven end no longer depends on the client
  noticing. Best-effort (does not gate `verified`; a tunnel with no user behind
  it is harmless). `verified` now defaults to `INCOMPLETE`, never silent success.
  _Component:_ `terraform/03-api/lambda/cleanup_user/handler.py`.

- **The CLI submits the same end-demand on ANY local exit** (Ctrl-C, shell exit,
  RDP client exit, poll-detected server end): after `Connect` returns it calls
  the terminate endpoint (fresh 10s context, best-effort) so the server tears
  down the OS user/profile too — fixing orphaned-user-on-CLI-exit. It still
  closes its local tunnel and shreds keys.
  _Component:_ `cli/internal/command/connect.go`.

- **The portal reflects transitional state honestly.** `list_sessions` now
  returns ending states (`END_REQUESTED`, `CLEANING_UP`) as well as live ones,
  so a session mid-teardown shows "Ending…" instead of silently vanishing;
  terminal states are excluded server-side. `ConnectButton` shows a
  non-actionable "Ending…" pill for ending sessions (two-click is now impossible
  by construction — you can't End something already ending). The old
  `pendingTerminations` client-side suppression is removed entirely: the backend
  is authoritative now, so the reader just maps the truth 1:1. Status vocabulary:
  `PENDING, PROVISIONING, ACTIVE, END_REQUESTED, CLEANING_UP, COMPLETED,
  CLEANUP_FAILED, FAILED`.
  _Components:_ `terraform/03-api/lambda/list_sessions/handler.py`,
  `portal/src/api/types.ts`, `portal/src/api/SessionsContext.tsx`,
  `portal/src/components/ConnectButton.tsx`, `SessionDrawer.tsx`.

- **IAM tightened.** Removed the `StepFunctionsExecutionControl` statement
  (`states:StopExecution` + `states:DescribeExecution`); added
  `ssm:DescribeSessions` + `ssm:TerminateSession`. Kept `states:StartExecution`.
  _Component:_ `terraform/03-api/main.tf`.

- **One-time data cleanup.** New `scripts/purge-stranded-sessions.py` converges
  the pre-existing stranded rows (their executions were aborted and will never
  finish). Dry-run by default; `--apply` marks them `COMPLETED` with an audit
  note (preserves the AC-2/AU-2 trail); condition-guarded and idempotent.

_Verification:_ all four Python handlers + purge script `py_compile` OK; ASL is
valid JSON (21 states) with no `StopExecution`; `terraform validate` (03-api)
passes and is `fmt`-clean; SPA `npm run build` (tsc -b + vite) passes; CLI
`go vet` + linux/windows/darwin builds pass. **Deploy is a matched set** — see
the runbook in `todo.md` (03-api apply -> SPA + hard-reload -> CLI publish ->
purge -> test). Supersedes the incremental I2/I5 fixes below.

---

## 2026-09-03 (later 2) — Two-click terminate: true (backend) root cause fixed (FIX-READY)

Live testing showed the two-click End Session bug persisting after the first
SPA-only fixes. Found the real cause: a backend timing race, not a UI heuristic.

- **I2 (reopened) — Ending a session took two clicks.** `terminate_session` ran
  the slow SSM cleanup first and wrote the CLEANING_UP status last, so the
  session was still ACTIVE in DynamoDB when the SPA re-polled after terminate,
  and it bounced back. Fixed on the backend: write CLEANING_UP FIRST (before the
  SSM cleanup) so the session is authoritatively non-ACTIVE the moment terminate
  returns. SPA now awaits the reconcile before closing the drawer.
  _Components:_ `terraform/03-api/lambda/terminate_session/handler.py`,
  `portal/src/api/SessionsContext.tsx`, `SessionDrawer.tsx`, `ConnectButton.tsx`.
  _Deploy:_ terminate_session Lambda + SPA together (matched pair).

---

## 2026-09-03 (later) — Live-test follow-ups: SSH force-end teardown + reconnect fix (FIX-READY)

Live testing of the earlier batch surfaced two more issues; both fixed, awaiting
re-deploy + verify.

- **I5 — SSH session/tunnel not torn down on portal force-end (AC-12).** The
  earlier I3 fix added portal-status polling to the RDP path only; the SSH path
  still blocked solely on shell exit, so a portal force-end left the shell live.
  Fixed: the SSH path now polls session status (5s) in the background and closes
  the connection on any non-ACTIVE status (force-end / TTL), plus Ctrl-C. Matches
  the RDP behavior.
  _Component:_ `cli/internal/connection/awsec2/tunnel.go`.

- **I6 — Could not reconnect to the same instance after ending a session
  (regression from the I2 fix).** The `pendingTerminations` suppression added for
  I2 was keyed by instance_id, so a NEW session on the same instance was hidden.
  Re-keyed to request_id so only the specific ended session is suppressed.
  _Components:_ `portal/src/api/SessionsContext.tsx`,
  `portal/src/components/ConnectButton.tsx`.

_Re-deploy:_ SPA (I6) + CLI (I5). See `issues.md` for commands. _Verified:_ SPA
diagnostics clean; CLI go vet + linux/windows/darwin builds pass.

---

## 2026-09-03 — Bug-fix batch: session lifecycle + ephemeral-user cleanup (DEPLOYED)

Four demo-found runtime bugs fixed under the ADR-0022 hierarchy. **Deployed
2026-09-03 09:28 CDT** to the POC (account 675405875014): layer 03-api applied
(cleanup_user + terminate_session Lambdas), SPA rebuilt + deployed, CLI rebuilt +
published. **Live verification (SoD) still pending** — see the per-issue live
tests in `issues.md`; entries move to fully confirmed once greg runs them.

- **I4 — Orphaned OS users/profiles after session end (AC-2 / AC-12).**
  Windows cleanup deleted the account but left the `C:\Users\<name>` profile and
  its ProfileList registry entry (Windows creates the profile lazily on first RDP
  logon). Now removes the profile via `Win32_UserProfile` (folder + registry) with
  a `Remove-Item` backstop, and verifies removal (`PORTAL_CLEANUP_OK` /
  `PORTAL_CLEANUP_INCOMPLETE`). Linux hardened: retries `userdel -r`, removes
  `/home` as a backstop, stops swallowing "user in use" errors. Applied to both
  cleanup paths; the cleanup Lambda now verifies the SSM result and logs any
  residual (AU-6 signal) while staying non-blocking.
  _Components:_ `terraform/03-api/lambda/cleanup_user/handler.py`,
  `terraform/03-api/lambda/terminate_session/handler.py`.

- **I2 — Ending a session took two attempts (AC-12).**
  The SPA re-added just-terminated sessions on its next poll (no status filter)
  and treated any session record as "active". Now the session map keeps only LIVE
  sessions (ACTIVE/PENDING/PROVISIONING) and drops ending/ended ones; a
  just-terminated instance is suppressed until the backend stops returning it; the
  "Active" pill keys on `status === 'ACTIVE'`. One click ends a session and it
  stays ended.
  _Components:_ `portal/src/api/SessionsContext.tsx`,
  `portal/src/components/ConnectButton.tsx`.

- **I1 — Portal did not auto-refresh session status.**
  Session polling is now adaptive: 3s while anything is in flight or a termination
  is pending, 15s at rest; terminating a session triggers an immediate reconcile;
  transitional sessions show a distinct "Provisioning..." state.
  _Components:_ `portal/src/api/SessionsContext.tsx`,
  `portal/src/components/ConnectButton.tsx`.

- **I3 — RDP tunnel stayed open after the RDP session ended (AC-12).**
  The CLI held the SSM tunnel open until Ctrl-C only. It now tears the tunnel down
  on any of: Ctrl-C, a portal-side end demand (5s poll of session status — handles
  operator/portal force-end and TTL cleanup), or native RDP client exit (Windows
  launches+waits `mstsc` via a passwordless temp `.rdp`; macOS best-effort; Linux
  falls back to the poll + Ctrl-C triggers). Transient API errors don't cause a
  teardown.
  _Components:_ `cli/internal/connection/awsec2/tunnel.go`,
  `cli/internal/connection/awsec2/rdp_windows.go` (new),
  `cli/internal/connection/awsec2/rdp_other.go` (new).

_Verification:_ Python handlers `py_compile` + template `.format()` OK; SPA
diagnostics clean; CLI `go vet` clean and builds pass for linux/amd64,
windows/amd64, darwin/arm64.
