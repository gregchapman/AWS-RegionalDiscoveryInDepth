#!/usr/bin/env bash
set -uo pipefail
export AWS_REGION=us-east-1
export AWS_PROFILE=personal-faws

echo "############ 1. cleanup-user PORTAL_CLEANUP / PROFILE lines (last 6h) ############"
start=$(( ($(date +%s) - 6*3600) * 1000 ))
aws logs filter-log-events \
  --log-group-name /aws/lambda/fedramp-portal-cleanup-user \
  --start-time "$start" \
  --filter-pattern 'PORTAL_CLEANUP' \
  --query 'events[].message' --output text 2>&1 | sed 's/^/  /'
echo
echo "-- also any PROFILE_REMOVE / verified / tunnels_terminated lines --"
aws logs filter-log-events \
  --log-group-name /aws/lambda/fedramp-portal-cleanup-user \
  --start-time "$start" \
  --query 'events[].message' --output text 2>&1 \
  | grep -iE 'PROFILE_REMOVE|verified|Cleanup verified|RESIDUAL|INCOMPLETE|tunnels_terminated|greg-racker-(2eed|e22f|6428)' | sed 's/^/  /'

echo
echo "############ 2. DynamoDB status of the 3 orphaned-profile sessions ############"
# The Users folders were greg-racker-2eed / -e22f / -6428. Scan for those usernames.
aws dynamodb scan \
  --table-name fedramp-portal-access-requests \
  --filter-expression "contains(provisioned_username, :a) OR contains(provisioned_username, :b) OR contains(provisioned_username, :c)" \
  --expression-attribute-values '{":a":{"S":"2eed"},":b":{"S":"e22f"},":c":{"S":"6428"}}' \
  --projection-expression "provisioned_username, #s, ended_by, end_source, end_reason, instance_id, created_at" \
  --expression-attribute-names '{"#s":"status"}' \
  --query 'Items[].{user:provisioned_username.S,status:#s.S,ended_by:ended_by.S,src:end_source.S,inst:instance_id.S,created:created_at.S}' \
  --output table 2>&1 | sed 's/^/  /'
echo "done"
