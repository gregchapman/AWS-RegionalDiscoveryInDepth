#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# shellcheck source=/dev/null
source ./_goenv.sh
echo "== go version =="
go version
echo "== go mod tidy =="
go mod tidy
echo "== go build ./... =="
go build ./...
echo "== go vet ./... =="
go vet ./...
echo "BUILD_OK"
