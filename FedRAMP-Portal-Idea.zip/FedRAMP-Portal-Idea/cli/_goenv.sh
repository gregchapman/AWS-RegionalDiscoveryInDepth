#!/usr/bin/env bash
# Shared Go environment for build/verify steps (user-local toolchain, no root).
# Source this, then run go commands. Keeps GOPATH/cache off the Windows mount
# (under the WSL home) so builds are fast and permissions are sane.
export GOROOT="${HOME}/.local/go-sdk/go"
export GOPATH="${HOME}/.local/go"
export GOCACHE="${HOME}/.cache/go-build"
export GOFLAGS="-mod=mod"
# Pin the toolchain: never auto-download a newer Go at build time. Keeps the
# (audited, cross-compiled) build reproducible on the toolchain we control.
export GOTOOLCHAIN=local
export PATH="${GOROOT}/bin:${GOPATH}/bin:${PATH}"
export CGO_ENABLED=0
