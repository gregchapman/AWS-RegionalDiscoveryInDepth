#!/usr/bin/env bash
# Wrapper: source the Go env, then run `make` with any passed target(s).
set -euo pipefail
cd "$(dirname "$0")"
# shellcheck source=/dev/null
source ./_goenv.sh
export GOTOOLCHAIN=local
if ! command -v make >/dev/null 2>&1; then
  echo "ERROR: make is not installed (apt-get install -y make)" >&2
  exit 1
fi
make "$@"
echo "== build tree =="
find build -type f | sort
