#!/usr/bin/env bash
# Pin dependencies to versions compatible with the Go 1.22 toolchain so the
# build is deterministic and does NOT auto-download a newer toolchain at
# compile time (important for a reproducible, audited cross-compile).
set -euo pipefail
cd "$(dirname "$0")"
# shellcheck source=/dev/null
source ./_goenv.sh
# Prevent auto-toolchain switching entirely.
export GOTOOLCHAIN=local
# x/term v0.28.0 / x/sys v0.28.0 still support go1.22 (the >=1.25 requirement
# only appears in the very latest tags).
go get golang.org/x/term@v0.28.0
go get golang.org/x/sys@v0.28.0
go mod tidy
go build ./...
go vet ./...
echo "PIN_OK"
