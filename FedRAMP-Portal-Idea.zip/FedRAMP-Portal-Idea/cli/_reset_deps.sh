#!/usr/bin/env bash
# Resolve deps at their current versions on the local go1.24 toolchain
# (GOTOOLCHAIN=local => no silent auto-upgrade; reproducible on the toolchain
# we control).
set -euo pipefail
cd "$(dirname "$0")"
# shellcheck source=/dev/null
source ./_goenv.sh
export GOTOOLCHAIN=local

rm -f go.sum
echo "== go version =="; go version
go get github.com/aws/aws-sdk-go-v2@latest
go get github.com/aws/aws-sdk-go-v2/service/cognitoidentityprovider@latest
go get github.com/spf13/cobra@latest
go get github.com/alexrudd/cognito-srp/v4@latest
# The x/* newest tags require Go 1.25; these versions support the 1.24 toolchain.
go get golang.org/x/term@v0.28.0
go get golang.org/x/sys@v0.28.0
go get golang.org/x/crypto@v0.31.0
go get github.com/aws/aws-sdk-go-v2/credentials@latest
go get github.com/aws/aws-sdk-go-v2/service/ssm@latest
echo "== go mod tidy =="
go mod tidy
echo "== go directive =="; grep -E '^go |^toolchain' go.mod || true
echo "== go build ./... =="; go build ./...
echo "== go vet ./... =="; go vet ./...
echo "RESET_OK"
