#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# shellcheck source=/dev/null
source ./_goenv.sh
export GOTOOLCHAIN=local
go build -o /tmp/passport ./cmd/passport
echo "== version =="; /tmp/passport version
echo "== help =="; /tmp/passport --help
echo "== connect help =="; /tmp/passport connect --help
echo "== bad instance prefix (expect error) =="; /tmp/passport connect bad-id --region us-east-2 || echo "exit=$?"
echo "== missing region (expect error) =="; /tmp/passport connect i-0abc || echo "exit=$?"
echo "SMOKE_OK"
