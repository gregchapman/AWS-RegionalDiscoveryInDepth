#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/build"
echo "== file types =="
for f in linux-amd64/passport linux-arm64/passport darwin-amd64/passport darwin-arm64/passport windows-amd64/passport.exe; do
  printf '%-28s ' "$f"; file "$f" | sed 's/^[^:]*: //'
done
echo "== checksum verify =="
sha256sum -c SHA256SUMS
echo "== run host (linux-amd64) binary =="
./linux-amd64/passport version
echo "VERIFY_OK"
