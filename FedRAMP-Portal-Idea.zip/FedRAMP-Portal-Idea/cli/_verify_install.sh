#!/usr/bin/env bash
# Verify install-script syntax and that the checksum-extraction logic matches
# the real SHA256SUMS layout (the fragile bit).
set -euo pipefail
cd "$(dirname "$0")"

echo "== bash -n =="
bash -n dist/install.sh && echo "install.sh OK"
bash -n publish.sh && echo "publish.sh OK"

echo "== checksum extraction logic vs real SHA256SUMS =="
# Reproduce install.sh's extraction for linux-amd64 and confirm it verifies.
platform="linux-amd64"; bin="passport"
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
cp "build/$platform/$bin" "$tmp/$bin"
cp build/SHA256SUMS "$tmp/SHA256SUMS"
expected="$(grep " $platform/$bin\$" "$tmp/SHA256SUMS" | awk '{print $1}')"
[ -n "$expected" ] || { echo "FAIL: no checksum entry extracted"; exit 1; }
echo "extracted expected=$expected"
( cd "$tmp" && echo "$expected  $bin" | sha256sum -c --quiet ) && echo "CHECKSUM_VERIFY_OK"
echo "INSTALL_VERIFY_OK"
