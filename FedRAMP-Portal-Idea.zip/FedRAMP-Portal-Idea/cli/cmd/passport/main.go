// Command passport is the FedRAMP Portal access CLI.
//
// It authenticates the user to the portal identity provider (Cognito, with
// MFA) and connects them to a target instance over SSM — WITHOUT the user
// holding any AWS credentials. The portal vends short-lived, instance-scoped
// AWS credentials for the single session (ADR-0012). Structured per ADR-0016
// around IdentityProvider + ConnectionProvider interfaces.
package main

import (
	"fmt"
	"os"

	"github.com/rackspace/fedramp-portal/cli/internal/command"
)

func main() {
	if err := command.Execute(); err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		os.Exit(1)
	}
}
