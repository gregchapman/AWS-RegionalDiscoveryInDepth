module github.com/rackspace/fedramp-portal/cli

go 1.24

require (
	github.com/alexrudd/cognito-srp/v4 v4.1.0
	github.com/aws/aws-sdk-go-v2 v1.45.1
	github.com/aws/aws-sdk-go-v2/credentials v1.20.1
	github.com/aws/aws-sdk-go-v2/service/cognitoidentityprovider v1.71.0
	github.com/aws/aws-sdk-go-v2/service/ssm v1.75.1
	github.com/spf13/cobra v1.10.2
	golang.org/x/crypto v0.31.0
	golang.org/x/term v0.27.0
)

require (
	github.com/aws/aws-sdk-go-v2/internal/configsources v1.5.1 // indirect
	github.com/aws/aws-sdk-go-v2/internal/endpoints/v2 v2.8.1 // indirect
	github.com/aws/smithy-go v1.28.1 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/spf13/pflag v1.0.9 // indirect
	golang.org/x/sys v0.28.0 // indirect
)
