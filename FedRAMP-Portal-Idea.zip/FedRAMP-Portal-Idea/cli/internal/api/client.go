// Package api is the typed client for the FedRAMP Portal HTTP API. It carries
// the Bearer identity token and NEVER sends AWS credentials. The four calls
// mirror the endpoints proven end-to-end in scripts/passport-connect.sh.
package api

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

// Client talks to the portal API at BaseURL using the identity token.
type Client struct {
	BaseURL string
	Token   string
	HTTP    *http.Client
}

// New builds a Client. baseURL trailing slash is trimmed.
func New(baseURL, token string) *Client {
	return &Client{
		BaseURL: strings.TrimRight(baseURL, "/"),
		Token:   token,
		HTTP:    &http.Client{Timeout: 30 * time.Second},
	}
}

func (c *Client) do(ctx context.Context, method, path string, body any, out any) (int, error) {
	var rdr io.Reader
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return 0, fmt.Errorf("marshal request: %w", err)
		}
		rdr = bytes.NewReader(b)
	}
	req, err := http.NewRequestWithContext(ctx, method, c.BaseURL+path, rdr)
	if err != nil {
		return 0, err
	}
	req.Header.Set("Authorization", "Bearer "+c.Token)
	req.Header.Set("Accept", "application/json")
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 400 {
		// Surface the API's {"error": "..."} message when present.
		var e struct {
			Error string `json:"error"`
		}
		if json.Unmarshal(raw, &e) == nil && e.Error != "" {
			return resp.StatusCode, fmt.Errorf("%s %s: HTTP %d: %s", method, path, resp.StatusCode, e.Error)
		}
		return resp.StatusCode, fmt.Errorf("%s %s: HTTP %d", method, path, resp.StatusCode)
	}
	if out != nil && len(raw) > 0 {
		if err := json.Unmarshal(raw, out); err != nil {
			return resp.StatusCode, fmt.Errorf("decode response: %w", err)
		}
	}
	return resp.StatusCode, nil
}

// --- POST /api/connect ---

type ConnectRequest struct {
	InstanceID string `json:"instance_id"`
	Region     string `json:"region"`
	AccessType string `json:"access_type"`
	TTLMinutes int    `json:"ttl_minutes"`
}

type ConnectResponse struct {
	RequestID  string `json:"request_id"`
	Status     string `json:"status"`
	Message    string `json:"message"`
	TTLMinutes int    `json:"ttl_minutes"`
	PollURL    string `json:"poll_url"`
}

func (c *Client) Connect(ctx context.Context, r ConnectRequest) (*ConnectResponse, error) {
	var out ConnectResponse
	code, err := c.do(ctx, http.MethodPost, "/api/connect", r, &out)
	if err != nil {
		return nil, err
	}
	if code != http.StatusAccepted {
		return nil, fmt.Errorf("unexpected status %d from /api/connect", code)
	}
	return &out, nil
}

// --- GET /api/session/{id} ---

type SessionConnection struct {
	Username          string `json:"username"`
	AuthMethod        string `json:"auth_method"`
	PortLocal         string `json:"port_local"`
	PortRemote        string `json:"port_remote"`
	ExpiresAt         string `json:"expires_at"` // epoch seconds as string
	TemporaryPassword string `json:"temporary_password"` // RDP only; empty for SSH (cert-based)
}

type SessionResponse struct {
	RequestID   string             `json:"request_id"`
	Status      string             `json:"status"`
	InstanceID  string             `json:"instance_id"`
	Region      string             `json:"region"`
	AccessType  string             `json:"access_type"`
	ErrorDetail string             `json:"error_detail"`
	Connection  *SessionConnection `json:"connection"`
}

func (c *Client) Session(ctx context.Context, requestID string) (*SessionResponse, error) {
	var out SessionResponse
	_, err := c.do(ctx, http.MethodGet, "/api/session/"+requestID, nil, &out)
	if err != nil {
		return nil, err
	}
	return &out, nil
}

// --- POST /api/sign ---

type SignRequest struct {
	RequestID string `json:"request_id"`
	PublicKey string `json:"public_key"`
}

type SignResponse struct {
	Certificate  string `json:"certificate"`
	KeyID        string `json:"key_id"`
	Username     string `json:"username"`
	ValidBefore  int64  `json:"valid_before"`
	ValidSeconds int    `json:"valid_seconds"`
}

func (c *Client) Sign(ctx context.Context, r SignRequest) (*SignResponse, error) {
	var out SignResponse
	_, err := c.do(ctx, http.MethodPost, "/api/sign", r, &out)
	if err != nil {
		return nil, err
	}
	return &out, nil
}

// --- POST /api/session/{id}/ssm-credentials ---

type CredentialsResponse struct {
	AccessKeyID     string `json:"access_key_id"`
	SecretAccessKey string `json:"secret_access_key"`
	SessionToken    string `json:"session_token"`
	Expiration      string `json:"expiration"`
	Region          string `json:"region"`
	InstanceID      string `json:"instance_id"`
	Username        string `json:"username"`
	PortLocal       string `json:"port_local"`
	PortRemote      string `json:"port_remote"`
}

func (c *Client) VendSSMCredentials(ctx context.Context, requestID string) (*CredentialsResponse, error) {
	var out CredentialsResponse
	_, err := c.do(ctx, http.MethodPost, "/api/session/"+requestID+"/ssm-credentials", nil, &out)
	if err != nil {
		return nil, err
	}
	return &out, nil
}

// --- POST /api/session/{id}/terminate ---

// TerminateRequest carries attribution for the end demand (ADR-0024). Every
// terminate is attributed; the CLI ends the CALLER's OWN session on local exit,
// so no operator reason is required — but it still identifies the source so the
// audit trail shows the session ended because the local client exited (vs. a
// portal End or an operator revoke).
type TerminateRequest struct {
	Reason string `json:"reason,omitempty"`
	Source string `json:"source,omitempty"`
}

// Terminate submits the end demand. source identifies WHY (e.g. "cli:exit").
func (c *Client) Terminate(ctx context.Context, requestID string, req TerminateRequest) error {
	_, err := c.do(ctx, http.MethodPost, "/api/session/"+requestID+"/terminate", req, nil)
	return err
}
