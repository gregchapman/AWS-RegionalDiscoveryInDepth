package command

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/rackspace/fedramp-portal/cli/internal/api"
	"github.com/rackspace/fedramp-portal/cli/internal/connection"
	"github.com/rackspace/fedramp-portal/cli/internal/connection/awsec2"
	"github.com/rackspace/fedramp-portal/cli/internal/identity"
	"github.com/rackspace/fedramp-portal/cli/internal/identity/cognito"
	"github.com/spf13/cobra"
)

// Cognito defaults for the deployed portal. Overridable via flags/env for other
// environments/partitions (ADR-0017), but default to the current deployment so
// the common case is a zero-config `passport connect <instance> --region`.
const (
	defaultCognitoRegion   = "us-east-1"
	defaultCognitoPoolID   = "us-east-1_Ud7Zxuvw0"
	defaultCognitoClientID = "1b2k0qs0g7v5s84ke250nbl2k"
)

func newConnectCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "connect <instance-id>",
		Short: "Authenticate and connect to a target instance over SSM (no AWS credentials needed)",
		Long: "Authenticate to the portal (with MFA) and connect to the target instance over\n" +
			"an SSM tunnel. Default is SSH (drops you into a shell). Use --rdp for Windows:\n" +
			"it opens a tunnel to 3389 and prints the values for your Remote Desktop client.\n" +
			"The portal vends short-lived, instance-scoped AWS credentials for the session —\n" +
			"you never need AWS credentials on your machine.",
		Args: cobra.ExactArgs(1),
		RunE: runConnect,
	}
	cmd.Flags().String("region", "", "AWS region of the target instance (required)")
	cmd.Flags().Int("ttl", 60, "authorization window in minutes (clamped 15-720 server-side)")
	cmd.Flags().Bool("rdp", false, "Windows/RDP: open an SSM tunnel to 3389 and print values for your RDP client (instead of SSH)")
	cmd.Flags().String("cognito-region", defaultCognitoRegion, "Cognito user pool region")
	cmd.Flags().String("cognito-pool-id", defaultCognitoPoolID, "Cognito user pool ID")
	cmd.Flags().String("cognito-client-id", defaultCognitoClientID, "Cognito app client ID")
	return cmd
}

func runConnect(cmd *cobra.Command, args []string) error {
	instanceID := strings.TrimSpace(args[0])
	if !strings.HasPrefix(instanceID, "i-") && !strings.HasPrefix(instanceID, "mi-") {
		return fmt.Errorf("instance id %q must start with i- or mi-", instanceID)
	}
	region, _ := cmd.Flags().GetString("region")
	if region == "" {
		return fmt.Errorf("--region is required")
	}
	ttl, _ := cmd.Flags().GetInt("ttl")
	rdp, _ := cmd.Flags().GetBool("rdp")
	accessType := "ssh"
	if rdp {
		accessType = "rdp"
	}
	baseURL, _ := cmd.Flags().GetString("base-url")
	cogRegion, _ := cmd.Flags().GetString("cognito-region")
	cogPool, _ := cmd.Flags().GetString("cognito-pool-id")
	cogClient, _ := cmd.Flags().GetString("cognito-client-id")

	// Cancel cleanly on Ctrl-C / SIGTERM so Cleanup runs (tunnel down, keys shredded).
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	// 1) AUTHENTICATE — the CLI earns its token (password + MFA). No handed-over
	//    bearer token; this is what makes the flow replay-resistant (ADR-0012).
	var idp identity.Provider = cognito.New(cogRegion, cogPool, cogClient)
	fmt.Fprintf(os.Stderr, "Authenticating to the portal (%s)...\n", idp.Name())
	tok, err := idp.Authenticate(ctx)
	if err != nil {
		return fmt.Errorf("authentication failed: %w", err)
	}
	if tok.Email != "" {
		fmt.Fprintf(os.Stderr, "Authenticated as %s.\n", tok.Email)
	} else {
		fmt.Fprintln(os.Stderr, "Authenticated.")
	}

	// 2) CONNECT — portal-brokered, credential-less. Dispatch on target kind
	//    (only aws-ec2 today; ADR-0016 leaves room for more).
	client := api.New(baseURL, tok.AccessToken)
	var provider connection.Provider = awsec2.New(client)
	defer provider.Cleanup()

	target := connection.Target{
		Kind:       connection.KindAWSEC2,
		InstanceID: instanceID,
		Region:     region,
		TTLMinutes: ttl,
		AccessType: accessType,
	}

	fmt.Fprintf(os.Stderr, "Requesting access to %s (%s)...\n", instanceID, region)
	sess, err := provider.RequestAccess(ctx, tok, target)
	if err != nil {
		return err
	}

	fmt.Fprintln(os.Stderr, "Waiting for the session to become active...")
	if err := provider.AwaitReady(ctx, tok, sess); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "Session active as %s.\n", sess.Username)

	// SSH needs a signed certificate (the authenticator). RDP uses the
	// short-lived password the portal provisioned (Passport V2 pattern,
	// ADR-0022) — no certificate is issued.
	var cred *connection.Credential
	if accessType == "ssh" {
		fmt.Fprintln(os.Stderr, "Issuing SSH certificate...")
		cred, err = provider.IssueCredential(ctx, tok, sess)
		if err != nil {
			return err
		}
	}

	fmt.Fprintln(os.Stderr, "Vending scoped session credentials...")
	vc, err := provider.VendCredential(ctx, tok, sess)
	if err != nil {
		return err
	}

	fmt.Fprintln(os.Stderr, "Opening tunnel...")
	connErr := provider.Connect(ctx, sess, cred, vc)

	// SUBMIT THE END DEMAND (ADR-0023). When Connect returns, this local session
	// is over — for ANY reason: the user exited the shell / closed RDP, pressed
	// Ctrl-C, or the portal-status poll saw the session end server-side. The CLI
	// is a caller, not the conductor: it does NOT tear anything down itself
	// (provider.Cleanup already closed the LOCAL tunnel + shredded keys). It
	// signals the portal so the CONDUCTOR runs the one verified server-side
	// teardown (remove the ephemeral OS user + profile). Without this, a local
	// exit (Ctrl-C / shell exit) left the OS user orphaned until TTL.
	//
	// Best-effort by design: use a FRESH short-lived context (the signal ctx is
	// already cancelled on Ctrl-C, so it can't carry this HTTP call), and never
	// fail the command on a terminate error — if the token has expired on a long
	// session the portal returns 401, and the authorization-window TTL still
	// converges the session. The end demand is idempotent server-side.
	termCtx, termCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer termCancel()
	// Attributed end demand (ADR-0024): this is the caller ending their OWN
	// session on local exit, so no operator reason is needed — but we stamp the
	// source so the audit trail records that the session ended because the local
	// CLI exited (distinct from a portal End or an operator revoke).
	if err := client.Terminate(termCtx, sess.RequestID, api.TerminateRequest{Source: "cli:exit"}); err != nil {
		fmt.Fprintf(os.Stderr, "Note: could not signal session end to the portal "+
			"(it will still expire on its own): %v\n", err)
	} else {
		fmt.Fprintln(os.Stderr, "Signaled session end to the portal.")
	}

	return connErr
}
