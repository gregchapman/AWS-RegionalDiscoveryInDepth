// Package command wires the cobra command surface for the passport CLI.
package command

import (
	"fmt"

	"github.com/rackspace/fedramp-portal/cli/internal/version"
	"github.com/spf13/cobra"
)

func newRootCmd() *cobra.Command {
	root := &cobra.Command{
		Use:           "passport",
		Short:         "FedRAMP Portal access CLI — credential-less SSM/SSH access",
		SilenceUsage:  true,
		SilenceErrors: true,
	}
	root.PersistentFlags().String("base-url", "https://portal.takahe.click", "portal base URL")
	root.AddCommand(newVersionCmd())
	root.AddCommand(newConnectCmd())
	return root
}

// Execute runs the root command.
func Execute() error {
	return newRootCmd().Execute()
}

func newVersionCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "version",
		Short: "Print the CLI version",
		Run: func(cmd *cobra.Command, _ []string) {
			fmt.Fprintln(cmd.OutOrStdout(), version.String())
		},
	}
}
