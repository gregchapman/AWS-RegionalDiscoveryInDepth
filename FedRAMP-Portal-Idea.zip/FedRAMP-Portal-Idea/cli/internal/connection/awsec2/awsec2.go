// Package awsec2 implements connection.Provider for EC2 / SSM-managed
// instances: SSH certificate authenticator (ADR-0014) over an SSM
// port-forward tunnel, using ONLY portal-vended, instance-scoped AWS
// credentials (ADR-0012). This is the Go port of production Passport's
// cli/connect/ssmtransport.go, preserving its behavior.
package awsec2

import (
	"context"
	"crypto/ed25519"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"github.com/rackspace/fedramp-portal/cli/internal/api"
	"github.com/rackspace/fedramp-portal/cli/internal/connection"
	"github.com/rackspace/fedramp-portal/cli/internal/identity"
	"golang.org/x/crypto/ssh"
)

const (
	pollInterval  = 3 * time.Second
	pollTimeout   = 120 * time.Second
	sshDefaultRem = "22"
)

// Provider is the aws-ec2 connection provider.
type Provider struct {
	client *api.Client

	// workDir holds the ephemeral key + cert; shredded on Cleanup.
	workDir string
	// tunnel state, set by Connect; torn down by Cleanup.
	tunnel *tunnel
}

// New builds the provider bound to the portal API client (carrying the
// already-earned identity token).
func New(client *api.Client) *Provider {
	return &Provider{client: client}
}

// Kind implements connection.Provider.
func (p *Provider) Kind() connection.Kind { return connection.KindAWSEC2 }

// RequestAccess creates the access request (POST /api/connect).
func (p *Provider) RequestAccess(ctx context.Context, _ *identity.Token, t connection.Target) (*connection.Session, error) {
	accessType := t.AccessType
	if accessType == "" {
		accessType = "ssh"
	}
	resp, err := p.client.Connect(ctx, api.ConnectRequest{
		InstanceID: t.InstanceID,
		Region:     t.Region,
		AccessType: accessType,
		TTLMinutes: t.TTLMinutes,
	})
	if err != nil {
		return nil, err
	}
	return &connection.Session{
		RequestID:  resp.RequestID,
		InstanceID: t.InstanceID,
		Region:     t.Region,
		AccessType: accessType,
		Status:     resp.Status,
	}, nil
}

// AwaitReady polls GET /api/session/{id} until ACTIVE (or FAILED/timeout),
// filling connection details onto s.
func (p *Provider) AwaitReady(ctx context.Context, _ *identity.Token, s *connection.Session) error {
	deadline := time.Now().Add(pollTimeout)
	for {
		resp, err := p.client.Session(ctx, s.RequestID)
		if err != nil {
			return err
		}
		s.Status = resp.Status
		switch resp.Status {
		case "ACTIVE":
			if resp.Connection == nil {
				return fmt.Errorf("session ACTIVE but no connection details returned")
			}
			s.Username = resp.Connection.Username
			s.Password = resp.Connection.TemporaryPassword // RDP only; empty for SSH
			defRemote := sshDefaultRem
			if s.AccessType == "rdp" {
				defRemote = "3389"
			}
			s.PortLocal = firstNonEmpty(resp.Connection.PortLocal, "2222")
			s.PortRemote = firstNonEmpty(resp.Connection.PortRemote, defRemote)
			if resp.Connection.ExpiresAt != "" {
				if e, perr := strconv.ParseInt(resp.Connection.ExpiresAt, 10, 64); perr == nil {
					s.ExpiresAt = e
				}
			}
			return nil
		case "FAILED":
			detail := resp.ErrorDetail
			if detail == "" {
				detail = "unknown"
			}
			return fmt.Errorf("provisioning failed: %s", detail)
		default:
			if time.Now().After(deadline) {
				return fmt.Errorf("timed out waiting for ACTIVE (last status: %s)", resp.Status)
			}
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(pollInterval):
			}
		}
	}
}

// IssueCredential generates an ephemeral ed25519 keypair, gets it signed
// (POST /api/sign), and writes key + cert to the work dir. The cert is written
// as "<key>-cert.pub" so the SSH client auto-associates it.
func (p *Provider) IssueCredential(ctx context.Context, _ *identity.Token, s *connection.Session) (*connection.Credential, error) {
	if err := p.ensureWorkDir(); err != nil {
		return nil, err
	}

	pub, priv, err := ed25519.GenerateKey(nil)
	if err != nil {
		return nil, fmt.Errorf("generate key: %w", err)
	}
	sshPub, err := ssh.NewPublicKey(pub)
	if err != nil {
		return nil, fmt.Errorf("wrap public key: %w", err)
	}
	authorizedPub := ssh.MarshalAuthorizedKey(sshPub) // "ssh-ed25519 AAAA...\n"

	// Private key in OpenSSH PEM so ssh.ParsePrivateKey can read it back.
	pemBlock, err := ssh.MarshalPrivateKey(priv, "passport-"+s.RequestID)
	if err != nil {
		return nil, fmt.Errorf("marshal private key: %w", err)
	}

	keyPath := filepath.Join(p.workDir, "id_ed25519")
	certPath := keyPath + "-cert.pub"
	if err := os.WriteFile(keyPath, encodePEM(pemBlock), 0o600); err != nil {
		return nil, fmt.Errorf("write private key: %w", err)
	}

	signResp, err := p.client.Sign(ctx, api.SignRequest{
		RequestID: s.RequestID,
		PublicKey: string(authorizedPub),
	})
	if err != nil {
		return nil, err
	}
	if signResp.Certificate == "" {
		return nil, fmt.Errorf("empty certificate returned")
	}
	if err := os.WriteFile(certPath, []byte(signResp.Certificate), 0o600); err != nil {
		return nil, fmt.Errorf("write certificate: %w", err)
	}

	username := firstNonEmpty(signResp.Username, s.Username)
	return &connection.Credential{
		PrivateKeyPath:  keyPath,
		CertificatePath: certPath,
		Username:        username,
		ValidSeconds:    signResp.ValidSeconds,
	}, nil
}

// VendCredential obtains scoped STS creds (POST .../ssm-credentials).
func (p *Provider) VendCredential(ctx context.Context, _ *identity.Token, s *connection.Session) (*connection.VendedCredentials, error) {
	resp, err := p.client.VendSSMCredentials(ctx, s.RequestID)
	if err != nil {
		return nil, err
	}
	if resp.AccessKeyID == "" {
		return nil, fmt.Errorf("no credentials in vend response")
	}
	return &connection.VendedCredentials{
		AccessKeyID:     resp.AccessKeyID,
		SecretAccessKey: resp.SecretAccessKey,
		SessionToken:    resp.SessionToken,
		Expiration:      resp.Expiration,
		Region:          resp.Region,
		InstanceID:      resp.InstanceID,
	}, nil
}

// Cleanup ends the SSM session (if any) and shreds local key material.
func (p *Provider) Cleanup() {
	if p.tunnel != nil {
		p.tunnel.close()
		p.tunnel = nil
	}
	if p.workDir != "" {
		shredDir(p.workDir)
		p.workDir = ""
	}
}

func (p *Provider) ensureWorkDir() error {
	if p.workDir != "" {
		return nil
	}
	base, err := os.UserHomeDir()
	if err != nil || base == "" {
		base = os.TempDir()
	} else {
		base = filepath.Join(base, ".rackspace-fedramp")
		if mkErr := os.MkdirAll(base, 0o700); mkErr != nil {
			base = os.TempDir()
		}
	}
	dir, err := os.MkdirTemp(base, "connect-")
	if err != nil {
		return fmt.Errorf("create work dir: %w", err)
	}
	if chErr := os.Chmod(dir, 0o700); chErr != nil {
		return fmt.Errorf("secure work dir: %w", chErr)
	}
	p.workDir = dir
	return nil
}

func firstNonEmpty(a, b string) string {
	if a != "" {
		return a
	}
	return b
}
