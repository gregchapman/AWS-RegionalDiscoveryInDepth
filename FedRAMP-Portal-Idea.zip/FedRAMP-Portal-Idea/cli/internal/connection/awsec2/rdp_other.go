//go:build !windows

package awsec2

import (
	"os/exec"
	"runtime"

	"github.com/rackspace/fedramp-portal/cli/internal/connection"
)

// launchRDPClient (non-Windows) is best-effort. On macOS we try to open an
// rdp:// URL, which the Microsoft Remote Desktop app can register; however the
// `open` command returns immediately (it does not stay attached to the app), so
// we cannot observe the client's exit. On Linux there is no single reliable
// native client. In both cases we therefore return a nil channel (never fires):
// holdForRDP falls back to tearing the tunnel down on Ctrl-C or a portal-side
// end demand (the server-status poll), which are the reliable cross-platform
// triggers. We do NOT return a channel we can't honor.
func launchRDPClient(_ *connection.Session) <-chan struct{} {
	if runtime.GOOS == "darwin" {
		// Best-effort convenience only; ignore errors and do not wait.
		_ = exec.Command("open", "rdp://localhost").Start() //nolint:errcheck
	}
	return nil
}
