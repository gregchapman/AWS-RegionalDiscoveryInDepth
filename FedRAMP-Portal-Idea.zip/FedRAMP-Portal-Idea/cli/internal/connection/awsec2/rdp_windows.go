//go:build windows

package awsec2

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"

	"github.com/rackspace/fedramp-portal/cli/internal/connection"
)

// launchRDPClient (Windows) writes a minimal .rdp file pointed at the local
// tunnel port and launches mstsc, then returns a channel that CLOSES when mstsc
// exits (i.e. the user logs out / closes the window). That lets holdForRDP tear
// the SSM tunnel down on RDP logout (issue I3).
//
// Best-effort: if mstsc can't be launched, it returns a nil channel (never
// fires) and holdForRDP falls back to Ctrl-C / server-side poll. We deliberately
// do NOT embed the password in the .rdp file (that would require DPAPI blob
// encryption and would persist a credential to disk); the user pastes the
// password once, as before. The value here is lifecycle, not autofill.
func launchRDPClient(s *connection.Session) <-chan struct{} {
	rdp := fmt.Sprintf(
		"full address:s:localhost:%s\r\nusername:s:.\\%s\r\nprompt for credentials:i:1\r\n",
		s.PortLocal, s.Username,
	)
	f, err := os.CreateTemp("", "portal-*.rdp")
	if err != nil {
		return nil
	}
	path := f.Name()
	if _, werr := f.WriteString(rdp); werr != nil {
		_ = f.Close()
		_ = os.Remove(path)
		return nil
	}
	_ = f.Close()

	cmd := exec.Command("mstsc", filepath.Clean(path)) //nolint:gosec // fixed client, temp file we wrote
	if err := cmd.Start(); err != nil {
		_ = os.Remove(path)
		return nil
	}

	done := make(chan struct{})
	go func() {
		_ = cmd.Wait()
		_ = os.Remove(path) // shred the .rdp once the client exits
		close(done)
	}()
	return done
}
