//go:build !windows

package awsec2

import (
	"os"
	"os/signal"
	"syscall"
)

// notifyResize delivers terminal window-change (SIGWINCH) events so the remote
// PTY can be resized to match.
func notifyResize(ch chan<- os.Signal) {
	signal.Notify(ch, syscall.SIGWINCH)
}
