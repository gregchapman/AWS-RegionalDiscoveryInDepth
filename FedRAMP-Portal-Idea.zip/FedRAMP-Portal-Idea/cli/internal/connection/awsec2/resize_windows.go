//go:build windows

package awsec2

import "os"

// notifyResize is a no-op on Windows (no SIGWINCH). The initial PTY size is
// still requested; live resize is simply not relayed.
func notifyResize(_ chan<- os.Signal) {}
