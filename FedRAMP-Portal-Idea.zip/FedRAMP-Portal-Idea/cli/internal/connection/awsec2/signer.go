package awsec2

import (
	"fmt"
	"os"

	"golang.org/x/crypto/ssh"
)

// certSigner loads the ephemeral private key and its signed certificate and
// returns an ssh.Signer that presents the certificate (so the server validates
// the CA-signed cert, per ADR-0014). Ported from Passport getCertSigner; we use
// ed25519 keys so the RSA-SHA1 interop workaround is not needed.
func certSigner(privPath, certPath string) (ssh.Signer, error) {
	privBytes, err := os.ReadFile(privPath)
	if err != nil {
		return nil, fmt.Errorf("read private key: %w", err)
	}
	privSigner, err := ssh.ParsePrivateKey(privBytes)
	if err != nil {
		return nil, fmt.Errorf("parse private key: %w", err)
	}

	certBytes, err := os.ReadFile(certPath)
	if err != nil {
		return nil, fmt.Errorf("read certificate: %w", err)
	}
	pub, _, _, _, err := ssh.ParseAuthorizedKey(certBytes)
	if err != nil {
		return nil, fmt.Errorf("parse certificate: %w", err)
	}
	cert, ok := pub.(*ssh.Certificate)
	if !ok {
		return nil, fmt.Errorf("signed material is not an SSH certificate")
	}
	certSigner, err := ssh.NewCertSigner(cert, privSigner)
	if err != nil {
		return nil, fmt.Errorf("build cert signer: %w", err)
	}
	return certSigner, nil
}
