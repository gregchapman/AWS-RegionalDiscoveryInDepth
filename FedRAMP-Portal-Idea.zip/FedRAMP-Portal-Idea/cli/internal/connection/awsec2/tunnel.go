package awsec2

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"os/signal"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/ssm"
	"github.com/rackspace/fedramp-portal/cli/internal/connection"
	"golang.org/x/crypto/ssh"
	"golang.org/x/term"
)

const pluginReadyTimeout = 60 * time.Second

// rdpStatusPollInterval is how often holdForRDP re-checks the portal for a
// server-side end demand (force-end / TTL cleanup). Short enough that a portal
// termination closes the local tunnel within a few seconds (AC-12).
const rdpStatusPollInterval = 5 * time.Second

// tunnel holds the running SSM port-forward session so Cleanup can tear it down.
type tunnel struct {
	region    string
	sessionID string
	pluginCmd *exec.Cmd
	ssmClient *ssm.Client
}

func (t *tunnel) close() {
	if t == nil {
		return
	}
	if t.pluginCmd != nil && t.pluginCmd.Process != nil {
		_ = t.pluginCmd.Process.Kill()
		_, _ = t.pluginCmd.Process.Wait()
	}
	if t.ssmClient != nil && t.sessionID != "" {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		_, _ = t.ssmClient.TerminateSession(ctx, &ssm.TerminateSessionInput{
			SessionId: aws.String(t.sessionID),
		})
	}
}

// Connect opens the SSM port-forward tunnel using ONLY the vended credentials,
// then SSHes over it into an interactive shell. Blocks until the shell exits.
func (p *Provider) Connect(ctx context.Context, s *connection.Session, cred *connection.Credential, vc *connection.VendedCredentials) error {
	// CRITICAL (ADR-0018): build the SSM client from ONLY the vended static
	// credentials. We do NOT call config.LoadDefaultConfig — that would pull
	// ambient AWS_* env vars or ~/.aws/* profiles. A bare aws.Config with a
	// StaticCredentialsProvider guarantees the tunnel can use nothing but the
	// short-lived, instance-scoped creds the portal vended.
	cfg := aws.Config{
		Region: vc.Region,
		Credentials: credentials.NewStaticCredentialsProvider(
			vc.AccessKeyID, vc.SecretAccessKey, vc.SessionToken,
		),
	}
	ssmClient := ssm.NewFromConfig(cfg)

	sessionID, err := p.startSSMSession(ctx, ssmClient, s, vc.Region)
	if err != nil {
		return err
	}
	// Record tunnel so Cleanup can terminate it.
	p.tunnel.ssmClient = ssmClient
	p.tunnel.sessionID = sessionID
	p.tunnel.region = vc.Region

	fmt.Fprintf(os.Stderr, "Tunnel active: localhost:%s -> %s:%s (session %s)\n",
		s.PortLocal, vc.InstanceID, s.PortRemote, sessionID)

	// RDP (ADR-0022, Passport V2 pattern): we don't drive the GUI client. Print
	// the values for the user's native RDP client and hold the tunnel open
	// until they Ctrl-C. SSH: drop straight into an interactive shell.
	if s.AccessType == "rdp" {
		return p.holdForRDP(ctx, s)
	}
	return p.startInteractiveShell(ctx, s, cred)
}

// holdForRDP prints the connection block and holds the SSM tunnel open until
// ANY of these ends the session (issue I3 — previously it only reacted to
// Ctrl-C, leaving the tunnel open after an RDP logout or a portal force-end):
//   1. Ctrl-C / SIGTERM (ctx cancelled),
//   2. the portal marks the session != ACTIVE (operator/portal force-end or TTL
//      cleanup) — detected by polling GET /api/session/{id} (AC-12), or
//   3. the native RDP client process exits (voluntary logout), if we were able
//      to launch it. Launching the client is best-effort; if it fails we fall
//      back to holding until (1) or (2).
// When it returns, the deferred Cleanup() tears the tunnel down.
func (p *Provider) holdForRDP(ctx context.Context, s *connection.Session) error {
	user := ".\\" + s.Username // leading .\ forces a LOCAL account login (no domain)
	fmt.Println()
	fmt.Println("RDP tunnel ready — connect your Remote Desktop client to:")
	fmt.Printf("  Host:     localhost:%s\n", s.PortLocal)
	fmt.Printf("  Username: %s\n", user)
	if s.Password != "" {
		fmt.Printf("  Password: %s\n", s.Password)
	} else {
		fmt.Println("  Password: (not returned by the portal for this session)")
	}
	fmt.Println()
	fmt.Println("Windows: Remote Desktop Connection (mstsc).  Mac: Microsoft Remote Desktop.")
	fmt.Println("Enter the username exactly as shown (the leading .\\ forces a local login).")
	fmt.Println("The tunnel closes automatically when you log out of RDP, when the session")
	fmt.Println("is ended in the portal, or when you press Ctrl-C here.")

	// (3) Best-effort: launch the native RDP client and watch for its exit.
	clientExited := launchRDPClient(s)

	// (2) Poll the portal for a server-side end demand.
	ticker := time.NewTicker(rdpStatusPollInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			fmt.Fprintln(os.Stderr, "\nClosing RDP tunnel (Ctrl-C)...")
			return nil
		case <-clientExited:
			fmt.Fprintln(os.Stderr, "\nRDP client closed — closing tunnel...")
			return nil
		case <-ticker.C:
			// If we can't reach the portal, keep the tunnel up (don't tear down
			// on a transient API error) — only act on a definitive non-ACTIVE.
			resp, err := p.client.Session(ctx, s.RequestID)
			if err != nil {
				continue
			}
			if resp.Status != "ACTIVE" {
				fmt.Fprintf(os.Stderr, "\nSession %s in portal — closing tunnel...\n", resp.Status)
				return nil
			}
		}
	}
}

// startSSMSession calls StartSession and hands the result to the
// session-manager-plugin, returning once the local port is listening.
func (p *Provider) startSSMSession(ctx context.Context, client *ssm.Client, s *connection.Session, region string) (string, error) {
	out, err := client.StartSession(ctx, &ssm.StartSessionInput{
		DocumentName: aws.String("AWS-StartPortForwardingSession"),
		Target:       aws.String(sessionTarget(s)),
		Parameters: map[string][]string{
			"portNumber":      {s.PortRemote},
			"localPortNumber": {s.PortLocal},
		},
	})
	if err != nil {
		return "", fmt.Errorf("ssm start-session: %w", err)
	}
	if out.SessionId == nil || out.StreamUrl == nil || out.TokenValue == nil {
		return "", fmt.Errorf("ssm start-session returned incomplete session")
	}

	pluginData, err := json.Marshal(struct {
		SessionID  string `json:"SessionId"`
		StreamURL  string `json:"StreamUrl"`
		TokenValue string `json:"TokenValue"`
	}{*out.SessionId, *out.StreamUrl, *out.TokenValue})
	if err != nil {
		return "", fmt.Errorf("marshal plugin data: %w", err)
	}

	// session-manager-plugin <json> <region> StartSession  (same handoff the
	// aws CLI performs internally).
	cmd := exec.Command("session-manager-plugin", string(pluginData), region, "StartSession") //nolint:gosec
	p.tunnel = &tunnel{pluginCmd: cmd}

	if err := p.startAndWaitReady(cmd, s.PortLocal); err != nil {
		return *out.SessionId, err
	}
	return *out.SessionId, nil
}

// startAndWaitReady starts the plugin and returns once stdout reports the local
// port is open (mirrors Passport's readiness check), or errors on timeout.
func (p *Provider) startAndWaitReady(cmd *exec.Cmd, localPort string) error {
	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("start session-manager-plugin (is it installed?): %w", err)
	}

	ready := []byte(fmt.Sprintf("Port %s opened for sessionId", localPort))
	deadline := time.After(pluginReadyTimeout)
	tick := time.NewTicker(300 * time.Millisecond)
	defer tick.Stop()
	for {
		select {
		case <-deadline:
			_ = cmd.Process.Kill()
			return fmt.Errorf("timed out waiting for tunnel: %s", out.String())
		case <-tick.C:
			if bytes.Contains(out.Bytes(), ready) {
				return nil
			}
			// If the plugin died early, surface its output.
			if cmd.ProcessState != nil && cmd.ProcessState.Exited() {
				return fmt.Errorf("session-manager-plugin exited early: %s", out.String())
			}
		}
	}
}

// startInteractiveShell dials the local tunnel port and runs an interactive
// SSH session authenticated by the issued certificate. It returns when the
// shell exits, when the context is cancelled (Ctrl-C), OR when the portal marks
// the session != ACTIVE (operator/portal force-end or TTL cleanup — AC-12,
// issue I5). A background poll watches the portal; on an end demand it closes
// the SSH connection, which unblocks sess.Wait().
func (p *Provider) startInteractiveShell(ctx context.Context, s *connection.Session, cred *connection.Credential) error {
	signer, err := certSigner(cred.PrivateKeyPath, cred.CertificatePath)
	if err != nil {
		return err
	}
	cfg := &ssh.ClientConfig{
		User:            cred.Username,
		Auth:            []ssh.AuthMethod{ssh.PublicKeys(signer)},
		HostKeyCallback: ssh.InsecureIgnoreHostKey(), //nolint:gosec // auth'd SSM tunnel; tracked in ARCHITECTURE-WEAKNESSES
		Timeout:         10 * time.Second,
	}

	addr := "localhost:" + s.PortLocal
	conn, err := ssh.Dial("tcp", addr, cfg)
	if err != nil {
		// localhost may not resolve; fall back to the loopback literal.
		conn, err = ssh.Dial("tcp", "127.0.0.1:"+s.PortLocal, cfg)
		if err != nil {
			return fmt.Errorf("ssh dial %s: %w", addr, err)
		}
	}
	defer conn.Close()

	sess, err := conn.NewSession()
	if err != nil {
		return fmt.Errorf("ssh session: %w", err)
	}
	defer sess.Close()

	sess.Stdin = os.Stdin
	sess.Stdout = os.Stdout
	sess.Stderr = os.Stderr

	fd := int(os.Stdin.Fd())
	w, h := 80, 40
	var restore func()
	if term.IsTerminal(fd) {
		state, merr := term.MakeRaw(fd)
		if merr == nil {
			restore = func() { _ = term.Restore(fd, state) }
			if tw, th, gerr := term.GetSize(fd); gerr == nil {
				w, h = tw, th
			}
		}
	}
	if restore != nil {
		defer restore()
	}

	modes := ssh.TerminalModes{ssh.ECHO: 1, ssh.TTY_OP_ISPEED: 14400, ssh.TTY_OP_OSPEED: 14400}
	if err := sess.RequestPty("xterm-256color", h, w, modes); err != nil {
		return fmt.Errorf("request pty: %w", err)
	}

	// Relay window-resize (SIGWINCH) so the remote PTY tracks the terminal.
	winch := make(chan os.Signal, 1)
	notifyResize(winch)
	go func() {
		for range winch {
			if tw, th, gerr := term.GetSize(fd); gerr == nil {
				_ = sess.WindowChange(th, tw)
			}
		}
	}()
	defer signal.Stop(winch)

	if err := sess.Shell(); err != nil {
		return fmt.Errorf("start shell: %w", err)
	}

	// Run the blocking shell wait in the background so we can ALSO react to a
	// portal-side end demand or Ctrl-C (issue I5). Whichever fires first wins;
	// closing conn unblocks sess.Wait().
	shellDone := make(chan error, 1)
	go func() { shellDone <- sess.Wait() }()

	// Poll the portal for a server-side end demand. Stop the poller when we
	// return (shell exit or ctx cancel) so it can't leak.
	pollCtx, stopPoll := context.WithCancel(ctx)
	defer stopPoll()
	go func() {
		ticker := time.NewTicker(rdpStatusPollInterval)
		defer ticker.Stop()
		for {
			select {
			case <-pollCtx.Done():
				return
			case <-ticker.C:
				resp, err := p.client.Session(pollCtx, s.RequestID)
				if err != nil {
					continue // transient API error — do not tear down
				}
				if resp.Status != "ACTIVE" {
					fmt.Fprintf(os.Stderr, "\r\nSession %s in portal — closing connection...\r\n", resp.Status)
					_ = conn.Close() // unblocks sess.Wait()
					return
				}
			}
		}
	}()

	select {
	case err := <-shellDone:
		// Normal shell exit (user typed exit / logout) OR conn closed by the
		// poller/ctx below. A closed-conn error after a force-end is expected.
		return err
	case <-ctx.Done():
		fmt.Fprintln(os.Stderr, "\nClosing SSH session (Ctrl-C)...")
		_ = conn.Close()
		<-shellDone
		return nil
	}
}

// sessionTarget is the SSM StartSession Target — the instance id itself.
func sessionTarget(s *connection.Session) string {
	return s.InstanceID
}
