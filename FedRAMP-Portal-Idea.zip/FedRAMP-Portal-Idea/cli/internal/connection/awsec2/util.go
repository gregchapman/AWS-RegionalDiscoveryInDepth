package awsec2

import (
	"crypto/rand"
	"encoding/pem"
	"os"
	"path/filepath"
)

// encodePEM renders a *pem.Block to bytes.
func encodePEM(b *pem.Block) []byte {
	return pem.EncodeToMemory(b)
}

// shredDir best-effort overwrites files with random bytes before removing the
// directory, so ephemeral private keys don't linger on disk. Mirrors the shell
// script's `shred -u` + `rm -rf`.
func shredDir(dir string) {
	_ = filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info == nil || info.IsDir() {
			return nil
		}
		if f, oerr := os.OpenFile(path, os.O_WRONLY, 0o600); oerr == nil {
			buf := make([]byte, info.Size())
			_, _ = rand.Read(buf)
			_, _ = f.WriteAt(buf, 0)
			_ = f.Sync()
			_ = f.Close()
		}
		return nil
	})
	_ = os.RemoveAll(dir)
}
