// Package connection defines the ConnectionProvider abstraction (ADR-0016).
//
// A ConnectionProvider knows how to take an authenticated identity and connect
// it to ONE class of target. Its verbs mirror the access lifecycle the portal
// already implements and match the production Passport fork on
// AccessRequest.Type:
//
//	RequestAccess  -> create the access request           (POST /api/connect)
//	AwaitReady     -> wait for provisioning to finish      (poll GET /api/session/{id})
//	IssueCredential-> obtain a short-lived authenticator    (POST /api/sign — SSH cert)
//	VendCredential -> obtain scoped, short-lived AWS creds   (POST /api/session/{id}/ssm-credentials)
//	Connect        -> open the transport + interactive session (SSM tunnel + SSH)
//	Cleanup        -> tear down / end the session            (POST .../terminate; local shred)
//
// The identity source (IdentityProvider) and the connection target are
// DIFFERENT interfaces on purpose. The CLI dispatches to a provider based on
// the target's kind. The first — and currently only — implementation is
// aws-ec2 (SSH-CA + SSM), in internal/connection/awsec2. Defining the
// interface first (even for one provider) is an explicit ADR-0016 requirement
// so aws-eks / vsphere / azure-vm can be added without reshaping the CLI.
package connection

import (
	"context"

	"github.com/rackspace/fedramp-portal/cli/internal/identity"
)

// Kind enumerates target classes a provider can serve.
type Kind string

const (
	// KindAWSEC2 is an EC2 (or SSM managed) instance reached via SSM.
	KindAWSEC2 Kind = "aws-ec2"
)

// Target describes what the user wants to connect to.
type Target struct {
	Kind       Kind
	InstanceID string // e.g. i-0abc... or mi-0abc...
	Region     string // e.g. us-east-2, us-gov-west-1
	TTLMinutes int    // requested authorization window (clamped server-side 15-720)
	AccessType string // "ssh" (default) or "rdp"
}

// Session is the live, provisioned access request plus its connection details.
// It is populated across the provider's lifecycle calls.
type Session struct {
	RequestID  string
	InstanceID string // target instance (i-... / mi-...)
	Region     string
	AccessType string // "ssh" or "rdp"
	Status     string
	Username   string // identity-derived OS user (ADR-0011)
	Password   string // RDP only; short-lived per-session password. Empty for SSH.
	PortLocal  string
	PortRemote string
	ExpiresAt  int64 // epoch seconds; 0 if unknown
}

// VendedCredentials are the short-lived, instance-scoped AWS credentials the
// portal vends for the SSM tunnel. They are used ONLY to open the tunnel and
// are never persisted or exported to the ambient environment.
type VendedCredentials struct {
	AccessKeyID     string
	SecretAccessKey string
	SessionToken    string
	Expiration      string // ISO 8601
	Region          string
	InstanceID      string
}

// Provider connects an authenticated identity to a target.
type Provider interface {
	// Kind reports which target class this provider serves.
	Kind() Kind

	// RequestAccess creates the access request and returns the new Session
	// (status typically PENDING).
	RequestAccess(ctx context.Context, tok *identity.Token, t Target) (*Session, error)

	// AwaitReady polls until the session is ACTIVE (or fails/times out),
	// filling in connection details on the Session.
	AwaitReady(ctx context.Context, tok *identity.Token, s *Session) error

	// IssueCredential obtains the short-lived authenticator (an SSH
	// certificate) for the session, writing whatever local key material is
	// needed and returning a handle the transport can use.
	IssueCredential(ctx context.Context, tok *identity.Token, s *Session) (*Credential, error)

	// VendCredential obtains scoped, short-lived AWS credentials for the SSM
	// tunnel.
	VendCredential(ctx context.Context, tok *identity.Token, s *Session) (*VendedCredentials, error)

	// Connect opens the transport (SSM port-forward tunnel) using ONLY the
	// vended credentials, then runs the interactive session (SSH over the
	// tunnel using the issued credential). It blocks until the user's session
	// ends.
	Connect(ctx context.Context, s *Session, cred *Credential, vc *VendedCredentials) error

	// Cleanup releases resources (ends the SSM session, shreds local key
	// material). Safe to call more than once.
	Cleanup()
}

// Credential is a provider-specific authenticator handle. For aws-ec2 it is an
// SSH certificate + private key on disk (paths), consumed by the SSH client.
type Credential struct {
	// PrivateKeyPath is the ephemeral private key file.
	PrivateKeyPath string
	// CertificatePath is the signed OpenSSH cert (<key>-cert.pub) next to it.
	CertificatePath string
	// Username is the login user the cert is valid for.
	Username string
	// ValidSeconds is the certificate lifetime (<= 3600).
	ValidSeconds int
}
