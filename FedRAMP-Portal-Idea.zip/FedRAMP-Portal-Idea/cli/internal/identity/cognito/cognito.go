// Package cognito implements identity.Provider against an Amazon Cognito user
// pool using the Secure Remote Password (SRP) flow plus TOTP MFA.
//
// This is the ADR-0012 "the CLI authenticates for real" piece. The CLI does
// NOT accept a handed-over bearer token — it drives USER_SRP_AUTH and answers
// the SOFTWARE_TOKEN_MFA challenge itself, so possessing the resulting token
// requires passing an interactive MFA check. That is what closes the
// bearer-token-replay origin: the token is earned, not transferred.
//
// SRP math is delegated to github.com/alexrudd/cognito-srp/v4 (a tested port of
// the reference "warrant" implementation) rather than hand-rolled — SRP is easy
// to get subtly and insecurely wrong.
package cognito

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"strings"

	cognitosrp "github.com/alexrudd/cognito-srp/v4"
	"github.com/aws/aws-sdk-go-v2/aws"
	cip "github.com/aws/aws-sdk-go-v2/service/cognitoidentityprovider"
	"github.com/aws/aws-sdk-go-v2/service/cognitoidentityprovider/types"
	"github.com/rackspace/fedramp-portal/cli/internal/identity"
	"golang.org/x/term"
)

// Provider authenticates against a specific Cognito user pool + app client.
type Provider struct {
	Region   string
	PoolID   string
	ClientID string

	// In/Out/ErrOut allow tests to inject IO; default to std streams.
	promptOut *os.File
	promptIn  *os.File
}

// New builds a Cognito identity provider for the given pool/client/region.
func New(region, poolID, clientID string) *Provider {
	return &Provider{
		Region:    region,
		PoolID:    poolID,
		ClientID:  clientID,
		promptOut: os.Stderr, // prompts go to stderr so stdout stays clean
		promptIn:  os.Stdin,
	}
}

// Name implements identity.Provider.
func (p *Provider) Name() string { return "cognito" }

// Authenticate runs USER_SRP_AUTH + SOFTWARE_TOKEN_MFA and returns a Token.
func (p *Provider) Authenticate(ctx context.Context) (*identity.Token, error) {
	username, err := p.prompt("Portal username (email): ")
	if err != nil {
		return nil, err
	}
	password, err := p.promptSecret("Password: ")
	if err != nil {
		return nil, err
	}

	// SRP client. Cognito needs the pool id in "region_poolsuffix" form.
	csrp, err := cognitosrp.NewCognitoSRP(username, password, p.PoolID, p.ClientID, nil)
	if err != nil {
		return nil, fmt.Errorf("init SRP: %w", err)
	}

	cfg := aws.Config{Region: p.Region}
	client := cip.NewFromConfig(cfg)

	// Step 1: InitiateAuth USER_SRP_AUTH -> PASSWORD_VERIFIER challenge.
	initResp, err := client.InitiateAuth(ctx, &cip.InitiateAuthInput{
		AuthFlow:       types.AuthFlowTypeUserSrpAuth,
		ClientId:       aws.String(csrp.GetClientId()),
		AuthParameters: csrp.GetAuthParams(),
	})
	if err != nil {
		return nil, fmt.Errorf("initiate auth: %w", authErr(err))
	}
	if initResp.ChallengeName != types.ChallengeNameTypePasswordVerifier {
		return nil, fmt.Errorf("unexpected challenge %q (expected PASSWORD_VERIFIER)", initResp.ChallengeName)
	}

	// Step 2: answer PASSWORD_VERIFIER.
	chalResponses, err := csrp.PasswordVerifierChallenge(initResp.ChallengeParameters, timeNow())
	if err != nil {
		return nil, fmt.Errorf("password verifier: %w", err)
	}
	verResp, err := client.RespondToAuthChallenge(ctx, &cip.RespondToAuthChallengeInput{
		ChallengeName:      types.ChallengeNameTypePasswordVerifier,
		ClientId:           aws.String(csrp.GetClientId()),
		ChallengeResponses: chalResponses,
	})
	if err != nil {
		return nil, fmt.Errorf("respond password verifier: %w", authErr(err))
	}

	// Step 3: MFA challenge loop. The pool requires SOFTWARE_TOKEN_MFA.
	resp := verResp
	for resp.AuthenticationResult == nil {
		switch resp.ChallengeName {
		case types.ChallengeNameTypeSoftwareTokenMfa:
			code, perr := p.prompt("MFA code (authenticator app): ")
			if perr != nil {
				return nil, perr
			}
			mfaResp, merr := client.RespondToAuthChallenge(ctx, &cip.RespondToAuthChallengeInput{
				ChallengeName: types.ChallengeNameTypeSoftwareTokenMfa,
				ClientId:      aws.String(csrp.GetClientId()),
				Session:       resp.Session,
				ChallengeResponses: map[string]string{
					"USERNAME":                username,
					"SOFTWARE_TOKEN_MFA_CODE": code,
				},
			})
			if merr != nil {
				return nil, fmt.Errorf("respond MFA: %w", authErr(merr))
			}
			resp = mfaResp
		case types.ChallengeNameTypeSmsMfa:
			code, perr := p.prompt("MFA code (SMS): ")
			if perr != nil {
				return nil, perr
			}
			mfaResp, merr := client.RespondToAuthChallenge(ctx, &cip.RespondToAuthChallengeInput{
				ChallengeName: types.ChallengeNameTypeSmsMfa,
				ClientId:      aws.String(csrp.GetClientId()),
				Session:       resp.Session,
				ChallengeResponses: map[string]string{
					"USERNAME":     username,
					"SMS_MFA_CODE": code,
				},
			})
			if merr != nil {
				return nil, fmt.Errorf("respond MFA: %w", authErr(merr))
			}
			resp = mfaResp
		default:
			return nil, fmt.Errorf("unsupported challenge %q; complete enrollment in the portal first", resp.ChallengeName)
		}
	}

	ar := resp.AuthenticationResult
	if ar.AccessToken == nil {
		return nil, fmt.Errorf("authentication succeeded but no access token returned")
	}
	tok := &identity.Token{
		AccessToken: aws.ToString(ar.AccessToken),
		IDToken:     aws.ToString(ar.IdToken),
	}
	tok.Email, tok.Subject = claimsFromJWT(tok.AccessToken)
	return tok, nil
}

// --- prompts ---

func (p *Provider) prompt(label string) (string, error) {
	fmt.Fprint(p.promptOut, label)
	r := bufio.NewReader(p.promptIn)
	line, err := r.ReadString('\n')
	if err != nil && line == "" {
		return "", fmt.Errorf("read input: %w", err)
	}
	return strings.TrimSpace(line), nil
}

func (p *Provider) promptSecret(label string) (string, error) {
	fmt.Fprint(p.promptOut, label)
	fd := int(p.promptIn.Fd())
	if term.IsTerminal(fd) {
		b, err := term.ReadPassword(fd)
		fmt.Fprintln(p.promptOut)
		if err != nil {
			return "", fmt.Errorf("read secret: %w", err)
		}
		return strings.TrimSpace(string(b)), nil
	}
	// Non-TTY (e.g. piped) — fall back to a line read.
	return p.prompt("")
}

// authErr unwraps common Cognito auth failures into friendlier messages.
func authErr(err error) error {
	var notAuth *types.NotAuthorizedException
	if asErr(err, &notAuth) {
		return fmt.Errorf("not authorized (bad username/password or MFA)")
	}
	var codeMismatch *types.CodeMismatchException
	if asErr(err, &codeMismatch) {
		return fmt.Errorf("incorrect MFA code")
	}
	var expired *types.ExpiredCodeException
	if asErr(err, &expired) {
		return fmt.Errorf("MFA code expired — try the next code")
	}
	return err
}
