package cognito

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"strings"
	"time"
)

// timeNow is a seam for tests; cognito-srp needs the timestamp used when
// signing the password-verifier challenge.
var timeNow = time.Now

// asErr is a thin errors.As wrapper for readability in authErr.
func asErr(err error, target any) bool {
	return errors.As(err, target)
}

// claimsFromJWT best-effort decodes the email + sub from a JWT payload. Purely
// for display/logging; NEVER used for authorization (the backend re-derives
// identity from the verified token). Returns empty strings on any problem.
func claimsFromJWT(tok string) (email, sub string) {
	parts := strings.Split(tok, ".")
	if len(parts) != 3 {
		return "", ""
	}
	payload, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return "", ""
	}
	var c struct {
		Email string `json:"email"`
		Sub   string `json:"sub"`
	}
	if json.Unmarshal(payload, &c) != nil {
		return "", ""
	}
	return c.Email, c.Sub
}
