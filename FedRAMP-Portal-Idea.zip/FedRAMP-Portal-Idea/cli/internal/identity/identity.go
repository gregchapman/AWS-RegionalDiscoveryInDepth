// Package identity defines the IdentityProvider abstraction (ADR-0016).
//
// An IdentityProvider authenticates the human and returns a portal identity
// token plus the claims the rest of the CLI needs. It is deliberately separate
// from the ConnectionProvider: WHO you are (identity source) is a different
// concern from WHAT you are connecting to (connection target). The first — and
// currently only — implementation is Cognito (internal/identity/cognito), but
// the interface is defined first so Identity Center / Entra ID / SAML-OIDC can
// slot in later without touching the connection side.
//
// Critically (ADR-0012 proof-scope note): the production CLI AUTHENTICATES —
// it does not accept a pre-obtained bearer token. Authenticate() performs a
// real login (password + MFA) so the CLI *earns* the token. This is what makes
// the credential path resistant to token replay: possession of the token is
// gated behind an interactive MFA challenge the CLI drives itself.
package identity

import "context"

// Token is the result of a successful authentication.
type Token struct {
	// AccessToken is the portal identity token (Cognito access token). It is
	// sent as the Bearer credential to the portal API. It is NOT an AWS
	// credential. Short-lived (~1h).
	AccessToken string

	// IDToken is retained for claim inspection/UX; the API accepts either but
	// the CLI standardizes on AccessToken for API calls.
	IDToken string

	// Email/Subject are convenience claims for display and logging. They are
	// derived from the token, never trusted for authorization (the backend
	// re-derives identity from the verified JWT).
	Email   string
	Subject string
}

// Provider authenticates a human and returns a portal identity Token.
type Provider interface {
	// Name identifies the provider (e.g. "cognito") for diagnostics.
	Name() string

	// Authenticate performs an interactive login (credentials + MFA as the
	// provider requires) and returns a portal identity Token. It must never
	// require or read AWS credentials. Implementations should prompt securely
	// (no echo for secrets) and honor ctx cancellation.
	Authenticate(ctx context.Context) (*Token, error)
}
