// Package version carries build-stamped version metadata, set via -ldflags at
// build time (see the Makefile), mirroring the production Passport CLI.
package version

var (
	// Version is the semantic version (e.g. "1.0.0" or "dev").
	Version = "dev"
	// Commit is the git commit the binary was built from.
	Commit = "none"
	// BuildTime is the RFC3339 build timestamp.
	BuildTime = "unknown"
)

// String returns a human-readable version line.
func String() string {
	return "passport " + Version + " (commit " + Commit + ", built " + BuildTime + ")"
}
