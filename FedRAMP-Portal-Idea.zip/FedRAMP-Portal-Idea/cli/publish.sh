#!/usr/bin/env bash
# Publish the built CLI artifacts + install scripts to the portal's static
# bucket, under the layout the installers expect:
#
#   cli/releases/LATEST/<os>-<arch>/passport[.exe]
#   cli/releases/LATEST/SHA256SUMS
#   cli/releases/LATEST/install.sh
#   cli/releases/LATEST/install.ps1
#
# The serve_spa Lambda serves any bucket key on the public $default route, so
# these become downloadable at https://portal.takahe.click/cli/releases/LATEST/...
#
# SoD (ADR-0018): this is a DEPLOY step — greg runs it with AWS_PROFILE set.
# Run `make cli` first so build/ is populated + checksummed.
#
# Usage:
#   (cd cli && ./_make.sh cli)                 # build all platforms + SHA256SUMS
#   AWS_PROFILE=personal-faws cli/publish.sh    # then publish
set -euo pipefail
cd "$(dirname "$0")"

BUCKET="${PORTAL_STATIC_BUCKET:-fedramp-portal-static-675405875014}"
PREFIX="cli/releases/LATEST"
AWS="${AWS_BIN:-/home/greg/.local/bin/aws}"   # avoid the venv CRT bug (todo.md)
command -v "$AWS" >/dev/null 2>&1 || AWS="aws"

[ -d build ] || { echo "error: build/ missing — run ./_make.sh cli first" >&2; exit 1; }
[ -f build/SHA256SUMS ] || { echo "error: build/SHA256SUMS missing — run ./_make.sh cli" >&2; exit 1; }

# Stage a clean tree that mirrors the download layout.
stage="$(mktemp -d)"; trap 'rm -rf "$stage"' EXIT
mkdir -p "$stage"
cp -r build/* "$stage"/           # <os>-<arch>/passport[.exe] + SHA256SUMS
cp dist/install.sh dist/install.ps1 "$stage"/

echo "Publishing to s3://$BUCKET/$PREFIX/ ..."
# Binaries: octet-stream, cacheable but revalidated. Install scripts: text.
"$AWS" s3 cp "$stage" "s3://$BUCKET/$PREFIX/" --recursive \
  --exclude "install.sh" --exclude "install.ps1" \
  --content-type "application/octet-stream" \
  --cache-control "public, max-age=300"
"$AWS" s3 cp "$stage/install.sh" "s3://$BUCKET/$PREFIX/install.sh" \
  --content-type "text/x-shellscript; charset=utf-8" --cache-control "public, max-age=300"
"$AWS" s3 cp "$stage/install.ps1" "s3://$BUCKET/$PREFIX/install.ps1" \
  --content-type "text/plain; charset=utf-8" --cache-control "public, max-age=300"

echo "Published. Verify:"
echo "  curl -fsSL https://portal.takahe.click/$PREFIX/SHA256SUMS"
echo "  curl -fsSL https://portal.takahe.click/$PREFIX/install.sh | head"
