# FedRAMP Portal / SSM Access Platform Audit

**Repository:** `/mnt/c/RGS-Code/FedRAMP-Portal-Idea`  
**Review date:** 2026-09-29  
**Review objective:** Assess the work as a replacement for VPN, jump hosts, and traditional VM-management access using AWS SSM; assess NIST 800-53/FedRAMP and FedRAMP 20x trust-center readiness; assess the path to multi-account and multi-cloud operation.

## Executive Verdict

This repository contains a credible AWS EC2 proof of concept for zero-inbound,
just-in-time access through SSM Session Manager. The strongest implemented path
is: Cognito-authenticated user -> regional API Gateway -> Lambda/Step Functions
session lifecycle -> SSM SendCommand and StartSession -> ephemeral identity-named
host account -> short-lived SSH certificate or RDP tunnel. That is a meaningful
replacement for a VPN and jump-host path for the AWS/EC2 case.

The repository intentionally separates design, implementation, deployment, and
authorization status. This audit does not interpret the project as claiming a
FedRAMP authorization or completed 20x certification. The current facts are:

- The AWS/EC2 access path is a strong, exercised POC.
- The platform contracts and CloudFormation delivery are substantial authored
  implementation, not merely architectural slides.
- ADR-0037's evidence and assurance plane is now implemented in the CFN track:
  schemas, control registry, evaluator tests, durable evidence storage, AWS
  posture collection, structured audit ingestion, alarms, compliance/audit
  projections, and human review.
- Those platform components remain deployment- and operations-unproven because
  this workspace has not applied them in an AWS Organization.
- Multi-cloud providers, multi-IdP federation, and cross-account Organization
  execution remain staged implementation work under ADR-0033 and ADR-0038.

**Overall assessment: strong AWS access POC, credible and increasingly concrete
product platform, with deployment, integration, and authorization evidence still
to be completed.**

The highest-risk issue found during review was authorization ordering:
`POST /api/connect` accepted a client-supplied instance and started the
provisioning workflow after a non-fatal tag lookup. That issue has now been
fixed in the POC, platform-module, and CloudFormation handler copies. The new
gate authorizes the target before any session record or workflow side effect;
credential vending still performs a second live-tag check.

## What Was Reviewed

- Root POC: `terraform/`, `portal/`, `cli/`, and `scripts/`.
- Productization track: `platform/modules/`, `platform/contracts/`, `platform/cfn/`, `platform/live/`.
- Architecture, target architecture, operator runbook, weaknesses register, and `todo.md`.
- Steering decisions in `.kiro/steering/`, with emphasis on ADR-0021, 0023-0029,
  0033, and 0036.
- First-party Python syntax and React build checks.

This workspace copy was not a Git checkout, so this review does not use commit
history, blame, or a diff baseline. Claims below are grounded in the checked-in
files and the validation results listed at the end.

## Decision-Record Assessment

The ADR set is a strength. It gives the project a clear hierarchy and makes
several important trade-offs explicit. The concern is implementation maturity,
not lack of architectural intent.

| Decision | Assessment |
|---|---|
| ADR-0006, ADR-0011, ADR-0014 | Well demonstrated in the POC for Linux: no inbound ports, identity-derived local users, passwordless SSH through an SSH CA. The local user is still administrator/root-equivalent, so attribution is stronger than least privilege. |
| ADR-0012 | Good pattern: the CLI receives short-lived STS credentials with a session policy narrowed to one target. The standing broker role remains broad and relies on code always supplying the narrowing policy. |
| ADR-0019 | The regional API Gateway/same-origin design is consistent with the stated partition intersection. The consequence is an open edge-WAF/IP-filtering gap because WAFv2 cannot attach to HTTP API v2. Do not describe the current front door as WAF-protected. |
| ADR-0020 | Managed-service inheritance is sensible, but inheritance is not evidence by itself. Production still needs an explicit control-owner, boundary, configuration, and evidence record for every inherited control. |
| ADR-0021 | The product north star is clear: auditors, operators, and customers are first-class users; tenant isolation is an invariant. The current single-account/tag model does not provide the required defense in depth for production. |
| ADR-0023 | The conductor and verified teardown are among the strongest parts of the implementation. They address the historical stranded-session problem. The remaining risk is failure detection, residual alerting, and cross-account wiring. |
| ADR-0024 | The original POC path relied heavily on application/service logs. The CFN platform now adds a durable structured audit stream for core inventory, session, credential-vend, termination, evidence, and review actions. Remaining work is complete endpoint/system-actor coverage, production retention/SIEM integration, and live operational exercise. |
| ADR-0037 | The evidence and assurance plane is implemented in the CFN track: machine-readable schemas, a provisional control registry, conservative evaluator tests, durable KMS/S3/DynamoDB storage, scheduled AWS collectors, structured audit ingestion, alarms, tenant-safe projections, and operator review. The remaining question is deployment and operational exercise, not whether the project has begun building the plane. |
| ADR-0038 | Multi-IdP federation and AD-optional AWS operation are now explicit target decisions. Cognito is the current runtime provider; SAML/OIDC registration, issuer/subject lifecycle, assurance mapping, and two-provider tests remain staged work. |
| ADR-0026 | The consumer API is still a draft and is not the runtime API surface. The current portal is not yet demonstrably replaceable by an external consumer generated from a stable contract. |
| ADR-0027 / ADR-0016 | The provider abstraction is the right direction, but AWS is the only implementation. vCenter/Azure/GCP entries describe future adapters, not delivered capabilities. |
| ADR-0028 | The abstraction correctly authorizes on assurance rather than mechanism. The shipped Cognito reference uses TOTP, which is not phishing-resistant MFA. A real IdP/federation and assurance mapping are still required. |
| ADR-0029 | Separate provider authorization boundaries and compliance profiles are the right model. They are architectural intent until a second provider and profile are deployed and evidenced. |
| ADR-0033 | The control-plane/member-account split is correctly identified, but the four runtime cross-account paths are not complete. This is a production-blocking capability gap, not a configuration toggle. |
| ADR-0036 | Moving delivery to CloudFormation/StackSets fits the governance operator and AWS Organizations model. The shipping CFN path is not yet applied or runtime-tested; the older Terraform remains as a reference and can confuse adopters unless clearly marked superseded everywhere. |

## Findings, Ordered by Risk

### P0: Authorization and tenant isolation

**1. Connect authorization previously occurred after target-side mutation; fixed
2026-09-29.**

Before the fix, `terraform/03-api/lambda/create_access_request/handler.py` accepted
`instance_id` and `region` from the request body. It reads the `Customer` tag
only to stamp the session record, treats lookup failure or a missing tag as
non-fatal, writes the request, and starts Step Functions. The workflow then
invokes `provision_user`, which runs `ssm:SendCommand` against the supplied
instance. The final `ssm_credentials` handler re-checks the customer tag before
vending tunnel credentials, but that is too late to prevent provisioning,
configuration changes, or a privileged local account from being created.

The fix adds `authorize_target_instance` to the shared utilities and invokes it
before DynamoDB or Step Functions. Customer callers must have a matching
`customer_id`, `CustomerAccess=true`, and an allowed target region; operators
retain their broader scope. Credential vending still revalidates the live tag.
The remaining work is automated negative coverage proving no unauthorized
request can invoke `SendCommand`, plus production account-boundary enforcement.

**2. Isolation depends on mutable tags and a shared account in the POC.**

The production invariant says Customer 1 must never see Customer 2. The POC uses
one AWS account, regions as simulated boundaries, and EC2 tags as the tenant
source of truth. A tag-integrity failure, privileged operator, or code defect can
cross tenants. The accepted ADR-0033 target correctly changes the boundary to
member accounts, but that target is not implemented end to end.

**Required correction:** use account/OU membership as the primary tenant
boundary, deploy the target-access role through StackSets, protect ownership tags
with Organizations/SCP/Config controls, and test cross-tenant denial at list,
connect, provision, vend, session-read, and terminate paths.

### P0: Identity and privileged access

**3. The reference profile uses TOTP; production profiles target phishing-resistant assurance.**

The Terraform and platform Cognito reference configuration enables software-token
MFA (TOTP). TOTP is useful MFA but is not phishing-resistant. The architecture
and ADR-0028 identity-by-assurance model are designed to accept a federated IdP
that enforces FIDO2/passkeys, YubiKey/PIV, or an equivalent assurance level.
This is a reference-profile boundary, not evidence that the project is closed to
those production methods.

**Required correction:** make the required assurance explicit in the identity
assertion and authorization policy, then exercise a federated production profile
with phishing-resistant authenticators. Keep the standalone Cognito/TOTP path
clearly labeled as the reference profile.

**4. Ephemeral accounts are administrator/root-equivalent.**

Linux provisioning adds the user to `sudo` or `wheel`; Windows provisioning adds
the user to `Administrators`. This may be necessary for some support tasks, but
it is not least privilege and creates a large blast radius if the account,
certificate, or session is abused. Identity attribution does not reduce the
privilege granted.

**Required correction:** define capability-specific roles and commands, separate
read-only/support/admin workflows, require ticket justification for on-behalf-of
admin actions, and make elevation explicit and time-bounded. If full admin is a
business requirement, document it as a controlled exception with monitoring and
approval rather than calling the base path least privilege.

**5. Windows/RDP still exposes a stored password.**

The Windows password is generated, returned from SSM, stored in the session
record, and read by the CLI. The weaknesses register correctly identifies the
plaintext DynamoDB issue. This conflicts with the otherwise strong credential
handling narrative and weakens SC-28/IA-5(1).

**Required correction:** prefer passwordless or brokered Windows access. If a
password is unavoidable, do not store it in the session record; vend it once
from a protected secret path or encrypt the field with a dedicated KMS key,
restrict decryption, suppress it from all logs, and prove expiry/revocation.

### P1: Audit, monitoring, and 20x evidence

**6. Audit implementation exists; operational review remains to be exercised.**

CloudTrail, SSM session logging, API Gateway/Lambda logs, and Step Functions
history create useful raw evidence. The CFN platform now adds a durable
structured audit stream for the core API paths, an evidence collector/API,
operator review, and collector/API failure alarms. The remaining gap is not
absence of implementation: complete endpoint/system-actor coverage, anomaly
detections, production SIEM/incident integration, and a live review drill still
need to be deployed and exercised.

**Required correction:** finish structured coverage for every endpoint and system
actor; subscribe the alert topic to the approved SIEM/incident path; add
detections for failed authentication, denied cross-tenant requests, unusual
enumeration, operator revocation bursts, failed cleanup, stale evidence, and
unexpected SSM commands; then execute an operations review/response drill.

**7. Evidence plane implemented; deployment and assessor exercise remain open.**

The repository now contains ADR-0037, machine-readable evidence and claim
schemas, a provisional NIST 800-53 Moderate registry, a conservative evaluator
with regression tests, durable KMS/S3/DynamoDB storage, AWS posture collectors,
structured audit ingestion, alarms, tenant-safe `/audit` and `/compliance`
projections, and operator review. It does not yet contain a deployed/exported
assessor package, OSCAL catalog/profile implementation, signed evidence bundle,
or live Organization evidence run. Those are deployment and packaging gaps,
not evidence-plane absence.

**Required correction:** deploy the CFN evidence plane in a disposable
Organization, complete the multi-source evaluator and export/signing workflow,
generate an inheritance manifest and assessor package, connect alerts to the
operational response system, and prove retention, access control, tenant
scoping, freshness, and tamper detection with live evidence.

**8. Audit-log protection is not production-grade in the single-account model.**

The POC's CloudTrail and DynamoDB/PITR choices help, but an account administrator
can still affect logs in the same account. DynamoDB TTL can remove operational
session records before a cleanup failure is acted upon, even if permanent service
logs remain. ADR-0033 correctly leaves organization-trail ownership open.

**Required correction:** send organization CloudTrail and evidence to a separate
log-archive/evidence account with restrictive retention and deletion controls;
retain terminal session records for the audit window; alert on `CLEANUP_FAILED`
and reconcile residual host accounts independently of the live-session table.

### P1: Production delivery and cross-account operation

**9. The platform deployment is not proven.**

The project states that the productized Terraform was validated but never
applied, and that the CloudFormation delivery is the current path. In this
workspace, `terraform validate` for `platform/live/poc-commercial` could not run
because modules are not initialized. The first-party Python handlers compiled and
the React portal built, but neither proves AWS resource creation or runtime
behavior.

**Required correction:** deploy a disposable reference profile, capture the
actual plan/apply results, run end-to-end negative and positive tests, and
publish the exact supported CFN artifact/package hashes. Validate the six CFN
templates and StackSet lifecycle in a test Organization before claiming adopter
readiness.

**10. The AWS Organization runtime path is incomplete by design.**

ADR-0033 and `platform/cfn/control-resources/lambda/PORTING-NOTES.md` state that
the target-account role mechanism exists but is not wired into provisioning,
cleanup, and credential vending. The account ID is also not yet the authoritative
tenant identity in the production assertion. Consequently, the platform can
deploy a control plane but cannot yet reliably manage instances in member
accounts.

**Required correction:** finish and test `target_client` use in every target
touching handler; carry immutable target account ID through the resource and
session records; deploy the StackSet target-access role; map identity tenant
claims to account/OU scope; and test denied role assumption, wrong-account
resource IDs, and partial member-account failure.

**11. IAM safety depends heavily on Lambda correctness.**

Several SSM/EC2 permissions are broad at the role level and narrowed by inline
session policy or application code. This can be acceptable as a broker pattern,
but it makes code review, deployment integrity, and policy regression testing
security-critical. A future code path that assumes the broker role without the
inline policy would have a larger reach than intended.

**Required correction:** reduce role-level resources where AWS permits; add
explicit deny conditions for missing session context/tags; use separate roles for
list, provision, cleanup, and credential vend; add IAM Access Analyzer and policy
regression tests; and log every AssumeRole with target account/resource context.

### P2: Reliability and operations

- Add EventBridge failure/abort handling and a reconciliation worker for sessions,
  local users, profiles, and SSM tunnels.
- Add a real emergency revoke-all workflow that writes end-demands to conductors,
  invalidates identity sessions, records a reason, and produces completion
  evidence. Do not use `states:StopExecution` as a substitute for cleanup.
- Add dead-letter/error handling for asynchronous workers and make partial
  cross-account failure visible to operators.
- Add synthetic portal/API/session canaries, dashboards, SLOs, backup/restore
  exercises, and incident runbooks.
- Move inline host scripts into versioned SSM Documents or another controlled,
  hash-pinned artifact path.
- Add dependency, container/layer, Lambda, EC2, IaC, and supply-chain scanning;
  generate SBOMs and verify artifact provenance in CI.
- Remove stale deployment instructions and keep the CFN delivery path clearly
  separated from superseded Terraform reference material.

## Goal-by-Goal Assessment

### Replace VPNs and jump hosts

**Achieved for the AWS POC, with boundaries.** Private instances have no inbound
SSH/RDP path; SSM VPC endpoints and Session Manager provide an outbound-managed
path; the user receives access to one instance rather than network placement.
This is a materially better access pattern than a broad VPN segment or bastion.

It is not yet a universal claim. The provider contract explicitly permits
provider-specific mechanisms for vCenter, Azure, and GCP, and those providers do
not exist. A provider using an existing AD trust, Bastion, or IAP can still be
valid under ADR-0027, but must meet the same attributed, ephemeral, verifiably
terminable session contract and its own authorization boundary. “No VPN” is a
product policy; “SSM everywhere” is not compatible with the stated multi-cloud
contract unless non-AWS adapters are constrained or separately justified.

### NIST 800-53 / FedRAMP

The design maps credibly to several control families: AC-2/AC-6/AC-12, IA-2,
IA-5 for Linux, AU-2/AU-3/AU-12, SC-7/SC-8/SC-13/SC-28, CM-6, CA-7, and SI-4.
The implementation is strongest where AWS managed services and SSM semantics do
the work. It remains weak or conditional for AC-2(7), AC-6 least privilege,
AU-6, AU-9/AU-11, IA-2 assurance, IA-5(1) Windows, RA-5, IR-4, and SC-7 edge
protection.

No repository can by itself establish a FedRAMP authorization. The missing
pieces are not only code: system boundary, SSP, control implementation
statements, inherited-control agreements, evidence procedures, POA&M, personnel
and incident processes, vulnerability management, configuration baselines,
continuous monitoring, and assessor-ready records are all required.

### FedRAMP 20x / trust center

The project is addressing the trust-center problem directly, not merely
describing it. ADR-0037 and the current CFN implementation establish the
evidence-plane foundation: machine-readable claims, scoped responsibility,
freshness, provenance, integrity hashes, durable storage, AWS collectors,
structured audit ingestion, alarms, tenant-safe projections, and human review.

The remaining maturity boundary is deployment and proof: run the plane in an
AWS Organization, connect alerts to operational response, generate signed
assessor exports/inheritance manifests, and demonstrate freshness, retention,
tenant isolation, and tamper handling with live evidence. That is an appropriate
next stage for a project intentionally preparing for 20x-style evidence; it is
not evidence that the project claimed certification or had no tooling.

### Multi-cloud and “any cloud” VM management

**Architecturally promising, operationally not delivered.** The canonical
resource model, provider-defined Connect operation, and separate provider
boundaries are sound decisions. AWS is the only actual provider. The vCenter,
Azure, and GCP rows in the contract are target-state examples, and the provider
contract is explicitly provisional until a second implementation pressure-tests
it. The next provider should be vCenter because it is the stated design pressure
and will expose identity, session termination, resource capabilities, and
boundary assumptions that AWS currently hides.

## Recommended Delivery Sequence

1. **Close authorization ordering first.** Make resource resolution and tenant /
   account authorization fail closed before any DynamoDB write, Step Functions
   start, or SSM SendCommand. Add cross-tenant negative tests.
2. **Make identity assurance honest.** Implement the normalized assertion with an
   explicit assurance level; federate a production IdP; require phishing-resistant
   MFA for high-impact roles; keep TOTP clearly scoped to demo/lower assurance.
3. **Finish the Organization profile.** Complete StackSets, target-account role
   assumption, account-scoped identity claims, and member-account failure tests.
4. **Exercise the evidence plane.** Deploy the implemented ADR-0037 CFN path,
  connect alerts to incident response, complete signed assessor exports and
  inheritance manifests, and run live freshness/retention/tenant/tamper tests.
5. **Remove credential and privilege exceptions.** Eliminate or securely vend
   RDP passwords and replace host-wide admin with capability-based elevation.
6. **Prove the CFN product.** Apply the current CloudFormation delivery in a
   disposable Organization, test upgrades/rollback/StackSet drift, and publish
   an adopter acceptance suite.
7. **Pressure-test the provider contract.** Implement one real second provider,
   preferably vCenter, behind its own boundary and profile. Freeze API/schema
   contracts only after this test.
8. **Build operating muscle.** Add monitoring, alerting, incident response,
   reconciliation, vulnerability management, canaries, backup/restore, and
   assessor evidence procedures.

## Evidence Inventory

### Strong evidence in the repository

- Regional API Gateway and same-origin SPA design with no inbound target ports.
- SSM VPC endpoints and EC2 test environment.
- SSH CA signing flow and passwordless Linux provisioning.
- Identity-derived usernames and SSM command comments.
- Scoped STS credential-vending design for a single instance.
- Step Functions conductor with verified cleanup and `CLEANUP_FAILED` semantics.
- KMS, encrypted storage, CloudTrail/SSM logging, Config/Security Hub/GuardDuty
  integration points.
- ADR-0037 evidence plane implementation: machine-readable claims, evaluator
  tests, durable evidence ledger/object storage, scheduled posture collection,
  structured audit ingestion, alarms, `/audit`/`/compliance` projections, and
  operator review.
- ADR-0038 multi-IdP/AD-optional target decision, with Cognito clearly marked as
  the current reference provider rather than the only architectural option.
- ADR set that clearly records trade-offs and deferred work.

### Evidence not yet sufficient for production claims

- End-to-end multi-account AWS Organization deployment.
- Real production IdP federation and phishing-resistant MFA.
- Live structured control-plane audit review and SIEM/incident integration.
- Immutable cross-account log archive and retention proof in the target Org.
- Signed assessor exports, inheritance manifests, and OSCAL/profile packaging.
- Provider implementation beyond AWS.
- Automated security/unit/integration/tenant-isolation test suite.
- Applied, upgraded, and rollback-tested CloudFormation delivery.

## Validation Performed

- **Passed:** first-party Python handler compilation for the inspected POC,
  platform, and CFN handler trees (vendored crypto-layer sources excluded).
- **Passed:** `portal/npm run build`; TypeScript compilation and Vite production
  build completed successfully.
- **Passed:** ADR-0037 evidence evaluator regression suite (9 tests), contract
  JSON/OpenAPI validation, CFN YAML syntax validation, full first-party CFN
  Lambda compilation, and mocked collector storage/hash behavior.
- **Not completed:** platform Terraform validation in this checkout; it stopped
  because required modules were not initialized. This is consistent with the
  documented “validated previously / not applied” status, but it is not fresh
  validation of this workspace.
- **Not performed:** AWS plan/apply of the new CFN evidence plane, live
  cross-account evidence collection, CFN StackSet deployment, browser tests,
  vulnerability scans, or assessor evidence review.

## Bottom Line

Keep the current ADR direction. It is the most valuable part of the project:
the separation of invariant access/compliance core, replaceable consumers and
identity, provider-specific boundaries, and deployment profiles is a defensible
way to grow beyond an AWS-only POC.

Use a more precise maturity statement. Today this is a well-developed,
exercised AWS/EC2 access-broker reference implementation plus a substantial
productized platform foundation. The evidence and assurance plane is now
implemented in code and contracts specifically to support 20x-oriented trust
center work; it still needs deployment, operational integration, signed export,
and live evidence exercise. The platform is not yet a general multi-cloud
implementation or production-authorized service, and the Cognito/TOTP reference
is not itself phishing-resistant. Those are staged boundaries, not evidence
that the project failed to build the trust-center capability.