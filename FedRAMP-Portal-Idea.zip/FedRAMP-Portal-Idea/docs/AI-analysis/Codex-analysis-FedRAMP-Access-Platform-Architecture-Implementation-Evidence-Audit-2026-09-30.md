# FedRAMP Access Platform --- Architecture, Implementation, and Evidence Audit

**Review date:** 2026-09-30\
**Objective:** Evaluate whether the project's security claims are
honestly reflected in its target architecture, product contracts,
current implementation lineage, and evidence strategy when measured
against NIST SP 800-53 Rev. 5 and the 2026 FedRAMP 20x model.

## Executive Assessment

The central architectural claim is defensible:

> **Privileged administrative access to cloud and hybrid virtual
> machines does not inherently require Active Directory domain
> membership, VPN access, bastion/jump hosts, routable
> administrator-to-workload network paths, or standing administrator
> credentials.**

Nothing in NIST SP 800-53 Rev. 5 mandates that traditional topology. The
relevant controls require outcomes: uniquely attributable identity,
appropriate authentication assurance, least privilege, controlled remote
access, session termination, auditability, protected communications,
configuration management, monitoring, and evidence that those properties
remain effective.

The target architecture is intentionally designed around those outcomes
rather than around legacy implementation mechanisms.

For the AWS reference provider, the replacement model is approximately:

**human identity → normalized assurance assertion → policy authorization
→ JIT access lifecycle → ephemeral AWS/host authority → AWS SSM control
channel → target VM → correlated audit evidence**

This is not merely a different transport for SSH/RDP. Properly
completed, it removes several sources of standing trust present in the
conventional AD + VPN + jump-host model.

The project also correctly distinguishes its completed AWS proof of
concept from the evolving platform. ADRs 0001--0025 primarily document
the POC lineage; ADR-0026 onward deliberately generalize the design into
a contract-first, provider-neutral, identity-by-assurance platform with
explicit evidence and multi-IdP models. POC limitations must therefore
not be reported as target-architecture defects where the later
architecture explicitly supersedes them.

**Overall conclusion:** The design provides a credible path to an
800-53-aligned, 20x-friendly privileged-access platform without
traditional VPN/jump-host/AD dependencies. The principal remaining risks
are not that the model is inherently noncompliant; they are that several
important target-state claims remain designed rather than exercised, and
that the evidence plane must mature from "collect security data" into
"continuously prove narrowly defined security assertions."

This is an engineering/evidence maturity problem, not evidence that the
core access model is invalid.

------------------------------------------------------------------------

## 1. Audit Baseline and Interpretation

### 1.1 Four different things must not be conflated

This review treats the repository as four related but distinct layers:

1.  **POC implementation** --- proves that the AWS/SSM access pattern
    works end to end.
2.  **ADRs** --- record design decisions, lessons from the POC, and
    target-state guidance.
3.  **Platform contracts/target architecture** --- define what the
    product is intended to guarantee independently of a particular IdP,
    MFA product, cloud provider, or UI.
4.  **Evidence/assurance plane** --- proves whether a particular
    deployed profile actually satisfies its declared security
    properties.

A POC limitation is a product gap only when it remains inconsistent with
the target architecture or has no credible implementation path.

### 1.2 Product boundary

The product is not responsible for making every attached VM, IdP, SIEM,
authenticator, or customer environment compliant.

It is responsible for:

-   enforcing the security properties that belong to the access
    platform;
-   defining explicit contracts for properties supplied by external
    components;
-   failing closed when required properties are absent or ambiguous;
-   preserving attribution and correlation across the access lifecycle;
-   exposing enough machine-readable state and evidence to determine
    whether the deployed profile satisfies its claims;
-   not falsely elevating a weak customer-selected integration into a
    stronger assurance claim.

For example, host audit forwarding to CloudWatch/SIEM can legitimately
remain a managed-VM/customer baseline responsibility. The access
platform must, however, preserve the identifiers needed to correlate the
human identity, authorization, session, ephemeral host principal, and
host audit stream. If host telemetry is absent, the corresponding
end-to-end audit claim should become **unknown/not satisfied**, not
silently "compliant."

------------------------------------------------------------------------

## 2. The Most Important Finding: The Architecture Does Not Need AD, VPN, or Jump Hosts to Satisfy 800-53

The conventional model often embeds several independent functions into
one familiar topology:

-   AD supplies identity and often group-based authorization.
-   VPN supplies network reachability.
-   A jump host creates an administrative choke point.
-   SSH/RDP supplies the interactive session.
-   SIEM/host logging supplies accountability.

Because these technologies commonly appear together, operators can
mistake the implementation pattern for the security requirement.

800-53 does not require that pattern. The platform can decompose those
functions:

  -----------------------------------------------------------------------
  Required security outcome           Target platform mechanism
  ----------------------------------- -----------------------------------
  Unique human identity               Normalized identity assertion keyed
                                      by issuer + subject

  MFA/authentication assurance        IdP-neutral assurance contract

  Authorization                       Tenant/group/role/attribute policy

  Least privilege                     Scoped JIT authorization and
                                      target-specific credentials

  Remote access control               Brokered provider connection

  Network exposure reduction          No inbound administrative ports for
                                      AWS/SSM profile

  Standing privilege reduction        Ephemeral credentials and ephemeral
                                      host principals

  Session termination                 Authoritative lifecycle conductor
                                      with verified teardown

  Accountability                      Correlated access
                                      request/session/audit identifiers

  Continuous assessment               Evidence and assurance plane

  Customer/auditor transparency       Machine-readable compliance/audit
                                      projections and future trust center
  -----------------------------------------------------------------------

The absence of a VPN or jump host is therefore not a control deficiency
by itself. It can be a reduction in attack surface if the replacement
path demonstrably supplies the required controls.

The same is true of AD. For the AWS/SSM profile, AD is not required to
authenticate the human, authorize the request, create a short-lived host
principal, or transport the session. AD remains permissible where a
provider or customer requires it (for example, a transitional vCenter
profile), but it is not an architectural prerequisite.

------------------------------------------------------------------------

## 3. Claim-to-Product Audit

### Claim A --- "No inbound administrative ports are required for the AWS profile"

**Assessment: Strongly supported for the POC/reference AWS path; target
claim is appropriate.**

The POC demonstrates SSM-mediated access without inbound SSH/RDP
exposure. ADR-0006 and the later provider model preserve this as an
AWS-provider property rather than incorrectly making SSM part of the
universal provider contract.

**Relevant controls/outcomes:** AC-17, SC-7, SC-8, SC-23, least
functionality/reduced exposure concepts.

**Remaining proof work:**

-   continuously verify that eligible AWS targets do not expose
    prohibited administrative ingress;
-   prove that access still functions through the intended SSM path;
-   surface exceptions rather than allowing a security group opening to
    coexist silently with a "zero inbound" claim.

**20x evidence candidate:** percentage/count of managed targets meeting
the no-inbound-management rule, exceptions, age of last evaluation, and
remediation state.

### Claim B --- "AWS access can operate without customer AD"

**Assessment: Architecturally supported and correctly scoped.**

ADR-0038 explicitly separates the AWS SSM access path from customer AD.
ADR-0028 defines identity by assurance rather than mechanism. The
platform's identity contract is the correct abstraction.

The target claim should remain:

> **AD-optional**, not "AD prohibited."

That distinction is important. A vCenter or legacy Windows provider may
legitimately use AD inside its own provider boundary while the AWS
provider remains directory-less.

**Relevant controls:** IA-2, IA-4, IA-5, AC-2, AC-3, AC-6.

**Real gap:** only the Cognito reference provider is currently
exercised. The multi-IdP claim is designed but not production-proven.

**Development proof required:**

-   one real SAML integration;
-   one real OIDC integration;
-   issuer+subject identity keying;
-   assurance mapping tests;
-   disabled-user/deprovisioning behavior;
-   ambiguous/missing claim failure;
-   cross-tenant identity collision tests;
-   two IdPs active concurrently.

### Claim C --- "Authentication is vendor-neutral and policy evaluates assurance, not authenticator brand"

**Assessment: Excellent target principle; contract exists; integration
proof incomplete.**

ADR-0028 is one of the strongest design decisions in the set. TOTP,
FIDO2/WebAuthn, PIV/CAC, Microsoft Authenticator in an appropriate
phishing-resistant mode, YubiKey, Swissbit, or future mechanisms can
participate if the upstream identity system can truthfully emit the
required assurance properties.

This avoids both vendor lock and the dangerous inverse error of
declaring an authenticator compliant because of its brand.

**Important compliance rule:** customer choice may weaken a deployed
profile. The platform should not weaken its semantics to accommodate
that choice.

Example:

-   Required assurance: `phishing-resistant`
-   IdP assertion: `mfa=true`, `authn_assurance=mfa` only
-   Result: **authorization denied or compliance claim not satisfied**,
    depending on policy.

The current POC's Cognito+TOTP should be documented as a reference/POC
assurance profile, not as evidence of production phishing-resistant
privileged authentication.

**Relevant controls:** IA-2 and enhancements, IA-5, AC-3; current
FedRAMP guidance requires phishing-resistant MFA for applicable MFA
requirements.

### Claim D --- "Authorization is JIT and least-privileged"

**Assessment: Strong architectural alignment; one of the best matches to
current 20x.**

The brokered session pattern, scoped credentials, target authorization,
ephemeral principal, and bounded session lifetime map directly to the
current 20x emphasis on least-privileged, role/attribute-based,
just-in-time authorization.

The historical pre-provisioning authorization defect identified in the
prior audit was significant, but the project records it as corrected
before workflow side effects, with a second authorization check at
credential vending.

**Remaining development risks:**

-   the production Organization/cross-account target role path is still
    deferred;
-   the POC's shared-account/tag isolation cannot be treated as the
    production tenant boundary;
-   standing broker permissions must remain constrained by mandatory
    code/policy guardrails;
-   negative tests need to prove that no unauthorized target can reach
    provisioning, credential vending, read, or termination side effects.

**Relevant controls:** AC-2, AC-3, AC-4, AC-5, AC-6, AC-17; KSI-IAM-JIT
and KSI-IAM-ELP.

### Claim E --- "The local VM principal is governed rather than inherited from a standing directory account"

**Assessment: Strong security model; proof needs to remain
provider-specific.**

The ephemeral identity-named local-principal model is a legitimate
replacement for a standing domain account in the AWS profile. It
improves correlation and reduces persistent credential exposure.

The target contract should describe the required property rather than
mandate a Unix implementation:

> provider connection establishes an attributable, brokered, ephemeral,
> verifiably terminable administrative authority.

Linux SSH certificates are one implementation. Windows, vCenter, Azure,
and future providers may implement that property differently.

**Relevant controls:** AC-2, AC-6, IA-4, IA-5, AC-12, AU-3.

**Remaining proof work:** demonstrate that teardown failure becomes
visible and does not produce a false terminal success state.

### Claim F --- "Every privileged action can be attributed to a human"

**Assessment: Partially product-owned, partially deployment-owned.**

The platform can and should prove:

-   authenticated issuer+subject;
-   assurance at authorization time;
-   tenant and policy decision;
-   access request;
-   target;
-   vended credential/session;
-   host principal identity;
-   start/end/termination outcome;
-   operator override/revocation identity.

It cannot by itself prove every command executed inside an SSH/RDP
session unless the target supplies appropriate host audit telemetry.

This is not necessarily a product defect. It is a **declared external
evidence dependency**.

The correct architecture is:

**platform identity/session evidence + target host audit evidence →
complete activity proof**

For SSM-tunneled SSH/port forwarding, native Session Manager does not
inspect the encrypted application stream. Therefore host-side audit
collection is necessary for command/activity-level evidence.

**Relevant controls:** AU-2, AU-3, AU-6, AU-8, AU-9, AU-12, AC-17(1),
CA-7.

**Required product behavior:** evidence claims dependent on host
telemetry must become `unknown` or `not_satisfied` when the required
stream is absent/stale.

### Claim G --- "The platform is multi-cloud/provider-neutral"

**Assessment: Architecturally credible, not yet demonstrated beyond
AWS.**

ADR-0027 correctly avoids making SSM part of the universal provider
contract. This is essential.

The universal operation is not "start an SSM session." It is:

> **establish an attributed, brokered, ephemeral, verifiably terminable
> session to this resource.**

AWS may implement this with SSM. vCenter, Azure, GCP, OpenStack, or
another platform may use different provider-local mechanisms while
preserving the core security contract.

This is a major architectural strength because it prevents AWS
implementation details from becoming accidental product semantics.

**Real gap:** a second provider has not yet proven the abstraction.
Until vCenter (the planned second reality) is implemented, the provider
contract remains provisional.

**Development priority:** implement vCenter before freezing provider
contract v1. It is more valuable as an architectural test than adding
another AWS feature.

### Claim H --- "Consumers/UI are replaceable"

**Assessment: Correctly designed; runtime convergence still required.**

ADR-0026 makes the versioned Consumer API the product surface and the
supplied portal a reference client. This is the correct anti-lock-in
model.

**Proof required:**

-   runtime API conforms to published OpenAPI;
-   generated or independent client can perform the supported lifecycle
    without portal-private behavior;
-   portal possesses no privilege unavailable through the contract;
-   breaking behavior requires contract versioning.

### Claim I --- "The platform can produce 20x-ready machine-readable proof"

**Assessment: Direction is strong; this is now the critical development
track.**

ADR-0037 is substantially aligned with the 2026 FedRAMP model:

-   versioned evidence;
-   control claims;
-   evidence hashes;
-   freshness/validity;
-   explicit scope;
-   human ownership/review;
-   exceptions;
-   conservative `unknown` behavior;
-   historical records;
-   assessor/operator/customer projections.

The repository contains evidence schemas, a control-claim schema, a
control registry, evaluator code/tests, collectors, evidence API, and
durable-store infrastructure in the CFN platform track.

This is meaningfully beyond a documentation-only design.

However, 20x requires more than collecting artifacts. The Security
Decision Record model requires providers to explain measures, verify
that the measures demonstrate the KSI, verify the automation, and
validate that the measures are accurately produced and working.
Historical metrics are required at higher classes.

Therefore:

> **A collector is not a control proof. A metric is not a KSI. A KSI is
> not automatically an 800-53 control implementation.**

The evidence plane should model this explicitly.

Recommended chain:

**observation → measure → security invariant/KSI → scoped control claim
→ verification → validation → historical metric**

This is the single most important conceptual refinement for the evidence
implementation.

------------------------------------------------------------------------

## 4. Genuine Remaining Gaps

These are gaps that remain after respecting the POC/target-state
distinction.

### P0 --- Must be resolved before strong production compliance claims

#### 1. Production multi-account authorization boundary is not yet exercised

ADR-0033 correctly identifies a control-plane account plus
member-account target-access role model, but the cross-account runtime
paths and StackSet rollout remain incomplete/deferred.

This is critical because production tenant isolation should not rest
primarily on mutable tags and application filtering.

**Proof of completion:**

-   deterministic target-access role deployed to member accounts;
-   assume-role/fan-out paths implemented for inventory, provisioning,
    cleanup, credential/session operations, and evidence collection as
    applicable;
-   account/OU ownership is authoritative;
-   cross-tenant negative tests;
-   target-account trust policies and permissions are machine-evaluated.

#### 2. Production phishing-resistant identity profile is not yet exercised

The abstraction is correct; the proof is missing.

**Proof of completion:**

-   deploy at least one production-style federated IdP;
-   use a phishing-resistant authenticator;
-   demonstrate normalized assurance;
-   demonstrate policy denial when assurance is insufficient;
-   record assurance in audit/evidence.

#### 3. Evidence plane has not yet been operationally proven in an Organization

The code/contracts exist, but static validity is not operational
evidence.

**Proof of completion:**

-   deploy into a disposable/multi-account Organization;
-   intentionally create compliant and noncompliant states;
-   demonstrate collection freshness;
-   demonstrate stale/missing/tampered evidence → `unknown`/failure;
-   demonstrate tenant-safe projections;
-   generate a reproducible assessor package;
-   verify/validate selected KSI measures independently.

#### 4. Host-activity evidence dependency needs a formal contract

Host logging itself can remain outside the product, but the dependency
must be machine-visible.

Define a target capability/assurance requirement such as:

`privileged_activity_audit = available|unavailable|stale`

and correlate host telemetry with session/request/principal identifiers.

A deployment without the required host telemetry can still use the
access product, but it must not receive an unsupported end-to-end
accountability claim.

### P1 --- High-value development work

#### 5. Prove the provider abstraction with vCenter

A second provider is the best test that AWS/SSM semantics have truly
been contained.

Validate:

-   canonical resource model;
-   capability negotiation;
-   provider-local authorization boundary;
-   attributed ephemeral connection semantics;
-   teardown;
-   evidence mapping;
-   legacy AD compatibility without making AD a core dependency.

#### 6. Prove simultaneous multi-IdP operation

Do not stop at "SAML works."

Test:

-   SAML + OIDC concurrently;
-   same email from different issuers remains distinct;
-   account linking requires explicit policy;
-   group/tenant mapping failure closes access;
-   IdP disablement/deprovisioning propagates;
-   active sessions respond correctly to revocation policy.

#### 7. Complete Consumer API/runtime conformance

The OpenAPI contract should become executable governance:

-   contract tests;
-   generated-client smoke tests;
-   version compatibility checks;
-   no portal-only endpoint/privilege;
-   API audit event coverage.

#### 8. Convert the evidence registry from control labels to defensible measures

Avoid broad claims such as "SSM instances are Online → AC-17 satisfied."

Instead define narrow assertions, for example:

-   target is registered and online;
-   target has no prohibited inbound management rule;
-   authorization was target-specific;
-   credential lifetime ≤ configured maximum;
-   session was terminated within required bound;
-   host audit telemetry is current;
-   privileged identity met required assurance;
-   no cross-tenant access was observed/allowed in negative tests.

Controls and KSIs can then reference combinations of these measures.

------------------------------------------------------------------------

## 5. 800-53 Families Most Directly Supported by the Product

This product should not attempt to claim all Moderate controls. Its
strongest direct contribution is concentrated in a subset.

### AC --- Access Control

**Strong relevance:** AC-2, AC-3, AC-5, AC-6, AC-12, AC-17, AC-20
depending on profile.

The JIT lifecycle, scoped authorization, ephemeral authority, session
termination, and remote-access mediation are directly relevant.

### IA --- Identification and Authentication

**Strong relevance:** IA-2, IA-4, IA-5 and applicable enhancements.

The identity-by-assurance contract is the correct target abstraction.
Production evidence must demonstrate the assurance actually used.

### AU --- Audit and Accountability

**Strong relevance:** AU-2, AU-3, AU-6, AU-8, AU-9, AU-11, AU-12.

The platform owns control-plane/session lifecycle evidence. Host
command/activity evidence is a target integration responsibility that
must be correlated and monitored.

### CA --- Assessment, Authorization, and Monitoring

**Strong relevance:** CA-7.

ADR-0037's persistent evidence lifecycle is directly aligned with
continuous monitoring, provided the measures themselves are verified and
validated.

### CM --- Configuration Management

**Supporting relevance:** CM-2, CM-3, CM-5, CM-6, CM-7, CM-8/related
enhancements depending on deployment.

The strongest product role is proving configuration invariants and
controlling platform changes, not replacing a full endpoint
configuration-management system.

### SC --- System and Communications Protection

**Strong/supporting relevance:** SC-7, SC-8, SC-12/13/17 as applicable,
SC-23, SC-28.

The no-inbound AWS profile and brokered protected management channel are
significant here. Cryptographic/FIPS claims must remain
profile/environment-specific and evidence-backed.

### SI / RA

Security monitoring and vulnerability posture are relevant evidence
inputs, but the access platform should not imply that it replaces
enterprise vulnerability management, EDR, or host security tooling.

------------------------------------------------------------------------

## 6. 20x Alignment

Current FedRAMP 20x is especially favorable to this architecture in four
areas.

### Identity and Access Management

Current KSI language explicitly emphasizes:

-   automated account/role/group lifecycle;
-   passwordless authentication when feasible, otherwise
    phishing-resistant MFA;
-   persistent least-privilege review;
-   role/attribute-based JIT authorization;
-   securing non-user authentication;
-   response to suspicious privileged activity.

The target architecture directly supports these concepts.

### Monitoring, Logging, and Auditing

20x expects maintained/reviewed event definitions, centralized
tamper-resistant logging, and persistent log review.

The platform should therefore distinguish:

-   events it generates itself;
-   inherited AWS events;
-   provider events;
-   required host/customer events.

The evidence plane can then report completeness rather than assuming it.

### Security Decision Record / Persistent Evidence

The 2026 model requires measures to be explained, verified, automation
to be verified, and measures to be validated as working. Higher
certification classes require historical metrics.

ADR-0037 is directionally correct, but development should now focus on
**quality of measures and validation**, not simply number of collectors.

### Trust Center

A future 20x-compatible trust center needs more than a dashboard.
Current FedRAMP rules call for ongoing sharing and documented
programmatic access to certification data.

The project's Consumer API/evidence architecture is a strong foundation.
The trust center should be a projection of the same authoritative
evidence store, not a separately maintained compliance website.

------------------------------------------------------------------------

## 7. The "Human Bias" Proof

A useful first proof for stakeholders is not a control spreadsheet. It
is a functional decomposition of the traditional model.

### Traditional assumption

`AD + VPN + jump host + SSH/RDP = secure administrative access`

### What those components actually supply

-   AD: identity, groups, lifecycle, sometimes device/domain trust.
-   VPN: network path.
-   Jump host: choke point and sometimes audit boundary.
-   SSH/RDP: interactive protocol.
-   SIEM/host audit: activity evidence.

### Replacement

-   IdP(s): identity and assurance.
-   Policy engine: authorization.
-   JIT broker: time/resource-scoped authority.
-   SSM/provider transport: controlled connection without inbound
    reachability.
-   Ephemeral principal/certificate: target-side authority.
-   Lifecycle conductor: authoritative teardown.
-   Evidence plane + host/SIEM integration: accountability and
    continuous proof.

The security question is therefore not:

> "Where is the VPN?"

It is:

> "Which required security property did the VPN supply, and where is
> that property enforced and evidenced now?"

The same question applies to AD and jump hosts.

That is the intellectually honest way to overcome topology bias. Do not
argue that old components are inherently insecure. Demonstrate that
their **security functions have been decomposed, replaced, narrowed, and
made observable**.

------------------------------------------------------------------------

## 8. Recommended Development Order

### Phase 1 --- Freeze the security invariants

Create a compact versioned security-invariant catalog. Each invariant
should include:

-   invariant ID;
-   security statement;
-   product-owned vs inherited/customer-owned responsibility;
-   applicable profile/provider;
-   enforcement point;
-   evidence source(s);
-   freshness;
-   failure semantics;
-   mapped KSI(s);
-   mapped 800-53 controls;
-   verification method;
-   validation method.

Examples:

-   AWS privileged target exposes no prohibited inbound management port.
-   Every privileged request is bound to issuer+subject and tenant.
-   Required authentication assurance is met at authorization time.
-   Authorization is resource-specific and time-bounded.
-   No session receives credentials broader than the approved target.
-   Ephemeral target authority is removed after termination.
-   Teardown failure is visible and never reported as successful
    completion.
-   Required host audit evidence is current for profiles claiming
    command accountability.
-   Cross-tenant access attempts fail before side effects.
-   Evidence older than its validity window cannot satisfy a claim.

### Phase 2 --- Build tests around invariants, not controls

Controls are often too broad to be useful unit-test targets.

Test the narrow security properties, then use the control registry to
show how those verified properties contribute to AC-17, AC-6, AU-12,
etc.

### Phase 3 --- Prove the Organization boundary

Finish ADR-0033 and exercise it.

### Phase 4 --- Prove identity neutrality

Exercise two IdPs simultaneously and at least one phishing-resistant
production profile.

### Phase 5 --- Prove provider neutrality

Implement vCenter and revise/freeze the provider contract based on what
breaks.

### Phase 6 --- Prove the evidence system

Run deliberate fault injection:

-   missing evidence;
-   stale evidence;
-   altered hash;
-   collector failure;
-   cross-tenant evidence reference;
-   insufficient assurance;
-   failed teardown;
-   unauthorized target;
-   missing host telemetry;
-   inherited-control evidence expiry.

The system should produce `unknown`, `not_satisfied`, or an explicit
exception---not a green check.

### Phase 7 --- Project the same truth into the trust center

Only after the evidence lifecycle is authoritative should the
public/authorized trust-center views be built.

------------------------------------------------------------------------

## 9. Claims That Are Safe Now vs Claims to Defer

### Defensible now, with scope

-   The AWS POC demonstrates privileged VM access through SSM without
    inbound SSH/RDP, a VPN, jump host, or customer AD dependency.
-   The target architecture is identity-provider neutral by design.
-   The target architecture represents authentication through assurance
    rather than authenticator vendor.
-   The platform architecture supports multiple provider boundaries and
    provider-specific connection mechanisms.
-   The project has implemented substantial evidence-plane contracts and
    code.
-   The design is aligned with important 800-53 remote-access,
    least-privilege, identity, audit, and continuous-monitoring
    outcomes.
-   The design is strongly aligned with current 20x JIT/least-privilege
    and machine-readable evidence direction.

### Do not claim yet without qualification

-   "Production supports multiple IdPs" --- integration is designed, not
    yet exercised as required by ADR-0038.
-   "Production supports vCenter/Azure/GCP" --- provider abstraction
    exists; implementations are not proven.
-   "The product is FedRAMP compliant" --- authorization/certification
    applies to a defined offering/boundary and requires
    assessment/evidence.
-   "Every privileged command is recorded" --- requires host-side
    telemetry for tunneled SSH/RDP and appropriate target configuration.
-   "Production tenant isolation is proven" ---
    Organization/cross-account target architecture remains to be
    exercised.
-   "Phishing-resistant MFA is implemented by the reference POC" ---
    Cognito+TOTP is the POC implementation; target production assurance
    is different.
-   "20x trust center is complete" --- evidence foundations exist, but
    programmatic certification-data publication and operational
    verification/validation remain.

------------------------------------------------------------------------

## 10. Bottom Line

The project's most important thesis survives rigorous examination:

> **AD, VPNs, jump hosts, and inbound administrative network paths are
> implementation choices, not NIST 800-53 security requirements.**

A system can replace them while remaining consistent with 800-53 if it
demonstrably supplies the security properties they traditionally
contributed.

This project has a credible architecture for doing that.

Its strongest design decisions are:

1.  identity by assurance rather than mechanism;
2.  JIT, target-specific authorization;
3.  brokered ephemeral authority;
4.  no inbound administrative exposure in the AWS/SSM profile;
5.  authoritative lifecycle/teardown;
6.  provider-neutral connection semantics;
7.  explicit authorization boundaries and compliance profiles;
8.  machine-readable evidence with conservative failure semantics;
9.  customer choice without silently lowering the meaning of an
    assurance claim.

The highest-value next work is therefore not adding more UI features or
more broad control labels. It is **turning those architectural claims
into narrow, continuously testable security invariants and proving them
in the production-shaped Organization, multi-IdP, and second-provider
deployments.**

That creates the bridge between the two proofs the project needs:

**Proof 1 --- architectural:** the traditional AD/VPN/jump-host topology
is not required to achieve the security outcomes.

**Proof 2 --- operational:** this particular deployed system
continuously demonstrates that those outcomes remain true.

The first proof changes human understanding.

The second proof is what the 20x evidence plane and trust center should
publish.

------------------------------------------------------------------------

## Primary External Standards Consulted

-   NIST SP 800-53 Rev. 5, Security and Privacy Controls for Information
    Systems and Organizations.
-   FedRAMP Consolidated Rules for 2026 --- Identification and
    Authentication.
-   FedRAMP Consolidated Rules for 2026 --- 20x Identity and Access
    Management Key Security Indicators.
-   FedRAMP Consolidated Rules for 2026 --- Security Decision Record.
-   FedRAMP Consolidated Rules for 2026 --- Certification Data Sharing /
    FedRAMP-Compatible Trust Centers.
-   FedRAMP Consolidated Rules for 2026 --- Independent Verification and
    Validation.

## Repository Material Used

-   ADR-0001 through ADR-0038.
-   `docs/ARCHITECTURE.md`
-   `docs/TARGET-ARCHITECTURE.md`
-   `docs/OPERATOR-RUNBOOK.md`
-   `docs/ONE-PAGER.md`
-   `Claude-proj-audit.md`
-   `ARCHITECTURE-WEAKNESSES.md`
-   `todo.md`
-   platform Consumer API, provider contract, identity/resource/evidence
    schemas, control registry, evaluator/tests, CloudFormation platform
    implementation, CLI/reference implementation, and associated scripts
    supplied for this review.
