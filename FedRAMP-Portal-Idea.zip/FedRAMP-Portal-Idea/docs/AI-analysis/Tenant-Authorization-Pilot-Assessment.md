# Tenant Authorization Pilot Assessment

**Assessment date:** 2026-10-01  
**Scope:** authenticated tenant authorization through access-request creation, provisioning, SSH certificate signing, and SSM credential vending.  
**Primary implementation:** CloudFormation delivery and runtime code in `platform/cfn`, with `cli` and applicable operational scripts as supporting code.  
**Historical context only:** root proof-of-concept Terraform, `platform/modules` Terraform references, and `portal`. These do not determine the primary findings or ratings.  
**Change boundary:** assessment only. No application code, infrastructure, Git state, cloud resources, or external systems were changed.

## Executive assessment

The CloudFormation delivery has a real fail-closed tenant check before a customer request is written or its workflow is started. A non-operator must supply a tenant claim, the target must exist in an allowed region, `CustomerAccess` must equal `true`, and the target's `Customer` tag must match the claim.

That control is not yet a complete replacement for a production privileged-access path. The highest-risk gap is privilege allocation after authorization: every provisioned Linux identity is placed in `sudo` or `wheel`, and every Windows identity is placed in `Administrators`. The workflow carries no role or entitlement to the provisioner. This directly varies from ADR-0011's role-scoped local-principal decision and prevents a supported least-privilege claim.

The next material gaps are operator actions without required justification, inconsistent authorization rules between create and vend, incomplete durable audit wrapping in CloudFormation, and configuration drift that can make inventory-visible regions impossible to connect to. The CloudFormation code also contains cross-account helper seams, but the reviewed request and provisioning path remains single-account in practice. That limitation is already acknowledged by ADR-0033.

This review supports engineering conclusions, not a FedRAMP authorization or a control-effectiveness determination. NIST SP 800-53A requires organization-defined assessment procedures and evidence; deployed behavior, IAM evaluation, CloudTrail/SSM records, negative tests, and operational procedures remain unverified.

## What was validated

Static tracing of the primary CloudFormation and CLI path established this sequence:

1. API Gateway supplies authenticated JWT claims.
2. `create_access_request` calls `authorize_target_instance` before DynamoDB or Step Functions.
3. The workflow invokes `provision_user` with instance, region, access type, username, and user email.
4. `sign_key` or `ssm_credentials` loads the request and applies ownership/operator checks.
5. The CLI requests access and later obtains a certificate or scoped STS credentials.

Python parsing was checked across the handler trees, including the reviewed CloudFormation create, sign, and credential-vend handlers. A synthetic, in-memory probe of the historical POC confirmed expected allow/deny behavior for matching tenant, mismatched tenant, missing tenant, disabled `CustomerAccess` at create, missing target, lookup failure, ownership, status, and expiry. That probe is corroborating context only; it is not evidence that the CloudFormation deployment works. No AWS endpoint was contacted.

## Findings

### F-01 — High — Provisioned identities receive unconditional administrator privilege

**Confirmed behavior.** The CloudFormation provisioner adds every Linux user to `sudo` or `wheel` and every Windows user to `Administrators` (`platform/cfn/control-resources/lambda/provision_user/handler.py`, lines 56-66 and 82-93). The handler input contains no requested role or entitlement (lines 97-105).

**Variation from design.** ADR-0011 requires group membership and sudoers scope to match the portal role. The current implementation cannot make that decision because create/workflow records do not carry a role or privilege profile.

**Control relevance.** This is directly relevant to AC-6 and AC-6(5). AC-6(5) is specifically about restricting privileged accounts to organization-defined personnel or roles; it is not a label for a second tenant-authorization check.

**Required disposition.** Define an explicit entitlement contract, persist the evaluated role with the request, pass it through the workflow, and generate narrow Linux sudoers/Windows group membership. Deny provisioning if the entitlement is missing or unknown. Test both permitted and forbidden commands for every role.

### F-02 — High — Operator access can act on behalf of another user without justification

**Confirmed behavior.** Credential vending and SSH signing allow an `Operators` caller to bypass request ownership. Neither endpoint accepts or enforces a reason or ticket. Credential vending uses the stored owner's provisioned username as `RoleSessionName`, even when an operator is the caller (`ssm_credentials/handler.py`, lines 173-184 and 271-287). SSH signing likewise signs the stored owner's principal for an operator (`sign_key/handler.py`, lines 123-173).

**Variation from design.** ADR-0024 requires a human justification, enforced fail-closed, whenever a principal operates on a resource it does not own. It also requires the audit record to identify who, what, which tenant/target, source, outcome, and reason. The current API models do not provide that information.

**Risk.** CloudTrail may show a role session named after the request owner while application logs identify a different operator. That weakens attribution precisely on the privileged support path.

**Required disposition.** Add an explicit on-behalf-of operation with mandatory reason/ticket, record actor and subject separately, and derive the AWS session identity from the actual operator. Preserve the target OS identity separately if the product intentionally supports impersonating the request owner's local principal.

### F-03 — High — CloudFormation durable audit coverage is not installed on key handlers

**Confirmed defect.** In `platform/cfn/control-resources/lambda/ssm_credentials/handler.py`, the statement intended to wrap the handler with `audited("session.credentials.vend", ...)` is indented after the return at line 322. It is unreachable, and `audited` is not imported. `list_instances/handler.py` has the same unreachable-wrapper pattern at line 152. The create handler installs its wrapper correctly at module scope.

**Impact.** Credential vending emits a structured application log, but it does not use the durable audit-table wrapper described by the documentation. Inventory enumeration lacks the promised wrapper as well. Documentation that says the core vend/inventory paths have durable structured coverage overstates the code.

**Required disposition.** Install the wrapper at module scope, import it, and add a test that imports each deployed handler and asserts that an allowed, denied, failed, and exceptional request produces the required durable event. Audit failure behavior must be an explicit policy decision; the shared wrapper currently logs a durable-write failure but allows the operation to continue.

### F-04 — Medium — Create and vend enforce different tenant-tag rules

**Confirmed behavior.** Creation compares `Customer` case-insensitively and requires `CustomerAccess=true`. Vending queries only the `Customer` tag and compares it case-sensitively (`ssm_credentials/handler.py`, lines 200-230). Therefore:

- a tenant case variation can create a request but later fail to vend credentials;
- changing `CustomerAccess` to `false` after creation does not stop a later vend;
- the “live recheck” is narrower than the original authorization decision.

**Risk.** The first case is an availability defect. The second weakens the expected revocation semantics if `CustomerAccess=false` is intended to disable access immediately.

**Required disposition.** Put target authorization in one shared policy function and invoke it at both create and vend. The vend decision should re-evaluate allowed region, target existence, `CustomerAccess`, tenant match, target account, request ownership, status, and expiry under one normalization rule.

### F-05 — Medium — Region configuration is disconnected from request creation

**Confirmed defect.** CloudFormation declares `TargetRegions` with default `us-east-1` and passes it to `ListInstancesFunction`, but it does not pass `TARGET_REGIONS` to `CreateAccessRequestFunction` (`application.yaml`, lines 25-28, 121-138, and 335-350). The helper consequently falls back to `us-east-2,us-west-1`.

**Impact.** With CloudFormation defaults, an instance can appear in inventory in `us-east-1` and be rejected when the user tries to connect. Conversely, the create handler's implicit regions can differ from the operator-approved deployment list.

**Required disposition.** Make allowed regions one required deployment input and pass it to every inventory, authorization, provisioning, cleanup, and vending component. Remove security-significant defaults from runtime helpers.

### Historical observation — excluded from primary findings — Terraform reference vocabulary

The superseded Terraform reference checks `Operators` during request creation and `Rackers` during credential vending. This is useful provenance showing why those artifacts must remain clearly labeled, but it is not rated as a defect in the current CloudFormation delivery. CloudFormation consistently intends `Operators` in the reviewed path.

**Disposition.** Keep the Terraform tree labeled as historical/reference-only and exclude it from current implementation assurance claims.

### F-06 — Medium — Cross-account target authorization is not end-to-end

**Confirmed limitation.** The CloudFormation shared library contains a `target_client` assume-role helper, and templates expose a target-role name. The reviewed create authorization calls the ambient EC2 client directly. The provisioner also creates an ambient regional SSM client. Request/workflow records do not carry a target account ID. Inventory's parallel call does not supply a target account ID to its helper.

**Documentation status.** This is consistent with ADR-0033's explicit statement that end-to-end multi-account behavior is deferred. Any newer document or diagram presenting member-account access as operational should retain that qualification.

**Risk.** Tenant tags inside one account are the current boundary. They are not equivalent to the hard account/boundary separation described as the production target.

### F-07 — Documentation defect — AC-6(5) is mapped incorrectly

`ARCHITECTURE-WEAKNESSES.md` calls the second create/vend authorization an AC-6(5) “secondary check.” NIST SP 800-53 Rev. 5 defines AC-6(5) as **Privileged Accounts**: restrict privileged accounts to organization-defined personnel or roles. The second check is useful defense in depth and is more naturally evidence for enforcement of authorization and information-flow policy, but it does not close AC-6(5).

This matters because F-01 shows that the actual AC-6(5) concern remains open: all ephemeral OS identities are privileged regardless of portal role.

## Positive controls observed

- JWT authentication is attached to the reviewed API routes.
- Customer creation authorization occurs before the DynamoDB write and Step Functions start.
- Lookup errors, missing targets, missing tenant claims, tag mismatch, and disabled customer access fail closed at creation.
- Request ownership, `ACTIVE` state, and remaining TTL are checked before STS vending.
- STS duration is capped at one hour and denied when less than the 900-second AWS minimum remains, avoiding credentials that outlive the authorization window.
- The STS session policy scopes `StartSession` to one target instance and two named AWS session documents.
- Linux uses identity-derived ephemeral users and short-lived SSH certificates rather than shared passwords.
- The CLI obtains short-lived session material from the broker rather than requiring a user's standing AWS credentials.

These controls are code observations. Their deployed effectiveness was not tested.

## Items requiring deployed verification

The following must remain `unknown` until exercised in an isolated AWS test account:

- effective IAM authorization after identity policies, role policies, session policy, SCPs, permission boundaries, resource policies, and KMS policies are combined;
- whether SSM `TerminateSession`/`ResumeSession` conditions prevent one holder from controlling another session on the same target;
- target-account assume-role trust and confused-deputy resistance;
- API Gateway JWT issuer/audience/group-claim behavior with each intended IdP;
- CloudTrail, SSM, OS, DynamoDB, and application-event correlation for actor, subject, target, tenant, request, reason, and outcome;
- cleanup on normal exit, timeout, Lambda failure, Step Functions failure, and network interruption;
- revocation latency after group removal, tenant reassignment, tag change, account disablement, or `CustomerAccess=false`;
- Windows password storage, display, rotation, and deletion behavior;
- evidence retention, integrity, alert delivery, and reviewer workflow.

## Documentation consistency judgment

The ADRs are generally candid about the product direction and the difference between a POC and a production multi-account design. The 2026-09-29 documentation accurately reports that pre-provision tenant authorization was added. It overstates three areas:

1. AC-6(5) is not closed because provisioned identities still receive blanket administrator privilege.
2. CloudFormation durable audit coverage is not complete for credential vending and inventory due to unreachable wrapper statements.
3. The live vend check is not equivalent to the create check because it omits `CustomerAccess` and uses different case handling.

The older client instructions and `portal` implementation should be labeled POC-only wherever they could be mistaken for the current delivery contract. Portal behavior is not used here to rate the CloudFormation platform.

## Recommended next bounded work package

Before a broad 800-53 assessment, fix and test the authorization kernel as one unit:

1. Define a versioned authorization input containing actor, actor role, actor tenant, target tenant, target account, region, requested access type, requested privilege profile, request owner, source, and justification.
2. Use that decision at create, provision, sign, vend, and terminate.
3. Add a small table-driven test suite covering customer, operator, mismatched tenant, missing claims, disabled target, changed tags, cross-account target, expired request, on-behalf-of reason, and each privilege profile.
4. Emit one schema-validated audit event for every allow, deny, and failure.
5. Run the vectors against the CloudFormation handlers and CLI contract. Use POC/reference behavior only when provenance helps explain an intentional port.

This is the most cost-efficient next step because it tests the security boundary directly. A full control-by-control narrative review before these defects are resolved would spend effort documenting behavior already known to vary from the ADRs.

## Authoritative references

- NIST SP 800-53 Rev. 5, including Release 5.2.0: https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final
- NIST SP 800-53A Rev. 5 assessment procedures: https://csrc.nist.gov/pubs/sp/800/53/a/r5/final
- Local governing records: ADR-0011, ADR-0021, ADR-0024, ADR-0025, ADR-0026, ADR-0033, ADR-0036, and ADR-0037 in `.kiro/steering/`.

## Cost and scope record

This pilot intentionally stopped after one vertical security path. It did not perform a repository-wide control mapping of all `platform`, `cli`, and `scripts` behavior. Deployment-oriented scripts were not executed because they would require live AWS state; `portal` and Terraform were treated as POC/reference context. The pilot did not build artifacts, install dependencies, invoke AWS, create paid resources, modify application code, or use Git. The only workspace artifact created is this report.
