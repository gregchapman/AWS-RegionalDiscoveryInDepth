# RGS FedRAMP Portal — Credential-less, 800-53-Compliant Access to Customer EC2

## The claim

We built an **800-53-compliant access method for customer EC2 resources
(Linux and Windows)** that **eliminates** the traditional access stack:

- ❌ **Jumphost** — no bastion to stand up, patch, or expose
- ❌ **Customer jumphost (custjumphost)** — no per-customer bastion sprawl
- ❌ **Active Directory** — no directory deployed into each customer account
  purely to be an identity source
- ❌ **VPN** — no network tunnel appliance or client

…while **preserving every control that stack was there to provide.** Access is
brokered by the portal over AWS Systems Manager (SSM) with short-lived,
instance-scoped credentials the user never has to hold.

This is an evolutionary POC of Rackspace prior art based on Janus and PassportV2.

## What the old model cost (and why it's an antique)

The legacy pattern deploys AD into every customer account mainly to be an
identity source, joins each VM (Windows or Linux/SSSD) to that domain, and
gates access behind VPN + jumphosts. It carries a heavy recurring monthly cost,
demands ongoing patching of the bastion/AD/VPN tier, and effectively limits the
offering to EC2. It also runs against the FedRAMP 20x direction. The portal
abstracts all of that infrastructure away and replaces it with a cloud-native,
serverless, in-boundary control plane that can be adapted for use across multiple cloud providers including 'private cloud' environments.

## How the controls are preserved (nothing is given up)

| Control objective | How the portal delivers it | 800-53 |
|---|---|---|
| **Access control** | Cognito authN + group-based authZ (Rackers vs Customers); every `/api/*` behind a JWT (JSON Web Token) authorizer; connect re-checks status + ownership | AC-3, AC-6 |
| **Audit trails** | CloudTrail (multi-region, log-file-validated, 365-day retain) + SSM Session logging (S3 + CloudWatch) + API/Lambda/Step Functions logs | AU-2, AU-3, AU-9, AU-12 |
| **Identity provenance** | Ephemeral OS users are **identity-named** (e.g. `greg-racker-6428`) and attributed in OS logs, SSM session IDs, and CloudTrail via the STS `RoleSessionName` | AC-2, AU-3, IA-4 |
| **Customer isolation** | `custom:customer_id` claim enforced fail-closed at list time **and** re-validated against the instance's live `Customer` tag at connect (independent second check); Customer 1 can never see/reach Customer 2 | AC-3, AC-6(5) |
| **MFA** | Cognito MFA is **required**; the CLI performs its own SRP (Secure Remote Password protocol) + TOTP (Time bsed One TIme Password) login (no handed-over token to replay) | IA-2, IA-2(1) |
| **Least privilege** | Vended STS creds are scoped by an inline session policy to **one instance**, **only** the port-forward / SSH documents, for **≤1 hour** | AC-6, AC-6(1) |
| **Temporary, short-lived credentials** | SSH certificate ≤1h; vended STS creds ≤1h (role-chaining ceiling); Windows password per-session; authorization window auto-expires (poll-loop = authoritative termination) | AC-12, IA-5 |
| **No inbound / minimized attack surface** | Instances have **zero inbound ports**; all traffic is SSM outbound over the AWS backbone via VPC endpoints; no bastion, no VPN, no public RDP/SSH | SC-7, AC-17 |

## AWS components and the value each contributes

**Front door (in-boundary, CONUS)**
- **Route 53 + ACM + API Gateway (HTTP API v2)** — one
  same-origin front door serving both the SPA (Single Page Application) and the API. TLS 1.2,
  API Gateway request throttling, no commercial global edge (IL4-safe). (An
  edge WAF requires an ALB/REST-v1 tier — tracked SC-7 remediation.)

**Identity**
- **Cognito User Pool** — the identity source that replaces AD. MFA required;
  `Rackers`/`Customers` groups + `custom:customer_id` drive authorization.
- **Pre-Token-Generation Lambda** — injects `email` into the access token so
  every downstream action attributes to a real person.

**Control plane (serverless)**
- **API Lambdas** (Python) — `serve_spa`, `list_accounts`, `list_instances`,
  `create_access_request`, `get_session_status`, `list_sessions`,
  `terminate_session`: the request/visibility/lifecycle surface.
- **sign_key Lambda (SSH Certificate Authority)** — issues a short-lived,
  identity-bound SSH user certificate: passwordless Linux login, no stored
  secret. Replaces AD/SSSD as the Linux authenticator.
- **ssm_credentials Lambda + session-broker role** — vends the scoped, ≤1h STS
  credentials for the SSM tunnel. This is what makes access **credential-less**:
  the user holds no AWS keys.
- **Step Functions (access lifecycle)** — provisions the ephemeral user, then
  **polls for an end demand or TTL** and cleans up. Termination is
  authoritative (no orphaned access).
- **provision_user / cleanup_user Lambdas** — create/remove the identity-named
  ephemeral OS user on the target (region-aware).

**State, secrets, hosting**
- **DynamoDB** — access-request state, TTL, and per-user index.
- **KMS CMKs** — encrypt credentials, the CA key, and all S3 (SSE-KMS).
- **Secrets Manager + SSM Parameter Store** — hold the SSH CA private key
  (secret) and public key (trusted by instances).
- **S3 (private)** — hosts the SPA and the checksum-verified CLI release
  artifacts (download-verify-install).

**Transport & targets**
- **AWS Systems Manager (SSM)** — the access channel. `StartSession`
  (port-forward) and `RunCommand`. Zero inbound; AWS backbone. Replaces the
  jumphost + VPN.
- **VPC endpoints (ssm, ssmmessages, ec2messages)** — keep SSM traffic private.
- **Customer EC2 (Linux + Windows)** — SSM Agent, IMDSv2, encrypted EBS, **no
  inbound ports**, tagged per customer for isolation. On Windows, Fleet Manager
  (DCV) is the AWS-native, directory-less admin path (roadmap).

**Audit & continuous monitoring**
- **CloudTrail, SSM Session logging, GuardDuty, Security Hub (NIST 800-53),
  AWS Config** — the evidence and detection layer.

**Client**
- **`passport` CLI (Go)** — cross-platform, checksum-distributed. Authenticates
  the user (Cognito + MFA), then brokers SSH (shell) or RDP (tunnel + native
  client) — no AWS credentials, no VPN, no directory on the endpoint.

## The one-line summary

Portal login **is** the authentication; the portal then **vends** scoped,
short-lived, per-session authorization over SSM — so we get jumphost/VPN/AD-grade
control, audit, isolation, and least privilege **without** the jumphost, the
custjumphost, the Active Directory, or the VPN.

---
*Diagram: `docs/fedramp-portal-architecture.drawio` (import into diagrams.net /
draw.io). Depth: ADRs in `.kiro/steering/`, gaps in `ARCHITECTURE-WEAKNESSES.md`.*
