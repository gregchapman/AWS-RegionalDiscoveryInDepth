# FedRAMP Portal — Operator Runbook: User Lifecycle (AC-2)

Operator procedures for the three distinct account-management events. Each is a
separate use case with different completeness requirements (AC-2 Account
Management, AC-2(1) automated support, IA-4 identifier management).

**Who runs these:** a portal operator/admin with `AWS_PROFILE` set for the
portal account (SoD, ADR-0018 — these are DEPLOY-context actions).

**Key facts that shape every procedure below:**
- A portal user is a **Cognito user pool user** (pool `us-east-1_Ud7Zxuvw0`,
  region `us-east-1`). Authorization comes from **group membership**
  (`Rackers` = multi-tenant; `Customers` = single-tenant) and, for Customers,
  the **`custom:customer_id`** attribute, which must match the target
  instances' `Customer` tag (AC-6(5) tenant isolation).
- This is the frozen POC procedure. The target platform is AD-optional and
  provider-neutral: Cognito is the current reference provider, while future
  deployments may configure multiple SAML/OIDC providers under ADR-0038. AWS
  SSM access does not require customer AD join or trust; any AD-compatible path
  is a provider-specific transitional mode.
- **Revocation latency (document this for auditors):** disabling a user
  immediately blocks new logins and revokes refresh tokens, BUT an **already-
  issued access token stays valid until it expires (≤1h)** because our API
  Gateway JWT authorizer validates signature+expiry locally and does not call
  Cognito for revocation status. Therefore revocation is NOT complete until you
  ALSO hard-kill the user's active sessions (below). The ≤1h token residual is
  the known bearer-token limitation (IA-2/SC-23, ARCHITECTURE-WEAKNESSES §2);
  DPoP/short-TTL is the future close.
- **Active sessions must be hard-revoked** in both the revoke and delete cases.
  "Hard-kill" = terminate the SSM session AND remove the ephemeral OS user on
  the instance (this is what drops a live RDP/SSH connection — the same action
  the portal's "End Session Now" button performs). Blocking the account alone
  does NOT drop a session already in progress.

Set these once per operator shell:
```bash
export AWS_PROFILE=personal-faws
POOL=us-east-1_Ud7Zxuvw0
REGION=us-east-1
TABLE=fedramp-portal-access-requests
AWS=/home/greg/.local/bin/aws   # avoids the venv CRT bug
```

---

## 1. ONBOARD a new user

Four parts. Parts 1-3 are operator actions; part 4 is the user's first login
(the CLI cannot do first-login MFA enrollment — it must happen in the browser).

### 1a. Create the Cognito user
```bash
$AWS cognito-idp admin-create-user --user-pool-id $POOL --region $REGION \
  --username <username> \
  --user-attributes Name=email,Value=<email> Name=email_verified,Value=true \
  --temporary-password 'FedRAMP-Test-2026!' --message-action SUPPRESS
```

### 1b. Assign the authorization group (REQUIRED — no group = no access)
```bash
# Racker (multi-tenant operator):
$AWS cognito-idp admin-add-user-to-group --user-pool-id $POOL --region $REGION \
  --username <username> --group-name Rackers
# — OR — Customer (single-tenant):
$AWS cognito-idp admin-add-user-to-group --user-pool-id $POOL --region $REGION \
  --username <username> --group-name Customers
```

### 1c. Set tenant scope — CUSTOMERS ONLY (must match instance `Customer` tag)
```bash
$AWS cognito-idp admin-update-user-attributes --user-pool-id $POOL --region $REGION \
  --username <username> \
  --user-attributes Name=custom:customer_id,Value=<customer1|customer2|...>
```
Rackers skip this (tenant-exempt). A wrong/missing `customer_id` on a Customer
means their connects will be DENIED (403) at the vend endpoint by design.

### 1d. First login (the USER does this, in a BROWSER — one time)
The account starts in `FORCE_CHANGE_PASSWORD` and is not MFA-enrolled. The
`passport` CLI's SRP flow can only answer an existing MFA challenge; it cannot
run the first-login ceremony. So the user must:
1. Log in at **https://portal.takahe.click** with the temp password.
2. Set a permanent password (12+ chars, upper+lower+number+symbol).
3. Enroll TOTP MFA (scan the QR with an authenticator app).

After that, both the portal and `passport connect` work for the user.

> The `scripts/create-test-users.sh` script does 1a-1c idempotently for the
> standard test accounts; add a `create_user` line and re-run to batch-add.

---

## 2. REVOKE a user's privileges (keep the account, cut access NOW)

Use when access must stop but the identity is retained (suspension, role change,
investigation). Order matters: **kill active sessions FIRST**, then block the
account, so there's no window where they re-establish a session during the
change.

### 2a. Hard-kill ALL of the user's active sessions
Find the user's Cognito `sub` (this is the `user_id` on session records):
```bash
SUB=$($AWS cognito-idp admin-get-user --user-pool-id $POOL --region $REGION \
  --username <username> --query 'UserAttributes[?Name==`sub`].Value' --output text)
```
List their live sessions (statuses that mean a tunnel/user may exist), via the
`user-index` GSI:
```bash
$AWS dynamodb query --table-name $TABLE --region $REGION \
  --index-name user-index \
  --key-condition-expression 'user_id = :u' \
  --expression-attribute-values "{\":u\":{\"S\":\"$SUB\"}}" \
  --query 'Items[?status.S==`ACTIVE` || status.S==`PROVISIONING`].[request_id.S,instance_id.S,region.S,status.S]' \
  --output table
```
Terminate EACH active request. As an operator you are a Racker, so the portal's
terminate endpoint will act on another user's session (Rackers are exempt from
the ownership check). Two ways:

- **Preferred (uses the built teardown):** call the terminate endpoint for each
  request_id with an operator (Racker) token — this runs the SSM cleanup
  (removes the ephemeral OS user, logs off the Windows/Linux session = drops the
  live RDP/SSH) AND stops the Step Function:
  ```bash
  curl -s -X POST -H "Authorization: Bearer <operator-racker-access-token>" \
    https://portal.takahe.click/api/session/<request_id>/terminate
  ```
- **Direct (break-glass, if the API is unavailable):** run the same teardown by
  hand — terminate the SSM session and remove the OS user:
  ```bash
  # find + terminate the SSM session on the instance:
  $AWS ssm describe-sessions --state Active --region <inst-region> \
    --query "Sessions[?Target=='<instance_id>'].SessionId" --output text
  $AWS ssm terminate-session --session-id <session-id> --region <inst-region>
  # remove the ephemeral OS user (Linux example; use AWS-RunPowerShellScript + Remove-LocalUser for Windows):
  $AWS ssm send-command --instance-ids <instance_id> --region <inst-region> \
    --document-name AWS-RunShellScript \
    --parameters 'commands=["pkill -u <prov-username> || true; userdel -r <prov-username> || true"]'
  ```

### 2b. Block the account + revoke tokens
```bash
$AWS cognito-idp admin-disable-user --user-pool-id $POOL --region $REGION \
  --username <username>
```
`admin-disable-user` deactivates the profile and revokes access tokens; the user
can't sign in. (Optionally also `admin-user-global-sign-out` to invalidate
refresh tokens explicitly — `admin-disable-user` already covers the sign-in
block.)

### 2c. (Optional, tighter) remove group membership
Belt-and-suspenders so that even if re-enabled later, access isn't automatic:
```bash
$AWS cognito-idp admin-remove-user-from-group --user-pool-id $POOL --region $REGION \
  --username <username> --group-name <Rackers|Customers>
```

### 2d. Residual to note
Any access token minted in the last hour remains cryptographically valid until
expiry (~1h) — but with sessions killed (2a) and the account disabled (2b),
there is nothing new to establish and no active session to use. The residual is
the ability to call a read API (e.g. list instances) for ≤1h; it cannot open a
NEW connection because provisioning + vend both re-check status/authorization.
Record the revocation time in your ticket; the token residual window is ≤1h.

### Re-enable (reverse of revoke)
```bash
$AWS cognito-idp admin-enable-user --user-pool-id $POOL --region $REGION --username <username>
# re-add group if you removed it in 2c.
```

---

## 3. DELETE a user entirely (remove the identity)

Use when the identity should no longer exist (offboarding, deprovisioning). This
is destructive and not reversible — the `sub` and username are gone. Do the
hard-kill FIRST (same as revoke), because once the user is deleted you lose the
easy `sub`→sessions lookup.

### 3a. Hard-kill all active sessions
Run **step 2a** in full first. Capture the user's `sub` and terminate every
ACTIVE/PROVISIONING request before deleting (below), so no tunnel is left
orphaned with the identity record gone.

### 3b. Delete the Cognito user
```bash
$AWS cognito-idp admin-delete-user --user-pool-id $POOL --region $REGION \
  --username <username>
```
This removes the profile and revokes tokens. The user disappears from
`list-users`.

### 3c. Clean up their access-request records (optional, hygiene/audit)
Session records are TTL'd (they expire on their own) and are retained for audit,
so deletion is NOT required for security. If you must purge for a
right-to-be-forgotten style request, delete each item by its full key
(`request_id` + `created_at`) — but weigh this against audit-retention needs
(AU-11) first; usually LEAVE them.

### 3d. Residual
Same ≤1h token residual as revoke (§2d). Sessions are already killed (3a), so
there is no active access; only the ≤1h read-API token window remains, and the
identity no longer exists to re-authenticate.

---

## Quick reference

| Goal | Cognito action | Active sessions | New logins | Reversible |
|------|----------------|-----------------|------------|------------|
| Onboard | `admin-create-user` + group (+ customer_id) + user's first-login MFA | n/a | enabled after 1d | — |
| Revoke | `admin-disable-user` | **hard-kill (2a) — REQUIRED** | blocked immediately | yes (`admin-enable-user`) |
| Delete | `admin-delete-user` | **hard-kill (3a) — REQUIRED** | blocked (identity gone) | no |

In all revoke/delete cases: **kill active sessions first, then block/delete the
account.** Blocking alone does not drop a session already in progress — that is
the whole reason the hard-kill step exists.
