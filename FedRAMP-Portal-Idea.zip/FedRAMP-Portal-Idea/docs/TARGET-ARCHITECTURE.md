# Target Architecture — Contract-First Access Platform

> **Status: ASPIRATIONAL / target-state. NOT current implementation.**
> This document describes where the product is going, not what is deployed
> today. The current, factual as-built architecture is `docs/ARCHITECTURE.md`;
> the honest gap register is `ARCHITECTURE-WEAKNESSES.md`; per-control status is
> `docs/ARCHITECTURE.md` §8. This file is the north star that keeps near-term
> decisions from constraining the strategy. It is cross-referenced to the ADR
> cluster (0026–0031) that formalizes each decision.

## 1. Why this document exists

The POC proved a specific, valuable thing on AWS: **credential-less, zero-inbound,
ephemeral-identity, attributed, verifiably-terminated privileged access** to a
target host, brokered by an identity-authenticated (MFA) control plane. That is
the mechanism. The strategy is to turn that mechanism into a **platform** that:

- **Cheapens, strengthens, and modernizes** the way privileged access is granted
  across diverse estates — replacing the AD + VPN + jump-host model (ADR-0021)
  not just on AWS but on the **vCenter** estate that is today's revenue base
  (currently GlobalProtect VPN + Swissbit/RSA tokens + customer jump hosts +
  a customer-AD-to-RGS-AD trust).
- **Integrates across public and private clouds** — AWS, vCenter, later Azure /
  GCP — through one consumer experience.
- **Holds an 800-53 ATO** (FedRAMP Moderate, target IL4 in GovCloud) for the AWS
  plane, while **opening an 800-171 market** across AWS / Azure / vCenter.
- Lets the **consumer model vary** — the RGS portal, a customer's own front end,
  a mobile client, a ServiceNow integration, an auditor's evidence puller — all
  against the same platform, because the platform's surface is a **published
  contract**, not a bespoke UI.

The single most important design commitment: **decide the boundaries now, deliver
the capabilities later.** The capabilities are a multi-phase roadmap; the
boundaries (the contracts) are cheap to shape correctly now and ruinously
expensive to retrofit once AWS-only assumptions harden into the code.

## 1a. What is GOLD (fixed) vs. what is the CUSTOMER'S (replaceable)

The platform's value is a **compliance-graded access capability** — the Passport
V2 gold. Some things are the gold and are deliberately NOT replaceable; some are
the compliance floor and are always inherited; the rest is the customer's to own.
Three classes, and the distinction governs the whole module design:

### Class 1 — INVARIANT CORE (the gold; NO swap seam exists)
These make the guarantee real. There is deliberately no configuration that
replaces or routes around them.
- **SSM Session Manager is THE access path — period.** No bastions, no VPN
  endpoints, not as an option or a fallback. Their ABSENCE is the security
  posture (zero inbound, no standing network path — ADR-0006). Offering them
  back would be selling the disease we cure. (SSH vs. RDP is target-OS-dependent,
  but always INSIDE the SSM-brokered path.)
- **The orchestration / choreography engine** — the Step Functions conductor
  (ADR-0023), the Lambdas, the KMS keys, the DynamoDB "score," and the
  verified-teardown / attribution (ADR-0024) / tenant-isolation (ADR-0021) logic.
  This is how the gold becomes operable and gradable. Not pluggable.
- **The provider `connect` is an SSM-equivalent brokered path**, always. When
  vCenter/Azure providers arrive, their `connect` must be a brokered, attributed,
  verifiably-terminable path — NOT "reopen the jump host." We are REPLACING the
  AD+VPN+jumphost model, not accommodating it.

### Class 2 — COMPLIANCE BASELINE (required, inherited, graded; not opt-out)
The security/audit floor composed into EVERY deployment profile
(`modules/_baseline/`): the attributed C2 plane, audit/evidence, encryption,
zero-inbound posture, tenant-isolation invariants. Always on; graded against the
benchmark below.

### Class 3 — CUSTOMER-OWNED (replaceable behind contracts; anti-lock-in)
The customer owns their business, not a vendor's licensing terms. Swappable
WITHOUT touching Class 1 or weakening Class 2:
- Branding / SPA appearance / the entire front end (reference client — ADR-0026)
- Identity source / IdP (behind the identity assertion — ADR-0028)
- MFA mechanism (TOTP / FIDO / a contracted MFA vendor / on-prem AD) — expressed
  as required ASSURANCE, satisfied by the chosen IdP (ADR-0028)
- Domain, portal DNS names, TLS cert (create-vs-consume)
- Region scope, and OU/org-root targeting (StackSets-style — production evolution
  of account/instance discovery)

**The bright line (enforced by the contracts):** no customization may route access
around SSM Session Manager or bypass the orchestration/compliance core. The
Provider contract's `connect` (ADR-0027) has no "via bastion/VPN" configuration.

**Why the three-class accounting is exhaustive and code-traceable.** This
satisfy / inherit / customer-controls breakdown is kept deliberately complete and
cross-referenced to the actual code and ADRs so the inheritance boundary is
UNAMBIGUOUS and INDEPENDENTLY AUDITABLE. Any question of "who is responsible for
control X" resolves to a specific, evidenced answer — we satisfy it (here is the
mechanism and the §8 row), you inherit it (here is the baseline module and the
inheritance manifest), or you solely control it and we deliberately never
influence it (identity, branding, MFA, domain — we have no reach into them by
design, which is itself a posture strength). The boundary is a matter of record,
not assertion.

## 1b. The benchmark — 800-53 as the umbrella over adjacent regimes

The core is graded against **NIST 800-53** as the primary benchmark, chosen
deliberately because it is the broadest umbrella: the adjacent regimes an adopter
may face — **IRS-1075, PCI-DSS, HIPAA, PII/privacy, FedRAMP/FTS** — are largely
concerned with **data tampering / theft / misuse and identity**, which 800-53
already covers. So building to 800-53 (Moderate, target IL4) subsumes the common
control concerns of the others; per-regime profiles (ADR-0029) then add or map
the regime-specific deltas.

> HONESTY NOTE: we grade the core AGAINST these regimes and map to them; we do NOT
> claim certified conformance to IRS-1075 / PCI / HIPAA. Those mappings must be
> validated by an owner of each framework. The claim is "built to the 800-53
> umbrella that subsumes their common concerns," not "certified under each."

## 2. The shape: one core, many boundaries, many profiles

```
                        Replaceable CONSUMERS
      RGS portal │ customer portal │ mobile │ ServiceNow │ auditor tool
                              │
                     ┌────────▼────────┐
                     │  Consumer API   │   (1) published contract, versioned
                     └────────┬────────┘
                              │
            ┌─────────────────┼─────────────────┐
            │                 │                 │
     ┌──────▼──────┐   ┌──────▼──────┐   ┌──────▼───────┐
     │  IDENTITY   │   │  CONTROL /  │   │    AUDIT /   │
     │   plane     │   │  WORKFLOW   │   │   EVIDENCE   │
     │ (3) assert. │   │   (core)    │   │    plane     │
     └──────┬──────┘   └──────┬──────┘   └──────────────┘
            │                 │
   Cognito│RGS-IdP│SAML│  Provider contract (4)
   OIDC│CAC-PIV│Swissbit      │
   │(assurance, not     ┌─────┴───────┬──────────┬──────────┐
   │ mechanism)         ▼             ▼          ▼          ▼
                      AWS          vCenter      Azure       GCP
                    (own ATO      (own ATO,   (own ATO)  (own ATO)
                     boundary)    revenue)
                        │
                 canonical Resource + Capability model (2)
```

- **The CORE** (Consumer API + identity plane + control/workflow + audit plane)
  is shared and is the thing we build once.
- **Each PROVIDER** (AWS, vCenter, Azure, GCP) sits in **its own authorization
  boundary with its own authorization package**, and connects to the core only
  through the Provider contract — a controlled, audited interface, never a shared
  network. The existing vCenter ATO stays intact; the AWS IL4 boundary is not
  contaminated by a reach into Azure/GCP.
- **COMPLIANCE PROFILES** (800-53 Moderate, IL4, 800-171) are *configuration of
  which controls apply and which partition/services are in scope* — **not** forks
  of the codebase.

## 3. The four contracts (the product surface)

Everything that varies for the business — front end, IdP, MFA type, target cloud
— is an **implementation behind one of these four contracts**. Nail these and
the variations become configuration + new implementations, not re-architecture.

### 3.1 Consumer / Portal API — *the keystone*
A versioned, published **OpenAPI** spec. Any consumer (RGS UI, customer UI,
mobile, ServiceNow, auditor tool) is a **client** of it. The RGS portal is a
**reference client, not a privileged component**: it must hold no API privilege a
third-party consumer could not also obtain. (Draft against the current endpoints:
`api/openapi/consumer-api.v1.yaml` — see §5.)

### 3.2 Canonical Resource + Capability model
Every managed thing is expressed as
`{ id, provider, provider_resource_id, resource_type, name, tenant, location,
state, capabilities: [...] }`. The consumer renders and acts from the
**capability list** (`start`, `stop`, `console`, `connect`, `metrics`, `cost`,
`compliance`, ...), never from provider-specific semantics. A vCenter VM, an EC2
instance, and an Azure VM all emit this same shape. (Schema:
`api/schemas/resource.schema.json`.)

### 3.3 Identity assertion — *assurance, not mechanism*
The platform consumes a normalized assertion:
`{ subject, issuer, tenant, authn_method, authn_assurance, mfa, groups,
session_id }`. **How** the subject authenticated — Cognito+TOTP, RGS-IdP+Swissbit,
customer SAML/OIDC, CAC/PIV, or (transitionally) an AD trust — is an
implementation below the contract. The platform authorizes on **assurance level
and attribution**, not on the mechanism. This is what makes "not married to
Cognito" real and lets the vCenter estate keep its AD trust *initially* while
migrating credential-less behind the same contract. (Schema:
`api/schemas/identity-assertion.schema.json`.)

### 3.4 Provider — *connection is provider-defined*
`List / Get / Start / Stop / Resize / Connect / GetCompliance / GetCost /
GetAuditEvents`. Crucially, **"connect" is abstract** — "establish an attributed,
brokered ephemeral session to this resource" — and each provider satisfies it its
own way: AWS via the SSM tunnel; vCenter via its own broker; Azure via
Bastion/Arc. **Nothing SSM-shaped may leak into the contract.** (Interface spec:
`api/schemas/provider-contract.md`.)

## 4. The boundary decisions (decide now — they prevent self-imposed traps)

| # | Decision | Trap it avoids | ADR |
|---|----------|----------------|-----|
| B1 | **Transport is abstract** in the Provider contract ("brokered ephemeral session," not "SSM tunnel"). | AWS/SSM becoming *the* transport — vCenter/Azure have no SSM. | 0027 |
| B2 | **Identity by assurance, not mechanism.** | Hard-coding "no directory" (breaks vCenter's AD reality) OR "AD trust" (drags AD into the clean AWS boundary). Lets vCenter keep AD trust initially, migrate behind the contract. | 0028 |
| B3 | **One core, many authorization boundaries, many compliance profiles.** Each provider in its own boundary/ATO; 800-53 Moderate / IL4 / 800-171 as profiles. | Entangling ATO boundaries; a reach into Azure/GCP contaminating the AWS IL4 boundary; forking commercial-vs-fedramp codebases. | 0029 |
| B4 | **Async by default** — every state-changing action is `202 Accepted` + `/jobs/{id}` (+ future events). | AWS-speed synchronous assumptions breaking on slower vCenter/Azure operations. | 0026 |
| B5 | **Portal is a reference client, not privileged.** | Private backdoors accreting between the RGS UI and the backend; the UI staying in the ATO control scope unnecessarily. | 0026 |

## 5. Phased delivery (build the boundaries now; deliver capabilities later)

> **Phase 1's contracts MUST be shaped knowing Phases 3–4 exist.** That is the
> entire point of deciding the boundaries now.

- **Phase 0 — current POC.** AWS/SSM + Cognito + one provider + one consumer.
  Job now: make the *boundaries* contract-shaped, not the *capabilities* complete.
- **Phase 1 — contract extraction (cheap, high-leverage).** Publish the four
  contracts as versioned specs; refactor the *current AWS implementation* to sit
  cleanly behind them. No new providers, no new IdPs — prove the AWS path works
  *through* the contracts. De-risks everything downstream; mostly formalizes what
  already exists.
- **Phase 2 — identity optionality.** Add a second `IdentityProvider` (RGS or a
  customer SAML/OIDC) behind the identity contract; add Swissbit/FIDO2 as an MFA
  assurance behind the same contract.
- **Phase 3 — the revenue play (vCenter provider).** Implement the vCenter
  Provider behind the contract, *initially* leaning on the existing AD-trust auth
  (don't break what pays), in its own boundary. Modernize vCenter access
  incrementally.
- **Phase 4 — market expansion.** Azure / GCP providers; the 800-171 compliance
  profile; the Security-Hub-as-one-source evidence/compliance plane.

## Cross-cutting build-now requirement — Evidence and Assurance Plane (ADR-0037)

This is not deferred to the later multi-cloud phase. Before broader enterprise
publishing, the core must establish versioned evidence and control-claim
schemas, scoped responsibility/inheritance, freshness, provenance, human review,
exception expiry, integrity-protected exports, and backed `audit`/`compliance`
behavior. Providers and profiles may add evidence sources, but may not bypass
the core claim and evidence lifecycle. The primary control alignment is CA-7
Continuous Monitoring, supported by AU-6, AU-12, CA-2, AU-9, CM-6, RA-5, and
SI-4. See ADR-0037 and `platform/contracts/schemas/evidence-model.md`.

## 6. Discipline — provisional until a second implementation proves it

Draft the contracts now, shaped to accommodate vCenter and 800-171, but treat
**v1 as PROVISIONAL**. Freeze only after a **second real implementation** (the
first actual vCenter provider) has pressure-tested them. Design for it now;
expect the first real vCenter implementation to refine it. Do not abstract on
pure speculation beyond what these two known realities (vCenter, 800-171) require.
Realistically, vCenter exposure arrives only after a stakeholder sees the POC and
asks "when can we have it?" — so these strategy docs double as the pitch that
triggers that moment.

## 7. Relationship to existing ADRs (reconcile, do not silently override)

- **ADR-0016** (provider/adapter interfaces) is the seed of contracts 3.3/3.4,
  but today it is only a Go interface in the CLI; the target extends it into
  server-side subsystems — a materially larger build. Stated honestly, not
  implied as done.
- **ADR-0009** (cross-layer deps via `terraform_remote_state`) is challenged by
  the "publish config via SSM/manifest" idea. Likely resolution: a **hybrid** —
  remote-state for stable lower layers (foundation → identity → security),
  published-contract only at seams needing independent lifecycle (provider
  adapters, portal). Decided explicitly in ADR-0030, not silently.
- **ADR-0011** (govern the local principal, no directory) collides with any
  smart-card/AD-dependent passwordless-RDP path; the identity-by-assurance
  contract (0028) is how both coexist (AD is one mechanism below the assertion).
- **ADR-0017 / 0019** (portability by config; partition intersection; no
  commercial/fedramp fork) are *reinforced* by B3 — profiles, not forks.
- The Terraform reorg to `modules/` + `live/<profile>/<NN-layer>/` is the right
  destination but a disruptive move; do it at the POC→production transition,
  after the ADRs, not mid-POC.

## 8. ADR cluster index

| ADR | Title | Covers |
|-----|-------|--------|
| 0026 | Contract-first platform; portal is a reference client | 3.1, B4, B5 |
| 0027 | Provider abstraction; connection is provider-defined; per-provider boundary | 3.2, 3.4, B1 |
| 0028 | Identity by assurance, not mechanism | 3.3, B2 |
| 0029 | One core, many authorization boundaries + compliance profiles | B3 |
| 0030 | Layer coupling: remote-state vs. published contract (reconciles ADR-0009) | §7 |
| 0031 | Phased capability delivery | §5, §6 |
| 0037 | Evidence and assurance plane; scoped claims, freshness, provenance, human review | CA-7 primary; AU-6/AU-12/CA-2/AU-9/CM-6/RA-5/SI-4 supporting |
| 0038 | Multi-IdP federation and AD-optional operation | IA-2/IA-4/IA-5/AC-2/AC-3/AC-6/AU-2/CA-7 |

## 9. Next concrete steps

Deploy and exercise the evidence plane in a disposable AWS Organization; then
implement one SAML and one OIDC provider behind the identity assertion and
pressure-test the contracts with a second provider implementation. The current
OpenAPI and machine-readable evidence/claim schemas are authored and
provisional, not deployment-proven.
