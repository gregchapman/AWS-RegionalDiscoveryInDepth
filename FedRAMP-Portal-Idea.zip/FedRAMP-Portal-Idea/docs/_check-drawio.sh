#!/usr/bin/env bash
set -euo pipefail
F=/mnt/c/RGS-Code/FedRAMP-Portal-Idea/docs/fedramp-portal-architecture.drawio
echo "== raw < or > inside value=\"...\" (should be NONE) =="
grep -nE 'value="[^"]*[<>]' "$F" || echo "NONE"
echo "== full XML well-formedness (definitive) =="
python3 -c "import xml.dom.minidom,sys; xml.dom.minidom.parse('$F'); print('XML_OK')"
