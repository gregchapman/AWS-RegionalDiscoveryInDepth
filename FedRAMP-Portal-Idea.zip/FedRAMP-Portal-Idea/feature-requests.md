Feature Request:
For the POC, what we've built is useful but we need to start planning what a production environment would be like:
- Should be based on a targeted OU or OUs in an AWS Organization for AWS accounts
- Should not include Suspended accounts
- Customer names should be extracted where possible from the member account's name
- Should refresh if the customer's account is renamed
- Should be aimed at GovCloud
- Should have an integration layer to allow identity to be sourced from customer IdP or Rackspace IdP
- should be able/open to manage resources running in GCP, OpenStack, Azure, VMWare/VCenter
- Access requests should have time periods of 1, 4, 8 and 12 hours
- Access requests should also require a reason supplied for the access request, most often a ticket number for clear auditing
- Needs to have the ability to integrate for push/pull to ticketing systems like Service Now following ITILv5 processes for creating INcidents, RITMs, extracted
- A process or module for retrieving/syncing usernamee/password combinations from existing Active Directory as a user migration step to allow shutting down exising AD infra
- single dashboard and live log tailing, multi-region to consolidate activity in config, cloudtrail, cloudwatch (currently restricted due to a lack of ability to test in an AWS Organization) as single log stream. I commercial, we'll onluy be working in CONUS regions. In GovCloud we'll be working in all regionsA
- A full end-to-end battery of tests (not unit tests) to automate functionality testing following a set of use cases, situations, expected results that we'll have to craft at some point. Selenium was my last experience for this kind of testing. Use up to date tools if selenium is no longer the preferred tool. 4 user perspectives: engineering applying code updates, operators resolving customer issues, auditors automating findings (no interview), customer interactions

---

## Frictionless remote desktop — adopt/adapt the Teleport "clientless RDP" pattern

**Problem (current POC):** connecting to a Windows host is clunky — the `passport`
CLI opens the SSM tunnel and prints Host/Username/Password, and the user then
hand-enters those into a native RDP client (mstsc / Microsoft Remote Desktop).
Too much copy/paste, and it still relies on a vended PASSWORD (the tracked
SC-28 / IA-5(1) residual).

**Prior art to steal from — how Teleport does it (researched 2026-09-04):**
Teleport renders the Windows desktop IN THE BROWSER; no local RDP client, no
paste. Mechanism (from their RFD-0033/0034 + "how we built a secure RDP client"
+ "passwordless remote access to Windows servers" posts — content rephrased for
licensing):
  - A Windows Desktop Service runs in-infra and makes an OUTBOUND reverse tunnel
    to the proxy (same zero-inbound posture we get from SSM). RDP is built into
    Windows, so nothing is installed on the target host.
  - Teleport implemented its OWN RDP protocol client (Rust); it speaks RDP to the
    host, captures the graphical display, and streams it as bitmaps to a canvas
    in the browser; keyboard/mouse are sent back. The user connects via the web
    UI — no separate RDP/VNC client.
  - PASSWORDLESS auth: the service authenticates to Windows with a short-lived
    X.509 certificate presented as a VIRTUAL SMART CARD; the host is configured
    (LDAP/AD + trusted CA) to accept smart-card logon. No password anywhere.

**Why it's not a drop-in for us:** (1) it's a substantial build — a full RDP
protocol client + browser streaming subsystem; (2) the passwordless half assumes
a DIRECTORY (AD/LDAP smart-card logon), which collides with ADR-0011 (govern the
local principal, no AD). Our local-ephemeral-user model is exactly why we vend a
password for RDP today.

**Tiered path (pick per appetite; higher tiers = bigger architecture change):**
  - **Tier 1 (near-term, no security-model change):** have the CLI LAUNCH the RDP
    client for the user with values pre-filled — write a temp `.rdp` (address +
    username) and inject the password via `cmdkey` so there's no manual paste,
    then clean both up on exit. Extends the existing `rdp_windows.go`. Removes
    most of the clunk while keeping the current (password) model.
  - **Tier 2 (Teleport-like experience):** browser-rendered RDP via an in-boundary
    gateway that speaks RDP to the host and streams to the browser over a
    websocket. EVALUATE Apache Guacamole (open-source, does exactly this) vs.
    building/embedding an RDP client. Must stay in the commercial∩GovCloud
    intersection (ADR-0019) and keep the zero-inbound + credential-less posture.
    This is a real project + likely its own ADR.
  - **Tier 3 (compliance north star):** true passwordless RDP via cert/smart-card
    logon — the clean close of the SC-28 / IA-5(1) password residual. Requires
    answering the directory question (AD/smart-card, or a Windows analogue of our
    SSH CA). Biggest lift; collides with ADR-0011's no-directory stance, so it
    needs its own ADR and a security-design conversation.

Capture now, don't build now. Tier 1 is the pragmatic quick win when we choose to
pick this up; Tier 2/3 are the Teleport-grade end state.

**Make Kiro stop being so lazy that every idea is labeled as a substantial build

**ability to replace front-end/SPA page with custom designs

**Include ability to configure different MFA sources such as Swissbit FIPS compliant hard tokens

**Multiple page integration to allow more operational functionality based on role. Things like a page that shows only active sessions across customers, dashboard access, etc

**Integration with AWS ORganizations to use OU structure to better target pages in view for Operational use

**Active Directory user migration from EC2 based AD or Managed AD to help provide a customer migration path of identities

---

## Strategic direction — "one core, many boundaries, many profiles" (captured 2026-09-07)

Thinking-out-loud session (greg + external analysis) crystallized the product
thesis and the modularization strategy. Capturing the DECISIONS and BOUNDARIES
here; full treatment belongs in a future `docs/TARGET-ARCHITECTURE.md` + a cluster
of ADRs (drafted when we resume — see "Next" below).

**The thesis.** Take the credential-less, zero-inbound, ephemeral-identity,
attributed-session model proven on AWS/SSM and bring it to the vCenter revenue
base and beyond — CHEAPER (retire VPN concentrators / jump hosts), STRONGER (no
standing AD trust, no long-lived hard-token+RSA+VPN chain), MODERN (browser/CLI,
not GlobalProtect), while holding an 800-53 ATO — AND open a new market selling
to 800-171 clients across AWS, Azure, and vCenter. This is the ADR-0021
"replace AD+VPN+jumphost" thesis, extended to the paying vCenter base.

**Current vCenter reality we're displacing (per greg; no direct access yet):**
Palo Alto GlobalProtect VPN + Swissbit hard tokens + RSA + customer JumpHosts;
dedicated customer AD with a trust to RGS's overarching AD that scopes RGS access
to customer resources. That AD+VPN+jumphost stack is exactly the model this
product exists to modernize.

**The four contracts to publish (the product surface; everything else is an
implementation behind them):**
  1. **Consumer/Portal API** (versioned OpenAPI) — any front end, mobile,
     ServiceNow, or auditor tool is just a client. Portal = reference client,
     NOT a privileged component (no API privilege a third party couldn't get).
  2. **Canonical Resource + Capability model** — `{provider,type,id,state,
     capabilities:[...]}`; UI renders/acts from capabilities, never from
     provider-specific semantics. vCenter VM / EC2 / Azure VM all emit this.
  3. **Identity assertion** — normalize to ASSURANCE + ATTRIBUTION
     (`{subject,issuer,tenant,authn_method,authn_assurance,mfa,groups}`), NOT
     mechanism. Cognito is ONE impl; RGS IdP / customer SAML/OIDC / CAC-PIV /
     Swissbit-FIDO2 / (transitional) AD-trust all sit below it. (greg: "not
     married to Cognito.")
  4. **Provider** — `List/Get/Start/Stop/GetCompliance/GetAuditEvents/...`;
     CONNECTION is provider-defined (AWS=SSM tunnel; vCenter=its own broker;
     Azure=Bastion/Arc) — nothing SSM-shaped may leak into the contract.

**Boundary decisions that avoid painting ourselves into a corner (build NOW):**
  - **Transport is abstract** — the contract says "attributed, brokered ephemeral
    session," not "SSM." (Trap: AWS/SSM becoming THE transport.)
  - **Identity by assurance, not mechanism** — lets vCenter keep its AD trust
    INITIALLY (don't break revenue) and migrate credential-less behind the same
    contract. (Trap: hard-coding either "no directory" or "AD trust".)
  - **One core, MANY authorization boundaries, MANY compliance profiles** — shared
    control plane (API/identity/workflow/audit); each provider in its OWN
    boundary with its OWN authorization package (the existing vCenter ATO stays
    intact, connects via the Provider contract, does NOT contaminate the AWS
    IL4 boundary); 800-53 Moderate/IL4 and 800-171 are PROFILES (which controls
    apply), NOT forks. (Trap: entangling ATO boundaries; forking the codebase.)
  - **Async by default** — every state-changing action is `202 + /jobs/{id}` (+
    future events) so a slow vCenter op and a fast AWS op look identical to the
    consumer. (Trap: AWS-speed synchronous assumptions.)

**Phased delivery (build the boundaries now; deliver capabilities later):**
  - **Phase 0 (now):** AWS/SSM + Cognito + one provider/consumer (the POC). Make
    its BOUNDARIES contract-shaped, not its capabilities complete.
  - **Phase 1 (contract extraction — cheap, high-leverage):** publish the four
    contracts; refactor the CURRENT AWS impl to sit cleanly behind them. No new
    providers/IdPs — prove AWS works THROUGH the contracts. De-risks everything.
  - **Phase 2 (identity optionality):** add a 2nd IdP (RGS/customer SAML/OIDC) +
    Swissbit/FIDO2 assurance behind the identity contract.
  - **Phase 3 (revenue play):** vCenter Provider behind the contract, initially
    leaning on the existing AD trust, in its own boundary — modernize vCenter
    access incrementally without breaking what pays.
  - **Phase 4 (market expansion):** Azure/GCP providers; 800-171 profile; the
    Security-Hub-as-one-source evidence plane.
  Phase 1's contracts MUST be shaped knowing Phases 3-4 exist — that's the whole
  point of deciding now.

**DISCIPLINE (agreed):** draft the contracts now, shaped to accommodate
vCenter/800-171, but treat v1 as PROVISIONAL. Freeze only after a SECOND real
implementation (the first actual vCenter provider) proves them. Design for it
now; don't abstract on pure speculation. Realistically, vCenter exposure comes
after a stakeholder sees the POC and asks "when can we have it?" — so the
strategy docs are also part of the pitch that triggers that.

**Reconcile-with-existing-ADRs flags (for the future ADR set — do NOT silently
change):**
  - ChatGPT's "drop `terraform_remote_state`, publish config via SSM/manifest"
    CONFLICTS with ADR-0009 (deliberate remote-state). Likely a HYBRID: keep
    remote-state for stable lower layers (foundation/identity/security);
    published-contract only at seams needing independent lifecycle
    (provider adapters, portal). Decide via ADR, not silently.
  - The identity-broker + provider abstractions EXTEND ADR-0016 (currently a CLI
    Go interface) into server-side subsystems — bigger than 0016 is today; note
    the scope honestly.
  - Terraform reorg to `modules/` + `live/<profile>/<NN-layer>/` is the right
    DESTINATION but a disruptive move — do it at the POC→production transition,
    AFTER the ADRs, not now.

**Next (when we resume — no code, docs precede implementation):**
  1. `docs/TARGET-ARCHITECTURE.md` — the north star (one core / many boundaries /
     many profiles) + the four contracts + the phased delivery. Marked aspirational.
  2. ADR cluster (interlocking, draft as a set): contract-first platform;
     provider abstraction (connection provider-defined; per-provider boundary);
     identity-by-assurance; one-core-many-boundaries-and-profiles; phased delivery.
  3. Highest-leverage concrete first step: draft the Consumer API contract as
     versioned OpenAPI against what ALREADY exists (auth/sessions/connect/
     terminate/list) + the canonical resource/capability schema.

---

## Strategic direction — "one core, many boundaries, many profiles" (captured 2026-09-07)

Thinking-out-loud session (greg + external analysis via ChatGPT, deliberately
run WITHOUT knowledge of our ADRs to get an independent stream) crystallized the
product thesis and the modularization strategy. Capturing the DECISIONS and
BOUNDARIES here; full treatment belongs in a future `docs/TARGET-ARCHITECTURE.md`
+ a cluster of ADRs (drafted when we resume — see "Next" below). NOTHING here is
built; this is direction, and part of it is the pitch that earns us vCenter
exposure in the first place.

**The thesis.** Take the credential-less, zero-inbound, ephemeral-identity,
attributed-session model proven on AWS/SSM and bring it to the vCenter revenue
base and beyond — CHEAPER (retire VPN concentrators / jump hosts), STRONGER (no
standing AD trust, no long-lived hard-token+RSA+VPN chain), MODERN (browser/CLI,
not GlobalProtect) — while holding an 800-53 ATO — AND open a new market selling
to 800-171 clients across AWS, Azure, and vCenter. This is the ADR-0021
"replace AD+VPN+jumphost" thesis, extended to the paying vCenter base.

**Current vCenter reality we're displacing (per greg; NO direct access yet).**
Palo Alto GlobalProtect VPN + Swissbit hard tokens + RSA + customer JumpHosts;
dedicated customer AD with a trust to RGS's overarching AD that scopes RGS access
to customer resources only. That AD+VPN+jumphost stack is exactly the model this
product exists to modernize. It is also today's big revenue generator and already
carries its OWN ATO — so vCenter is a FIRST-CLASS provider to plan for, not
speculative future scope.

**The four contracts to publish (the product surface; everything else is an
implementation behind them):**
  1. **Consumer / Portal API** (versioned OpenAPI) — any front end, mobile,
     ServiceNow integration, or auditor tool is just a client. The portal is a
     REFERENCE CLIENT, NOT a privileged component: it must hold no API privilege
     a third-party portal couldn't also obtain (keeps the abstraction honest,
     prevents backdoors, and drops the UI out of much of the ATO control scope).
  2. **Canonical Resource + Capability model** — `{provider,type,id,state,
     capabilities:[...]}`; the UI renders and acts from the capability list,
     never from provider-specific semantics. A vCenter VM, an EC2 instance, and
     an Azure VM all emit this same shape.
  3. **Identity assertion** — normalize to ASSURANCE + ATTRIBUTION
     (`{subject,issuer,tenant,authn_method,authn_assurance,mfa,groups}`), NOT
     mechanism. Cognito is ONE implementation; RGS IdP / customer SAML / OIDC /
     CAC-PIV / Swissbit-FIDO2 / (transitional) AD-trust all sit BELOW it. (greg:
     "not married to Cognito"; a known RGS IdP is a real target.)
  4. **Provider** — `List/Get/Start/Stop/GetCompliance/GetAuditEvents/...`;
     CONNECTION is provider-defined (AWS = SSM tunnel; vCenter = its own broker;
     Azure = Bastion/Arc). Nothing SSM-shaped may leak into the contract.

**Boundary decisions that avoid painting ourselves into a corner (decide NOW,
even though we build later):**
  - **Transport is abstract.** The contract says "establish an attributed,
    brokered ephemeral session," not "open an SSM tunnel." (Trap avoided: the
    AWS/SSM transport becoming THE transport, which vCenter can't implement.)
  - **Identity by assurance, not mechanism.** Lets vCenter keep its AD trust
    INITIALLY (don't break revenue) and migrate toward credential-less behind
    the same contract. (Trap avoided: hard-coding either "no directory" — breaks
    vCenter — or "AD trust" — drags AD into the clean AWS boundary.)
  - **One core, MANY authorization boundaries, MANY compliance profiles.** Shared
    control plane (API / identity / workflow / audit). Each provider sits in its
    OWN boundary with its OWN authorization package — the existing vCenter ATO
    stays intact and connects via the Provider contract (a controlled, audited
    interface, NOT a shared network), and does NOT contaminate the AWS IL4
    boundary. 800-53 Moderate/IL4 and 800-171 are PROFILES (which controls
    apply), NOT forks of the codebase. This is the structural decision that lets
    us sell to 800-171 clients without re-architecting and without weakening the
    IL4 boundary. (Trap avoided: entangling ATO boundaries; forking commercial
    vs. fedramp.)
  - **Async by default.** Every state-changing action is `202 Accepted` +
    `/jobs/{id}` (+ future SSE/WebSocket events) so a slow vCenter operation and
    a fast AWS one look identical to the consumer. Maps onto our existing Step
    Functions substrate. (Trap avoided: AWS-speed synchronous assumptions baked
    into the API.)

**Phased delivery (build the boundaries now; deliver capabilities later).**
  - **Phase 0 (now):** AWS/SSM + Cognito + one provider / one consumer (the POC).
    The job now is to make its BOUNDARIES contract-shaped, not its capabilities
    complete.
  - **Phase 1 (contract extraction — cheap, high-leverage):** publish the four
    contracts as versioned specs; refactor the CURRENT AWS implementation to sit
    cleanly behind them. No new providers, no new IdPs — prove the AWS path works
    THROUGH the contracts. This de-risks everything downstream and is mostly
    formalizing what already exists.
  - **Phase 2 (identity optionality):** add a SECOND IdP (RGS or customer
    SAML/OIDC) behind the identity contract; add Swissbit/FIDO2 as an MFA
    assurance behind the same contract.
  - **Phase 3 (the revenue play — vCenter provider):** implement the vCenter
    Provider behind the contract, INITIALLY leaning on the existing AD-trust auth
    (don't break what pays the bills), in its OWN boundary. Modernize vCenter
    access incrementally.
  - **Phase 4 (market expansion):** Azure/GCP providers; the 800-171 compliance
    profile; the Security-Hub-as-one-source evidence/compliance plane.
  Phase 1's contracts MUST be shaped KNOWING Phases 3-4 exist — that is the whole
  point of deciding the boundaries now. Shape it for AWS only and we bake in
  SSM/Cognito/IL4 assumptions and pay dearly to unwind them.

**DISCIPLINE (agreed — the balance between "build to the strategy now" and
"don't abstract on pure speculation").** Draft the contracts now, shaped to
accommodate vCenter and 800-171, but treat v1 as PROVISIONAL. Freeze only after a
SECOND real implementation (the first actual vCenter provider) has pressure-tested
them. Design for it now; expect the first real vCenter implementation to refine
it. Realistically vCenter exposure arrives only after a stakeholder sees the POC
and asks "when can we have it?" — so the strategy docs double as the pitch that
triggers that moment.

**Reconcile-with-existing-ADRs flags (for the future ADR set — do NOT silently
change any of these):**
  - The external analysis proposed "drop `terraform_remote_state`, publish config
    via SSM/manifest." This CONFLICTS with ADR-0009 (deliberate remote-state for
    cross-layer deps). Remote-state gives plan-time, typed, auditable dependency
    validation — arguably an ASSET for a FedRAMP system — vs. the loose-coupling
    of a published contract. Likely resolution: a HYBRID — keep remote-state for
    the STABLE lower layers (foundation → identity → security), use the
    published-contract (SSM/manifest) pattern only at seams that genuinely need
    independent lifecycle (provider adapters, portal). Decide via ADR, explicitly.
  - The identity-broker and provider abstractions EXTEND ADR-0016 (today just a
    Go interface in the CLI) into server-side subsystems — a materially bigger
    build than 0016 is now. Note the scope honestly; don't imply it exists.
  - Terraform reorg to `modules/` + `live/<profile>/<NN-layer>/` (bootstrap /
    foundation / identity / security / platform / providers / api-contract /
    portal / observability, each its own state) is the right DESTINATION but a
    disruptive move. Do it at the POC→production transition, AFTER the ADRs, NOT
    mid-POC while the stack is working.
  - The external analysis independently reinvented several things we ALREADY
    decided (partition intersection = ADR-0019; provider seams = ADR-0016; no
    commercial/fedramp fork = ADR-0017/0019) — validating — but it was unaware
    of ADR-0011's deliberate no-directory stance (which collides with its
    smart-card RDP assumption) and ADR-0009. Value is in RECONCILING it with what
    we've built, not adopting it wholesale.

**Next (when we resume — no code; docs precede implementation, per our pattern):**
  1. `docs/TARGET-ARCHITECTURE.md` — the north star (one core / many boundaries /
     many profiles), the four contracts, the phased delivery. Explicitly marked
     ASPIRATIONAL / target-state, cross-referenced to the ADRs it touches.
  2. ADR cluster (interlocking — draft as a set): (a) contract-first platform +
     portal-as-reference-client; (b) provider abstraction (connection is
     provider-defined; each provider in its own boundary); (c) identity by
     assurance, not mechanism (Cognito is one impl; supersedes the Cognito-centric
     framing); (d) one core, many authorization boundaries + compliance profiles
     (800-53 Moderate/IL4 and 800-171 as profiles, not forks); (e) layer coupling
     (remote-state vs. published-contract — the ADR-0009 reconciliation);
     (f) phased capability delivery (so Phase 1 isn't over-built).
  3. Highest-leverage CONCRETE first step: draft the Consumer/Portal API as a
     versioned OpenAPI spec against what ALREADY exists (auth / sessions /
     connect / terminate / list_instances) plus the canonical resource +
     capability JSON schema. Small, real, and it directly unlocks the
     replaceable-front-end goal.
