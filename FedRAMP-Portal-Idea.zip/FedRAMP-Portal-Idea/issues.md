# FedRAMP Portal — Issues

Bug tracker (separate from `todo.md`; items move to `todo.md` as we pick them
off). Fixed under the ADR-0022 hierarchy (Passport prior art -> satisfy 800-53
-> lowest-risk tiebreak + document). SoD (ADR-0018): Kiro edits code; greg runs
deploy + live tests.

Status legend: OPEN | INVESTIGATING | FIX-READY (code done, awaiting greg deploy/test) | CLOSED

---

## I10 — Windows ephemeral accounts survive cleanup (disconnected RDP session); false PORTAL_CLEANUP_OK (AC-2, HIGH) — FIX-READY
- **Symptom:** ended RDP sessions leave ENABLED `greg-racker-*` local accounts on
  the Windows host, with loaded profiles in `C:\Users`. Ground truth (live box):
  `greg-racker-6428` (idle 3+ days) and `greg-racker-2eed` present + Enabled=True,
  profiles `Loaded=True`. Yet the cleanup Lambda logged `Cleanup verified ... OK`
  and the sessions went COMPLETED (records later TTL-expired, erasing the trail).
- **Root cause (CONFIRMED via `quser`):** the ended sessions are in state **`Disc`
  (disconnected), not logged off**. A disconnected session keeps the profile hive
  LOADED and the account in-use, so `Remove-LocalUser` (run under
  `-ErrorAction SilentlyContinue`) silently fails and the account survives. The
  old logoff step parsed `quser` TEXT, whose columns shift for a `Disc` row (blank
  SESSIONNAME), so it missed the session id and never logged the user off. The
  raw SSM output showed `PORTAL_CLEANUP_OK` was emitted anyway → the verification
  false-passed (the exact "silent COMPLETED masks a residual" class ADR-0023
  fought, resurfacing on the Windows path). This is an AC-2 orphaned-privilege
  failure — enabled ephemeral admin accounts with no live record.
- **Control/ADR relevance:** AC-2 / AC-2(3) (ephemeral account must not persist),
  AU-6 (residual must surface, not be masked), ADR-0023 (verified teardown).
- **Fix (FIX-READY):** hardened `WINDOWS_CLEANUP` in `cleanup_user/handler.py`:
  (1) resolve the account SID (from the account, else ProfileList); (2) force
  logoff EVERY session for that user via `query session` matched on the username
  column (handles `Disc` rows), not fragile `quser` text; (3) kill the user's
  processes; (4) `reg unload HKU\<SID>` to release the hive; (5) `Remove-LocalUser`
  with the error CAPTURED (not swallowed); (6) remove profile via CIM + folder +
  stale ProfileList key; (7) HONEST verify — `PORTAL_CLEANUP_OK` only when the
  account AND profile folder AND every session are gone, else INCOMPLETE + exit 1
  (→ conductor retries → CLEANUP_FAILED, never silent COMPLETED). Lambda poll
  widened to ~45s for the added logoff/unload waits.
- **Affected:** `terraform/03-api/lambda/cleanup_user/handler.py` (WINDOWS_CLEANUP
  + verification poll). SSH/Linux path unchanged (already worked).
- **Verified (Kiro):** py_compile OK; `.format()` renders (braces balanced);
  `terraform validate` 03-api SUCCESS.
- **Deploy (greg, SoD):** `cd terraform/03-api && terraform apply` (cleanup-user
  Lambda only). Then re-test RDP: connect, DISCONNECT (close the RDP client
  without logging off) to reproduce the `Disc` state, End the session, and verify
  the `greg-racker-*` account is GONE (`Get-LocalUser`, `quser`) and the profile
  folder is removed. `tunnels_terminated` unaffected.
- **Existing orphans (`2eed`, `6428`) have NO DynamoDB record left (TTL-expired),**
  so the purge script won't touch them — remove manually on the box (or reboot to
  unload hives, then delete account + profile). Kiro can supply the PowerShell.
- **VERIFIED FIXED 2026-09-04 (greg, live on i-018bd775b286ff1b1):** test user
  `greg-racker-6d54` ended, then all five ground-truth checks clean —
  `Get-LocalUser` (none), `Test-Path C:\Users\...` (False), `Win32_UserProfile`
  (none), ProfileList registry (none), `quser` (none). Account + profile + hive +
  registry + session all removed. (Pre-existing orphans `2eed`/`6428` remain —
  they predate the fix and have no DynamoDB record; to be reaped manually.)
- **Status:** VERIFIED / CLOSED — Windows ephemeral account + profile now fully
  removed on session end (AC-2 satisfied). Recommend one more run ending from a
  DISCONNECTED (Disc) session to nail the exact original failure mode.
- **RELATED DEFERRED (needs 800-53 review, greg):** DynamoDB `expires_at` TTL
  reaped the session records BEFORE/independent of verified teardown, so a
  cleanup failure vanished from the audit trail (AU-9/AU-11 + AC-2). Candidate
  refinement: never TTL-reap a non-terminal record; retain terminal records for
  the audit window. Tracked as a distinct ADR-0023 refinement, NOT fixed here.

## I9 — Two session records per connect; End hit the wrong one; no operator visibility (AC-12/AC-2, HIGH) — FIX-READY (ADR-0025)
- **Symptom:** clicking portal End on an RDP session did nothing to the live
  tunnel; the record it ended (`dc28541d…`) was NOT the record the live tunnel
  belonged to (`2eedcb1d…`). Proven from the C2 log: terminate wrote
  END_REQUESTED to a DIFFERENT request than the one still polling ACTIVE.
- **Root cause (CONFIRMED):** clicking portal Connect called POST /api/connect,
  which minted an access request AND provisioned a real ephemeral OS user
  (record A) — purely to show the `passport connect` command. The user then ran
  the CLI, which authenticates and calls POST /api/connect AGAIN, minting a
  SECOND record + ephemeral user (record B, the live tunnel). Two records, two
  privileged users, for one intended session. Portal End acted on A; B lived on.
  Net harm: End-wrong-record (looked like a persistent bug) AND an unused,
  unlogged-into ephemeral privileged account left on the host until TTL
  (orphaned-privilege, AC-6/AC-2; hidden state, AU-6).
- **Second gap exposed:** `list_sessions` only ever returned the CALLER's own
  sessions (user-index by user_id). A Racker asked to revoke "Customer1 / Joe"
  saw NOTHING — no operator lens. You cannot reliably terminate (AC-12) or
  manage accounts (AC-2/AC-2(1)) for access you cannot see.
- **Control/ADR relevance:** AC-12, AC-2, AC-6, AU-6; ADR-0021 tenant isolation;
  ADR-0025 (session model + operator lens); ADR-0024 (attributed C2 plane).
- **Fix (FIX-READY, ADR-0025):**
  1. ONE authoritative record per connect: the portal Connect provisions
     NOTHING — it opens an instructions drawer with the `passport connect`
     command; the CLI's authenticated request is the single session record.
     Opening the drawer is not a plane action; running the CLI is.
  2. Target tenant on the record: `create_access_request` stamps the instance's
     `Customer` tag as `customer_id` (region-aware read; fail-open, logged) so
     the operator lens is tenant-scopable server-side.
  3. Operator lens: GET /api/sessions?scope=all (Rackers only, fail-closed;
     optional &customer_id= tenant scope, ADR-0021) via the status-index GSI —
     full detail, NO session secret (least privilege). New RackerDashboard
     "Active Sessions (All Users)" console with per-session End.
  4. Attributed + justified revoke: terminate persists ended_by / end_source /
     end_reason; an operator revoke (Racker ending another user's session)
     REQUIRES a reason (ticket #), fail-closed 400 (ADR-0024). Reason dialog in
     the operator console; self-terminate + cli:exit auto-attributed, no prompt.
- **Affected:** `create_access_request/handler.py`, `list_sessions/handler.py`,
  `terminate_session/handler.py`, `portal/src/components/ConnectButton.tsx`,
  `SessionDrawer.tsx`, new `OperatorSessions.tsx`, `pages/RackerDashboard.tsx`,
  `portal/src/api/types.ts`, `cli/internal/api/client.go`,
  `cli/internal/command/connect.go`.
- **Verified (Kiro):** py_compile 3 lambdas; terraform validate 03-api; SPA
  npm run build (tsc -b + vite); CLI go vet + linux/windows/darwin builds.
- **Deploy (greg, SoD):** 03-api apply (3 lambdas) + SPA (hard-reload) + CLI
  publish/reinstall. See todo.md runbook.
- **Status:** FIX-READY (ADR-0025). NOTE: the plane-wide attribution retrofit
  (ADR-0024 — attribute+log EVERY action incl. reads) is a SEPARATE follow-up
  change, not included here.

---

## I8 — Server-side End does NOT sever the live session; access persists after "COMPLETED" (AC-12, HIGH) — FIX-READY
- **Symptom:** clicking End in the portal ONCE cleanly converges the backend
  (`END_REQUESTED -> CLEANING_UP -> cleanup verified OK -> COMPLETED`) but the
  user's SSH shell REMAINS FULLY INTERACTIVE with all privileges. Access only
  actually ends on a SECOND action (second End click / CLI poll), which drops
  the tunnel. So the system REPORTS access revoked while access is still live.
- **Severity:** HIGH. This is a real AC-12 (reliable termination) / AC-2 failure,
  not a UX nit: there is a window where the audit/record says COMPLETED but the
  operator still has a privileged session. "Reported terminated != actually
  terminated" is an assessment-failing gap for an access broker.
- **Root cause (CONFIRMED from the 06-observability execution log, req
  `aef762df…`, user `greg-racker-aef7`, 2026-09-04):** the conductor's cleanup
  returned `tunnels_terminated: 0` — it never tore down the SSM port-forward
  tunnel. `teardown_tunnels` filtered SSM sessions by `username in Owner`, but
  the tunnel is opened by the CLI using the VENDED STS creds, so the SSM
  session's `Owner` is the assumed-role principal from `ssm_credentials`, NOT
  the ephemeral OS account (`greg-racker-aef7`). The filter matched nothing, so
  the transport survived; the SSH connection rode on it until a later action
  finally dropped the tunnel. (The OS `userdel` ran and the script reported OK,
  but the still-live tunnel/session kept the shell interactive.)
- **Affected:** `terraform/03-api/lambda/cleanup_user/handler.py`
  (`teardown_tunnels`).
- **Fix (FIX-READY):** terminate EVERY active `AWS-StartPortForwarding*` session
  whose `Target` is this instance; dropped the wrong `username in Owner` filter.
  In this model a session is single-purpose + one-at-a-time per instance and is
  ending regardless, so instance+document is the correct key. Owner is now just
  logged. py_compile OK.
- **Deploy (greg, SoD):** `cd terraform/03-api && terraform apply` (cleanup-user
  Lambda only — no SPA/CLI change).
- **Verify (all three must hold):** (1) execution log shows
  `tunnels_terminated: 1` (not 0); (2) the SSH shell dies on the FIRST End; (3)
  immediately after End, a command in that shell (e.g. `id`) does NOT return —
  access is genuinely gone, not just reported gone.
- **If still live after tunnel teardown:** then the already-established sshd
  LOGIN SESSION is surviving independently of the transport, and the Linux
  cleanup must kill the session tied to the tunnel more aggressively (pull the
  `describe_sessions` shape + confirm `loginctl terminate-user` actually killed
  the leader). Do NOT pre-build that — verify the tunnel fix first.
- **VERIFIED FIXED 2026-09-04 (greg, live):** redeployed cleanup-user; SSH to
  `i-0b7079a48830f9c41` (us-east-1) as `greg-racker-0614`. Typed a command
  pre-click (normal response), then clicked End ONCE — the SSH session dropped
  immediately and returned to the local prompt; no second click, no residual
  interactivity. Server-side tunnel teardown now severs the transport on the
  first end demand. (The `error: wait: remote command exited without exit
  status or exit signal` line on exit is cosmetic — the SSH client noting the
  transport was pulled vs. a clean `logout`; correctness unaffected.)
- **RDP ALSO VERIFIED 2026-09-04 (greg, live):** same one-click test on a
  Windows/RDP session — first End click killed the session cleanly (tunnel
  severed, RDP client lost the desktop). Both access paths now terminate on the
  first end demand.
- **DECISION (greg): the `error: wait: remote command exited without exit status
  or exit signal` line stays.** It is PROOF that the transport was forcibly
  severed (a real kill) rather than a graceful client logout — useful evidence,
  not a defect. Not suppressing it.
- **Status:** VERIFIED / CLOSED — SSH + RDP both confirmed. One click = immediate,
  real loss of access; reported state and actual state agree (AC-12 satisfied).

---

## I7 — Sessions strand at CLEANING_UP; conductor aborted (structural) — ADR-0023
- **Symptom:** after the incremental I1–I6 fixes, live testing STILL showed
  sessions stuck at `CLEANING_UP`, ephemeral users/profiles orphaned, and 81
  Step Function executions in `Aborted` state.
- **Root cause (CONFIRMED, structural):** `terminate_session` called
  `states:StopExecution`, which **aborted the Step Function (the conductor)
  before it could write a terminal state** — so the record never converged past
  `CLEANING_UP`. More broadly, responsibility for teardown was scattered across
  callers (portal, CLI, TTL) with no single authority; a failed cleanup could
  even report `COMPLETED`. This is not a UI bug — I1/I2/I5/I6 were treating
  symptoms of a missing conductor.
- **Control/ADR relevance:** AC-12 (reliable, verified termination), AC-2
  (no orphaned accounts), AU-6 (residuals must surface).
- **Fix (FIX-READY) — the ADR-0023 redesign (supersedes the incremental I2/I5/I6
  patches):**
  1. `terminate_session` is a pure END DEMAND (writes `END_REQUESTED`,
     condition-guarded; no inline cleanup; no `states:StopExecution`).
  2. The state machine is the verifying conductor: `CleanupUser` branches on the
     cleanup Lambda's `verified` result (`OK` -> `COMPLETED`; `INCOMPLETE` after
     3x/10s retry -> new terminal `CLEANUP_FAILED`); the silent `Catch ->
     COMPLETED` is removed; poll `Wait` 30s -> 10s.
  3. `cleanup_user` owns tunnel teardown (`ssm:DescribeSessions` +
     `ssm:TerminateSession`) and defaults `verified` to `INCOMPLETE`.
  4. The CLI submits the same end-demand on ANY local exit (fixes
     orphaned-user-on-CLI-exit).
  5. Portal shows ending states honestly ("Ending…", non-actionable); the
     `pendingTerminations` client hack is removed (backend now authoritative).
  6. IAM: removed `states:StopExecution`/`DescribeExecution`; added the ssm
     session perms.
- **Affected:** `terraform/03-api/lambda/terminate_session/handler.py`,
  `.../cleanup_user/handler.py`, `.../list_sessions/handler.py`,
  `terraform/03-api/state-machine/access-lifecycle.asl.json`,
  `terraform/03-api/main.tf`, `portal/src/api/types.ts`,
  `portal/src/api/SessionsContext.tsx`,
  `portal/src/components/ConnectButton.tsx`, `SessionDrawer.tsx`,
  `cli/internal/command/connect.go`. Plus one-time
  `scripts/purge-stranded-sessions.py` for the pre-existing debris.
- **Verified:** all Python `py_compile` OK; ASL valid JSON (21 states), no
  `StopExecution`; `terraform validate` (03-api) passes, `fmt`-clean; SPA
  `npm run build` passes; CLI `go vet` + linux/windows/darwin builds pass.
- **Deploy (greg, SoD):** matched set — see the ordered runbook in `todo.md`
  (03-api apply -> SPA + hard-reload -> CLI publish + reinstall -> purge -> test).
- **Status:** FIX-READY (ADR-0023). Awaiting greg deploy + live-verify. On verify,
  this closes I2/I4/I5/I6 as well (they are subsumed by the one teardown path).

---

## I1 — Portal does not auto-refresh session status
- **Symptom:** the portal page does not auto-refresh to show session status; the
  user must manually reload to see state changes.
- **Root cause (CONFIRMED):** same root cause as I2. `SessionsContext` DOES poll
  every 15s, but (a) instances are fetch-once (no poll), (b) the 1s countdown
  timer in `SessionDrawer` is cosmetic and drives no refetch, and (c) the
  "active" pill is existence-based so stale entries linger between polls.
- **Affected:** `portal/src/api/SessionsContext.tsx`, `SessionDrawer.tsx`,
  `ConnectButton.tsx`.
- **Control/ADR relevance:** UX; indirectly AC-12 (users can't see authoritative
  termination happen).
- **Fix (FIX-READY):** `SessionsContext` now (a) adaptively polls — 3s while any
  session is transitional or a termination is pending, 15s at rest (was fixed
  15s), and (b) `removeSession` fires an immediate `refresh()` so the UI updates
  now, not on the next tick. Fixed with I2 (same file).
- **Status:** DEPLOYED 2026-09-03 (SPA). Awaiting greg live-verify -> CLOSED.

## I2 — Ending a session takes two attempts
- **Symptom:** ending a session via the portal requires pressing End Session,
  reloading the portal, re-opening the (still-shown) active session, and ending
  it a second time before it actually ends.
- **Root cause (CONFIRMED):** `SessionsContext.refresh()` inserts EVERY session
  from `/api/sessions` into the map with NO status filter, so a just-terminated
  session (still ACTIVE/CLEANING_UP on the backend for a moment) is re-added,
  overriding the optimistic `removeSession()` → the row reverts to "Active", so a
  second attempt is needed once the backend reaches a terminal state. Compounded
  by `ConnectButton` treating map EXISTENCE (not `status === 'ACTIVE'`) as
  "active", and `handleTerminate` never confirming the status transition.
- **Affected:** `portal/src/api/SessionsContext.tsx` (refresh filter),
  `ConnectButton.tsx` (existence vs status), `SessionDrawer.tsx` (no confirm).
- **Control/ADR relevance:** AC-12 (termination must be reliable + usable). The
  backend poll-loop is authoritative; this is the UI not reflecting it.
- **Fix (FIX-READY):** three coordinated SPA changes — (1) `SessionsContext.refresh()`
  now only keeps LIVE sessions (ACTIVE/PENDING/PROVISIONING) and DROPS
  ending/ended ones (CLEANING_UP/COMPLETED/FAILED), so a just-terminated session
  no longer bounces back; (2) a `pendingTerminations` ref suppresses a
  just-terminated instance even if the backend briefly still returns it ACTIVE,
  cleared once the backend stops returning it live; (3) `ConnectButton` keys the
  "Active - View Session" pill on `status === 'ACTIVE'` (not mere existence) and
  shows a "Provisioning..." state for transitional sessions; the drawer only
  opens for a truly ACTIVE session and closes on terminate. One click now ends
  the session and it stays ended.
- **Affected (edited):** `portal/src/api/SessionsContext.tsx`,
  `portal/src/components/ConnectButton.tsx`. Diagnostics clean.
- **Deploy (greg, SoD):** rebuild + redeploy the SPA
  (`AWS_PROFILE=personal-faws ./scripts/deploy-portal.sh`). Test: connect, then
  End Session ONCE — row returns to Connect and stays; no reload/second click.
- **TRUE root cause (found on 3rd pass, 2026-09-03):** the earlier SPA-only
  attempts were fighting a BACKEND timing race. `terminate_session` ran the
  (slow) SSM cleanup `send_command` FIRST and wrote status=CLEANING_UP AFTER, so
  the terminate POST didn't return until both were done — and worse, the SPA's
  post-terminate re-poll of `GET /api/sessions` (which returns only ACTIVE) could
  hit while the status was still ACTIVE, re-adding the session. No amount of
  client suppression could reliably win a race against the DB still saying ACTIVE.
- **Real fix (FIX-READY):** (backend) `terminate_session` now writes
  CLEANING_UP BEFORE the SSM cleanup, so the session is authoritatively
  non-ACTIVE the instant the POST returns 200; (SPA) `handleTerminate` now
  AWAITS the reconcile (`removeSession` -> `refresh`, both made async) before
  closing the drawer, so it can't re-render a stale Active pill. request_id
  suppression retained (I6). Requires BOTH the terminate_session Lambda AND the
  SPA to be redeployed together (matched pair).
- **Affected:** `terraform/03-api/lambda/terminate_session/handler.py`,
  `portal/src/api/SessionsContext.tsx`, `portal/src/components/SessionDrawer.tsx`,
  `portal/src/components/ConnectButton.tsx`. py_compile + diagnostics clean.
- **Deploy (greg, SoD):** (1) `cd /mnt/c/RGS-Code/FedRAMP-Portal-Idea/terraform/03-api && AWS_PROFILE=personal-faws terraform apply` (terminate_session in-place); (2) `cd /mnt/c/RGS-Code/FedRAMP-Portal-Idea && AWS_PROFILE=personal-faws ./scripts/deploy-portal.sh`. Test: End Session ONCE -> stays ended.
- **Status:** FIX-READY v2 (awaiting deploy/test) — 3rd attempt; backend+SPA pair.

## I3 — RDP tunnel remains open after the RDP session ends
- **Symptom:** when an RDP session ends (voluntary logout OR forced end via the
  portal), the SSM port-forward tunnel stays open even though the RDP session
  has logged out.
- **Root cause (CONFIRMED):** `holdForRDP` (cli tunnel.go) blocks only on
  `<-ctx.Done()`, which is cancelled ONLY by an OS signal to `passport`
  (Ctrl-C). The CLI never launches or waits on the native RDP client (no mstsc
  exec), and never polls `GET /api/session/{id}` status after ACTIVE. So neither
  RDP logout nor a portal force-end reaches the teardown. SSH is the correct
  pattern to mirror: it blocks on `sess.Wait()` so client-exit tears down.
- **Affected:** `cli/internal/connection/awsec2/tunnel.go` (holdForRDP),
  `awsec2.go` (AwaitReady/Cleanup), `cli/internal/api/client.go` (unused
  Session/Terminate).
- **Control/ADR relevance:** AC-12 (a lingering tunnel is residual access);
  least privilege / minimized surface.
- **Fix (FIX-READY):** `holdForRDP` (tunnel.go) no longer blocks only on Ctrl-C.
  It now `select`s on THREE teardown triggers: (1) Ctrl-C/SIGTERM, (2) a 5s poll
  of `GET /api/session/{id}` — tears down when status != ACTIVE (portal
  force-end / TTL cleanup; the AC-12 fix, cross-platform + reliable), and (3)
  native RDP client exit. Client launch is best-effort + OS-specific: new
  `rdp_windows.go` writes a temp `.rdp` (no embedded password — DPAPI/disk-secret
  avoided per ADR-0022) and launches+waits `mstsc`, closing a channel on exit;
  `rdp_other.go` best-effort `open rdp://` on macOS, nil channel on Linux
  (falls back to triggers 1+2). Transient API errors during the poll do NOT tear
  down (only a definitive non-ACTIVE does). SSH path unchanged (already tears
  down on shell exit).
- **Affected (edited/added):** `cli/internal/connection/awsec2/tunnel.go`
  (holdForRDP + poll const), NEW `rdp_windows.go`, NEW `rdp_other.go`.
- **Verified:** `go vet` clean; builds pass for linux/amd64, windows/amd64
  (rdp_windows.go), darwin/arm64 (rdp_other.go).
- **Deploy (greg, SoD):** rebuild + publish the CLI
  (`cd cli && ./_make.sh cli && AWS_PROFILE=personal-faws ./publish.sh`), then
  re-install the `passport` binary. Test: RDP in, log out of Windows -> tunnel
  closes; reconnect, force-end via portal -> tunnel closes within ~5s; Ctrl-C
  still works.
- **Status:** DEPLOYED 2026-09-03 (CLI published). Awaiting greg live-verify ->
  CLOSED. NOTE: re-install the `passport` binary before testing.

## I4 — Orphaned OS users/profiles after session end (Windows confirmed; Linux likely)
- **Symptom:** ended sessions on Windows hosts leave old users behind in the
  Windows Users folder (orphaned profiles). Not yet checked on Linux but likely
  present too.
- **Root cause (CONFIRMED):** Windows cleanup uses `Remove-LocalUser`, which
  deletes the account object but NOT the `C:\Users\<username>` profile directory
  or the ProfileList registry entry. Windows creates the profile lazily on first
  RDP logon, so any logged-into session orphans a profile. No `Win32_UserProfile`
  removal anywhere. Linux uses `userdel -r` (correct) BUT wraps it in
  `2>/dev/null || true`, which swallows "user in use" failures → best-effort, not
  guaranteed. **The gap exists in TWO files:** `cleanup_user/handler.py`
  (WINDOWS_CLEANUP) AND the duplicate inline cleanup in
  `terminate_session/handler.py` — both must be fixed.
- **Affected:** `terraform/03-api/lambda/cleanup_user/handler.py`,
  `terraform/03-api/lambda/terminate_session/handler.py`.
- **Control/ADR relevance:** **AC-2 / AC-12 (highest)** — the "identity-named
  EPHEMERAL user" claim is the heart of the pitch; a leftover profile is a
  standing account and undermines it.
- **Fix (FIX-READY):** Windows cleanup now removes the profile via
  `Get-CimInstance Win32_UserProfile | Remove-CimInstance` (cleans folder + the
  ProfileList registry entry) + a direct `Remove-Item` backstop, and VERIFIES
  (emits `PORTAL_CLEANUP_OK` / `PORTAL_CLEANUP_INCOMPLETE`, non-zero exit on
  residual). Linux retries `userdel -r` (kill -9 + loop), removes `/home` as a
  backstop, and no longer swallows failures. Applied to BOTH
  `cleanup_user/handler.py` (templates) and `terminate_session/handler.py`
  (inline). `cleanup_user` Lambda now polls `get_command_invocation` (~30s cap)
  and LOGS a residual (AU-6 signal) but still returns success (non-blocking).
  py_compile + template.format() verified. Follow-up (not blocking): dedup the
  two copies into a shared source.
- **Deploy (greg, SoD):** `cd terraform/03-api && AWS_PROFILE=personal-faws terraform apply`
  (re-packages cleanup_user + terminate_session Lambdas). Test: RDP in as a
  fresh user, log out, end session; confirm the account AND `C:\Users\<name>`
  are gone. Repeat forced-end. Linux: SSH, end, confirm `/home/<name>` gone.
- **Status:** DEPLOYED 2026-09-03 (layer 03-api applied). Awaiting greg
  live-verify -> CLOSED.

## I5 — SSH tunnel/session NOT torn down on portal force-end (SSH twin of I3)
- **Symptom (greg live test, 2026-09-03):** killed a session to a Linux EC2 from
  the portal. Portal updated immediately, but the `passport` SSH session stayed
  live and kept accepting input.
- **Root cause (CONFIRMED):** the I3 fix added portal-status polling to the RDP
  path (`holdForRDP`) only. The SSH path (`startInteractiveShell`, tunnel.go)
  ends with `return sess.Wait()` — it blocks ONLY on the local shell exit, with
  no poll of `GET /api/session/{id}`, so a portal/operator force-end never
  reaches the CLI. (The context-gatherer flagged this during I3; it should have
  been fixed for SSH too. My miss.)
- **Affected:** `cli/internal/connection/awsec2/tunnel.go` (startInteractiveShell).
- **Control/ADR relevance:** **AC-12** — a live shell after force-end is
  unterminated privileged access. Highest.
- **Fix (FIX-READY):** `startInteractiveShell` now takes `ctx`, runs
  `sess.Wait()` in a goroutine, and runs a background 5s poll of
  `GET /api/session/{id}` (same mechanism as the RDP fix). On status != ACTIVE it
  closes the SSH conn, which unblocks the shell and triggers `defer Cleanup()`
  (tunnel down). Also tears down on Ctrl-C. Transient API errors don't tear down.
- **Affected:** `cli/internal/connection/awsec2/tunnel.go`.
- **Verified:** go vet clean; builds linux/windows/darwin.
- **Deploy (greg, SoD):** `cd /mnt/c/RGS-Code/FedRAMP-Portal-Idea/cli && ./_make.sh cli && AWS_PROFILE=personal-faws ./publish.sh`, then re-install `passport`. Test: SSH in, force-end via portal -> shell/tunnel close within ~5s.
- **Status:** FIX-READY (awaiting deploy/test)

## I6 — Cannot reconnect after force-ending a session
- **Symptom (greg live test, 2026-09-03):** after killing the session, the SPA
  Connect(SSH) button shows no active session AND a new access request fails to
  create; the old connection remained live.
- **Suspected relationship to I5:** likely PARTLY a symptom of I5 — because the
  SSH session never died, the ephemeral user stayed logged in, so cleanup's
  `userdel` couldn't complete and the session record may be stuck in CLEANING_UP,
  which can wedge subsequent connects. Needs backend trace (create_access_request
  has no existing-session guard by inspection, so the "new request fails" needs
  its actual error confirmed — CloudWatch logs for create-access-request).
- **Root cause (CONFIRMED — a regression from the I1/I2 fix):** the
  `pendingTerminations` suppression I added for I2 was keyed by **instance_id**.
  When you end a session and then create a NEW session on the SAME instance, the
  new session's instance_id is still in the suppression set, so `refresh()` hides
  the new (PENDING/PROVISIONING/ACTIVE) session — the Connect button stays gone /
  the drawer never opens, and it "looks like nothing happened." The BACKEND was
  fine: `create_access_request` has no existing-session guard, provision is
  idempotent, and there is no per-instance mutex — a new connect is accepted.
- **Fix (FIX-READY):** re-keyed `pendingTerminations` from instance_id to
  **request_id**. `removeSession(instanceId, requestId)` now suppresses only that
  specific ended session; a new session on the same instance is unaffected. Also
  guarded the map-drop so it won't delete a newly-created session that reused the
  instance slot. `ConnectButton.onTerminated` passes `activeSession.request_id`.
- **Affected:** `portal/src/api/SessionsContext.tsx`,
  `portal/src/components/ConnectButton.tsx`. Diagnostics clean.
- **Deploy (greg, SoD):** rebuild+deploy the SPA
  (`cd /mnt/c/RGS-Code/FedRAMP-Portal-Idea && AWS_PROFILE=personal-faws ./scripts/deploy-portal.sh`).
  Test: connect, end, immediately reconnect to the SAME instance -> new session
  provisions and shows normally.
- **Control/ADR relevance:** availability of the access path (demo-blocking).
- **Status:** FIX-READY (awaiting deploy/test)

---

## Fix order (worst-compliance-risk first, grouped by root cause)
1. **I4** — orphaned users (AC-2/AC-12). FIX-READY.
2. **I1 + I2** — SPA session-state refresh (one root cause). FIX-READY.
3. **I3** — RDP tunnel teardown (CLI lifecycle). FIX-READY.

All four are FIX-READY (code done + compiled/verified). They require greg to
deploy + live-test (SoD, ADR-0018).

## Deploy runbook (copy-paste; WSL Ubuntu; run one command at a time)

Assumes repo at `/mnt/c/RGS-Code/FedRAMP-Portal-Idea` and `AWS_PROFILE=personal-faws`.
Deploy 1 must finish before its I4 live test; Deploys 2 and 3 are independent
(any order).

### Deploy 1 — I4 (orphaned users): apply layer 03-api
```
cd /mnt/c/RGS-Code/FedRAMP-Portal-Idea/terraform/03-api
AWS_PROFILE=personal-faws terraform plan
AWS_PROFILE=personal-faws terraform apply    # type: yes
```
Expect ONLY in-place updates to `aws_lambda_function.cleanup_user` and
`aws_lambda_function.terminate_session` (new source_code_hash). If the plan shows
anything else (e.g. the state machine), STOP and review before applying.

### Deploy 2 — I1 + I2 (SPA session state): rebuild + deploy the SPA
```
cd /mnt/c/RGS-Code/FedRAMP-Portal-Idea
AWS_PROFILE=personal-faws ./scripts/deploy-portal.sh
```
Watch for `tsc -b` passing (compile gate) and the verify tail: portal 200 /
cli install 302.

### Deploy 3 — I3 (RDP tunnel teardown): rebuild + publish the CLI
```
cd /mnt/c/RGS-Code/FedRAMP-Portal-Idea/cli
./_make.sh cli
AWS_PROFILE=personal-faws ./publish.sh
```
Then re-install the `passport` binary on the machine you test RDP from.

## Live tests (SoD)
- **I4:** RDP into a Windows box (fresh session), log out, end the session in the
  portal. Confirm on the host BOTH the account AND `C:\Users\<username>` are gone.
  Repeat with a forced end. Linux: SSH in, end, confirm `/home/<username>` gone.
- **I1/I2:** Connect, then press End Session ONCE — row returns to Connect and
  stays (no reload, no second click).
- **I3:** RDP in, log out -> tunnel closes; reconnect, force-end via portal ->
  tunnel closes within ~5s; Ctrl-C still works.

Move each to todo.md and mark CLOSED once greg confirms the live test passes.
Record each applied fix in `RELEASE-NOTES.md` (timestamped).
