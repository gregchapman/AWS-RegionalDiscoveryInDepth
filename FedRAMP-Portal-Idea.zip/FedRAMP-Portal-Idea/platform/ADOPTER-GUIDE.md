# Adopter Guide — standing up the platform cold

You are reading this because you are about to deploy this platform, probably into
an AWS Organization, possibly with **no prior context** and no author to ask.
This guide is written for that person. It tells you, in order: what this is, what
you must decide first, what is proven vs not-yet-built, how to deploy the part
that works, and exactly which seams you must fill for a multi-account Org.

Read the whole "Before you touch anything" section before running a single
command. The single most important fact is in it.

---

## 0. The single most important fact

**As shipped, this platform is SINGLE-ACCOUNT. AWS regions stand in for tenants.**
It has been `terraform validate`'d but **never `apply`'d to AWS**.

If your target is a real AWS **Organization** (many member accounts with target
instances in them), the platform **cannot reach member-account instances yet**.
The runtime Lambdas use the deploying account's own credentials and only vary the
region — there is no cross-account role assumption. See **ADR-0033** for the full
analysis and the target model. Section 6 below tells you exactly what to build.

You can still (a) deploy the whole control plane, and (b) run the single-account
profile end-to-end for a demo. You cannot yet manage instances in other accounts
without doing the work in Section 6.

Do not let a clean `terraform plan` fool you into thinking multi-account works —
`plan`/`validate` never exercise the cross-account path, because there isn't one.

---

## 1. What this is (one paragraph)

A zero-trust, ephemeral, identity-attributed access broker for EC2 instances,
built on **SSM Session Manager** (no bastions, no VPN, ever), a **Step Functions
conductor** that provisions an identity-named OS user for a session and verifies
its teardown, a **DynamoDB "score"** that records session state, **KMS** for
credential encryption, an **SSH certificate authority** for passwordless Linux
login, and an **HTTP API + JWT authorizer** front door. The React portal is just
the *reference client* — every capability is reachable by any client the JWT
authorizer accepts (ADR-0026). The whole point of `platform/` (vs the frozen POC
at the repo root) is that you tailor branding, identity source, MFA, portal DNS,
and target clouds **without re-solving NIST 800-53** — the baseline module and
the contracts carry that weight.

---

## 2. Before you touch anything — decisions you must make

| Decision | Options | Where it goes |
|---|---|---|
| **Deployment model** | (a) single-account demo profile [works today] · (b) Org multi-account [needs Section 6 work] | picks your `live/` root |
| **Control-plane account** | Org management · delegated-admin · dedicated tooling account | must have `organizations:ListAccounts` if you want the live accounts list |
| **Identity source** | Cognito (reference, shipped) · your OIDC/SAML IdP | `identity-cognito` module, or swap behind the JWT authorizer inputs (ADR-0028) |
| **MFA** | TOTP (shipped, ON) · your IdP's MFA | inside `identity-cognito` (folded in, not a separate module yet) |
| **Portal domain + cert** | none (use the raw API endpoint) · your domain + ACM cert + Route53 | `api-edge` inputs `portal_domain` / `acm_certificate_arn` / `hosted_zone_id` |
| **Baseline security services** | inherit from Org (leave `enable_*` OFF) · own them here (turn ON) | `_baseline` `enable_*` flags — see Section 5 |
| **name_prefix** | keep `fedramp-platform` · your brand | every module; MUST differ from any co-located POC (`fedramp-portal-*`) |

If you cannot answer "deployment model" yet: start with **(a) single-account
demo** to see it run, then do Section 6 for the Org.

---

## 3. Prerequisites

- Terraform >= 1.5, AWS provider ~> 5.0, the `archive` provider.
- AWS credentials for the chosen control-plane account, and a region.
- Python 3.12 available to (re)build the crypto Lambda layer for the SSH-CA sign
  path. The layer's built wheels are vendored under
  `modules/access-broker/lambda/layers/crypto/python/` (cryptography 50.x, cp312)
  — good enough to `plan`, but **rebuild before a real `apply`** so the wheels
  match your runtime (`modules/access-broker/lambda/layers/build-crypto-layer.sh`;
  see the crypto-layer gotcha in the repo-root `todo.md`).
- If you want the live accounts list: the control-plane account must be the Org
  management account or a delegated admin, or `organizations:ListAccounts` returns
  AccessDenied.
- Target EC2 instances must be **SSM-managed** (SSM agent online, an instance
  profile allowing SSM, and — for member accounts — reachability per Section 6).

---

## 4. Deploy the single-account profile (the part that works today)

This stands the platform up **beside** a frozen POC without collision (distinct
`name_prefix`, own state).

```bash
cd platform/live/poc-commercial
terraform init
terraform plan     # READ the plan. See "What to check in the plan" below.
# terraform apply  # only after the plan is clean and you accept the changes
```

Key inputs (see `live/poc-commercial/variables.tf` for all defaults):
- `region` / `secondary_region` — control-plane region + the second region the
  baseline's two-region detectors cover.
- `target_regions` — the regions `list_instances` enumerates (this is the
  region-as-tenant model; in single-account mode a "customer" is a region).
- `name_prefix` — default `fedramp-platform`. Change to your brand; keep it
  distinct from any co-located POC.
- `portal_domain` / `acm_certificate_arn` / `hosted_zone_id` — optional custom
  domain. Leave empty to use the raw API endpoint.
- `spa_bucket_name` / `spa_bucket_arn` — optional; where the SPA assets live for
  `serve_spa`. Leave empty to deploy the API without SPA serving.

**Flip `ENVIRONMENT` off `dev`/`test`** (via `var.environment`) if you want
`list_accounts` to call real Organizations instead of returning the built-in
SIMULATED_ACCOUNTS. In `dev`/`test` it serves fake accounts by design.

### What to check in the plan
- Everything is named `<name_prefix>-*`. Any "already exists" error = a real
  collision (SSM doc, KMS alias, Cognito domain) with a co-located stack — change
  `name_prefix` or gate the singleton.
- `_baseline` is NOT trying to create a second GuardDuty detector / Config
  recorder if your Org already owns them (see Section 5).
- Rough resource shape: 2 KMS keys, 1 DynamoDB table, Cognito pool+client+domain
  +2 groups, 1 Step Function, ~9 Lambdas, 1 HTTP API + 9 routes, optional custom
  domain + Route53 record. A whole missing module means a wiring problem.

### After apply — initialize the SSH CA
The CA private key is generated **out of band** and imported into Secrets Manager
(it never transits Terraform state). The secret + public-key SSM parameter are
created empty with placeholders. Populate them with the repo's `init-ssh-ca.sh`
pattern (see the POC `scripts/`), targeting the platform's secret name
(`<name_prefix>/ssh-ca-private-key`) and param (`/<name_prefix>/ssh-ca-public-key`).
Until you do, the `/api/sign` passwordless-Linux path will not issue certs.

---

## 5. Baseline security services (`_baseline`) — inherited vs owned

`_baseline` is the non-optional 800-53 baseline, BUT its account-singleton
services are `enable_*`-gated and **default OFF**, because the design assumes the
Org already owns them in the account:

- `enable_guardduty`, `enable_security_hub`, `enable_config`,
  `enable_ssm_session_document` — all default `false`.
- CloudTrail IS always created, but as a **single-account** trail
  (`is_multi_region_trail = true`, but NOT `is_organization_trail`).

Decide per account:
- If your Org **already manages** GuardDuty/Security Hub/Config (delegated admin,
  org trail): leave the flags OFF — you inherit those controls. Record this in
  your inheritance manifest as "inherited from Org."
- If this account must **own** them: turn the relevant flags ON. Turning
  `enable_ssm_session_document` ON when a co-located stack already created the
  named SSM document WILL collide — only one stack per account may own it.
- If you need an **organization** CloudTrail, that is not shipped — it is a
  follow-up (ADR-0033).

---

## 6. Making it work in an AWS Organization (the deferred engineering)

This is the work that is **designed but not built** (ADR-0033). Do not deploy an
Org expecting instance access until these are done. In priority order:

1. **Target-access role in every member account.** Create an IAM role (e.g.
   `<name_prefix>-target-access`) in each member account whose:
   - **trust policy** admits ONLY the control-plane account's Lambda execution
     roles (`<name_prefix>-broker-handler`, `<name_prefix>-provisioner`);
   - **permissions**: `ssm:SendCommand`, `ssm:GetCommandInvocation`,
     `ssm:StartSession`, `ssm:DescribeSessions`, `ssm:TerminateSession`,
     `ssm:GetParameter` (CA pubkey), `ec2:DescribeInstances`, `ec2:DescribeTags`,
     `ssm:DescribeInstanceInformation` — scoped to that account.
   Roll it out with **CloudFormation StackSets** (Org-managed) or an Org-level
   Terraform stack. This is the AWS provider's data-plane contract (ADR-0027).

2. **Cross-account assume in the four runtime handlers.** Retrofit
   `list_instances`, `provision_user`, `cleanup_user`, and the `ssm_credentials`
   tenant re-check to `sts:AssumeRole` into the target-account role for the
   member account being addressed, then build the SSM/EC2 client from those
   credentials — instead of today's ambient, region-only client. Fan out per
   member account, not per region.

3. **Account/OU/Org inputs + a new `live/org-*` root.** Author
   `live/org-commercial/` that takes an account list (or OU / Org id) and either
   cross-account provider aliases or the in-Lambda assume config, and passes the
   target-account role name through to the handlers.

4. **`customer_id` → account id in the identity assertion.** Today tenant
   filtering compares a `customer_id` claim that is never populated with a real
   account id. Map it in Cognito `pre_token_generation` (or your IdP's claim
   mapping) so non-operator users resolve to their member account(s).

5. **Baseline ownership decision per account** + optional organization
   CloudTrail (Section 5).

Until (1)–(4) exist, the honest capability is: **control plane deploys; member
accounts are unreachable.** A half-built cross-account path that silently returns
empty is worse than this documented boundary — which is why it was left
documented, not faked.

---

## 7. What is inherited vs your responsibility (start of the manifest)

Per ADR-0020, every deploy should emit an inheritance manifest. Starting point:

- **Carried by the platform (you inherit):** ephemeral identity-named OS users;
  verified teardown (the conductor, incl. the Linux session-teardown and Windows
  disconnected-session cleanup fixes); passwordless Linux via SSH CA; credential
  encryption (KMS); attributable SSM commands; JWT-gated API; the `_baseline`
  controls you enable.
- **Your responsibility:** the IdP and its assurance level (if you swap Cognito);
  MFA enforcement if using an external IdP; branding + portal DNS + cert; the
  target-access role rollout + cross-account wiring (Section 6); baseline
  ownership decisions (Section 5); populating the SSH CA; SC-7 edge-WAF (a known
  gap — HTTP API v2 can't attach WAFv2; tracked in `ARCHITECTURE-WEAKNESSES.md`).
- **Graded, not certified:** benchmarked against NIST 800-53 as the umbrella over
  IRS-1075/PCI/HIPAA/PII concerns (data tampering/theft/misuse + identity). This
  is "graded against, not certified under" — your ATO is your responsibility.

---

## 8. Where to read more

- `platform/README.md` — the POC-vs-platform hinge + honest 3-track status.
- `docs/TARGET-ARCHITECTURE.md` — the three-class module taxonomy + four contracts.
- `.kiro/steering/adr-0033-*` — the Organization deployment model + this gap.
- `.kiro/steering/adr-0026..0032` — contract-first platform, provider abstraction,
  identity-by-assurance, boundaries/profiles, layer coupling, phased delivery,
  non-disruptive parallel deploy.
- Each `platform/modules/*/PROVENANCE.md` — what was reused from the POC verbatim
  vs re-authored, per module.
- Repo-root `todo.md` — living state; the "START HERE" section is newest-first.


---

# CloudFormation delivery — the ordered deploy (ADR-0035 / ADR-0036)

> **This is the delivery path.** Per ADR-0036 the platform ships as CloudFormation
> (the `platform/cfn/` templates). The `platform/modules/` + `platform/live/`
> Terraform is a superseded reference, not the delivery. All six templates
> `cfn-lint` clean. Nothing here has been deployed to AWS yet (SoD: you deploy).

## Roles in the model (institution-neutral)

- **Control account** — hosts the control plane (API, conductor, Cognito/IdP,
  score, KMS, broker). May be the Org management account, a delegated-admin
  account, or a dedicated tooling account. Needs `organizations:ListAccounts` if
  you want the live accounts list.
- **Member accounts** — hold the target instances. Each gets the deterministic
  **target-access role** the control plane assumes (ADR-0033).
- **Operators / Tenants** — the two Cognito groups (control-relationship roles,
  not brand terms). Operators manage across tenants; Tenants are scoped.

## Prerequisites

- CloudFormation StackSets enabled with **service-managed permissions**
  (Organizations trusted access + a delegated admin, or run from the management
  account). This is how member templates reach every account by OU and
  auto-enroll new accounts.
- An **artifact S3 bucket** in the control account holding the packaged Lambda
  zips, the two layer zips, and the ASL json. Build these from
  `platform/cfn/control-resources/lambda/` (zip each handler dir; zip `shared/`
  and `layers/crypto/` as layers; rebuild the crypto layer for the runtime first
  — see the crypto-layer note in the repo-root `todo.md`).
- A consistent **NamePrefix** (default `fedramp-platform`) used across every
  stack/StackSet so the deterministic ARNs line up.

## The order (STRICT — no cross-StackSet DependsOn; a role must exist before
anything that assumes it). This is ADR-0035 §7 made concrete.

**Step 1 — member-iam StackSet (per OU).** Creates the target-access role +
optional log-forwarder role in every member account.

```
aws cloudformation create-stack-set \
  --stack-set-name <NamePrefix>-member-iam \
  --template-body file://platform/cfn/member-iam/target-access-role.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --permission-model SERVICE_MANAGED \
  --auto-deployment Enabled=true,RetainStacksOnAccountRemoval=false \
  --parameters ParameterKey=ControlAccountId,ParameterValue=<CONTROL_ACCT> \
               ParameterKey=NamePrefix,ParameterValue=<NamePrefix>
# then create stack instances targeting your OU(s):
aws cloudformation create-stack-instances \
  --stack-set-name <NamePrefix>-member-iam \
  --deployment-targets OrganizationalUnitIds=<OU_ID> \
  --regions <HOME_REGION>
```

**Step 2 — member-resources StackSet (per OU).** Per-account log group +
subscription filter to the control sink. Same StackSet pattern, template
`platform/cfn/member-resources/log-forwarding.yaml`, pass `LogDestinationArn`
(the control-account sink) + `LogForwarderRoleName` (from step 1).

**Step 3 — control-iam stack (control account).** The control-plane roles.

```
aws cloudformation deploy \
  --stack-name <NamePrefix>-control-iam \
  --template-file platform/cfn/control-iam/control-plane-roles.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameter-overrides NamePrefix=<NamePrefix>
```

**Step 4 — control-resources: foundation, then application, then routes.**

```
# 4a foundation (KMS/DDB/SSH-CA/SPA/Cognito). Needs the pre-token zip in S3.
aws cloudformation deploy --stack-name <NamePrefix>-foundation \
  --template-file platform/cfn/control-resources/foundation.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameter-overrides NamePrefix=<NamePrefix> \
      PreTokenGenS3Bucket=<ARTIFACT_BUCKET>

# 4b application (layers/Lambdas/conductor/API/authorizer/stage).
aws cloudformation deploy --stack-name <NamePrefix>-application \
  --template-file platform/cfn/control-resources/application.yaml \
  --parameter-overrides NamePrefix=<NamePrefix> \
      LambdaS3Bucket=<ARTIFACT_BUCKET> \
      TargetRegions=<r1,r2>

# 4c routes (integrations/routes/permissions) - pass the API id, authorizer id,
#     execution ARN, and the nine function ARNs+names from 4b's outputs/console.
aws cloudformation deploy --stack-name <NamePrefix>-application-routes \
  --template-file platform/cfn/control-resources/application-routes.yaml \
  --parameter-overrides ApiId=... AuthorizerId=... ApiExecutionArn=... <9x ARNs+names>
```

**Step 5 — initialize the SSH CA + finish log aggregation.** Populate the
Secrets Manager secret (`<NamePrefix>/ssh-ca-private-key`) and the SSM param
(`/<NamePrefix>/ssh-ca-public-key`) out of band (the POC `init-ssh-ca.sh`
pattern). Confirm the member subscription filters are delivering to the control
sink and the dashboard lights up.

New accounts joining the OU inherit steps 1–2 automatically (service-managed
StackSets). The control plane reaches them by constructing their target-access
ARN from the deterministic name — no control-plane redeploy.

## When IAM fails with "already exists" (ADR-0035)

This is expected during IAM evolution with deterministic names. Do NOT randomize
names. Instead **import the existing resource** into the StackSet (resource
import) rather than recreate, and keep the IAM template additive. Because IAM is
its own thin StackSet, the blast radius is small and the compute stacks are
unaffected.

## Cross-account reach status (ADR-0033) — READ THIS

The control-plane handlers reach member-account instances by assuming the
target-access role via `portal_utils.target_client(...)`. This is **wired as a
reference in `list_instances`** and the **mechanism is complete**, but the other
three instance-touching handlers (`provision_user`, `cleanup_user`,
`ssm_credentials`) still need the same one-line switch + a `target_account_id`
threaded from the request/record. See
`platform/cfn/control-resources/lambda/PORTING-NOTES.md`. Until that is finished
and tested against a real Org, treat member-account provisioning/cleanup as
NOT-YET-FUNCTIONAL — the single-account path works, the multi-account write path
does not. This was left as a testable step precisely because it cannot be
validated without Org access.

## CloudTrail

Consolidated CloudTrail is inherited, not built here (ADR-0035 §5): configure an
organization trail, or let Control Tower do it. This platform does not create a
trail.
