# Platform — the productizable, contract-first build

> **You have seen the POC (`../POC-equivalent`: the `cli/`, `portal/`,
> `scripts/`, `terraform/` at the repo root). This is different.**
>
> The **POC** answers *"Try it. Get it running. See what it does."* It is a
> single, opinionated, working reference on AWS Commercial. It is deliberately
> NOT built to be re-branded, re-hosted, or extended to other clouds/IdPs — once
> an adopter gets serious, the POC is no longer fit for purpose.
>
> **`platform/` answers *"Now build your own."*** It is the contract-first,
> module-composed version an adopter tailors to their branding, their DevOps,
> their IdP, their target clouds — WITHOUT giving up the security posture and the
> 800-53 alignment, and WITHOUT re-solving the problems the POC already debugged
> (session lifecycle conductor, verified teardown, operator lens, tenant
> isolation, attributed C2 plane).

> **DEPLOYING THIS? START WITH [`ADOPTER-GUIDE.md`](./ADOPTER-GUIDE.md).** It is
> written for someone standing this up cold, tells you what works today
> (single-account) vs what an AWS Organization needs (not yet built — see
> [ADR-0033](../.kiro/steering/adr-0033-organization-deployment-model.md)), and
> what is inherited vs your responsibility. **Read section 0 before running
> anything:** as shipped this is single-account (regions = tenants) and has never
> been applied to AWS.

Design narrative: `../docs/TARGET-ARCHITECTURE.md`. Decisions: the ADR cluster in
`../.kiro/steering/` (ADR-0026–0033 govern this build; ADR-0011/0012/0014/0016/
0019/0021/0022/0023/0024/0025 carry forward). Compliance status of what exists:
`../docs/ARCHITECTURE.md` §8.

## The promise (read this first)

**You are buried under the 800-53 mountain. This platform carries that weight so
you do not have to.**

Adopt it and you inherit — by construction, not by your own effort — the controls
this design already implements and this project already debugged: an attributed
command-and-control plane (ADR-0024), reliable *verified* session termination
(ADR-0023), zero-inbound access (ADR-0006), tenant isolation (ADR-0021),
credential-less brokered access (ADR-0012), and the rest of the §8 posture. You
bring the parts that are genuinely YOURS — your branding, your front end, your
identity source, your DevOps pipeline, your target clouds — and plug them in
BEHIND the four published contracts and ABOVE the security baseline.

What that means concretely:
- The **security / 800-53 baseline is composed automatically** into every
  deployment profile (`modules/_baseline/`). It is not an optional module and
  there is no supported way to deploy without it.
- The **contracts refuse configurations that would weaken a control** — e.g. an
  identity implementation that can't assert an assurance level, or a provider
  whose `connect` isn't attributable + terminable, does not satisfy the contract.
- You get a **legible inheritance boundary**: the platform tells you which
  controls you INHERIT and which remain YOUR responsibility (the
  customer-responsibility side is never zero — ADR-0020). No false assurance.

So the pitch to an adopter drowning in an ATO effort is exactly: *"Here's this
thing. Don't worry about the 800-53 mountain — the contract ensures you don't
have to re-climb it. Here's how to make the rest of it yours."*

## The non-negotiable principle — three classes

See `../docs/TARGET-ARCHITECTURE.md` §1a for the full statement. In short:

1. **INVARIANT CORE (gold; no swap seam).** SSM Session Manager is THE access
   path (no bastions/VPN — ever); the orchestration engine (conductor, Lambdas,
   keys, the "score") is the Passport V2 capability. Not replaceable.
2. **COMPLIANCE BASELINE (required, inherited, graded).** `modules/_baseline/` —
   attributed C2 plane (ADR-0024), tenant isolation (ADR-0021), verified teardown
   (ADR-0023), zero-inbound (ADR-0006), audit/evidence. Composed into every
   profile; not opt-out.
3. **CUSTOMER-OWNED (replaceable behind contracts; anti-lock-in).** Branding /
   SPA / front end, IdP, MFA mechanism, domain/DNS/cert, region + OU scope. Swap
   these WITHOUT touching Class 1 or weakening Class 2.

**The bright line:** no customization may route access around SSM Session Manager
or bypass the orchestration/compliance core. The contracts enforce it (the
Provider `connect` has no "via bastion/VPN" option). Benchmark = NIST 800-53 as
the umbrella that subsumes the common concerns of IRS-1075 / PCI / HIPAA / PII /
FTS (data tampering/theft/misuse + identity); see `../docs/TARGET-ARCHITECTURE.md`
§1b.

```
   Adopter customizes  ──►  SPA / front end (any consumer of the Consumer API)
                            IdP + MFA source (behind the Identity assertion)
                            Providers (AWS / vCenter / Azure / GCP)
                            Branding, DevOps, deployment profile
   ────────────────────────────────────────────────────────────────
   Always inherited    ──►  Security + 800-53 baseline (required modules)
                            Attributed C2 plane · tenant isolation ·
                            verified teardown · zero-inbound · audit/evidence
```

## Layout

```
platform/
  README.md                     ← this file (the POC-vs-platform hinge)
  contracts/                    ← the product surface (published, versioned)
                                  PROVISIONAL CONTRACTS — deployment pressure-test remains
    openapi/consumer-api.v1.yaml    ← consumer, evidence, and review paths
    schemas/*.schema.json           ← resource, identity, evidence, and claim schemas
    schemas/*.md                    ← contract descriptors and examples
    provider-contract.md            ← provider-neutral connection contract
  modules/                      ← reusable Terraform building blocks
                                  (IMPLEMENTED; reuse POC code verbatim;
                                   `terraform validate` clean, not yet applied)
    _baseline/                  ← Class 2 REQUIRED security/compliance (not opt-out)
    kms/                        ← Class 1 core: credentials + SSH-CA keys
    data-score/                 ← Class 1 core: the session record (DynamoDB "score")
    workflow-engine/            ← Class 1 core: the conductor (ADR-0023; carries I8/I10)
    access-broker/              ← Class 1 core: the SSM access path (ADR-0012/0014/0024/0025)
    identity-cognito/           ← Class 3 customer-owned: reference IdP (ADR-0028)
    api-edge/                   ← Class 2: the Consumer API front door + JWT authorizer
  live/                         ← root deployments that COMPOSE modules
    poc-commercial/             ← IMPLEMENTED module-composed equivalent that stands
                                  up BESIDE the running POC (own state, distinct
                                  names) — `terraform validate` clean, not yet applied
    govcloud-dev/  govcloud-test/  govcloud-prod/   ← future profiles
```

**Not yet broken out as separate modules (folded in for this pass):** the
taxonomy in `../docs/TARGET-ARCHITECTURE.md` names Class 3 `mfa`, `portal-runtime`,
`edge-dns`, and `provider-aws` modules. For now: MFA lives inside
`identity-cognito`; the SPA-serving + custom-domain/DNS live inside `api-edge`
(behind the same inputs, documented in `api-edge/PROVENANCE.md`); `provider-aws`
is implicit (this build is AWS-only until a second provider — vCenter — proves the
Provider contract, ADR-0031). Identity is also Cognito-only at runtime today;
multi-IdP SAML/OIDC support is an explicit extensibility target under ADR-0038.
AWS access remains AD-optional; AD trust is a provider-specific transitional
option. Splitting these concerns into standalone swappable modules is future
work and does not change the composed behavior.

## Relationship to the running POC (important)

`platform/live/poc-commercial/` is a NEW, independently-stated deployment that
composes `platform/modules/`. It is authored to stand up ALONGSIDE the current
POC (the root `terraform/` stack) using its own Terraform state and distinct
resource names — so building and testing `platform/` never disturbs the running
POC demo. The POC stays deployed and runnable as-is; cutover (or coexistence as
"demo" vs "platform") is a deliberate later decision, not a side effect.

The `platform/modules/` are authored FRESH by extracting the proven PATTERNS from
the POC code — they are NOT created by moving the POC's live Terraform state.
That keeps the POC untouched and gives the platform a module-first structure from
day one.

## Status (as of 2026-09-09)

> **IaC UPDATE (ADR-0036):** the delivery is now **CloudFormation** in
> [`cfn/`](./cfn/) (all six templates `cfn-lint` clean; ordered runbook in
> [`ADOPTER-GUIDE.md`](./ADOPTER-GUIDE.md)). The Terraform in `modules/` and
> `live/` is **superseded for delivery** — retained as a validated reference for
> the CFN port, not deleted. Where the text below says "Terraform," read it as the
> reference implementation; the shipping form is CFN.

Read this as three separate tracks — they are at different maturities, and
conflating them is how "ready" gets misread.

**1. Modules — IMPLEMENTED.** All eight modules under `modules/` are written,
reuse the POC's proven application code and bug fixes BYTE-FOR-BYTE (only the
Terraform packaging was re-authored, per ADR-0032), and pass `terraform validate`
both individually and composed. Each has a `PROVENANCE.md` recording what was
reused vs re-authored.

**2. Reference deployment — VALIDATED, NOT YET DEPLOYED.**
`live/poc-commercial/` composes all eight modules and `terraform validate`
returns clean (the full cross-module graph resolves; no cycles). It has NOT been
`terraform plan`'d or `apply`'d against AWS. `validate` does not catch name
collisions, provider-side rejections, or runtime issues — so "stands up" is
unproven until the plan/apply runs (greg, per the ADR-0018 SoD split).

**3. Contracts — PROVISIONAL, machine-readable foundation present.** The four
published contracts are what an adopter builds against (their SPA behind the
Consumer API; their IdP behind the identity assertion; their provider behind
the Provider contract). Resource, identity, evidence, and control-claim JSON
Schemas now exist, and the OpenAPI surface includes evidence and human review.
The contracts remain provisional until a real Organization and second provider
pressure-test them; they are no longer documentation-only skeletons.

**Fitness, stated plainly:**
- READY as the **reference implementation for us** to `terraform plan`/`apply`
  and stand up beside the POC.
- NOT YET READY to hand to a **third-party adopter** — that still needs (a) a
  successful plan/apply of the reference deployment, (b) a real Organization
  test, and (c) SAML/OIDC multi-IdP and second-provider pressure tests.

**Next work, in order:** (1) run `terraform plan` on `live/poc-commercial/`
against the target account and report collisions/errors; (2) finalize
`contracts/openapi/consumer-api.v1.yaml` + real JSON Schemas for the resource and
identity-assertion models; (3) optional: split the folded-in Class 3 modules.
