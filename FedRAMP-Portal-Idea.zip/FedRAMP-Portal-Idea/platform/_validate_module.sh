#!/usr/bin/env bash
# Validate a single platform module in isolation.
# Usage: bash _validate_module.sh <module> [providers-map]
#   bash _validate_module.sh kms
#   bash _validate_module.sh _baseline "aws.region_a = aws.ra, aws.region_b = aws.rb"
set -uo pipefail
MOD="${1:?module name required}"
PROVMAP="${2:-}"
ROOT=/mnt/c/RGS-Code/FedRAMP-Portal-Idea/platform
MODPATH="$ROOT/modules/$MOD"
[ -d "$MODPATH" ] || { echo "no such module: $MODPATH"; exit 3; }

echo "=== terraform fmt $MOD ==="
( cd "$MODPATH" && terraform fmt . )

tmp=$(mktemp -d)
cat > "$tmp/main.tf" <<HARNESS
terraform {
  required_providers {
    aws     = { source = "hashicorp/aws", version = "~> 5.0" }
    archive = { source = "hashicorp/archive", version = "~> 2.0" }
  }
}
provider "aws" {
  region = "us-east-1"
}
provider "aws" {
  alias  = "ra"
  region = "us-east-2"
}
provider "aws" {
  alias  = "rb"
  region = "us-west-1"
}
module "m" {
  source = "$MODPATH"
$( [ -n "$PROVMAP" ] && echo "  providers = { aws = aws, $PROVMAP }" )
$( [ -f "$MODPATH/.validate_args.hcl" ] && cat "$MODPATH/.validate_args.hcl" )
}
HARNESS

( cd "$tmp" && terraform init -backend=false -input=false >/tmp/tfinit_$MOD.log 2>&1 && terraform validate )
rc=$?
[ $rc -ne 0 ] && { echo "--- init log tail ---"; tail -20 /tmp/tfinit_$MOD.log; }
rm -rf "$tmp"
echo "validate-rc=$rc"
