# platform/cfn — CloudFormation delivery (ADR-0036)

This is the delivery form of the platform. Per **ADR-0036** the whole delivery is
CloudFormation; Terraform is retired for delivery (the `platform/modules/` +
`platform/live/` Terraform remains as a validated reference, marked superseded —
not deleted). Per **ADR-0035** the deployment is two planes across four template
families, and **IAM is never in the same template as resources**.

Everything here is authored to be **truly variable-driven** — zero dependency on
any corporate or institutional identity. All names, accounts, regions, domains,
and roles are parameters with generic defaults.

## The four families (ADR-0035 matrix)

|                          | IAM layer                                  | Resource layer                                      |
|--------------------------|--------------------------------------------|-----------------------------------------------------|
| **Control account** (single stack) | `control-iam/`                    | `control-resources/`                                |
| **Member accounts** (StackSet, by OU) | `member-iam/`                  | `member-resources/`                                 |

- `member-iam/` — the deterministic **target-access role** (ADR-0033) each member
  account exposes for the control plane to assume, plus cross-account
  log-forwarding IAM. Distributed by **service-managed StackSet**, targeted at
  OUs, auto-enrolls new accounts.
- `member-resources/` — per-account footprint (CloudWatch Logs config /
  subscription-filter forwarders to the control-account sink). StackSet.
- `control-iam/` — the control-plane roles (broker-handler, provisioner,
  sfn-exec, session-broker, reader, spa). Single stack in the control account.
- `control-resources/` — the application: KMS, DynamoDB score, Cognito, Lambdas +
  layers, the Step Functions conductor, HTTP API + authorizer + routes, SPA
  serving, the unified dashboard. Single stack (or nested) in the control account.

## Non-negotiable rules (ADR-0035)

1. **IAM never with resources.** Primary reason: StackSets + named IAM produce
   "IAM ... already exists" failures on permission / IAM-resource-type /
   service-API changes; StackSet ops are not transactional across accounts, so
   you chase failed operation instances per account. Isolating IAM means the
   fragile create-surface is touched rarely and the blast radius is one thin,
   importable StackSet. Never add an `AWS::IAM::*` resource to a resource
   template as a shortcut.
2. **Deterministic IAM names, no CFN random suffix.** The control plane constructs
   member role ARNs from the name (`arn:${partition}:iam::${member}:role/<prefix>-target-access`)
   without reading them back (ADR-0033 cycle-break). This is exactly what removes
   CFN's collision-avoidance, which is *why* rule 1 is mandatory. Manage
   collisions by process: **import over recreate**; keep IAM templates additive.
3. **Sequenced deploy (no cross-StackSet DependsOn).** A role must exist before
   anything that assumes/references it:
   `member-iam → member-resources → control-iam → control-resources → log-aggregation`.
   The literal runbook is in `../ADOPTER-GUIDE.md`.

## Vocabulary (institution-neutral)

Roles in the control relationship, per the contract (ADR-0028) — all parties are
themselves bound by the controls:
- **Operators** — manage what others may see/do (multi-tenant).
- **Tenants** — the managed, scoped parties.
No vendor/brand terms. (The retired Terraform + the frozen POC still use the older
`Rackers`/`Customers` labels; the CFN delivery uses `Operators`/`Tenants`.)

## Authoring form

Raw CloudFormation YAML (consumed natively by StackSets). CDK-synth-to-CFN is
permissible for the control plane, but the shipped artifact is CFN either way.

## Status

TEMPLATES COMPLETE + `cfn-lint` CLEAN (all six). Not yet deployed to AWS (SoD,
ADR-0018 — the operator deploys). The ordered deploy runbook is in
`../ADOPTER-GUIDE.md`.

Files:
- `member-iam/target-access-role.yaml`
- `member-resources/log-forwarding.yaml`
- `control-iam/control-plane-roles.yaml`
- `control-resources/foundation.yaml`
- `control-resources/application.yaml`
- `control-resources/application-routes.yaml`
- `control-resources/lambda/**` — ported handlers (Operators/Tenants vocabulary;
  `py_compile` clean) + `PORTING-NOTES.md` (the ADR-0033 cross-account reach: the
  `target_client` mechanism is done and wired as a reference in `list_instances`;
  three handlers await the same one-line switch + a real Org to test).

KNOWN NOT-DONE (honest): the cross-account write path (provision/cleanup/
ssm-credentials) is not fully wired — see PORTING-NOTES.md. Single-account works;
multi-account writes need the reference pattern applied + Org testing.
