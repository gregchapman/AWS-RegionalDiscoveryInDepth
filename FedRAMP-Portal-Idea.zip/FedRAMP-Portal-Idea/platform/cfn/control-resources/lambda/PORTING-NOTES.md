# Lambda porting notes — CFN control-resources

These handlers are the POC's proven code, ported for the CloudFormation delivery
(ADR-0036). App logic + bug fixes (I8/I10/ADR-0023, ADR-0012/0014/0024/0025) are
BYTE-FOR-BYTE the POC's; only the two changes below were made here.

## 1. Vocabulary rename (DONE, verified)

`Rackers` -> `Operators`, `is_racker` -> `is_operator`, `"Customers"` ->
`"Tenants"` across all handlers (9 files changed). The operator ROLE label is now
institution-neutral (ADR-0028 / ADR-0036). All 13 handlers `py_compile` clean.

**Intentionally NOT renamed:** `customer_id` — it is the internal tenant-scoping
CLAIM/attribute/DDB-field name, not a brand term. The Cognito custom attribute in
`../foundation.yaml` is `custom:customer_id` to match. A future `customer_id` ->
`tenant_id` data-model rename is possible but is a wider change (claim + attribute
+ DDB field + trigger) and was deliberately left out of this pass.

## 2. Cross-account reach (ADR-0033) — MECHANISM done, wiring PARTIALLY applied

`shared/python/portal_utils.py` now provides `target_client(service, region,
target_account_id="")`:
- No `target_account_id` (or same as the control account) -> ambient client,
  region only = the ORIGINAL single-account behavior, unchanged.
- A member `target_account_id` -> assumes
  `arn:<partition>:iam::<account>:role/<TARGET_ACCESS_ROLE_NAME>` (the
  member-iam StackSet role) and builds the client from the vended creds. Caches
  per (account, region) for the invocation.

**Reference wiring applied:** `list_instances/handler.py` — `get_instance_details`
now takes `target_account_id` and uses `target_client`. This is the pattern.

### REMAINING WIRING (deliberate follow-up — NOT blind-edited)

The other three instance-touching handlers still call `boto3.client("ssm"|"ec2",
region_name=region)` directly and must be switched to `target_client(...)` with a
member `target_account_id` threaded from the request/record:

- `provision_user/handler.py` — the SSM client that runs SendCommand on the
  target instance.
- `cleanup_user/handler.py` — the SSM client for teardown + tunnel termination.
- `ssm_credentials/handler.py` — the EC2 tenant re-check client, and the vended
  session policy's instance ARN (already wildcard-account, but the assume path
  should target the member).

Also: the ACCOUNT the target instance lives in must be threaded through. Options:
carry `target_account_id` on the access-request record (written at create time
from the resource's account), and/or resolve it from the resource id. `list_accounts`
already enumerates the Org; that account id is the scoping key.

**Why left as a follow-up, not done blind:** these three carry the hard-won
I8/I10/ADR-0023 fixes and CANNOT be runtime-tested without a real AWS Organization
(no access today, SoD). Per ADR-0033, a documented seam beats a half-wired
cross-account path that silently returns empty or mis-scopes. The mechanism is in
place and one reference handler shows the exact change; completing the other three
is a mechanical, TESTABLE step once an Org is reachable.

## Deployment packaging

Each handler dir is zipped to the `LambdaS3Bucket` keys referenced by
`../application.yaml` (e.g. `create-access-request.zip`). The `shared/` and
`layers/crypto/` trees are the two Lambda layers. `pre_token_generation` is
referenced by `../foundation.yaml`. Rebuild the crypto layer for the runtime
before a real deploy (see repo-root todo.md crypto-layer note).
