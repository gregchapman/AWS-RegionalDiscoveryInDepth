"""Lambda: cleanup_user (invoked by Step Function)

Region-aware SSM user cleanup. Removes the ephemeral OS user (and, on Windows,
the profile + hive) from the target instance and returns a VERIFIED result.

CONTRACT (ADR-0023): this is NOT fire-and-forget. It returns
`verified in {"OK","INCOMPLETE"}` — "OK" ONLY when the OS user + profile + any
lingering login session are confirmed gone; otherwise "INCOMPLETE" (never None).
The conductor treats INCOMPLETE as a failure and retries, ultimately routing to
the terminal CLEANUP_FAILED rather than a silent COMPLETED. Only the SSM TUNNEL
teardown (teardown_tunnels) is genuinely best-effort and does NOT gate `verified`
— a lingering tunnel is harmless once the OS user is gone. (This function always
RETURNS a dict so the state machine transition succeeds; "success of the Lambda"
is distinct from "the cleanup was verified" — the latter is carried in `verified`.)

Input (from Step Function):
  {
    "instance_id": "i-...",
    "region": "us-east-2",
    "access_type": "ssh" | "rdp",
    "username": "greg-racker-xxxx"
  }
"""

import boto3
import logging

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)


LINUX_CLEANUP = """#!/bin/bash
# Cleanup mirrors provision (useradd -m). We must GUARANTEE the account AND its
# home dir are gone (AC-2/AC-12: the ephemeral user must not persist). We do NOT
# blanket-suppress errors — a "user in use" failure must be retried, not hidden,
# or an orphaned account is left behind (the I4 bug).
USERNAME="{username}"

# The ephemeral user's LOGIN SESSION (sshd + shell) keeps the account "busy",
# so a naive userdel fails with "user currently used by process N" and the
# account survives — that was the real two-click bug: the first terminate ran
# while the SSH session was still established, userdel refused, and the session
# lived on. We must authoritatively END the login session BEFORE userdel:
#   1) lock the account so no NEW logins,
#   2) systemd: terminate the whole user (kills the session scope + lingering),
#   3) kill any remaining processes (TERM then KILL),
#   4) THEN userdel, with retries.
usermod -L "$USERNAME" 2>/dev/null || true

# systemd-managed session teardown (Amazon Linux 2023 / modern distros). This
# kills the user's session scope including the sshd-owned session leader that
# pkill -u often can't reach.
loginctl terminate-user "$USERNAME" 2>/dev/null || true
sleep 1

pkill -TERM -u "$USERNAME" 2>/dev/null || true
sleep 2
pkill -KILL -u "$USERNAME" 2>/dev/null || true
sleep 1

# Remove the account + home dir (-r). --force lets userdel proceed even if a
# process is still (briefly) running as the user. Retry escalating if needed.
for attempt in 1 2 3 4; do
  if ! id "$USERNAME" >/dev/null 2>&1; then
    break
  fi
  userdel -r -f "$USERNAME" 2>/tmp/portal_userdel.err && break
  # Still here -> kill harder (systemd + KILL) and retry.
  loginctl terminate-user "$USERNAME" 2>/dev/null || true
  pkill -KILL -u "$USERNAME" 2>/dev/null || true
  sleep 2
done

# Belt-and-suspenders: if the account is gone but the home dir somehow remains,
# remove it explicitly.
if [ -d "/home/$USERNAME" ]; then
  rm -rf "/home/$USERNAME" 2>/dev/null || true
fi

rm -f /etc/ssh/sshd_config.d/99-portal.conf
systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true

if id "$USERNAME" >/dev/null 2>&1 || [ -d "/home/$USERNAME" ]; then
  echo "PORTAL_CLEANUP_INCOMPLETE $USERNAME"
  cat /tmp/portal_userdel.err 2>/dev/null || true
  exit 1
fi
echo "PORTAL_CLEANUP_OK $USERNAME"
"""

WINDOWS_CLEANUP = """
$ErrorActionPreference = "Continue"
$Username = "{username}"

# ROOT CAUSE of the I10 orphaned-account bug: an ended RDP session usually ends
# up DISCONNECTED (state "Disc"), not logged off. A disconnected session keeps
# the user's profile hive LOADED and the account "in use", so Remove-LocalUser
# silently fails and the account survives. The prior logoff step parsed `quser`
# text, whose columns SHIFT for a Disc row (blank SESSIONNAME), so it often
# missed the session id and never logged the user off. We now resolve the
# account's SID and force-log-off EVERY session bound to that SID, then unload
# the hive by SID, BEFORE deleting the account. And we make verification
# trustworthy: OK is emitted ONLY when the account, every session, the profile
# folder, and the ProfileList registry key are all gone (AC-2).

# --- resolve the account SID (needed for hive unload + session match) ---
$acct = Get-LocalUser -Name $Username -ErrorAction SilentlyContinue
$sid = $null
if ($acct) {{ $sid = $acct.SID.Value }}
if (-not $sid) {{
    # Account object already gone; try to recover the SID from ProfileList so we
    # can still finish profile/hive teardown.
    $pl = Get-ChildItem 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\ProfileList' -ErrorAction SilentlyContinue |
        Where-Object {{ (Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue).ProfileImagePath -like "*\\$Username" }}
    if ($pl) {{ $sid = $pl.PSChildName }}
}}

# --- force-logoff ALL sessions for this account (connected OR disconnected) ---
# Use `query session` and match the USERNAME column reliably; a Disc row still
# lists the username and id. Log off each id we find for this user.
$qs = (query session 2>$null)
foreach ($row in $qs) {{
    # Rows look like: ">rdp-tcp#0  greg-racker-xxxx  18  Active" or for Disc:
    # "                greg-racker-xxxx  15  Disc". Split on whitespace and, if
    # the username token is present, take the first integer token as the id.
    $t = ($row -replace '^>', '') -split '\\s+' | Where-Object {{ $_ -ne '' }}
    if ($t -contains $Username) {{
        $sessId = $null
        foreach ($tok in $t) {{ if ($tok -match '^[0-9]+$') {{ $sessId = $tok; break }} }}
        if ($sessId) {{ logoff $sessId 2>$null }}
    }}
}}

# Kill any lingering processes owned by the user so the hive can unload.
Get-Process -IncludeUserName -ErrorAction SilentlyContinue |
    Where-Object {{ $_.UserName -and $_.UserName.EndsWith("\\$Username") }} |
    Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3

# --- unload the profile hive (HKU\\<SID>) so the account is no longer in use ---
if ($sid) {{
    # reg unload fails harmlessly if the hive isn't loaded.
    reg unload "HKU\\$sid" 2>$null | Out-Null
    Start-Sleep -Seconds 1
}}

# --- 1) delete the local account, CAPTURING any error (do NOT swallow) ---
$acctErr = $null
if (Get-LocalUser -Name $Username -ErrorAction SilentlyContinue) {{
    try {{ Remove-LocalUser -Name $Username -ErrorAction Stop }}
    catch {{ $acctErr = $_.Exception.Message; Write-Output ("ACCT_REMOVE_ERR " + $acctErr) }}
}}

# --- 2) remove the profile (folder + ProfileList registry) via CIM ---
$profiles = Get-CimInstance -ClassName Win32_UserProfile -ErrorAction SilentlyContinue |
    Where-Object {{ $_.LocalPath -and (Split-Path $_.LocalPath -Leaf) -eq $Username }}
foreach ($p in $profiles) {{
    try {{ Remove-CimInstance -InputObject $p -ErrorAction Stop }}
    catch {{ Write-Output ("PROFILE_REMOVE_RETRY " + $_.Exception.Message) }}
}}

# --- 3) belt-and-suspenders: remove the folder + any stale ProfileList key ---
$profileDir = Join-Path $env:SystemDrive ("Users\\" + $Username)
if (Test-Path $profileDir) {{
    Remove-Item -LiteralPath $profileDir -Recurse -Force -ErrorAction SilentlyContinue
}}
if ($sid) {{
    Remove-Item -LiteralPath ("HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\ProfileList\\" + $sid) -Force -ErrorAction SilentlyContinue
}}

# --- 4) HONEST verification (AC-2). OK only if EVERYTHING is gone. ---
# A lingering session (even Disc) or a still-present account means NOT clean.
$acctGone = -not (Get-LocalUser -Name $Username -ErrorAction SilentlyContinue)
$dirGone  = -not (Test-Path $profileDir)
$sessionGone = $true
$qs2 = (query session 2>$null)
foreach ($row in $qs2) {{
    $t = ($row -replace '^>', '') -split '\\s+' | Where-Object {{ $_ -ne '' }}
    if ($t -contains $Username) {{ $sessionGone = $false }}
}}
if ($acctGone -and $dirGone -and $sessionGone) {{
    Write-Output "PORTAL_CLEANUP_OK $Username"
}} else {{
    Write-Output ("PORTAL_CLEANUP_INCOMPLETE " + $Username + " acctGone=" + $acctGone + " dirGone=" + $dirGone + " sessionGone=" + $sessionGone)
    exit 1
}}
"""


def teardown_tunnels(ssm, instance_id, username):
    """Concern (d): tear down any live SSM port-forward tunnel for this session.

    The conductor owns tunnel teardown (ADR-0023) so a server-driven end does
    not depend on the CLI noticing.

    MATCHING (corrected): we terminate every ACTIVE port-forward session whose
    Target is THIS instance. We deliberately do NOT filter on the session Owner:
    the tunnel is opened by the CLI using the VENDED STS credentials, so the SSM
    session's Owner is the assumed-role principal from ssm_credentials — NOT the
    ephemeral OS account (greg-racker-XXXX) we're cleaning up. An earlier
    `username in owner` filter therefore matched nothing (tunnels_terminated
    stayed 0 and the SSH transport survived the server-side end). In this model
    a portal session is single-purpose and one-at-a-time per instance, so any
    active AWS-StartPortForwarding* session to this instance IS this session's
    tunnel, and the session is ending regardless — terminating it is correct.

    (If we ever need to be surgical about which tunnel, record the SSM SessionId
    on the DynamoDB record when the CLI opens it and match on that instead.)

    Best-effort: a lingering tunnel is harmless once the OS user is gone, so this
    does NOT gate cleanup verification; failures are logged only.
    """
    terminated = 0
    try:
        paginator = ssm.get_paginator("describe_sessions")
        for page in paginator.paginate(State="Active"):
            for sess in page.get("Sessions", []):
                if sess.get("Target") != instance_id:
                    continue
                doc = sess.get("DocumentName", "") or ""
                # Only port-forward tunnels (not, say, a shell session an
                # operator opened separately).
                if not doc.startswith("AWS-StartPortForwarding"):
                    continue
                sid = sess.get("SessionId")
                if not sid:
                    continue
                owner = sess.get("Owner", "") or ""
                try:
                    ssm.terminate_session(SessionId=sid)
                    terminated += 1
                    logger.info(
                        f"Terminated SSM tunnel {sid} to {instance_id} "
                        f"(owner={owner}) during cleanup of {username}"
                    )
                except Exception as e:
                    logger.warning(f"Failed terminating SSM tunnel {sid}: {e}")
    except Exception as e:
        # describe_sessions may be denied or throttle — non-fatal (best-effort).
        logger.warning(f"Tunnel teardown enumerate failed (non-fatal): {e}")
    return terminated


def lambda_handler(event, context):
    """Remove the ephemeral user from the target instance + tear down its tunnel."""
    instance_id = event["instance_id"]
    region = event["region"]
    access_type = event.get("access_type", "ssh")
    username = event["username"]
    user_email = event.get("user_email", "unknown")

    ssm = boto3.client("ssm", region_name=region)

    # Concern (d) FIRST: drop the SSM tunnel so the interactive session's
    # transport is severed even before the OS user is removed. Best-effort.
    tunnels_terminated = teardown_tunnels(ssm, instance_id, username)

    if access_type == "rdp":
        document = "AWS-RunPowerShellScript"
        script = WINDOWS_CLEANUP.format(username=username)
    else:
        document = "AWS-RunShellScript"
        script = LINUX_CLEANUP.format(username=username)

    comment = f"portal-cleanup for {user_email} -> {username}"[:100]

    # Best-effort by design (the workflow must complete), but we now VERIFY the
    # result rather than fire-and-forget: the scripts emit PORTAL_CLEANUP_OK on
    # full removal (account + profile/home) or PORTAL_CLEANUP_INCOMPLETE (+ a
    # non-zero exit) if a residual remains. We poll briefly and LOG a residual so
    # it is visible to AU-6 monitoring, without making cleanup fail the workflow.
    # verified is the CONTRACT with the conductor (ADR-0023): "OK" only when the
    # OS user + profile are confirmed gone; "INCOMPLETE" otherwise. We NEVER
    # return None — an unknown result must read as INCOMPLETE so the conductor
    # retries (and ultimately routes to CLEANUP_FAILED rather than a silent
    # COMPLETED). The user/profile removal is the AC-2/AC-12 core that gates
    # verification; tunnel teardown (above) is best-effort and does NOT gate it.
    verified = "INCOMPLETE"
    try:
        resp = ssm.send_command(
            InstanceIds=[instance_id],
            DocumentName=document,
            Parameters={"commands": [script]},
            TimeoutSeconds=60,
            Comment=comment,
        )
        command_id = resp["Command"]["CommandId"]
        logger.info(f"Cleanup command {command_id} sent for {username} on {instance_id}")

        # Verification poll. The hardened Windows script does logoff + hive
        # unload + delete + re-verify with internal waits (~8s), so give the
        # invocation headroom to reach a terminal status (cap ~45s; the
        # conductor retries anyway if this is still INCOMPLETE).
        import time
        for _ in range(15):
            time.sleep(3)
            try:
                inv = ssm.get_command_invocation(
                    CommandId=command_id, InstanceId=instance_id
                )
            except ssm.exceptions.InvocationDoesNotExist:
                continue
            status = inv.get("Status")
            if status in ("Success", "Failed", "Cancelled", "TimedOut"):
                out = (inv.get("StandardOutputContent") or "") + (inv.get("StandardErrorContent") or "")
                if "PORTAL_CLEANUP_OK" in out and status == "Success":
                    verified = "OK"
                    logger.info(
                        f"Cleanup verified for {username} on {instance_id} "
                        f"(tunnels_terminated={tunnels_terminated})"
                    )
                else:
                    verified = "INCOMPLETE"
                    # AU-6 signal: a residual ephemeral user/profile may remain.
                    logger.warning(
                        f"CLEANUP RESIDUAL: {username} on {instance_id} status={status} "
                        f"output={out.strip()[:500]}"
                    )
                break
        else:
            # Poll exhausted without a terminal invocation status.
            logger.warning(
                f"CLEANUP RESIDUAL: {username} on {instance_id} — verification "
                f"poll timed out; treating as INCOMPLETE (conductor will retry)."
            )
    except Exception as e:
        # Any failure to send/verify reads as INCOMPLETE (conductor retries).
        logger.warning(f"Cleanup send/verify failed -> INCOMPLETE: {e}")

    return {
        "status": "CLEANED",
        "username": username,
        "verified": verified,
        "tunnels_terminated": tunnels_terminated,
    }
