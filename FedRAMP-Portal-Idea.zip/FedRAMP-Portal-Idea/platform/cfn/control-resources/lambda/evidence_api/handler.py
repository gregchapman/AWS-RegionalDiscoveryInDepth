"""Evidence and assurance API (ADR-0037).

Routes:
  GET  /api/audit
  GET  /api/compliance/frameworks/{framework}
  POST /api/compliance/claims/{claimId}/review

This handler is intentionally a projection layer. Raw evidence remains in the
encrypted/versioned evidence bucket; tenant users receive scoped claims, while
operators can review and remediate without exposing another tenant's raw logs.
"""

import json
import logging
import uuid
from datetime import datetime, timezone

import boto3

from portal_utils import (
    error_response,
    get_env,
    get_user_from_event,
    json_response,
    parse_body,
    parse_path_params,
    parse_query_params,
)

logger = logging.getLogger("fedramp-platform-evidence")
logger.setLevel(logging.INFO)

_dynamodb = boto3.resource("dynamodb")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _is_operator(user: dict) -> bool:
    return "Operators" in user.get("groups", [])


def _tenant_scope(tenant_id: str) -> str:
    return f"tenant#{tenant_id}" if tenant_id else "tenant#<missing>"


def _audit_table():
    return _dynamodb.Table(get_env("AUDIT_TABLE_NAME"))


def _evidence_table():
    return _dynamodb.Table(get_env("EVIDENCE_TABLE_NAME"))


def _emit_audit(user: dict, action: str, outcome: str, tenant_id: str, target: str = "", reason: str = "") -> None:
    """Write a structured C2 event; never include secrets or raw evidence."""
    timestamp = _now()
    event_id = str(uuid.uuid4())
    item = {
        "scope_key": _tenant_scope(tenant_id),
        "event_key": f"{timestamp}#{event_id}",
        "actor_key": user.get("user_id", "unknown"),
        "event_id": event_id,
        "timestamp": timestamp,
        "actor": user.get("email", "unknown"),
        "actor_id": user.get("user_id", "unknown"),
        "tenant": tenant_id,
        "action": action,
        "target": target,
        "outcome": outcome,
        "reason": reason,
        "source": "api",
    }
    _audit_table().put_item(Item=item)
    logger.info(json.dumps({"audit_event": item}, separators=(",", ":")))


def _requested_tenant(user: dict, params: dict):
    requested = (params.get("tenant") or "").strip()
    if not _is_operator(user):
        own = user.get("customer_id", "")
        if requested and requested != own:
            return None, error_response(403, "Access denied")
        if not own:
            return None, error_response(403, "Tenant scope is not configured")
        return own, None
    return requested, None


def _audit_events(user: dict, params: dict):
    tenant, denied = _requested_tenant(user, params)
    if denied:
        return denied
    limit = min(max(int(params.get("limit") or 100), 1), 1000)
    table = _audit_table()

    if tenant:
        result = table.query(
            KeyConditionExpression="scope_key = :scope",
            ExpressionAttributeValues={":scope": _tenant_scope(tenant)},
            ScanIndexForward=False,
            Limit=limit,
        )
    elif _is_operator(user):
        result = table.scan(Limit=limit)
    else:
        return error_response(403, "Tenant scope is not configured")

    events = result.get("Items", [])
    return json_response(200, {
        "events": events,
        "count": len(events),
        "tenant": tenant or None,
        "next_cursor": result.get("LastEvaluatedKey"),
    })


def _claims(user: dict, framework: str, params: dict):
    tenant, denied = _requested_tenant(user, params)
    if denied:
        return denied
    profile = (params.get("profile") or "moderate").strip()
    table = _evidence_table()
    expression_values = {
        ":claim": "CLAIM",
        ":framework": framework,
        ":profile": profile,
    }
    filter_expression = "record_type = :claim AND framework = :framework AND profile = :profile"

    if tenant:
        expression_values[":scope"] = _tenant_scope(tenant)
        result = table.query(
            IndexName="scope-index",
            KeyConditionExpression="scope_key = :scope",
            FilterExpression=filter_expression,
            ExpressionAttributeValues=expression_values,
            ScanIndexForward=False,
        )
    elif _is_operator(user):
        result = table.scan(
            FilterExpression=filter_expression,
            ExpressionAttributeValues=expression_values,
        )
    else:
        return error_response(403, "Tenant scope is not configured")

    claims = [item.get("claim", item) for item in result.get("Items", [])]
    summary = {
        "satisfied": sum(claim.get("result") == "satisfied" for claim in claims),
        "not_satisfied": sum(claim.get("result") == "not_satisfied" for claim in claims),
        "unknown": sum(claim.get("result") == "unknown" for claim in claims),
        "not_applicable": sum(claim.get("result") == "not_applicable" for claim in claims),
        "exceptions": sum(claim.get("result") == "exception" for claim in claims),
    }
    _emit_audit(user, "compliance.read", "allowed", tenant, framework)
    return json_response(200, {
        "framework": framework,
        "profile": profile,
        "generated_at": _now(),
        "disclaimer": "Graded against, not certified under. ATO remains the adopter's responsibility.",
        "claims": claims,
        "summary": summary,
        "tenant": tenant or None,
    })


def _review_claim(user: dict, claim_id: str, body: dict):
    if not _is_operator(user):
        return error_response(403, "Operator review required")
    decision = (body.get("decision") or "").strip().lower()
    reason = (body.get("reason") or "").strip()
    if decision not in ("approved", "rejected"):
        return error_response(400, "decision must be approved or rejected")
    if not reason:
        return error_response(400, "reason is required for human review")

    table = _evidence_table()
    existing = table.get_item(Key={"record_key": claim_id, "record_type": "CLAIM"}).get("Item")
    if not existing:
        return error_response(404, "Claim not found")

    reviewed_at = _now()
    claim = dict(existing.get("claim", {}))
    claim["review"] = {
        "state": decision,
        "reviewer": user.get("user_id", "unknown"),
        "reviewed_at": reviewed_at,
        "reason": reason,
    }
    table.update_item(
        Key={"record_key": claim_id, "record_type": "CLAIM"},
        UpdateExpression="SET #claim = :claim, review_state = :state, reviewed_at = :at, reviewer = :reviewer",
        ExpressionAttributeNames={"#claim": "claim"},
        ExpressionAttributeValues={
            ":claim": claim,
            ":state": decision,
            ":at": reviewed_at,
            ":reviewer": user.get("user_id", "unknown"),
        },
    )
    tenant = claim.get("scope", {}).get("tenant_id", "")
    _emit_audit(user, "compliance.review", "allowed", tenant, claim_id, reason)
    return json_response(200, {"claim": claim, "status": decision})


def lambda_handler(event, context):
    user = get_user_from_event(event)
    method = event.get("requestContext", {}).get("http", {}).get("method", "GET").upper()
    path = event.get("rawPath", "")
    params = parse_query_params(event)

    try:
        if method == "GET" and path.endswith("/audit"):
            return _audit_events(user, params)
        if method == "GET" and "/compliance/frameworks/" in path:
            framework = path.rsplit("/", 1)[-1]
            return _claims(user, framework, params)
        if method == "POST" and "/compliance/claims/" in path and path.endswith("/review"):
            claim_id = parse_path_params(event).get("claimId") or path.split("/compliance/claims/", 1)[1].rsplit("/", 1)[0]
            return _review_claim(user, claim_id, parse_body(event))
        return error_response(404, "Evidence route not found")
    except Exception as exc:
        logger.exception("Evidence API failure: %s", exc)
        return error_response(500, "Evidence service unavailable")