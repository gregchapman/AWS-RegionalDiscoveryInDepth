"""Scheduled AWS posture collector for ADR-0037.

The collector stores raw snapshots in the encrypted evidence bucket and a
scoped, hashed evidence envelope in the DynamoDB ledger. AWS service failures
are recorded as ``unknown`` evidence; they never disappear into a successful
empty result.
"""

import hashlib
import json
import logging
import os
import uuid
from datetime import datetime, timedelta, timezone

import boto3

logger = logging.getLogger("fedramp-platform-evidence-collector")
logger.setLevel(logging.INFO)

_s3 = boto3.client("s3")
_dynamodb = boto3.resource("dynamodb")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical_without_hash(evidence: dict) -> bytes:
    payload = {key: value for key, value in evidence.items() if key != "evidence_hash"}
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")


def _digest(evidence: dict) -> str:
    return "sha256:" + hashlib.sha256(_canonical_without_hash(evidence)).hexdigest()


def _scope(region: str) -> dict:
    account_id = boto3.client("sts").get_caller_identity()["Account"]
    return {
        "tenant_id": None,
        "account_id": account_id,
        "resource_refs": [],
        "fleet_scope": f"aws:{account_id}:{region}",
    }


def _store_evidence(evidence: dict, raw_snapshot: dict) -> None:
    bucket = os.environ["EVIDENCE_BUCKET_NAME"]
    key = f"raw/{evidence['profile']}/{evidence['control_id']}/{evidence['evidence_id']}.json"
    raw = json.dumps(raw_snapshot, sort_keys=True, default=str).encode("utf-8")
    raw_hash = hashlib.sha256(raw).hexdigest()
    _s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=raw,
        ContentType="application/json",
        ServerSideEncryption="aws:kms",
        SSEKMSKeyId=os.environ["KMS_KEY_ID"],
        Metadata={"sha256": raw_hash, "evidence-id": evidence["evidence_id"]},
    )
    evidence["evidence_refs"] = [{"id": key, "sha256": raw_hash, "media_type": "application/json"}]
    evidence["evidence_hash"] = _digest(evidence)
    table = _dynamodb.Table(os.environ["EVIDENCE_TABLE_NAME"])
    table.put_item(Item={
        "record_key": evidence["evidence_id"],
        "record_type": "EVIDENCE",
        "scope_key": f"fleet#{evidence['scope']['fleet_scope']}",
        "control_key": f"{evidence['framework']}#{evidence['profile']}#{evidence['control_id']}",
        "observed_at": evidence["observed_at"],
        "evidence": evidence,
    })


def _store_claim(evidence: dict) -> dict:
    """Materialize the initial one-source claim for the compliance projection.

    The full multi-source evaluator remains the contract-level implementation;
    this collector still emits a claim immediately so the runtime never has an
    evidence store with an empty compliance surface. Conflicting sources remain
    separate claims until the profile evaluator merges them.
    """
    claim_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{evidence['control_id']}|{evidence['evidence_id']}"))
    claim = {
        "claim_id": claim_id,
        "control_id": evidence["control_id"],
        "framework": evidence["framework"],
        "profile": evidence["profile"],
        "boundary_id": evidence["boundary_id"],
        "provider": evidence["provider"],
        "scope": evidence["scope"],
        "title": evidence["claim"],
        "responsible_party": evidence["responsible_party"],
        "result": evidence["result"],
        "observed_at": evidence["observed_at"],
        "valid_until": evidence["valid_until"],
        "evaluator_version": "collector-source-claim-v1",
        "evidence_ids": [evidence["evidence_id"]],
        "review": {"state": "automated"},
        "reasons": [] if evidence["result"] == "satisfied" else [f"source:{evidence['result']}"],
    }
    table = _dynamodb.Table(os.environ["EVIDENCE_TABLE_NAME"])
    table.put_item(Item={
        "record_key": claim_id,
        "record_type": "CLAIM",
        "scope_key": f"fleet#{evidence['scope']['fleet_scope']}",
        "control_key": f"{evidence['framework']}#{evidence['profile']}#{evidence['control_id']}",
        "observed_at": evidence["observed_at"],
        "claim": claim,
    })
    return claim


def _collect_source(control_id: str, source_name: str, snapshot: dict, result: str, now: datetime, scope: dict) -> dict:
    evidence = {
        "evidence_id": str(uuid.uuid4()),
        "control_id": control_id,
        "framework": "nist-800-53",
        "profile": os.environ.get("COMPLIANCE_PROFILE", "moderate"),
        "boundary_id": os.environ.get("BOUNDARY_ID", "aws-control-plane"),
        "provider": "aws",
        "scope": scope,
        "claim": f"{source_name} posture was collected and evaluated",
        "result": result,
        "responsible_party": "shared",
        "source": {"system": source_name, "collected_at": _iso(now)},
        "observed_at": _iso(now),
        "valid_until": _iso(now + timedelta(hours=1)),
        "collector_version": os.environ.get("COLLECTOR_VERSION", "evidence-collector-v1"),
        "review": {"state": "automated"},
    }
    _store_evidence(evidence, snapshot)
    return evidence


def _config_snapshot(region: str):
    try:
        client = boto3.client("config", region_name=region)
        response = client.describe_compliance_by_config_rule()
        rules = response.get("ComplianceByConfigRules", [])
        noncompliant = [rule for rule in rules if rule.get("Compliance", {}).get("ComplianceType") == "NON_COMPLIANT"]
        return response, "not_satisfied" if noncompliant else ("satisfied" if rules else "unknown")
    except Exception as exc:
        logger.exception("Config collection failed: %s", exc)
        return {"error": str(exc)}, "unknown"


def _security_hub_snapshot(region: str):
    try:
        client = boto3.client("securityhub", region_name=region)
        response = client.get_findings(Filters={"RecordState": [{"Value": "ACTIVE", "Comparison": "EQUALS"}]}, MaxResults=100)
        findings = response.get("Findings", [])
        serious = [finding for finding in findings if finding.get("Severity", {}).get("Label") in ("HIGH", "CRITICAL")]
        return response, "not_satisfied" if serious else "satisfied"
    except Exception as exc:
        logger.exception("Security Hub collection failed: %s", exc)
        return {"error": str(exc)}, "unknown"


def _guardduty_snapshot(region: str):
    try:
        client = boto3.client("guardduty", region_name=region)
        detector_ids = client.list_detectors().get("DetectorIds", [])
        findings = []
        for detector_id in detector_ids[:1]:
            ids = client.list_findings(DetectorId=detector_id).get("FindingIds", [])
            if ids:
                findings.extend(client.get_findings(DetectorId=detector_id, FindingIds=ids[:100]).get("Findings", []))
        serious = [finding for finding in findings if finding.get("Severity", 0) >= 7]
        return {"findings": findings}, "not_satisfied" if serious else "satisfied"
    except Exception as exc:
        logger.exception("GuardDuty collection failed: %s", exc)
        return {"error": str(exc)}, "unknown"


def _ssm_snapshot(region: str):
    try:
        client = boto3.client("ssm", region_name=region)
        paginator = client.get_paginator("describe_instance_information")
        instances = []
        for page in paginator.paginate():
            instances.extend(page.get("InstanceInformationList", []))
        return {"instances": instances}, "satisfied" if instances and all(i.get("PingStatus") == "Online" for i in instances) else "unknown"
    except Exception as exc:
        logger.exception("SSM collection failed: %s", exc)
        return {"error": str(exc)}, "unknown"


def lambda_handler(event, context):
    region = os.environ.get("AWS_REGION", "us-east-1")
    now = _now()
    scope = _scope(region)
    collectors = [
        ("CA-7", "aws-config", _config_snapshot),
        ("SI-4", "security-hub", _security_hub_snapshot),
        ("SI-4", "guardduty", _guardduty_snapshot),
        ("AC-17", "ssm", _ssm_snapshot),
    ]
    evidence = []
    for control_id, source_name, collector in collectors:
        snapshot, result = collector(region)
        item = _collect_source(control_id, source_name, snapshot, result, now, scope)
        _store_claim(item)
        evidence.append(item)
    logger.info("Evidence collection completed: %s", json.dumps({"count": len(evidence), "region": region}))
    return {"status": "SUCCESS", "count": len(evidence), "evidence_ids": [item["evidence_id"] for item in evidence]}