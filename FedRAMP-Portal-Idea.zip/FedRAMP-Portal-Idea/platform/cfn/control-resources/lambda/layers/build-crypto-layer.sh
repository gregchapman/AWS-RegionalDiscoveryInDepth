#!/usr/bin/env bash
###############################################################################
# build-crypto-layer.sh
#
# Builds a Lambda layer containing the `cryptography` package, compiled for the
# Lambda runtime (Amazon Linux, manylinux2014 x86_64). Run this once (and after
# any cryptography version bump). The output dir is zipped by Terraform at
# apply time, mirroring the shared layer.
#
# cryptography ships compiled native wheels, so we must fetch the manylinux
# build that matches the Lambda execution environment — not the host's wheel.
#
# Usage:
#   ./terraform/03-api/lambda/layers/build-crypto-layer.sh
#
# Requires: python3 + pip. Uses --platform to pull the correct wheel without
# needing Docker.
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAYER_DIR="$SCRIPT_DIR/crypto/python"
PY_VERSION="3.12"

# Pick an interpreter to DRIVE pip. This must be >=3.9, because pip applies the
# RUNNING interpreter's Requires-Python gate even for cross-target downloads —
# a host python3 of 3.8.x makes `pip install cryptography` fail before it can
# place the (correct, 3.12) wheel. The --python-version/--platform flags below
# still control the TARGET wheel, independent of which python drives pip.
PYBIN=""
for cand in python3.12 python3.11 python3.10 python3.9 python python3; do
  if command -v "$cand" >/dev/null 2>&1; then
    ver="$("$cand" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo 0.0)"
    major="${ver%%.*}"; minor="${ver#*.}"
    if [ "$major" -eq 3 ] && [ "$minor" -ge 9 ]; then
      PYBIN="$cand"
      break
    fi
  fi
done

if [ -z "$PYBIN" ]; then
  echo "ERROR: need a Python >=3.9 to drive pip (host python3 is too old to" >&2
  echo "       resolve modern cryptography). Install/point to python3.9+ and retry." >&2
  exit 1
fi

# Build pip inside a throwaway venv created from $PYBIN. This is deliberate:
# on Ubuntu 20.04 (focal), invoking `$PYBIN -m pip` directly loads the SYSTEM
# pip under /usr/lib/python3/dist-packages, which was built for the old system
# python3 (3.8) and imports `distutils` — removed from the stdlib in 3.12 —
# so it crashes with ModuleNotFoundError: distutils. A fresh venv gets its own
# modern pip bound to $PYBIN, sidestepping the system pip entirely and touching
# nothing outside the temp dir. (Learned 2026-08-28.)
VENV_DIR="$(mktemp -d)/cryptobuild"
trap 'rm -rf "$(dirname "$VENV_DIR")"' EXIT

echo "-> Driving pip via a temp venv on: $PYBIN ($("$PYBIN" --version 2>&1)); target runtime python$PY_VERSION"
"$PYBIN" -m venv "$VENV_DIR"
"$VENV_DIR/bin/python" -m pip install --quiet --upgrade pip

echo "-> Building cryptography layer into $LAYER_DIR"
rm -rf "$LAYER_DIR"
mkdir -p "$LAYER_DIR"

"$VENV_DIR/bin/python" -m pip install \
  --platform manylinux2014_x86_64 \
  --implementation cp \
  --python-version "$PY_VERSION" \
  --only-binary=:all: \
  --target "$LAYER_DIR" \
  cryptography

# Drop console-script shims — not needed in a Lambda layer, just dead weight.
rm -rf "$LAYER_DIR/bin"

echo "-> Done. Layer contents:"
ls "$LAYER_DIR"
echo ""
echo "Terraform will zip terraform/03-api/lambda/layers/crypto/ into the layer."
