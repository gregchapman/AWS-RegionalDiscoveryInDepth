"""Lambda: GET /api/accounts

Lists AWS accounts. In production (org mode), calls organizations:ListAccounts.
In single-account test mode, returns simulated accounts based on target regions.
"""

import boto3
import logging
from portal_utils import (
    get_env,
    get_user_from_event,
    json_response,
    error_response,
)

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)

# Simulated accounts for single-account testing (regions as boundaries)
SIMULATED_ACCOUNTS = [
    {
        "id": "SIMULATED-EAST1",
        "name": "Management",
        "region": "us-east-1",
        "status": "ACTIVE",
    },
    {
        "id": "SIMULATED-EAST2",
        "name": "Customer 1",
        "region": "us-east-2",
        "status": "ACTIVE",
    },
    {
        "id": "SIMULATED-WEST1",
        "name": "Customer 2",
        "region": "us-west-1",
        "status": "ACTIVE",
    },
    {
        "id": "SIMULATED-WEST2",
        "name": "Customer 3",
        "region": "us-west-2",
        "status": "ACTIVE",
    },
]


def lambda_handler(event, context):
    """Handle GET /api/accounts."""
    logger.info("list-accounts invoked")

    user = get_user_from_event(event)
    logger.info(f"User: {user['email']}, Groups: {user['groups']}")

    # Only Operators can see all accounts; customers see only their own
    is_operator = "Operators" in user.get("groups", [])

    environment = get_env("ENVIRONMENT", "dev")

    # In dev/test mode, return simulated accounts (regions as boundaries)
    if environment in ("dev", "test"):
        accounts = SIMULATED_ACCOUNTS
        if not is_operator:
            # Customers see only their assigned account
            # In production, this would filter by customer_id claim
            accounts = accounts[:1]  # Default: first simulated account

        return json_response(200, {
            "accounts": accounts,
            "mode": "simulated",
            "count": len(accounts),
        })

    # Production mode: call Organizations API
    try:
        # Organizations is a global service, but its endpoint differs by
        # partition (us-east-1 in commercial, us-gov-west-1 in GovCloud).
        # Omitting region_name lets boto3 resolve the correct partition
        # endpoint from the ambient region/credentials (ADR-0017).
        org_client = boto3.client("organizations")
        paginator = org_client.get_paginator("list_accounts")

        accounts = []
        for page in paginator.paginate():
            for acct in page["Accounts"]:
                accounts.append({
                    "id": acct["Id"],
                    "name": acct["Name"],
                    "email": acct["Email"],
                    "status": acct["Status"],
                })

        if not is_operator:
            # Filter to customer's assigned account(s)
            customer_id = user.get("customer_id", "")
            accounts = [a for a in accounts if a["id"] == customer_id]

        return json_response(200, {
            "accounts": accounts,
            "mode": "live",
            "count": len(accounts),
        })

    except Exception as e:
        logger.error(f"Error listing accounts: {e}")
        return error_response(500, "Failed to list accounts")
    lambda_handler = audited("inventory.accounts.list", lambda_handler)
