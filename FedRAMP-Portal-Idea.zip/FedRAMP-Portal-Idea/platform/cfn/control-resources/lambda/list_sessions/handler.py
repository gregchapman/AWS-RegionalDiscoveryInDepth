"""Lambda: GET /api/sessions

Two modes (ADR-0025):

  * SELF (default): returns the CALLER's own live/ending sessions so the portal
    can restore session state after a reload. Queries the user-index GSI by
    user_id. Includes the connection block (incl. the caller's own decrypted
    password) — it's the caller's own session.

  * OPERATOR (`?scope=all`, Operators only): returns EVERY user's live/ending
    sessions so an authorized operator can SEE and revoke another user's access
    (e.g. "end Customer1 / Joe"). Queries the status-index GSI per visible
    status. Scoped by tenant `customer_id` when the caller supplies a
    `?customer_id=` filter; tenant isolation (ADR-0021) remains inviolable — a
    non-Operator can NEVER use this mode. The operator view deliberately does NOT
    return session SECRETS (temporary_password): an operator needs to see WHO
    has access to WHAT, not harvest tenants' credentials (least privilege).
"""

import boto3
import base64
import logging
from portal_utils import (
    get_env,
    get_user_from_event,
    json_response,
    error_response,
    parse_query_params,
    audited,
)

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)

# Ambient region (AWS_REGION) — portable across regions/partitions (ADR-0017).
kms_client = boto3.client("kms")


def decrypt_field(value: str) -> str:
    """Decrypt KMS ciphertext; fall back to plaintext if not encrypted.

    Only attempts decryption for values long enough to be real KMS
    ciphertext (~180+ base64 chars). Short ephemeral passwords are
    returned as-is, even if they happen to be valid base64.
    """
    if not value:
        return ""
    if len(value) < 100:
        return value
    try:
        response = kms_client.decrypt(
            CiphertextBlob=base64.b64decode(value),
            KeyId=get_env("KMS_KEY_ID"),
        )
        return response["Plaintext"].decode("utf-8")
    except Exception:
        return value


# LIVE + ENDING states are visible (ADR-0023): the user/operator sees a session
# mid-teardown instead of it silently vanishing. Terminal states (COMPLETED /
# CLEANUP_FAILED / FAILED) are excluded server-side.
VISIBLE = ("PENDING", "PROVISIONING", "ACTIVE", "END_REQUESTED", "CLEANING_UP")


def _self_session(item):
    """Full session view for the CALLER's OWN session (includes their secret)."""
    encrypted_password = item.get("temporary_password", {}).get("S", "")
    return {
        "request_id": item.get("request_id", {}).get("S", ""),
        "status": item.get("status", {}).get("S", ""),
        "instance_id": item.get("instance_id", {}).get("S", ""),
        "region": item.get("region", {}).get("S", ""),
        "access_type": item.get("access_type", {}).get("S", ""),
        "created_at": item.get("created_at", {}).get("S", ""),
        "ttl_minutes": int(item.get("ttl_minutes", {}).get("N", "0")),
        "user_email": item.get("user_email", {}).get("S", ""),
        "connection": {
            "username": item.get("provisioned_username", {}).get("S", ""),
            "auth_method": item.get("auth_method", {}).get("S", ""),
            "temporary_password": decrypt_field(encrypted_password),
            "port_forward_command": item.get("port_forward_command", {}).get("S", ""),
            "port_local": item.get("port_local", {}).get("S", "2222"),
            "port_remote": item.get("port_remote", {}).get("S", "22"),
            "expires_at": item.get("expires_at", {}).get("N", ""),
        },
    }


def _operator_session(item):
    """Operator view of ANOTHER user's session: who has access to what, and the
    accountability fields — but NO session secret (least privilege; an operator
    doesn't harvest tenants' passwords). No decrypted password / connection
    block is returned."""
    return {
        "request_id": item.get("request_id", {}).get("S", ""),
        "status": item.get("status", {}).get("S", ""),
        "instance_id": item.get("instance_id", {}).get("S", ""),
        "region": item.get("region", {}).get("S", ""),
        "access_type": item.get("access_type", {}).get("S", ""),
        "created_at": item.get("created_at", {}).get("S", ""),
        "ttl_minutes": int(item.get("ttl_minutes", {}).get("N", "0")),
        # WHO holds the access + WHICH tenant it targets (ADR-0025).
        "user_email": item.get("user_email", {}).get("S", ""),
        "user_id": item.get("user_id", {}).get("S", ""),
        "customer_id": item.get("customer_id", {}).get("S", ""),
        "provisioned_username": item.get("provisioned_username", {}).get("S", ""),
        # End-attribution, if an end is already in motion (ADR-0024).
        "ended_by": item.get("ended_by", {}).get("S", ""),
        "end_source": item.get("end_source", {}).get("S", ""),
        "end_reason": item.get("end_reason", {}).get("S", ""),
    }


def _list_self(dynamodb, table_name, user):
    """Caller's own sessions via the user-index GSI."""
    result = dynamodb.query(
        TableName=table_name,
        IndexName="user-index",
        KeyConditionExpression="user_id = :uid",
        ExpressionAttributeValues={":uid": {"S": user["user_id"]}},
        ScanIndexForward=False,
    )
    out = []
    for item in result.get("Items", []):
        if item.get("status", {}).get("S", "") in VISIBLE:
            out.append(_self_session(item))
    return out


def _list_operator(dynamodb, table_name, customer_filter):
    """EVERY user's live/ending sessions via the status-index GSI (one query per
    visible status). Optionally tenant-scoped by customer_id. Operators only —
    the caller's authorization is checked before this is invoked."""
    out = []
    for status in VISIBLE:
        start_key = None
        while True:
            kwargs = {
                "TableName": table_name,
                "IndexName": "status-index",
                "KeyConditionExpression": "#s = :st",
                "ExpressionAttributeNames": {"#s": "status"},
                "ExpressionAttributeValues": {":st": {"S": status}},
                "ScanIndexForward": False,
            }
            if start_key:
                kwargs["ExclusiveStartKey"] = start_key
            page = dynamodb.query(**kwargs)
            for item in page.get("Items", []):
                # Tenant scope (ADR-0021): if a customer filter is supplied, only
                # return sessions targeting that tenant. Fail-closed on mismatch.
                if customer_filter:
                    if item.get("customer_id", {}).get("S", "") != customer_filter:
                        continue
                out.append(_operator_session(item))
            start_key = page.get("LastEvaluatedKey")
            if not start_key:
                break
    return out


def lambda_handler(event, context):
    """Handle GET /api/sessions — self mode (default) or operator mode (?scope=all)."""
    logger.info("list-sessions invoked")

    user = get_user_from_event(event)
    table_name = get_env("TABLE_NAME")
    dynamodb = boto3.client("dynamodb")  # ambient region (ADR-0017)

    qs = parse_query_params(event)
    scope = (qs.get("scope") or "self").strip().lower()
    is_operator = "Operators" in user.get("groups", [])

    try:
        if scope == "all":
            # OPERATOR mode — Operators only, fail-closed (ADR-0021/0025).
            if not is_operator:
                logger.warning(
                    f"Denied operator session list for non-Operator {user.get('email','?')}"
                )
                return error_response(403, "Access denied")
            customer_filter = (qs.get("customer_id") or "").strip()
            sessions = _list_operator(dynamodb, table_name, customer_filter)
            logger.info(
                f"Operator session list by {user.get('email','?')} "
                f"(customer_filter={customer_filter or 'ALL'}): {len(sessions)} live"
            )
            return json_response(200, {
                "sessions": sessions,
                "count": len(sessions),
                "scope": "all",
                "customer_id": customer_filter,
            })

        # SELF mode (default).
        sessions = _list_self(dynamodb, table_name, user)
        return json_response(200, {
            "sessions": sessions,
            "count": len(sessions),
            "scope": "self",
        })
    except Exception as e:
        logger.error(f"DynamoDB query failed: {e}")
        return error_response(500, "Failed to list sessions")


lambda_handler = audited("session.list", lambda_handler)
