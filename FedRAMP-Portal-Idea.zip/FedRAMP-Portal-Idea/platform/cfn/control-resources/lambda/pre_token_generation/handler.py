"""Lambda: Cognito Pre Token Generation trigger (V2_0) — ADR-0011 attribution fix

Problem this fixes: the Cognito ACCESS token (what the SPA sends and the API
Gateway JWT authorizer validates) does NOT carry an `email` claim — only the ID
token does. Our handlers read identity from the access token via
`get_user_from_event`, so `email` was absent and username derivation fell back
to "unknown" (e.g. `unknown-9656` instead of `greg-racker-9656`). That breaks
the ADR-0011 promise that OS users, SSM logs, and CloudTrail attribute to a real
person (AU-2/AU-3/AC-2).

Fix at the SOURCE: this trigger copies the user's email (and a couple of useful
identity claims) INTO the access token, so every downstream consumer gets real
attribution with no per-endpoint hacks.

Trigger version: V2_0 (required to customize ACCESS-token claims; V1_0 can only
touch the ID token). Wired via aws_cognito_user_pool.lambda_config
pre_token_generation_config with LAMBDA_VERSION = "V2_0".

Event shape (V2_0):
  event["request"]["userAttributes"]  -> the user's attributes (incl. email)
  event["response"]["claimsAndScopeOverrideDetails"]["accessTokenGeneration"]
    ["claimsToAddOrOverride"]          -> claims to inject into the access token

We only ADD identity claims; we never override reserved claims (sub, token_use,
etc. cannot be overridden and we don't try). Fail-open: if anything is missing,
we return the event unchanged so login is never blocked by this trigger.
"""

import logging

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    try:
        attrs = (event.get("request") or {}).get("userAttributes") or {}
        email = attrs.get("email", "")
        # custom:customer_id is how tenant scoping is carried (ADR-0021); mirror
        # it onto the access token too so the vend endpoint's AC-6(5) check can
        # rely on it regardless of which token variant a client presents.
        customer_id = attrs.get("custom:customer_id", "")

        claims = {}
        if email:
            claims["email"] = email
        if customer_id:
            claims["custom:customer_id"] = customer_id

        if claims:
            event.setdefault("response", {})
            event["response"]["claimsAndScopeOverrideDetails"] = {
                "accessTokenGeneration": {
                    "claimsToAddOrOverride": claims
                }
            }
            logger.info(f"Injected access-token claims: {list(claims.keys())} for sub={attrs.get('sub','?')}")
        else:
            logger.info("No email/customer_id on user; access token left unchanged")
    except Exception as e:
        # Never block token issuance because of this enrichment step.
        logger.error(f"pre-token-generation enrichment skipped due to error: {e}")

    return event
