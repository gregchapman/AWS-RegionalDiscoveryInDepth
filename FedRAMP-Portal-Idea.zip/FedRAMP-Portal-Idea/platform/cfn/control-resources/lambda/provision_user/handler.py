"""Lambda: provision_user (invoked by Step Function)

Region-aware SSM user provisioning. The Step Function's native SSM
integration can only target us-east-1, so we use this Lambda to call
SSM in the instance's actual region (boto3 accepts region_name).

Input (from Step Function):
  {
    "instance_id": "i-...",
    "region": "us-east-2",
    "access_type": "ssh" | "rdp",
    "username": "p-xxxxxxxx"
  }

Output:
  {
    "status": "SUCCESS" | "FAILED",
    "username": "p-xxxxxxxx",
    "password": "...",
    "error": "..."  (if failed)
  }
"""

import os
import time
import boto3
import logging

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)

# Control-plane client: SSM Parameter Store (CA pubkey) lives in the management
# region. Use the ambient region (AWS_REGION) so this is portable (ADR-0017).
# NOTE: distinct from the region-aware ssm client below, which deliberately
# targets the *instance's* region.
_ssm_ctrl = boto3.client("ssm")  # for SSM Parameter Store (CA pubkey)
_ca_public_key_cache = None


def _get_ca_public_key():
    """Fetch and cache the SSH CA public key from SSM Parameter Store."""
    global _ca_public_key_cache
    if _ca_public_key_cache is not None:
        return _ca_public_key_cache
    param_name = os.environ.get("SSH_CA_PUBLIC_KEY_PARAM", "/fedramp-portal/ssh-ca-public-key")
    resp = _ssm_ctrl.get_parameter(Name=param_name)
    _ca_public_key_cache = resp["Parameter"]["Value"].strip()
    return _ca_public_key_cache


# Passwordless Linux provisioning (ADR-0014). Creates the identity-named user
# with NO password, installs the SSH CA public key as a trusted user CA, and
# keeps password auth OFF. Login is authorized by a short-lived CA-signed cert
# whose ValidPrincipals includes this username. The CA public key is injected
# by the Lambda (fetched from SSM) into {ca_public_key}.
LINUX_SCRIPT = """#!/bin/bash
set -e
USERNAME="{username}"
id "$USERNAME" >/dev/null 2>&1 || useradd -m -s /bin/bash "$USERNAME"
# No password is set — the account cannot be logged into with a password.
passwd -l "$USERNAME" >/dev/null 2>&1 || true
if getent group sudo >/dev/null; then
  usermod -aG sudo "$USERNAME"
else
  usermod -aG wheel "$USERNAME"
fi
# Trust the Passport SSH CA for user certificates.
mkdir -p /etc/ssh
cat > /etc/ssh/passport_ca.pub <<'CAEOF'
{ca_public_key}
CAEOF
chmod 644 /etc/ssh/passport_ca.pub
cat > /etc/ssh/sshd_config.d/99-portal.conf <<'CFGEOF'
TrustedUserCAKeys /etc/ssh/passport_ca.pub
PasswordAuthentication no
ChallengeResponseAuthentication no
CFGEOF
systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
echo "PORTAL_PROVISIONED $USERNAME"
"""

WINDOWS_SCRIPT = """
$Username = "{username}"
Add-Type -AssemblyName System.Web
$Password = [System.Web.Security.Membership]::GeneratePassword(24,4)
$SecurePass = ConvertTo-SecureString $Password -AsPlainText -Force
if (Get-LocalUser -Name $Username -ErrorAction SilentlyContinue) {{
  Set-LocalUser -Name $Username -Password $SecurePass
}} else {{
  New-LocalUser -Name $Username -Password $SecurePass -FullName "Portal Temp User"
}}
Add-LocalGroupMember -Group "Administrators" -Member $Username -ErrorAction SilentlyContinue
Write-Output "PORTAL_CREDS $Username $Password"
"""


def lambda_handler(event, context):
    """Provision an ephemeral user on the target instance via SSM."""
    instance_id = event["instance_id"]
    region = event["region"]
    access_type = event.get("access_type", "ssh")
    username = event["username"]
    user_email = event.get("user_email", "unknown")

    ssm = boto3.client("ssm", region_name=region)

    if access_type == "rdp":
        document = "AWS-RunPowerShellScript"
        script = WINDOWS_SCRIPT.format(username=username)
    else:
        document = "AWS-RunShellScript"
        # Passwordless SSH: inject the CA public key so the instance trusts
        # CA-signed user certs (ADR-0014). No password is generated.
        try:
            ca_public_key = _get_ca_public_key()
        except Exception as e:
            logger.error(f"Failed to fetch CA public key: {e}")
            return {"status": "FAILED", "username": username, "error": f"CA public key unavailable: {e}"}
        script = LINUX_SCRIPT.format(username=username, ca_public_key=ca_public_key)

    # Stamp the requesting identity into the command Comment. This lands in
    # CloudTrail's SendCommand event and SSM command history, so the
    # provisioning action is attributable to the human (ADR-0011), even
    # though the API caller is the Lambda role.
    comment = f"portal-access for {user_email} -> {username}"[:100]

    try:
        send = ssm.send_command(
            InstanceIds=[instance_id],
            DocumentName=document,
            Parameters={"commands": [script]},
            TimeoutSeconds=60,
            Comment=comment,
        )
        command_id = send["Command"]["CommandId"]
    except Exception as e:
        logger.error(f"SendCommand failed: {e}")
        return {"status": "FAILED", "username": username, "error": str(e)}

    # Poll for command completion (up to ~50s)
    for _ in range(25):
        time.sleep(2)
        try:
            inv = ssm.get_command_invocation(
                CommandId=command_id,
                InstanceId=instance_id,
            )
        except ssm.exceptions.InvocationDoesNotExist:
            continue

        status = inv["Status"]
        if status == "Success":
            output = inv.get("StandardOutputContent", "")
            password = ""
            for line in output.splitlines():
                if line.startswith("PORTAL_CREDS"):
                    parts = line.split()
                    if len(parts) >= 3:
                        password = parts[2]
                    break
            return {
                "status": "SUCCESS",
                "username": username,
                "password": password,
            }
        if status in ("Failed", "Cancelled", "TimedOut"):
            return {
                "status": "FAILED",
                "username": username,
                "error": inv.get("StandardErrorContent", "")[:500] or f"Command {status}",
            }

    return {"status": "FAILED", "username": username, "error": "Provisioning timed out"}
