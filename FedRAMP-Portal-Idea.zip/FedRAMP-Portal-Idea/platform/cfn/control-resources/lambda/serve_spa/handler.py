"""Lambda: serve_spa  (HTTP API v2 $default catch-all — ADR-0019)

Serves the React SPA's static assets from the PRIVATE S3 bucket created in
layer 02. This replaces CloudFront+S3+OAC (banned for IL4 — CloudFront is a
commercial-only global edge, ADR-0019). The bucket is private; this Lambda's
execution role is the only reader (s3:GetObject granted in layer 03).

Routing model (IMPORTANT):
  - This handler is wired to the $default route with authorization_type = NONE.
    It serves the PUBLIC static shell (index.html, hashed JS/CSS, icons) to
    UNAUTHENTICATED browsers. That is correct and intended: the app shell is
    public; all DATA is behind the JWT-authorized /api/* routes. Never serve
    anything sensitive from the SPA bucket.
  - /api/* routes are matched by more specific routes (JWT-authorized) and never
    reach this handler.

SPA client-side routing fallback:
  - A request for a real asset key (e.g. /assets/index-abc123.js) returns that
    object.
  - A request for a client-route path with no matching object (e.g. /racker,
    /customer, /callback) returns index.html with HTTP 200, so the SPA's router
    can take over. This replaces CloudFront's custom-error-response trick.
  - A request that clearly targets a file (has an extension) but is missing
    returns a genuine 404.

Binary vs text:
  - API Gateway v2 requires binary response bodies to be base64-encoded with
    isBase64Encoded=true. We base64 anything not in the known-text set.
"""

import os
import base64
import logging

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)

# Ambient region (AWS_REGION) — portable across regions/partitions (ADR-0017).
# The SPA bucket is in the same region/partition as this Lambda.
_s3 = boto3.client("s3")

# Separate client for PRESIGNING CLI download URLs (ADR-0016). It MUST use
# Signature Version 4 and the regional endpoint: the bucket objects are
# SSE-KMS encrypted, and S3 rejects KMS-encrypted GETs signed with SigV2
# ("Requests specifying SSE with AWS KMS managed keys require AWS Signature
# Version 4"). boto3's default presigner can emit SigV2, so we pin s3v4 +
# region + virtual addressing explicitly.
_s3_presign = boto3.client(
    "s3",
    region_name=os.environ.get("AWS_REGION", "us-east-1"),
    endpoint_url="https://s3." + os.environ.get("AWS_REGION", "us-east-1") + ".amazonaws.com",
    config=Config(signature_version="s3v4", s3={"addressing_style": "virtual"}),
)

BUCKET = os.environ["SPA_BUCKET"]
INDEX_DOCUMENT = os.environ.get("SPA_INDEX", "index.html")

# Content types by extension. S3 object ContentType is preferred when present;
# this is the fallback and also decides text-vs-binary transfer encoding.
_CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".map": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
    ".ttf": "font/ttf",
    ".txt": "text/plain; charset=utf-8",
    ".webmanifest": "application/manifest+json",
}

# Extensions we transfer as UTF-8 text (everything else is base64 binary).
_TEXT_EXTS = {".html", ".js", ".mjs", ".css", ".json", ".map", ".svg", ".txt", ".webmanifest"}


def _ext(key: str) -> str:
    dot = key.rfind(".")
    slash = key.rfind("/")
    if dot == -1 or dot < slash:
        return ""  # no extension in the last path segment
    return key[dot:].lower()


def _content_type(key: str, s3_ct: str) -> str:
    if s3_ct and s3_ct != "binary/octet-stream":
        return s3_ct
    return _CONTENT_TYPES.get(_ext(key), "application/octet-stream")


def _security_headers(content_type: str, cache: str) -> dict:
    return {
        "Content-Type": content_type,
        "Cache-Control": cache,
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "no-referrer",
    }


def _key_from_path(raw_path: str) -> str:
    """Map a request path to an S3 object key."""
    path = (raw_path or "/").split("?", 1)[0]
    path = path.lstrip("/")
    if path == "" or path.endswith("/"):
        path = path + INDEX_DOCUMENT
    return path


def _get_object(key: str):
    """Return (body_bytes, content_type) or None if the key is absent."""
    try:
        resp = _s3.get_object(Bucket=BUCKET, Key=key)
        return resp["Body"].read(), resp.get("ContentType", "")
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code in ("NoSuchKey", "AccessDenied", "404", "NoSuchBucket"):
            return None
        raise


def _respond(key: str, body: bytes, s3_ct: str, cache: str):
    content_type = _content_type(key, s3_ct)
    if _ext(key) in _TEXT_EXTS:
        return {
            "statusCode": 200,
            "headers": _security_headers(content_type, cache),
            "body": body.decode("utf-8"),
            "isBase64Encoded": False,
        }
    return {
        "statusCode": 200,
        "headers": _security_headers(content_type, cache),
        "body": base64.b64encode(body).decode("ascii"),
        "isBase64Encoded": True,
    }


def _serve_index():
    """Serve index.html (200) — used for the SPA client-side-routing fallback."""
    result = _get_object(INDEX_DOCUMENT)
    if result is None:
        logger.error(f"index document '{INDEX_DOCUMENT}' missing from bucket '{BUCKET}'")
        return {
            "statusCode": 500,
            "headers": _security_headers("text/plain; charset=utf-8", "no-store"),
            "body": "Portal assets not deployed.",
            "isBase64Encoded": False,
        }
    body, s3_ct = result
    # index.html must never be cached — it references the current hashed assets.
    return _respond(INDEX_DOCUMENT, body, s3_ct, "no-cache")


def lambda_handler(event, context):
    """HTTP API v2 $default handler — serve SPA assets with client-route fallback."""
    raw_path = event.get("rawPath", "/")
    key = _key_from_path(raw_path)

    # CLI DOWNLOADS (ADR-0016): the passport binaries are ~8-9 MB, which exceeds
    # the Lambda/API Gateway 6 MiB response cap (a base64 body would be ~11 MB
    # and fail with 500). Do NOT proxy these bytes through the Lambda. Instead
    # redirect to a short-lived presigned S3 URL so the client downloads the
    # object DIRECTLY from S3 — no size limit, and the bucket stays private
    # (the presigned URL is signed by this Lambda's role, valid 5 min). Applies
    # to any key under cli/releases/ that actually exists.
    if key.startswith("cli/releases/") and not key.endswith("/"):
        try:
            _s3.head_object(Bucket=BUCKET, Key=key)
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            # A missing key on a private bucket can surface as 404/NoSuchKey OR
            # AccessDenied/403 (S3 hides existence). Treat all of these as a
            # clean 404 for a download path rather than a 500 — e.g. after a CLI
            # artifact was (wrongly) pruned, users should see "not found", not a
            # server error.
            if code in ("404", "NoSuchKey", "NotFound", "AccessDenied", "403"):
                return {
                    "statusCode": 404,
                    "headers": _security_headers("text/plain; charset=utf-8", "no-store"),
                    "body": "Not found.",
                    "isBase64Encoded": False,
                }
            raise
        url = _s3_presign.generate_presigned_url(
            "get_object",
            Params={"Bucket": BUCKET, "Key": key},
            ExpiresIn=300,
        )
        return {
            "statusCode": 302,
            "headers": {
                "Location": url,
                "Cache-Control": "no-store",
                "X-Content-Type-Options": "nosniff",
            },
            "isBase64Encoded": False,
        }

    result = _get_object(key)
    if result is not None:
        body, s3_ct = result
        # Hashed build assets (Vite emits content-hashed filenames under /assets)
        # are immutable -> cache hard. index.html handled via _serve_index.
        if key == INDEX_DOCUMENT:
            cache = "no-cache"
        elif key.startswith("assets/"):
            cache = "public, max-age=31536000, immutable"
        else:
            cache = "public, max-age=3600"
        return _respond(key, body, s3_ct, cache)

    # Not found. If it clearly targets a file (has an extension), it's a real
    # 404. Otherwise treat it as a client-side route -> serve index.html (200).
    if _ext(key):
        return {
            "statusCode": 404,
            "headers": _security_headers("text/plain; charset=utf-8", "no-store"),
            "body": "Not found.",
            "isBase64Encoded": False,
        }
    return _serve_index()
