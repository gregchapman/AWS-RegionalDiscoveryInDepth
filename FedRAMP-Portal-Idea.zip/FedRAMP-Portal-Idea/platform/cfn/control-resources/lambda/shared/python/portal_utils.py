"""Shared utilities for FedRAMP Portal Lambda functions."""

import json
import logging
import os
import uuid
from datetime import datetime, timezone

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)


def get_env(key: str, default: str = "") -> str:
    """Get environment variable with optional default."""
    return os.environ.get(key, default)


def json_response(status_code: int, body: dict) -> dict:
    """Build API Gateway v2 proxy response."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "Cache-Control": "no-store",
        },
        "body": json.dumps(body, default=str),
    }


def error_response(status_code: int, message: str) -> dict:
    """Build a standard error response."""
    return json_response(status_code, {"error": message})


def audited(action: str, handler):
    """Wrap an API handler with a durable, structured audit event.

    The wrapper records reads and writes, including denied outcomes. It stores
    only identity, route, tenant, status, and correlation data; secrets and
    request bodies are intentionally excluded. If the audit table is absent in
    a local test profile, the structured log remains visible and the request is
    not converted into a silent authorization success.
    """
    import boto3

    def wrapped(event, context):
        user = get_user_from_event(event)
        request_id = event.get("requestContext", {}).get("requestId", str(uuid.uuid4()))
        path = event.get("rawPath", event.get("routeKey", action))
        timestamp = utc_now()
        status_code = 500
        try:
            response = handler(event, context)
            status_code = int(response.get("statusCode", 500))
            return response
        except Exception:
            raise
        finally:
            outcome = "allowed" if status_code < 400 else "denied" if status_code < 500 else "failed"
            item = {
                "scope_key": f"tenant#{user.get('customer_id', '') or '<missing>'}",
                "event_key": f"{timestamp}#{request_id}",
                "actor_key": user.get("user_id", "unknown"),
                "event_id": request_id,
                "timestamp": timestamp,
                "actor": user.get("email", "unknown"),
                "actor_id": user.get("user_id", "unknown"),
                "tenant": user.get("customer_id", ""),
                "action": action,
                "target": path,
                "outcome": outcome,
                "reason": "",
                "source": "api",
            }
            table_name = get_env("AUDIT_TABLE_NAME")
            if table_name:
                try:
                    boto3.resource("dynamodb").Table(table_name).put_item(Item=item)
                except Exception as audit_error:
                    logger.error("Durable audit write failed for %s: %s", action, audit_error)
            logger.info(json.dumps({"audit_event": item}, separators=(",", ":")))

    return wrapped


def get_user_from_event(event: dict) -> dict:
    """Extract user info from API Gateway JWT authorizer context."""
    claims = (
        event.get("requestContext", {})
        .get("authorizer", {})
        .get("jwt", {})
        .get("claims", {})
    )

    # cognito:groups can arrive as:
    #   - A string: "Operators" (single group)
    #   - A comma-separated string: "Operators,Admins"
    #   - A JSON array string: "[Operators]" or "[\"Operators\"]"
    #   - None/empty
    raw_groups = claims.get("cognito:groups", "")
    if isinstance(raw_groups, list):
        groups = raw_groups
    elif raw_groups:
        # Strip brackets if present
        cleaned = raw_groups.strip("[]\" ")
        groups = [g.strip().strip('"') for g in cleaned.split(",") if g.strip()]
    else:
        groups = []

    import logging
    logger = logging.getLogger("fedramp-portal")
    logger.info(f"JWT claims keys: {list(claims.keys())}")
    logger.info(f"Raw cognito:groups value: '{raw_groups}' -> parsed: {groups}")

    # Identity for attribution (ADR-0011). The access token now carries `email`
    # via the pre-token-generation trigger (cognito-triggers.tf). This fallback
    # chain is defense in depth so attribution NEVER silently lands on the
    # literal "unknown" (which produced usernames like unknown-9656) if the
    # trigger is absent/misconfigured. Order: email -> custom:email ->
    # cognito:username (only when it's NOT just the UUID sub) -> sub. `email`
    # stays keyed as-is so derive_username keeps taking the local-part.
    sub = claims.get("sub", "")
    cognito_username = claims.get("cognito:username", claims.get("username", ""))
    email = claims.get("email") or claims.get("custom:email") or ""
    if not email:
        # A username that isn't just the UUID sub is still human-meaningful.
        if cognito_username and cognito_username != sub:
            email = cognito_username
        elif sub:
            email = sub  # last resort: at least stable + traceable to the pool
        else:
            email = "unknown"

    return {
        "user_id": sub or "unknown",
        "email": email,
        "groups": groups,
        "customer_id": claims.get("custom:customer_id", ""),
    }


def utc_now() -> str:
    """Return current UTC time as ISO 8601 string."""
    return datetime.now(timezone.utc).isoformat()


def parse_query_params(event: dict) -> dict:
    """Extract query string parameters from event."""
    return event.get("queryStringParameters") or {}


def parse_path_params(event: dict) -> dict:
    """Extract path parameters from event."""
    return event.get("pathParameters") or {}


def parse_body(event: dict) -> dict:
    """Parse JSON body from event."""
    body = event.get("body", "")
    if not body:
        return {}
    try:
        return json.loads(body)
    except (json.JSONDecodeError, TypeError):
        return {}


def authorize_target_instance(instance_id: str, region: str, user: dict) -> str:
    """Authorize a target before any access-request side effect occurs."""
    target_regions = {
        value.strip()
        for value in get_env("TARGET_REGIONS", "us-east-2,us-west-1").split(",")
        if value.strip()
    }
    if region not in target_regions:
        raise PermissionError("target region is not allowed")

    try:
        ec2 = _boto3.client("ec2", region_name=region)
        response = ec2.describe_instances(InstanceIds=[instance_id])
    except Exception as exc:
        logger.warning("Target authorization lookup failed for %s: %s", instance_id, exc)
        raise PermissionError("target is not authorized") from exc

    instances = [
        instance
        for reservation in response.get("Reservations", [])
        for instance in reservation.get("Instances", [])
        if instance.get("InstanceId") == instance_id
    ]
    if not instances:
        raise PermissionError("target is not authorized")

    tags = {
        tag["Key"]: tag["Value"]
        for tag in instances[0].get("Tags", [])
        if "Key" in tag and "Value" in tag
    }
    target_customer_id = tags.get("Customer", "")
    is_operator = "Operators" in user.get("groups", [])
    if not is_operator:
        caller_customer_id = user.get("customer_id", "")
        if (
            not caller_customer_id
            or tags.get("CustomerAccess", "").lower() != "true"
            or target_customer_id.lower() != caller_customer_id.lower()
        ):
            logger.warning(
                "Denied target %s for customer %s",
                instance_id,
                caller_customer_id or "<missing>",
            )
            raise PermissionError("target is not authorized")

    return target_customer_id


def derive_username(identity: str, request_id: str, access_type: str = "ssh") -> str:
    """Derive an OS username from the authenticated identity.

    Per ADR-0011, ephemeral users are named for the real person (not a
    random token) so OS-level audit logs attribute to a human. A short
    suffix from the request_id keeps concurrent sessions by the same user
    to the same host from colliding.

    identity: the user's email or username (e.g. "greg-racker@rgs-test.local")
    request_id: the session UUID (first 4 hex chars used as suffix)
    access_type: "ssh" (Linux, 32-char limit) or "rdp" (Windows, 20-char limit)

    Examples:
      greg-racker@rgs-test.local + a751a325... -> "greg-racker-a751"
    """
    import re

    # Take the local part of an email, lowercase it
    local = identity.split("@")[0].lower()
    # Replace anything not [a-z0-9_-] with a hyphen, collapse repeats
    local = re.sub(r"[^a-z0-9_-]", "-", local)
    local = re.sub(r"-+", "-", local).strip("-")
    # Must start with a letter (Linux useradd requirement)
    if not local or not local[0].isalpha():
        local = "u-" + local
    local = local.strip("-")

    suffix = request_id.replace("-", "")[:4]

    # OS length limits: Linux 32, Windows 20. Reserve room for "-<suffix>".
    max_len = 20 if access_type == "rdp" else 32
    base_max = max_len - (len(suffix) + 1)
    base = local[:base_max].strip("-")

    return f"{base}-{suffix}"


def encrypt_field(plaintext: str, kms_key_id: str) -> str:
    """Encrypt a string with KMS and return base64-encoded ciphertext.
    
    Used to protect ephemeral credentials before writing to DynamoDB.
    Requires KMS_KEY_ID environment variable or explicit key_id parameter.
    """
    import base64
    import boto3

    if not plaintext or not kms_key_id:
        return plaintext

    # Ambient region (AWS_REGION) keeps this portable across regions/partitions (ADR-0017).
    kms = boto3.client("kms")
    response = kms.encrypt(
        KeyId=kms_key_id,
        Plaintext=plaintext.encode("utf-8"),
    )
    return base64.b64encode(response["CiphertextBlob"]).decode("utf-8")


# ---------------------------------------------------------------------------
# Cross-account client factory (ADR-0033 Organization reach).
#
# The control plane reaches a target instance that lives in a MEMBER account by
# assuming that account's deterministic target-access role
# (arn:<partition>:iam::<account>:role/<TARGET_ACCESS_ROLE_NAME>) and building
# the SSM/EC2 client from the vended credentials.
#
# Backward-compatible by design: if no target_account_id is supplied (or it
# equals the caller's own account), it returns an AMBIENT client with only the
# region set - i.e. the original single-account behavior is preserved exactly.
# This lets the same code run in the getting-started single-account profile AND
# in a multi-account Organization without branching in each handler.
# ---------------------------------------------------------------------------

import boto3 as _boto3

_TARGET_ACCESS_ROLE_NAME = os.environ.get("TARGET_ACCESS_ROLE_NAME", "")
_PARTITION = os.environ.get("PORTAL_PARTITION", "aws")

# Cache assumed-role sessions per (account, region) for the Lambda's lifetime.
_assumed_session_cache: dict = {}


def _caller_account_id() -> str:
    try:
        return _boto3.client("sts").get_caller_identity()["Account"]
    except Exception:  # pragma: no cover - best effort
        return ""


def target_client(service: str, region: str, target_account_id: str = "") -> "object":
    """Return a boto3 client for `service` in `region`, reaching a member account
    via the target-access role when `target_account_id` is set and differs from
    the control-plane account. Falls back to an ambient client otherwise.

    Requires TARGET_ACCESS_ROLE_NAME in the environment for cross-account use.
    """
    if not target_account_id or target_account_id == _caller_account_id():
        # Single-account / local: original behavior, region only.
        return _boto3.client(service, region_name=region)

    if not _TARGET_ACCESS_ROLE_NAME:
        raise RuntimeError(
            "TARGET_ACCESS_ROLE_NAME not configured but a cross-account target "
            "was requested (ADR-0033). Set the env var or deploy single-account."
        )

    cache_key = (target_account_id, region)
    creds = _assumed_session_cache.get(cache_key)
    now = datetime.now(timezone.utc)
    if not creds or creds["expiry"] <= now:
        role_arn = (
            f"arn:{_PARTITION}:iam::{target_account_id}:role/{_TARGET_ACCESS_ROLE_NAME}"
        )
        resp = _boto3.client("sts").assume_role(
            RoleArn=role_arn,
            RoleSessionName=f"platform-{service}-{region}"[:64],
            DurationSeconds=3600,
        )
        c = resp["Credentials"]
        creds = {
            "AccessKeyId": c["AccessKeyId"],
            "SecretAccessKey": c["SecretAccessKey"],
            "SessionToken": c["SessionToken"],
            "expiry": c["Expiration"],
        }
        _assumed_session_cache[cache_key] = creds

    return _boto3.client(
        service,
        region_name=region,
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
    )
