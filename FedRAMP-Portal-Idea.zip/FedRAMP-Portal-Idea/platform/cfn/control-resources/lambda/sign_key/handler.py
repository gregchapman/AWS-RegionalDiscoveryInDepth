"""Lambda: POST /api/sign  (ADR-0014 — SSH Certificate Authority)

Signs a user-supplied SSH public key with the CA private key, returning a
short-lived OpenSSH user certificate. No password is ever created or stored.

Ported from production Passport's internal/cacertificate/signer.go.

Request body:
  {
    "request_id": "<access request uuid>",
    "public_key": "ssh-ed25519 AAAA... or ssh-rsa AAAA..."
  }

The username and TTL are looked up from the access-request record in DynamoDB
(not trusted from the client). The issued cert:
  - CertType: user
  - ValidPrincipals: [username, request_id]
  - ValidBefore: now + min(session TTL remaining, 3600s)  (max 1 hour)
  - KeyId: "passport_<username>_<epoch>"  (appears in sshd auth logs -> AU-2/AU-3)
  - Extensions: permit-pty, permit-port-forwarding, permit-agent-forwarding
"""

import time
import boto3
import logging

from cryptography.hazmat.primitives.serialization import (
    load_ssh_private_key,
    load_ssh_public_key,
    SSHCertificateBuilder,
    SSHCertificateType,
)
from cryptography.hazmat.primitives.asymmetric import rsa, ed25519

from portal_utils import (
    get_env,
    get_user_from_event,
    json_response,
    error_response,
    parse_body,
)

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)

MAX_CERT_TTL_SECONDS = 3600  # 1 hour hard cap (matches Passport signer.go)

# Control-plane clients use the Lambda's ambient region (AWS_REGION), so the
# same code runs unchanged in any region/partition (ADR-0017). These target
# management-region resources (Secrets Manager CA key, DynamoDB request table).
_secrets = boto3.client("secretsmanager")
_dynamodb = boto3.client("dynamodb")

# Cache the CA key across warm invocations
_ca_private_key = None


def _load_ca_private_key():
    """Load and cache the CA private key from Secrets Manager."""
    global _ca_private_key
    if _ca_private_key is not None:
        return _ca_private_key
    secret_arn = get_env("SSH_CA_SECRET_ARN")
    resp = _secrets.get_secret_value(SecretId=secret_arn)
    pem = resp["SecretString"].encode("utf-8")
    _ca_private_key = load_ssh_private_key(pem, password=None)
    return _ca_private_key


def _validate_user_public_key(public_key_bytes: bytes):
    """Parse and strength-check the user's public key.

    Mirrors signer.go ValidateUserPublicKey: RSA >= 4096 bits, ed25519 256-bit.
    Returns the loaded public key object or raises ValueError.
    """
    pub = load_ssh_public_key(public_key_bytes)
    if isinstance(pub, rsa.RSAPublicKey):
        if pub.key_size < 4096:
            raise ValueError("invalid ssh-rsa key size (require >= 4096 bits)")
    elif isinstance(pub, ed25519.Ed25519PublicKey):
        pass  # ed25519 is fixed 256-bit
    else:
        raise ValueError("invalid ssh key type (require ssh-rsa or ssh-ed25519)")
    return pub


def _lookup_access_request(request_id: str):
    """Fetch the access-request record; returns the most recent item or None."""
    table_name = get_env("TABLE_NAME")
    result = _dynamodb.query(
        TableName=table_name,
        KeyConditionExpression="request_id = :r",
        ExpressionAttributeValues={":r": {"S": request_id}},
        ScanIndexForward=False,
        Limit=1,
    )
    items = result.get("Items", [])
    return items[0] if items else None


def lambda_handler(event, context):
    """Handle POST /api/sign."""
    logger.info("sign-key invoked")

    user = get_user_from_event(event)
    body = parse_body(event)

    request_id = body.get("request_id")
    public_key_str = body.get("public_key")

    if not request_id:
        return error_response(400, "request_id is required")
    if not public_key_str:
        return error_response(400, "public_key is required")

    # Validate the submitted public key strength
    try:
        _validate_user_public_key(public_key_str.encode("utf-8"))
    except Exception as e:
        logger.warning(f"Public key validation failed: {e}")
        return error_response(400, f"Invalid public key: {e}")

    # Look up the access request (authoritative source for username/TTL/owner)
    item = _lookup_access_request(request_id)
    if not item:
        return error_response(404, "Access request not found")

    # Ownership: caller must own the request (or be an Operator)
    is_operator = "Operators" in user.get("groups", [])
    item_user_id = item.get("user_id", {}).get("S", "")
    if not is_operator and item_user_id != user["user_id"]:
        return error_response(403, "Access denied")

    access_type = item.get("access_type", {}).get("S", "ssh")
    if access_type != "ssh":
        return error_response(400, "SSH certificates only apply to SSH access")

    username = item.get("provisioned_username", {}).get("S", "")
    if not username:
        return error_response(409, "Session not yet provisioned")

    status = item.get("status", {}).get("S", "")
    if status not in ("ACTIVE", "PROVISIONING"):
        return error_response(409, f"Session not connectable (status={status})")

    # Compute validity: min(remaining session TTL, 1 hour cap)
    now = int(time.time())
    expires_at_epoch = int(item.get("expires_at", {}).get("N", str(now)))
    remaining = max(0, expires_at_epoch - now)
    valid_seconds = min(remaining, MAX_CERT_TTL_SECONDS)
    if valid_seconds <= 0:
        return error_response(409, "Session has expired")
    valid_before = now + valid_seconds

    # Build and sign the certificate
    try:
        ca_key = _load_ca_private_key()
        user_pub = load_ssh_public_key(public_key_str.encode("utf-8"))

        key_id = f"passport_{username}_{now}"
        builder = (
            SSHCertificateBuilder()
            .public_key(user_pub)
            .type(SSHCertificateType.USER)
            .key_id(key_id.encode("utf-8"))
            .valid_principals([username.encode("utf-8"), request_id.encode("utf-8")])
            .valid_after(now)
            .valid_before(valid_before)
            .add_extension(b"permit-pty", b"")
            .add_extension(b"permit-port-forwarding", b"")
            .add_extension(b"permit-agent-forwarding", b"")
        )
        certificate = builder.sign(ca_key)
        cert_bytes = certificate.public_bytes()  # OpenSSH cert format
    except Exception as e:
        logger.error(f"Signing failed: {e}")
        return error_response(500, "Failed to sign certificate")

    logger.info(f"Issued cert key_id={key_id} principals=[{username},{request_id}] ttl={valid_seconds}s")

    return json_response(200, {
        "certificate": cert_bytes.decode("utf-8"),
        "key_id": key_id,
        "username": username,
        "valid_before": valid_before,
        "valid_seconds": valid_seconds,
    })
