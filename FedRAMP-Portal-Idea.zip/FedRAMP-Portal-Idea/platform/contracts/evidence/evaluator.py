"""Conservative control-claim evaluation primitives (ADR-0037).

This module is deliberately provider- and storage-neutral. Collectors produce
evidence envelopes; this evaluator decides whether a scoped control claim is
currently supportable. It never turns missing or unverifiable evidence into a
pass.
"""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from datetime import datetime, timezone
from typing import Any, Iterable


RESULTS = {"satisfied", "not_satisfied", "unknown", "not_applicable", "exception"}
RESPONSIBLE_PARTIES = {"platform", "inherited", "organization", "customer", "shared"}
CONTROL_ID = re.compile(r"^[A-Z]{2,4}-[0-9]{1,3}(\([0-9]+\))?$")


def _parse_time(value: Any) -> datetime:
    if not isinstance(value, str):
        raise ValueError("timestamp must be a string")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timestamp must include a timezone")
    return parsed.astimezone(timezone.utc)


def _canonical_without_hash(evidence: dict[str, Any]) -> bytes:
    payload = {key: value for key, value in evidence.items() if key != "evidence_hash"}
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def evidence_digest(evidence: dict[str, Any]) -> str:
    """Return the canonical digest expected in ``evidence_hash``."""
    return "sha256:" + hashlib.sha256(_canonical_without_hash(evidence)).hexdigest()


def _scope_matches(evidence: dict[str, Any], expected: dict[str, Any]) -> bool:
    scope = evidence.get("scope")
    if not isinstance(scope, dict):
        return False
    for key in ("tenant_id", "account_id", "fleet_scope"):
        if key in expected and scope.get(key) != expected[key]:
            return False
    expected_resources = set(expected.get("resource_refs", []))
    actual_resources = set(scope.get("resource_refs", []))
    return not expected_resources or expected_resources == actual_resources


def _invalid_reasons(
    evidence: dict[str, Any],
    *,
    control_id: str,
    profile: str,
    boundary_id: str,
    provider: str,
    scope: dict[str, Any],
    now: datetime,
) -> list[str]:
    reasons: list[str] = []
    required = (
        "evidence_id", "control_id", "profile", "boundary_id", "provider", "scope",
        "result", "responsible_party", "observed_at", "valid_until", "evidence_hash",
        "review",
    )
    reasons.extend(f"missing:{key}" for key in required if key not in evidence)
    if reasons:
        return reasons
    if not isinstance(evidence["evidence_id"], str) or not evidence["evidence_id"]:
        reasons.append("invalid:evidence_id")
    if not isinstance(evidence["control_id"], str) or not CONTROL_ID.fullmatch(evidence["control_id"]):
        reasons.append("invalid:control_id")
    if evidence["control_id"] != control_id:
        reasons.append("scope:control_id")
    if evidence["profile"] != profile:
        reasons.append("scope:profile")
    if evidence["boundary_id"] != boundary_id:
        reasons.append("scope:boundary_id")
    if evidence["provider"] != provider:
        reasons.append("scope:provider")
    if not _scope_matches(evidence, scope):
        reasons.append("scope:tenant_or_resource")
    if evidence["result"] not in RESULTS:
        reasons.append("invalid:result")
    if evidence["responsible_party"] not in RESPONSIBLE_PARTIES:
        reasons.append("invalid:responsible_party")
    try:
        observed_at = _parse_time(evidence["observed_at"])
        valid_until = _parse_time(evidence["valid_until"])
        if valid_until < observed_at:
            reasons.append("invalid:freshness_window")
        if valid_until <= now:
            reasons.append("stale:valid_until")
    except ValueError as exc:
        reasons.append(f"invalid:timestamp:{exc}")
    if evidence.get("evidence_hash") != evidence_digest(evidence):
        reasons.append("integrity:evidence_hash")
    if not isinstance(evidence.get("review"), dict):
        reasons.append("invalid:review")
    if evidence.get("result") == "exception" and not evidence.get("exception_ref"):
        reasons.append("missing:exception_ref")
    return reasons


def evaluate_control_claim(
    evidence_items: Iterable[dict[str, Any]],
    *,
    control_id: str,
    framework: str,
    profile: str,
    boundary_id: str,
    provider: str,
    scope: dict[str, Any],
    title: str,
    responsible_party: str,
    now: datetime | None = None,
    evaluator_version: str = "evaluator-v1",
) -> dict[str, Any]:
    """Evaluate evidence for one exact control/profile/scope tuple.

    Invalid or stale evidence has precedence over a pass. A failed source
    produces ``not_satisfied`` only when all evidence is valid. Approved
    exceptions remain explicit as ``exception``; they are never converted to a
    compliant result.
    """
    if now is None:
        now = datetime.now(timezone.utc)
    now = now.astimezone(timezone.utc)
    evidence = list(evidence_items)
    evidence_ids = [item.get("evidence_id", "") for item in evidence]
    reasons: list[str] = []
    for item in evidence:
        reasons.extend(
            _invalid_reasons(
                item,
                control_id=control_id,
                profile=profile,
                boundary_id=boundary_id,
                provider=provider,
                scope=scope,
                now=now,
            )
        )

    if not evidence:
        result = "unknown"
        reasons.append("missing:evidence")
    elif reasons:
        result = "unknown"
    else:
        source_results = {item["result"] for item in evidence}
        if "not_satisfied" in source_results:
            result = "not_satisfied"
            if len(source_results) > 1:
                reasons.append("conflict:source_results")
        elif "exception" in source_results:
            if all(item.get("review", {}).get("state") == "approved" for item in evidence):
                result = "exception"
            else:
                result = "unknown"
                reasons.append("exception:pending_review")
        elif "unknown" in source_results:
            result = "unknown"
        elif source_results == {"not_applicable"}:
            result = "not_applicable"
        elif source_results == {"satisfied"}:
            result = "satisfied"
        else:
            result = "unknown"
            reasons.append("conflict:source_results")

    claim_seed = "|".join(
        [control_id, framework, profile, boundary_id, provider, json.dumps(scope, sort_keys=True)]
        + sorted(str(value) for value in evidence_ids)
    )
    claim_id = str(uuid.uuid5(uuid.NAMESPACE_URL, claim_seed))
    review_state = "automated" if result in {"satisfied", "not_satisfied", "unknown", "not_applicable"} else "pending"
    valid_until_values = []
    for item in evidence:
        try:
            valid_until_values.append(_parse_time(item["valid_until"]))
        except (KeyError, ValueError, TypeError):
            continue
    claim_valid_until = min(valid_until_values, default=now)

    return {
        "claim_id": claim_id,
        "control_id": control_id,
        "framework": framework,
        "profile": profile,
        "boundary_id": boundary_id,
        "provider": provider,
        "scope": scope,
        "title": title,
        "responsible_party": responsible_party,
        "result": result,
        "observed_at": now.isoformat().replace("+00:00", "Z"),
        "valid_until": claim_valid_until.isoformat().replace("+00:00", "Z"),
        "evaluator_version": evaluator_version,
        "evidence_ids": evidence_ids,
        "review": {"state": review_state},
        "reasons": sorted(set(reasons)),
    }