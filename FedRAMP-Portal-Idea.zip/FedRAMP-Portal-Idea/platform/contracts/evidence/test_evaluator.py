import copy
import unittest
from datetime import datetime, timezone, timedelta

from evaluator import evaluate_control_claim, evidence_digest


NOW = datetime(2026, 9, 29, 12, 0, tzinfo=timezone.utc)


def evidence(result="satisfied", tenant="tenant-a", valid_until="2026-09-29T13:00:00Z"):
    item = {
        "evidence_id": "123e4567-e89b-12d3-a456-426614174000",
        "control_id": "CA-7",
        "framework": "nist-800-53",
        "profile": "moderate",
        "boundary_id": "aws-control-plane",
        "provider": "aws",
        "scope": {"tenant_id": tenant, "resource_refs": ["resource-a"]},
        "claim": "Target posture is continuously evaluated",
        "result": result,
        "responsible_party": "platform",
        "source": {"system": "aws-config", "collected_at": "2026-09-29T12:00:00Z"},
        "observed_at": "2026-09-29T12:00:00Z",
        "valid_until": valid_until,
        "collector_version": "sha256:" + "a" * 64,
        "evidence_refs": [{"id": "config-rule-1", "sha256": "b" * 64}],
        "review": {"state": "automated"},
    }
    item["evidence_hash"] = evidence_digest(item)
    return item


def evaluate(items):
    return evaluate_control_claim(
        items,
        control_id="CA-7",
        framework="nist-800-53",
        profile="moderate",
        boundary_id="aws-control-plane",
        provider="aws",
        scope={"tenant_id": "tenant-a", "resource_refs": ["resource-a"]},
        title="Continuous monitoring",
        responsible_party="platform",
        now=NOW,
    )


class EvaluatorTests(unittest.TestCase):
    def test_valid_evidence_satisfies_claim(self):
        self.assertEqual(evaluate([evidence()])["result"], "satisfied")

    def test_missing_evidence_is_unknown(self):
        claim = evaluate([])
        self.assertEqual(claim["result"], "unknown")
        self.assertIn("missing:evidence", claim["reasons"])

    def test_stale_evidence_is_unknown(self):
        claim = evaluate([evidence(valid_until="2026-09-29T11:59:59Z")])
        self.assertEqual(claim["result"], "unknown")
        self.assertIn("stale:valid_until", claim["reasons"])

    def test_cross_tenant_evidence_is_unknown(self):
        claim = evaluate([evidence(tenant="tenant-b")])
        self.assertEqual(claim["result"], "unknown")
        self.assertIn("scope:tenant_or_resource", claim["reasons"])

    def test_tampered_evidence_is_unknown(self):
        item = evidence()
        item["claim"] = "altered after collection"
        claim = evaluate([item])
        self.assertEqual(claim["result"], "unknown")
        self.assertIn("integrity:evidence_hash", claim["reasons"])

    def test_malformed_timestamp_is_unknown_without_crashing(self):
        item = evidence(valid_until="not-a-timestamp")
        item["evidence_hash"] = evidence_digest(item)
        claim = evaluate([item])
        self.assertEqual(claim["result"], "unknown")
        self.assertTrue(any(reason.startswith("invalid:timestamp") for reason in claim["reasons"]))

    def test_failed_evidence_is_not_satisfied(self):
        claim = evaluate([evidence(result="not_satisfied")])
        self.assertEqual(claim["result"], "not_satisfied")

    def test_unapproved_exception_is_unknown(self):
        item = evidence(result="exception")
        item["exception_ref"] = "poam-1"
        item["evidence_hash"] = evidence_digest(item)
        claim = evaluate([item])
        self.assertEqual(claim["result"], "unknown")
        self.assertIn("exception:pending_review", claim["reasons"])

    def test_approved_exception_remains_explicit(self):
        item = evidence(result="exception")
        item["exception_ref"] = "poam-1"
        item["review"] = {"state": "approved", "reviewer": "reviewer-1"}
        item["evidence_hash"] = evidence_digest(item)
        claim = evaluate([item])
        self.assertEqual(claim["result"], "exception")
        self.assertEqual(claim["review"]["state"], "pending")


if __name__ == "__main__":
    unittest.main()