# Provider contract — connection is provider-defined (DRAFT — ADR-0027)

> Skeleton. Extends ADR-0016's CLI `ConnectionProvider`/`IdentityProvider` into a
> server-side platform contract. PROVISIONAL; the vCenter implementation is the
> pressure test that freezes it (ADR-0031).

Each provider (AWS, vCenter, Azure, GCP) implements this. It emits the canonical
resource model (`schemas/resource-model.md`) and defines connection abstractly.

## Operations
```
List(tenant, filter)        -> [Resource]        # canonical resource model
Get(resource_id)            -> Resource
Start(resource_id)          -> Job
Stop(resource_id)           -> Job
Resize(resource_id, spec)   -> Job
Connect(resource_id, subj)  -> Session           # SEE "Connect is abstract" below
GetCompliance(resource_id)  -> [Finding]         # feeds the evidence plane (ADR-0024)
GetCost(resource_id)        -> Cost
GetAuditEvents(resource_id) -> [Event]
```

## Connect is ABSTRACT (ADR-0027 B1) — the load-bearing rule
`Connect` means **"establish an attributed, brokered, ephemeral session to this
resource that can be verifiably terminated"** (ADR-0023 semantics), NOT "open an
SSM tunnel." Each provider satisfies it its own way:

| Provider | How Connect is satisfied (implementation detail, below the contract) |
|----------|----------------------------------------------------------------------|
| aws      | SSM `StartSession` port-forward + vended scoped STS creds + SSH cert / RDP password (the POC mechanism) |
| vcenter  | vCenter's own session broker (initially over the existing access path; AD-trust auth as `authn_method: ad-trust`) |
| azure    | Bastion / Arc |
| gcp      | IAP / equivalent |

**Nothing SSM-shaped may appear in this contract.** `ssm-credentials` and `sign`
(SSH cert) in the POC become provider-DEFINED steps of AWS's `Connect`, not
platform surface.

## Boundary rule (ADR-0029)
Each provider runs in its OWN authorization boundary with its OWN authorization
package and connects to the core only through this contract — a controlled,
audited interface, never a shared network. The existing vCenter ATO stays intact;
a reach into a commercial cloud never contaminates the AWS IL4 boundary.

## Provider Terraform modules deploy the ADAPTER, not customer resources
`platform/modules/provider-<name>/` stands up the adapter runtime + its scoped
access — it does not provision the tenant's workloads.
