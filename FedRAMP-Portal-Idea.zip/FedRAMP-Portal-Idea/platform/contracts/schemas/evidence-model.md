# Evidence and Control Claim Model

Status: **provisional contract; ADR-0037**

This schema is the product boundary for machine-readable assurance evidence. It
is intentionally separate from raw CloudTrail, Config, Security Hub, or SSM
records. Raw records are evidence sources; a control claim is the scoped,
versioned evaluation that an assessor or consumer can understand.

Every claim must identify its framework/profile, authorization boundary,
provider, tenant/resource scope, responsible party, result, observed time,
freshness deadline, evaluation rule, source evidence, integrity hash, and review
or exception state. Missing or stale evidence produces `unknown`, never
`satisfied`.

## Canonical results

- `satisfied`: the current evidence satisfies the versioned test.
- `not_satisfied`: the test failed.
- `unknown`: evidence is missing, stale, contradictory, or unverifiable.
- `not_applicable`: the control is explicitly out of scope for the profile.
- `exception`: a documented, approved residual risk exists with an expiry.

## Evidence envelope

```json
{
  "evidence_id": "uuid",
  "control_id": "CA-7",
  "profile": "nist-800-53-moderate",
  "boundary_id": "aws-control-plane",
  "provider": "aws",
  "tenant_id": "tenant-reference",
  "resource_refs": ["provider-resource-id"],
  "claim": "SSM-managed targets are continuously evaluated",
  "result": "satisfied",
  "responsible_party": "platform|inherited|organization|customer|shared",
  "source": "aws-config",
  "observed_at": "2026-09-29T12:00:00Z",
  "valid_until": "2026-09-29T13:00:00Z",
  "evaluator_version": "sha256:...",
  "evidence_refs": ["evidence-object-reference"],
  "evidence_hash": "sha256:...",
  "review": {
    "state": "automated|pending|approved|rejected|expired",
    "reviewer": null,
    "reviewed_at": null,
    "reason": null
  },
  "exception_ref": null
}
```

The canonical JSON Schemas now live beside this descriptor as
`evidence.schema.json` and `control-claim.schema.json`. The next implementation
step is to validate all collected evidence and published claims against those
schemas in the runtime and CI.