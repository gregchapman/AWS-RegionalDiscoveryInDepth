# Identity assertion — assurance, not mechanism (ADR-0028)

The platform authorizes on **assurance + attribution**, not on HOW the subject
authenticated. Cognito is one implementation; an enterprise IdP / customer SAML /
OIDC / CAC-PIV / hardware-FIDO2 / (transitional) AD-trust all normalize to the
shape below beneath the contract. PROVISIONAL until a second IdP proves it (ADR-0031).
Mirrors the `IdentityAssertion` schema in `../openapi/consumer-api.v1.yaml`.

**Rule:** platform authorization decisions reference `authn_assurance` and
`tenant`/`groups`, **never** `authn_method`. Adding hardware security tokens or a
customer IdP is an implementation below this contract, not a platform change.
This is what makes "not married to Cognito" real, and lets a vCenter estate keep
its AD trust initially (`authn_method: ad-trust`) while migrating credential-less
behind the same assertion.

## Machine-readable JSON Schema (copy-ready)

> The block below IS the finished JSON Schema (draft 2020-12). It lives inside
> this `.md` because the authoring tool blocks writing `*.schema.json` files
> directly. **To use it: copy the block into `identity-assertion.schema.json`**
> as-is — the `$schema`/`$id` header is already included.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "identity-assertion.schema.json",
  "title": "Identity assertion — assurance, not mechanism (ADR-0028)",
  "type": "object",
  "required": ["subject", "issuer", "tenant", "authn_assurance"],
  "additionalProperties": false,
  "properties": {
    "subject": {
      "type": "string",
      "description": "Stable subject id."
    },
    "issuer": {
      "type": "string",
      "description": "Which IdP issued the assertion.",
      "examples": ["example-idp", "cognito"]
    },
    "tenant": {
      "type": "string",
      "description": "Tenant scope / customer_id (ADR-0021)."
    },
    "authn_method": {
      "type": "string",
      "description": "HOW the subject authenticated. Recorded for audit, NEVER used for authorization.",
      "examples": ["totp", "fido2", "piv", "hardware-token", "ad-trust"]
    },
    "authn_assurance": {
      "type": "string",
      "description": "The LEVEL the authentication ceremony provided — what the platform authorizes on.",
      "enum": ["single-factor", "mfa", "phishing-resistant", "hardware-backed"]
    },
    "mfa": {
      "type": "boolean",
      "description": "Whether more than one factor was presented."
    },
    "groups": {
      "type": "array",
      "description": "Role/authorization groups (e.g. Operators vs Tenants) — the control-relationship role, not an org label.",
      "items": { "type": "string" }
    },
    "session_id": {
      "type": "string",
      "description": "Correlates the assertion to a platform session."
    }
  }
}
```

## Example assertion

```json
{
  "subject": "user-0472",
  "issuer": "example-idp",
  "tenant": "tenant-a",
  "authn_method": "fido2",
  "authn_assurance": "phishing-resistant",
  "mfa": true,
  "groups": ["Operators"],
  "session_id": "s-91a2f0"
}
```
