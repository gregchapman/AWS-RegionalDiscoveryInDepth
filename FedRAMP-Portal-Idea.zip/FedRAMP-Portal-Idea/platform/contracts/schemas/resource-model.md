# Canonical Resource + Capability model (ADR-0027)

Provider-neutral shape every managed thing emits. The consumer renders and acts
from `capabilities`, **never** from provider-specific semantics. A vCenter VM, an
EC2 instance, and an Azure VM all emit this same shape. PROVISIONAL until the
vCenter provider pressure-tests it (ADR-0031). This mirrors the `Resource` schema
in `../openapi/consumer-api.v1.yaml`.

**Required:** `id`, `provider`, `resource_type`, `state`, `capabilities`.
**Rule:** the UI shows Start/Stop/Console/Connect/… strictly from `capabilities`;
provider differences are expressed by which capabilities are present, not by the
consumer knowing AWS vs vCenter vs Azure.

## Machine-readable JSON Schema (copy-ready)

> The block below IS the finished JSON Schema (draft 2020-12). It lives inside
> this `.md` because the authoring tool blocks writing `*.schema.json` files
> directly. **To use it: copy the block into `resource.schema.json`** as-is — the
> `$schema`/`$id` header is already included — and it will validate/codegen with
> any standard tool.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "resource.schema.json",
  "title": "Canonical Resource + Capability model (ADR-0027)",
  "type": "object",
  "required": ["id", "provider", "resource_type", "state", "capabilities"],
  "additionalProperties": false,
  "properties": {
    "id": {
      "type": "string",
      "description": "Platform-canonical id, stable across providers.",
      "examples": ["r-4f8372"]
    },
    "provider": {
      "type": "string",
      "description": "Provider that backs this resource.",
      "enum": ["aws", "vcenter", "azure", "gcp"]
    },
    "provider_resource_id": {
      "type": "string",
      "description": "Native id in the provider.",
      "examples": ["i-1234567890abcdef0", "vm-1042"]
    },
    "resource_type": {
      "type": "string",
      "description": "Canonical type, NOT provider-specific.",
      "examples": ["compute"]
    },
    "name": { "type": "string" },
    "tenant": {
      "type": "string",
      "description": "Owning tenant / customer_id. Tenant isolation is inviolable (ADR-0021)."
    },
    "location": {
      "type": "string",
      "description": "Region / datacenter / cluster.",
      "examples": ["us-east-1"]
    },
    "state": {
      "type": "string",
      "description": "Canonical lifecycle state, provider-neutral.",
      "enum": ["running", "stopped", "starting", "stopping", "rebooting", "terminated", "unknown"]
    },
    "capabilities": {
      "type": "array",
      "description": "What the consumer may offer for THIS resource. The UI renders controls strictly from this list.",
      "items": {
        "type": "string",
        "enum": ["start", "stop", "reboot", "resize", "console", "connect", "metrics", "cost", "compliance", "backup"]
      },
      "uniqueItems": true
    }
  }
}
```

## Example instance (AWS provider)

```json
{
  "id": "r-4f8372",
  "provider": "aws",
  "provider_resource_id": "i-1234567890abcdef0",
  "resource_type": "compute",
  "name": "web-01",
  "tenant": "tenant-a",
  "location": "us-east-1",
  "state": "running",
  "capabilities": ["start", "stop", "reboot", "console", "connect", "metrics", "compliance"]
}
```
