# platform/live — root deployments that compose modules

Each subfolder is an independently-stated deployment (its own Terraform state)
that COMPOSES `../modules/`, always including the REQUIRED baseline. A deployment
is a **profile**: which compliance profile (800-53 Moderate / IL4 / 800-171),
which partition (commercial / GovCloud), which identity + provider modules are
switched on.

- **`poc-commercial/`** — a module-composed deployment that stands up ALONGSIDE
  the running POC (the root `terraform/` stack): its OWN state, DISTINCT resource
  names, same account/region acceptable for now (separate account is the
  production-honest target — ADR-0032). Building/testing this NEVER disturbs the
  running POC demo.
- **`govcloud-dev/` `govcloud-test/` `govcloud-prod/`** — future IL4 profiles.

Layer convention inside a profile (each its own state; layer boundary ≈ trust
boundary; loosely coupled per ADR-0030):
```
00-bootstrap  10-foundation  20-identity  30-security(_baseline)
40-platform(api-edge/workflow/audit)  50-providers  60-portal  70-observability
```

STATUS: scaffold. No live deployment authored yet.
