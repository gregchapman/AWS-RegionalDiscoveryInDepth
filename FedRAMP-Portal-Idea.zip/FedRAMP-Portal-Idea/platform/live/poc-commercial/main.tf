###############################################################################
# live/poc-commercial — the reference composition
#
# Wires the eight platform modules into one deployable stack, in a commercial
# AWS partition, standing up ALONGSIDE the POC (distinct name_prefix). This is
# the "reference client" root (ADR-0026): it demonstrates the contract wiring an
# adopter would copy and rebrand. Nothing here re-solves 800-53 — it composes.
#
# CYCLE-BREAK (documented): the kms key policies name the consuming role ARNs
# (POC-faithful), and the broker/sfn Lambdas need the key ARNs. Passing module
# outputs both ways would create a kms <-> access-broker module cycle. Because
# both consuming role names are DETERMINISTIC from name_prefix, we CONSTRUCT
# those ARNs from the account/partition here and hand them to kms. kms then
# depends only on this root's caller-identity data, not on the other modules —
# no cycle, same key policy.
###############################################################################

terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    archive = {
      source  = "hashicorp/archive"
      version = "~> 2.0"
    }
  }
}

provider "aws" {
  region = var.region
}

# Regional detector aliases the _baseline module expects (two-region coverage).
provider "aws" {
  alias  = "region_a"
  region = var.region
}
provider "aws" {
  alias  = "region_b"
  region = var.secondary_region
}

data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}

locals {
  name_prefix = var.name_prefix
  account_id  = data.aws_caller_identity.current.account_id
  partition   = data.aws_partition.current.partition

  # Deterministic consuming-role ARNs (must match the names the modules create).
  broker_handler_role_arn = "arn:${local.partition}:iam::${local.account_id}:role/${local.name_prefix}-broker-handler"
  sfn_exec_role_arn       = "arn:${local.partition}:iam::${local.account_id}:role/${local.name_prefix}-sfn-exec"

  tags = {
    Project   = "fedramp-platform"
    Stack     = "poc-commercial"
    ManagedBy = "terraform"
  }
}

###############################################################################
# Class 2 — compliance baseline (account-wide detectors/guardrails)
###############################################################################

module "baseline" {
  source = "../../modules/_baseline"
  providers = {
    aws          = aws
    aws.region_a = aws.region_a
    aws.region_b = aws.region_b
  }
  name_prefix = local.name_prefix
  tags        = local.tags
}

###############################################################################
# Class 1 — invariant core: keys, score, conductor, access path
###############################################################################

module "kms" {
  source      = "../../modules/kms"
  name_prefix = local.name_prefix

  # POC-faithful key policies naming the consuming roles (ARNs constructed above
  # to avoid the module cycle).
  lambda_exec_role_arn = local.broker_handler_role_arn
  sfn_exec_role_arn    = local.sfn_exec_role_arn

  tags = local.tags
}

module "data_score" {
  source      = "../../modules/data-score"
  name_prefix = local.name_prefix
  tags        = local.tags
}

module "workflow_engine" {
  source      = "../../modules/workflow-engine"
  name_prefix = local.name_prefix

  table_arn = module.data_score.table_arn

  # Must match access-broker's public-key parameter name.
  ssh_ca_public_key_param = module.access_broker.ssh_ca_public_key_param

  tags = local.tags
}

module "access_broker" {
  source      = "../../modules/access-broker"
  name_prefix = local.name_prefix

  # from kms
  credentials_key_arn = module.kms.credentials_key_arn
  credentials_key_id  = module.kms.credentials_key_id
  ssh_ca_key_arn      = module.kms.ssh_ca_key_arn

  # from data-score
  table_name               = module.data_score.table_name
  table_arn                = module.data_score.table_arn
  table_index_arn_wildcard = module.data_score.table_index_arn_wildcard

  # from workflow-engine
  state_machine_arn = module.workflow_engine.state_machine_arn

  session_ttl_minutes = var.session_ttl_minutes
  tags                = local.tags
}

###############################################################################
# Class 3 — customer-owned: identity (reference: Cognito)
###############################################################################

module "identity" {
  source      = "../../modules/identity-cognito"
  name_prefix = local.name_prefix

  callback_urls = var.portal_domain != "" ? ["https://${var.portal_domain}/callback"] : ["http://localhost:5173/callback"]
  logout_urls   = var.portal_domain != "" ? ["https://${var.portal_domain}"] : ["http://localhost:5173"]

  tags = local.tags
}

###############################################################################
# Class 2 — the contract front door
###############################################################################

module "api_edge" {
  source      = "../../modules/api-edge"
  name_prefix = local.name_prefix

  # identity seam (ADR-0028)
  jwt_issuer_url = module.identity.issuer_url
  jwt_audiences  = [module.identity.user_pool_client_id]

  # access-lifecycle handlers (from access-broker)
  access_handlers = module.access_broker.handlers

  # portal/edge contract (optional custom domain + SPA bucket)
  spa_bucket_name     = var.spa_bucket_name
  spa_bucket_arn      = var.spa_bucket_arn
  portal_domain       = var.portal_domain
  acm_certificate_arn = var.acm_certificate_arn
  hosted_zone_id      = var.hosted_zone_id

  target_regions = var.target_regions
  tags           = local.tags
}
