###############################################################################
# live/poc-commercial — outputs (the operator-facing seam)
###############################################################################

output "portal_url" {
  description = "Public portal URL (custom domain if configured, else the default API stage)."
  value       = module.api_edge.portal_url
}

output "api_endpoint" {
  description = "Default execute-api endpoint."
  value       = module.api_edge.api_endpoint
}

output "cognito_user_pool_id" {
  description = "Identity pool id (reference IdP)."
  value       = module.identity.user_pool_id
}

output "cognito_user_pool_client_id" {
  description = "SPA app-client id."
  value       = module.identity.user_pool_client_id
}

output "cognito_domain" {
  description = "Cognito hosted-UI domain prefix."
  value       = module.identity.user_pool_domain
}

output "state_machine_arn" {
  description = "The conductor (access-lifecycle state machine) ARN."
  value       = module.workflow_engine.state_machine_arn
}

output "access_requests_table" {
  description = "The score (DynamoDB table) name."
  value       = module.data_score.table_name
}

output "ssh_ca_secret_arn" {
  description = "Secrets Manager ARN for the SSH CA private key (populate with init-ssh-ca.sh)."
  value       = module.access_broker.ssh_ca_secret_arn
}

output "ssh_ca_public_key_param" {
  description = "SSM parameter name for the SSH CA public key (populate with init-ssh-ca.sh)."
  value       = module.access_broker.ssh_ca_public_key_param
}
