###############################################################################
# live/poc-commercial — variables
###############################################################################

variable "region" {
  description = "Primary AWS region for the stack."
  type        = string
  default     = "us-east-1"
}

variable "secondary_region" {
  description = "Secondary region for the baseline's two-region detector coverage."
  type        = string
  default     = "us-west-2"
}

variable "name_prefix" {
  description = "Name prefix for every resource. Distinct from the POC ('fedramp-portal') so the platform stands up alongside it (ADR-0032)."
  type        = string
  default     = "fedramp-platform"
}

variable "session_ttl_minutes" {
  description = "Maximum session lifetime."
  type        = number
  default     = 60
}

variable "target_regions" {
  description = "Regions the list-instances endpoint enumerates."
  type        = list(string)
  default     = ["us-east-1", "us-west-2"]
}

# --- portal/edge contract (optional; empty = default API endpoint, no SPA) ---
variable "spa_bucket_name" {
  type    = string
  default = ""
}
variable "spa_bucket_arn" {
  type    = string
  default = ""
}
variable "portal_domain" {
  type    = string
  default = ""
}
variable "acm_certificate_arn" {
  type    = string
  default = ""
}
variable "hosted_zone_id" {
  type    = string
  default = ""
}
