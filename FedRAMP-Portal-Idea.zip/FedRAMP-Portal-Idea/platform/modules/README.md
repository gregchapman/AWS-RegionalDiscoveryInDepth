# platform/modules — reusable Terraform building blocks

THREE classes of module (see `../../docs/TARGET-ARCHITECTURE.md` §1a). The class
tells an adopter what they may touch.

## CLASS 1 — INVARIANT CORE (the gold; NO swap seam — do not make these pluggable)
The Passport V2 capability that makes the guarantee real. There is deliberately
no configuration that replaces or routes around these.
- **`workflow-engine/`** — the Step Functions CONDUCTOR + its Lambdas + IAM
  (verified teardown, ADR-0023). The orchestration/choreography that gives the
  gold its value.
- **`access-broker/`** — the SSM Session Manager brokered access path + the
  session-broker role + credential vend + SSH-cert signing (ADR-0012/0014). SSM
  is THE path — no bastions/VPN, ever (ADR-0006). Providers' `connect` is an
  SSM-equivalent brokered path (ADR-0027 B1), never a jump host.
- **`data-score/`** — the DynamoDB access-request table + GSIs (the "score";
  ADR-0023). Drives nothing, records everything.
- **`kms/`** — the credential + SSH-CA keys.

## CLASS 2 — COMPLIANCE BASELINE (required, inherited, graded; no opt-out)
Composed into every profile; graded against the 800-53 umbrella (ADR-0029).
- **`_baseline/`** — attributed C2 plane (ADR-0024), audit/evidence,
  CloudTrail/Config/SSM-logging, encryption, zero-inbound, tenant-isolation
  invariants (ADR-0021), the compliance-PROFILE selector + inheritance manifest.
- **`api-edge/`** — the Consumer API front door + JWT authorizer (the enforcement
  point; ADR-0026). The contract, not the UI, is where authz happens.

## CLASS 3 — CUSTOMER-OWNED (replaceable behind contracts; anti-lock-in)
Swap these WITHOUT touching Class 1 or weakening Class 2.
- **`identity/`** — `cognito` | `saml` | `oidc` | `rgs-idp` | `ad` behind the
  identity assertion (assurance, not mechanism — ADR-0028).
- **`mfa/`** — `totp` | `fido2` | `piv` | `swissbit` | vendor — expressed as
  required ASSURANCE, satisfied by the chosen IdP (ADR-0028).
- **`portal-runtime/`** — the REFERENCE consumer. Fully replaceable; an adopter
  brings their own front end / branding as a client of the Consumer API
  (ADR-0026). Holds no privilege a third-party consumer couldn't.
- **`edge-dns/`** — domain, portal DNS, TLS cert (create-vs-consume).
- **`provider-aws/`**, **`provider-vcenter/`**, `provider-azure/`, `provider-gcp/`
  — each implements the Provider contract (ADR-0027); deploys the ADAPTER +
  scoped access, in its OWN authorization boundary (ADR-0029). NOTE: `provider-*`
  is customer-selectable, but each provider's `connect` is Class-1-constrained
  (brokered/SSM-equivalent, never a bastion).

Rule of thumb: **if customizing it could weaken a control or route around SSM /
the orchestration core, it is NOT customizable.** Branding, UX, IdP, MFA, domain,
region/OU scope, and which providers are yours. The access path, the orchestration
engine, and the control posture are ours (inherited).

## REUSE the POC's code and bug fixes (this is not a rewrite)

The POC is the PROVEN implementation. Its handlers, scripts, state machine, and
utilities carry hard-won bug fixes (I8 SSH-persist, I9 two-records/operator lens,
I10 Windows disconnected-session cleanup, the ADR-0023 verified-teardown conductor,
ADR-0024/0025 attribution + operator revoke). We do NOT re-derive any of that —
re-deriving would discard debugging we already paid for and risk reintroducing the
exact bugs we fixed.

**The rule:**
> Modules REUSE the POC's application code and bug fixes (copy the Lambda
> handlers / cleanup scripts / state-machine / `portal_utils`, PRESERVING the
> fixes). Modules only re-author the Terraform PACKAGING — `variables.tf` /
> `main.tf` / `outputs.tf` / the module interface — so the proven code becomes
> composable WITHOUT touching the POC's live Terraform state (ADR-0032).

So a typical module = **the same proven source the POC runs** + a fresh
parameterized Terraform wrapper. The code is the asset; the module is the
reusable packaging around it.

**Provenance:** each module records which POC path it was extracted from and
which fixes it carries (a `PROVENANCE` note in the module), so lineage is legible
and reconcilable if the POC is ever changed. (Source-sharing strategy — copy vs.
a shared `platform/src/` — is copy-with-provenance for now, since the POC is
frozen-as-deployed and drift risk is low; revisit if both evolve in parallel.)

STATUS: scaffold. Modules re-author only the Terraform packaging around the POC's
proven code; the POC's live state is never moved (see `../README.md`, ADR-0032).
