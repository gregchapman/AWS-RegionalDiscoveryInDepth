# PROVENANCE — module `_baseline`

**Extracted from:** the POC layer `terraform/05-security-baseline/`
(`main.tf`, `variables.tf`, `outputs.tf`) as deployed in the running POC.

**Class:** 2 — COMPLIANCE BASELINE (required, inherited, graded). See
`../README.md` and `../../../docs/TARGET-ARCHITECTURE.md` §1a.

**What was REUSED verbatim (the proven asset — ADR-0032 reuse rule):**
- CloudTrail: multi-region, log-file validation, KMS-encrypted S3 + lifecycle
  (Glacier@90d, expire@retention), CW delivery role/group (AU-9/AU-11).
- SSM Session Manager logging: S3 + CW log group, encryption, lifecycle (AU-12).
- AWS Config: recorder + delivery channel + S3 + IAM role + the three rules
  (required-tags, ec2-managed-by-ssm, restricted-ssh) (CM-6).
- GuardDuty detector config (SI-4); Security Hub account (CA-7).
- Partition-safe ARNs via `data.aws_partition` (ADR-0017).

**What was RE-AUTHORED (packaging only, not logic):**
- Removed the root-layer `provider {}` and `terraform { backend }` blocks — a
  MODULE inherits providers from its caller. Regional GuardDuty detectors now
  take providers via `configuration_aliases = [aws.region_a, aws.region_b]`
  passed by the root deployment (was hardcoded `aws.us_east_2` / `aws.us_west_1`).
- Resource names parameterized via `var.name_prefix` (default `fedramp-platform`,
  DISTINCT from the POC's `fedramp-portal`) so a platform deployment stands up
  ALONGSIDE the running POC without collision (ADR-0032).
- Security Hub standards are now selected by `var.compliance_profile` (a
  `for_each` over a profile→standards map) instead of two hardcoded
  subscriptions — implements the compliance-PROFILE selector (ADR-0029). 800-53
  is the umbrella; profiles add/select standards.
- Region scope generalized to `var.scoped_regions` (customer choice).
- The account-wide `SSM-SessionManagerRunShell` document is now `count`-gated by
  `var.enable_ssm_session_document` (default FALSE) because it's a named,
  account-singleton the POC already owns — must not be double-owned (ADR-0032).
- `enable_guardduty/security_hub/config` default to FALSE here (the POC's org
  defers them); the POC layer defaulted true. Flip per deployment.

**Bug fixes carried:** none specific to this layer — 05 was not implicated in
I8/I9/I10 (those were in 03-api). This is a faithful structural reuse.

**Reconciliation note:** if the POC's `terraform/05-security-baseline` is ever
changed, diff it against this module and update deliberately. The POC is
frozen-as-deployed, so drift risk is low.

**Not yet done (module completeness):** no `terraform validate` has been run on
this module in isolation (it needs a caller supplying the `aws`, `aws.region_a`,
`aws.region_b` providers). Validate when the first `live/poc-commercial/` root
composes it. A `README.md` for the module usage/interface is TODO.
