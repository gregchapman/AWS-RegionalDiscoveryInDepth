# module: _baseline — REQUIRED security / 800-53 compliance baseline

> **This module is not optional and has no opt-out.** Every `live/<profile>/`
> deployment composes it. It is what lets us tell an adopter "don't worry about
> the 800-53 mountain — you inherit it." (ADR-0026, ADR-0029; §8 of
> `../../../docs/ARCHITECTURE.md`.)

Scope (what the baseline guarantees so the adopter doesn't have to build it):
- **Attributed command-and-control plane** — every action attributed + logged,
  privileged on-behalf-of actions justified fail-closed (ADR-0024).
- **Audit / evidence plane** — CloudTrail + structured audit + the Evidence and
  Assurance Plane defined by ADR-0037. Claims are scoped, freshness-bound,
  provenance-linked, and explicit about inherited vs. customer responsibility.
- **Zero-inbound posture** (ADR-0006), **tenant isolation** invariants (ADR-0021),
  **encryption at rest/in transit** (SC-8/SC-13/SC-28), **KMS key management**.
- **Compliance PROFILE selector** — 800-53 Moderate / IL4 / 800-171 as *which
  controls apply + which partition/services are in scope* (ADR-0029), not a fork.
- **The inheritance manifest** — emits, per deployment, the list of controls the
  adopter INHERITS vs. the customer-responsibility controls they still own
  (ADR-0020, no false assurance).

The contracts (`../../contracts/`) are written so a capability module that would
weaken any baseline guarantee simply does not satisfy the contract.

STATUS: scaffold placeholder for the evidence implementation. The target
contract is now explicit in ADR-0037 and
`contracts/schemas/evidence-model.md`; the collectors, evaluator, durable
evidence store, review workflow, and backed `/audit`/`/compliance` endpoints
remain build work. Patterns to extract from the POC: the terminate/cleanup
attribution, the CloudTrail/observability layer (`terraform/05-*`,
`terraform/06-observability`), the KMS + zero-inbound SG posture.
