###############################################################################
# module: _baseline — Class 2 COMPLIANCE BASELINE (required, inherited, graded)
#
# REUSE of the proven POC layer terraform/05-security-baseline (PROVENANCE.md).
# The RESOURCE code is carried forward verbatim in intent; only the PACKAGING is
# re-authored for module use (ADR-0032):
#   * NO provider{} / terraform{} blocks here — a module inherits providers from
#     its caller. Regional detectors take providers via `providers = { aws.rX }`
#     passed by the root deployment.
#   * Resource names are parameterized via var.name_prefix (distinct from the POC
#     so this stands up ALONGSIDE it without collision).
#   * Security Hub standards are selected by var.compliance_profile (ADR-0029).
#   * Region scope is var.scoped_regions (customer choice — TARGET-ARCH §1a).
#
# Controls: SI-4 (GuardDuty) · CA-7 (Security Hub) · CM-6 (Config) ·
#           AU-9/AU-11 (CloudTrail, retention) · AU-12 (SSM session logging).
###############################################################################

terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source                = "hashicorp/aws"
      version               = "~> 5.0"
      configuration_aliases = [aws.region_a, aws.region_b]
    }
  }
}

data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}
data "aws_region" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  partition  = data.aws_partition.current.partition # aws | aws-us-gov (ADR-0017)
  region     = data.aws_region.current.name

  # Map compliance_profile -> the Security Hub standards to subscribe.
  # 800-53 is the umbrella; profiles add/select the relevant standard arns.
  sh_standards = {
    "nist-800-53-moderate" = ["nist-800-53/v/5.0.0", "aws-foundational-security-best-practices/v/1.0.0"]
    "nist-800-53-high"     = ["nist-800-53/v/5.0.0", "aws-foundational-security-best-practices/v/1.0.0"]
    "il4"                  = ["nist-800-53/v/5.0.0", "aws-foundational-security-best-practices/v/1.0.0"]
    "nist-800-171"         = ["nist-800-53/v/5.0.0"]
    "irs-1075"             = ["nist-800-53/v/5.0.0"]
    "pci-dss"              = ["pci-dss/v/3.2.1", "nist-800-53/v/5.0.0"]
    "hipaa"                = ["nist-800-53/v/5.0.0"]
  }
}

###############################################################################
# GuardDuty (SI-4) — primary + scoped regions (regional providers from caller)
###############################################################################

resource "aws_guardduty_detector" "primary" {
  count  = var.enable_guardduty ? 1 : 0
  enable = true

  finding_publishing_frequency = "FIFTEEN_MINUTES"

  datasources {
    s3_logs {
      enable = true
    }
    kubernetes {
      audit_logs {
        enable = false
      }
    }
    malware_protection {
      scan_ec2_instance_with_findings {
        ebs_volumes {
          enable = true
        }
      }
    }
  }
}

resource "aws_guardduty_detector" "region_a" {
  count    = var.enable_guardduty ? 1 : 0
  provider = aws.region_a
  enable   = true

  finding_publishing_frequency = "FIFTEEN_MINUTES"
}

resource "aws_guardduty_detector" "region_b" {
  count    = var.enable_guardduty ? 1 : 0
  provider = aws.region_b
  enable   = true

  finding_publishing_frequency = "FIFTEEN_MINUTES"
}

###############################################################################
# Security Hub (CA-7) — standards selected by the compliance profile (ADR-0029)
###############################################################################

resource "aws_securityhub_account" "main" {
  count = var.enable_security_hub ? 1 : 0
}

resource "aws_securityhub_standards_subscription" "profile" {
  for_each      = var.enable_security_hub ? toset(local.sh_standards[var.compliance_profile]) : toset([])
  depends_on    = [aws_securityhub_account.main]
  standards_arn = "arn:${local.partition}:securityhub:${local.region}::standards/${each.value}"
}

###############################################################################
# AWS Config (CM-6) — recorder + delivery + rules (unchanged from POC intent)
###############################################################################

resource "aws_config_configuration_recorder" "main" {
  count    = var.enable_config ? 1 : 0
  name     = "${var.name_prefix}-config-recorder"
  role_arn = aws_iam_role.config[0].arn

  recording_group {
    all_supported                 = true
    include_global_resource_types = true
  }
}

resource "aws_config_delivery_channel" "main" {
  count          = var.enable_config ? 1 : 0
  name           = "${var.name_prefix}-config-channel"
  s3_bucket_name = aws_s3_bucket.config[0].id

  snapshot_delivery_properties { delivery_frequency = "Six_Hours" }
  depends_on = [aws_config_configuration_recorder.main]
}

resource "aws_config_configuration_recorder_status" "main" {
  count      = var.enable_config ? 1 : 0
  name       = aws_config_configuration_recorder.main[0].name
  is_enabled = true
  depends_on = [aws_config_delivery_channel.main]
}

resource "aws_s3_bucket" "config" {
  count  = var.enable_config ? 1 : 0
  bucket = "${var.name_prefix}-config-${local.account_id}"
  tags   = var.tags
}

resource "aws_s3_bucket_versioning" "config" {
  count  = var.enable_config ? 1 : 0
  bucket = aws_s3_bucket.config[0].id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "config" {
  count  = var.enable_config ? 1 : 0
  bucket = aws_s3_bucket.config[0].id
  rule {
    apply_server_side_encryption_by_default { sse_algorithm = "aws:kms" }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_public_access_block" "config" {
  count                   = var.enable_config ? 1 : 0
  bucket                  = aws_s3_bucket.config[0].id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_policy" "config" {
  count  = var.enable_config ? 1 : 0
  bucket = aws_s3_bucket.config[0].id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AWSConfigBucketPermissionsCheck"
        Effect    = "Allow"
        Principal = { Service = "config.amazonaws.com" }
        Action    = "s3:GetBucketAcl"
        Resource  = aws_s3_bucket.config[0].arn
      },
      {
        Sid       = "AWSConfigBucketDelivery"
        Effect    = "Allow"
        Principal = { Service = "config.amazonaws.com" }
        Action    = "s3:PutObject"
        Resource  = "${aws_s3_bucket.config[0].arn}/AWSLogs/${local.account_id}/Config/*"
        Condition = { StringEquals = { "s3:x-amz-acl" = "bucket-owner-full-control" } }
      }
    ]
  })
}

resource "aws_iam_role" "config" {
  count = var.enable_config ? 1 : 0
  name  = "${var.name_prefix}-config-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "config.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "config" {
  count      = var.enable_config ? 1 : 0
  role       = aws_iam_role.config[0].name
  policy_arn = "arn:${local.partition}:iam::aws:policy/service-role/AWS_ConfigRole"
}

resource "aws_iam_role_policy" "config_s3" {
  count = var.enable_config ? 1 : 0
  name  = "config-s3-delivery"
  role  = aws_iam_role.config[0].id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["s3:PutObject", "s3:GetBucketAcl"]
      Resource = [aws_s3_bucket.config[0].arn, "${aws_s3_bucket.config[0].arn}/*"]
    }]
  })
}

resource "aws_config_config_rule" "required_tags" {
  count = var.enable_config ? 1 : 0
  name  = "${var.name_prefix}-required-tags"
  source {
    owner             = "AWS"
    source_identifier = "REQUIRED_TAGS"
  }
  input_parameters = jsonencode({ tag1Key = "Customer", tag2Key = "CustomerAccess", tag3Key = "ManagedBy" })
  scope { compliance_resource_types = ["AWS::EC2::Instance"] }
  depends_on = [aws_config_configuration_recorder_status.main]
}

resource "aws_config_config_rule" "ec2_managed_by_ssm" {
  count = var.enable_config ? 1 : 0
  name  = "${var.name_prefix}-ec2-managed-by-ssm"
  source {
    owner             = "AWS"
    source_identifier = "EC2_INSTANCE_MANAGED_BY_SSM"
  }
  scope { compliance_resource_types = ["AWS::EC2::Instance"] }
  depends_on = [aws_config_configuration_recorder_status.main]
}

resource "aws_config_config_rule" "restricted_ssh" {
  count = var.enable_config ? 1 : 0
  name  = "${var.name_prefix}-restricted-ssh"
  source {
    owner             = "AWS"
    source_identifier = "INCOMING_SSH_DISABLED"
  }
  scope { compliance_resource_types = ["AWS::EC2::SecurityGroup"] }
  depends_on = [aws_config_configuration_recorder_status.main]
}

###############################################################################
# CloudTrail (AU-9 / AU-11) — always on; multi-region; log-file validation
###############################################################################

resource "aws_s3_bucket" "cloudtrail" {
  bucket = "${var.name_prefix}-cloudtrail-${local.account_id}"
  tags   = var.tags
}

resource "aws_s3_bucket_versioning" "cloudtrail" {
  bucket = aws_s3_bucket.cloudtrail.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "cloudtrail" {
  bucket = aws_s3_bucket.cloudtrail.id
  rule {
    apply_server_side_encryption_by_default { sse_algorithm = "aws:kms" }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_public_access_block" "cloudtrail" {
  bucket                  = aws_s3_bucket.cloudtrail.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_lifecycle_configuration" "cloudtrail" {
  bucket = aws_s3_bucket.cloudtrail.id
  rule {
    id     = "archive-and-expire"
    status = "Enabled"
    filter {} # apply to all objects (future-proofs the rule; provider requires filter|prefix)
    transition {
      days          = 90
      storage_class = "GLACIER"
    }
    expiration { days = var.cloudtrail_log_retention_days }
  }
}

resource "aws_s3_bucket_policy" "cloudtrail" {
  bucket = aws_s3_bucket.cloudtrail.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "CloudTrailAclCheck"
        Effect    = "Allow"
        Principal = { Service = "cloudtrail.amazonaws.com" }
        Action    = "s3:GetBucketAcl"
        Resource  = aws_s3_bucket.cloudtrail.arn
      },
      {
        Sid       = "CloudTrailWrite"
        Effect    = "Allow"
        Principal = { Service = "cloudtrail.amazonaws.com" }
        Action    = "s3:PutObject"
        Resource  = "${aws_s3_bucket.cloudtrail.arn}/AWSLogs/${local.account_id}/*"
        Condition = { StringEquals = { "s3:x-amz-acl" = "bucket-owner-full-control" } }
      }
    ]
  })
}

resource "aws_cloudtrail" "main" {
  name                          = "${var.name_prefix}-trail"
  s3_bucket_name                = aws_s3_bucket.cloudtrail.id
  include_global_service_events = true
  is_multi_region_trail         = true
  enable_log_file_validation    = true

  cloud_watch_logs_group_arn = "${aws_cloudwatch_log_group.cloudtrail.arn}:*"
  cloud_watch_logs_role_arn  = aws_iam_role.cloudtrail_cw.arn

  event_selector {
    read_write_type           = "All"
    include_management_events = true
  }
  depends_on = [aws_s3_bucket_policy.cloudtrail]
}

resource "aws_cloudwatch_log_group" "cloudtrail" {
  name              = "/aws/cloudtrail/${var.name_prefix}"
  retention_in_days = 90
}

resource "aws_iam_role" "cloudtrail_cw" {
  name = "${var.name_prefix}-cloudtrail-cw"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "cloudtrail.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "cloudtrail_cw" {
  name = "cloudtrail-cloudwatch-delivery"
  role = aws_iam_role.cloudtrail_cw.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["logs:CreateLogStream", "logs:PutLogEvents"]
      Resource = "${aws_cloudwatch_log_group.cloudtrail.arn}:*"
    }]
  })
}

###############################################################################
# SSM Session Manager Logging (AU-12)
###############################################################################

resource "aws_s3_bucket" "ssm_sessions" {
  bucket = "${var.name_prefix}-ssm-sessions-${local.account_id}"
  tags   = var.tags
}

resource "aws_s3_bucket_versioning" "ssm_sessions" {
  bucket = aws_s3_bucket.ssm_sessions.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "ssm_sessions" {
  bucket = aws_s3_bucket.ssm_sessions.id
  rule {
    apply_server_side_encryption_by_default { sse_algorithm = "aws:kms" }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_public_access_block" "ssm_sessions" {
  bucket                  = aws_s3_bucket.ssm_sessions.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_lifecycle_configuration" "ssm_sessions" {
  bucket = aws_s3_bucket.ssm_sessions.id
  rule {
    id     = "expire-session-logs"
    status = "Enabled"
    filter {} # apply to all objects (future-proofs the rule)
    expiration { days = 90 }
  }
}

resource "aws_cloudwatch_log_group" "ssm_sessions" {
  name              = "/aws/ssm/${var.name_prefix}-sessions"
  retention_in_days = 90
}

# NOTE: SSM-SessionManagerRunShell is an ACCOUNT-WIDE named document. The running
# POC (layer 05) already owns it; a platform deployment in the SAME account must
# NOT also manage it (name collision — ADR-0032). This resource is therefore
# gated: create it only when this deployment owns the account's session prefs.
resource "aws_ssm_document" "session_preferences" {
  count           = var.enable_ssm_session_document ? 1 : 0
  name            = "SSM-SessionManagerRunShell"
  document_type   = "Session"
  document_format = "JSON"
  content = jsonencode({
    schemaVersion = "1.0"
    description   = "Platform SSM Session Manager preferences"
    sessionType   = "Standard_Stream"
    inputs = {
      s3BucketName                = aws_s3_bucket.ssm_sessions.id
      s3KeyPrefix                 = var.ssm_session_log_bucket_prefix
      s3EncryptionEnabled         = true
      cloudWatchLogGroupName      = aws_cloudwatch_log_group.ssm_sessions.name
      cloudWatchEncryptionEnabled = true
      cloudWatchStreamingEnabled  = true
      idleSessionTimeout          = "20"
      maxSessionDuration          = "120"
      kmsKeyId                    = ""
      runAsEnabled                = false
      shellProfile                = { linux = "/bin/bash", windows = "" }
    }
  })
}
