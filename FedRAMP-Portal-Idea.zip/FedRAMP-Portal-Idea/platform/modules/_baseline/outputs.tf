###############################################################################
# module: _baseline — outputs
#
# These are the "boring facts" downstream layers / the inheritance manifest
# consume (ADR-0030 published-contract seams). Values degrade to
# "managed-by-org" when a service is deferred to the Organization.
###############################################################################

output "compliance_profile" {
  description = "The control regime this deployment is graded to (ADR-0029)."
  value       = var.compliance_profile
}

output "guardduty_detector_id" {
  description = "Primary-region GuardDuty detector id, or managed-by-org."
  value       = var.enable_guardduty ? aws_guardduty_detector.primary[0].id : "managed-by-org"
}

output "security_hub_arn" {
  description = "Security Hub account ARN, or managed-by-org."
  value       = var.enable_security_hub ? aws_securityhub_account.main[0].arn : "managed-by-org"
}

output "security_hub_standards" {
  description = "Standards subscribed for the selected compliance profile."
  value       = var.enable_security_hub ? keys(aws_securityhub_standards_subscription.profile) : []
}

output "config_recorder_name" {
  description = "AWS Config recorder name, or managed-by-org."
  value       = var.enable_config ? aws_config_configuration_recorder.main[0].name : "managed-by-org"
}

output "cloudtrail_arn" {
  description = "CloudTrail trail ARN (always created)."
  value       = aws_cloudtrail.main.arn
}

output "cloudtrail_bucket_name" {
  description = "S3 bucket for CloudTrail logs."
  value       = aws_s3_bucket.cloudtrail.id
}

output "cloudtrail_log_group" {
  description = "CloudWatch log group for CloudTrail."
  value       = aws_cloudwatch_log_group.cloudtrail.name
}

output "config_bucket_name" {
  description = "S3 bucket for Config snapshots, or managed-by-org."
  value       = var.enable_config ? aws_s3_bucket.config[0].id : "managed-by-org"
}

output "ssm_session_log_bucket" {
  description = "S3 bucket for SSM session logs (AU-12)."
  value       = aws_s3_bucket.ssm_sessions.id
}

output "ssm_session_log_group" {
  description = "CloudWatch log group for SSM session logs (AU-12)."
  value       = aws_cloudwatch_log_group.ssm_sessions.name
}

output "ssm_session_document_owned" {
  description = "True if THIS deployment owns SSM-SessionManagerRunShell (false when deferring to the POC/other owner — ADR-0032)."
  value       = var.enable_ssm_session_document
}
