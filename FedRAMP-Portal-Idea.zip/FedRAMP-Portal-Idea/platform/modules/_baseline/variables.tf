###############################################################################
# module: _baseline — variables
#
# Class 2 (COMPLIANCE BASELINE): required, inherited by every profile, graded
# against the 800-53 umbrella. Reuses the proven POC layer 05-security-baseline
# code (see PROVENANCE.md); re-authored as a MODULE (providers come from the
# caller, not declared here).
#
# Customization axes exposed as inputs (ADR-0029 / TARGET-ARCHITECTURE §1a
# Class 3 scope knobs) WITHOUT weakening the baseline:
#   - which regions are in scope
#   - which org-managed services to defer (enable_* flags)
#   - the compliance profile (which control regime this deployment is graded to)
#   - the audit-sink retention
###############################################################################

variable "environment" {
  description = "Environment name (dev|test|prod)."
  type        = string
  default     = "dev"
}

variable "compliance_profile" {
  description = <<-EOT
    The control regime this deployment is graded to (ADR-0029). 800-53 is the
    umbrella that subsumes the common concerns (data tampering/theft/misuse +
    identity) of the adjacent regimes; per-profile deltas are layered on. This
    selects standards subscriptions + which control set the inheritance manifest
    is scored against. NOT a code fork — a profile.
  EOT
  type        = string
  default     = "nist-800-53-moderate"
  validation {
    condition = contains([
      "nist-800-53-moderate", "nist-800-53-high", "il4",
      "nist-800-171", "irs-1075", "pci-dss", "hipaa"
    ], var.compliance_profile)
    error_message = "compliance_profile must be a known regime profile."
  }
}

variable "primary_region" {
  description = "Primary region for account-level security services (CloudTrail is multi-region regardless)."
  type        = string
  default     = "us-east-1"
}

variable "scoped_regions" {
  description = <<-EOT
    Regions in scope for regional detectors (GuardDuty/Config). The customer
    chooses which regions matter (TARGET-ARCHITECTURE §1a Class 3). Commercial:
    CONUS only. GovCloud: all gov regions.
  EOT
  type        = list(string)
  default     = ["us-east-2", "us-west-1"]
}

# --- Org-managed deferral: set false when the AWS Organization already manages
#     the service (the POC defers GuardDuty/SecurityHub/Config to the org).
variable "enable_guardduty" {
  description = "Create GuardDuty detectors. false if already enabled by the Organization."
  type        = bool
  default     = false
}

variable "enable_security_hub" {
  description = "Enable Security Hub. false if already enabled by the Organization."
  type        = bool
  default     = false
}

variable "enable_config" {
  description = "Create the Config recorder. false if blocked by SCP or org-managed."
  type        = bool
  default     = false
}

variable "cloudtrail_log_retention_days" {
  description = "Days to retain CloudTrail logs before expiration (AU-11)."
  type        = number
  default     = 365
}

variable "ssm_session_log_bucket_prefix" {
  description = "S3 prefix for SSM session logs (AU-12)."
  type        = string
  default     = "ssm-sessions/"
}

variable "enable_ssm_session_document" {
  description = <<-EOT
    Create/own the account-wide SSM-SessionManagerRunShell session document.
    MUST be false when deploying ALONGSIDE the POC in the same account — the POC
    (layer 05) already owns that named document and it cannot be owned twice
    (ADR-0032). Set true only when this deployment is the sole owner of the
    account's session preferences.
  EOT
  type        = bool
  default     = false
}

variable "name_prefix" {
  description = <<-EOT
    Resource name prefix. DISTINCT from the POC so a platform deployment stands
    up ALONGSIDE the running POC without collision (ADR-0032). Default is
    'fedramp-platform', NOT the POC's 'fedramp-portal'.
  EOT
  type        = string
  default     = "fedramp-platform"
}

variable "tags" {
  description = "Tags applied to taggable resources."
  type        = map(string)
  default = {
    Project   = "fedramp-platform"
    ManagedBy = "terraform"
    Class     = "baseline"
  }
}
