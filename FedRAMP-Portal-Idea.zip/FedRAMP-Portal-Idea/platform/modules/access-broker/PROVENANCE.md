# PROVENANCE — module `access-broker` (THE SSM ACCESS PATH)

**Extracted from:** the POC `terraform/03-api`:
- `session-broker.tf` — the `session_broker` role + its SSM policy + the
  lambda→broker assume edge (ADR-0012),
- `ssh-ca.tf` — the Secrets Manager secret + SSM public-key parameter + the
  Lambda read-secret IAM (the non-KMS parts; the KMS key is in the kms module),
- `main.tf` — the six access-lifecycle Lambda functions, the shared + crypto
  layers, and the relevant parts of the shared `lambda_exec` role/policy,
- `lambda/{create_access_request,get_session_status,list_sessions,
  terminate_session,ssm_credentials,sign_key}/` — handler code,
- `lambda/shared/python/portal_utils.py` — the shared layer,
- `lambda/layers/crypto/` + `build-crypto-layer.sh` — the crypto layer.
as deployed in the running POC.

**Class:** 1 — INVARIANT CORE. `connect` is always an SSM-equivalent brokered
path — no bastions, no VPN, ever. No swap seam. See TARGET-ARCHITECTURE §1a.

**REUSED verbatim (byte-for-byte handler + layer code):**
- All six handlers, copied unchanged. These carry:
  - **ADR-0012** — `ssm_credentials`: assume `session_broker` with a per-request
    inline session policy narrowed to one instance (heimdall port).
  - **ADR-0014** — `sign_key`: SSH CA cert signing via the crypto layer.
  - **ADR-0024/0025** — `list_sessions` (self vs operator lens, `?scope=all`),
    `terminate_session` (writes END_REQUESTED; the conductor tears down),
    `get_session_status` (decrypts credentials for display).
- `portal_utils.py` (shared layer) — identity extraction / responses, unchanged.
- The crypto layer built tree (`cryptography`/`cffi`/`pycparser`) + build script.
- The `session_broker` role assume policy + SSM policy — verbatim (empty-account
  "::" AWS-owned document ARNs; instance/managed-instance/session scoping;
  max_session_duration = 3600).
- The SSH-CA secret + public-key SSM parameter (placeholder + `ignore_changes`
  on value) — verbatim.

**RE-AUTHORED (packaging only):**
- No provider/terraform-backend blocks. Split into iam.tf / ssh-ca.tf /
  layers.tf / lambdas.tf / variables.tf / outputs.tf for readability.
- Names via `var.name_prefix` (default `fedramp-platform`, distinct from POC).
- All cross-module couplings are INPUTS: `credentials_key_arn`/`_id`,
  `ssh_ca_key_arn` (kms); `table_name`/`table_arn`/`table_index_arn_wildcard`
  (data-score); `state_machine_arn` (workflow-engine). Env wiring matches the
  POC exactly.
- `handlers` output map (function_name + invoke_arn per route) so api-edge builds
  the integrations/permissions.

**DELIBERATE, FAITHFUL-IN-BEHAVIOR DECISIONS (documented):**
- The handler role is the POC's shared `lambda_exec` role MINUS what belongs
  elsewhere: dropped `organizations:List/DescribeAccount` (that was for
  list_accounts, which lives in api-edge). Kept `states:StartExecution` scoped to
  the passed `state_machine_arn` (create_access_request needs it). Everything the
  six handlers actually use (DynamoDB on table+index, SSM describe/send/sessions,
  EC2 describe, assume-broker, secret read) is present.
- KMS access is NOT an explicit role statement — exactly as in the POC, the
  credentials KEY POLICY names this role. The live root wires
  `access-broker.handler_exec_role_arn` into `kms.lambda_exec_role_arn`, so the
  Encrypt/Decrypt grant lives in the key policy (faithful to the POC model).
- The broker role trust principal is the handler role (the POC named
  `lambda_exec`, the same single role). The single sts:AssumeRole edge is
  preserved.

**Validation:** `terraform validate` clean via the standalone-module harness
(archive provider; the shared + crypto + six handler source_dirs all exist;
`.validate_args.hcl` supplies the required cross-module inputs).
