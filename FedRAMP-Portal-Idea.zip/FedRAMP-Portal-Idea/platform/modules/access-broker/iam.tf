###############################################################################
# module: access-broker — IAM
#
# The handler execution role is the faithful analog of the POC's shared
# lambda_exec role, MINUS the pieces that belong to other modules:
#   - Organizations:List/DescribeAccount -> that was for list_accounts, which
#     lives in api-edge (not an access-broker concern).
#   - StepFunctions StartExecution -> KEPT (create_access_request needs it),
#     scoped to the passed state_machine_arn.
# KMS access is NOT granted here: exactly like the POC, the credentials KEY
# POLICY names this role (the kms module takes lambda_exec_role_arn as input),
# so access flows from the key policy, not the role. Faithful to the POC.
###############################################################################

data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  partition  = data.aws_partition.current.partition
}

###############################################################################
# Handler execution role (create/get/list_sessions/terminate/ssm_credentials/sign)
###############################################################################

resource "aws_iam_role" "handler_exec" {
  name = "${var.name_prefix}-broker-handler"
  tags = var.tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "handler_basic" {
  role       = aws_iam_role.handler_exec.name
  policy_arn = "arn:${local.partition}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "handler_app" {
  name = "${var.name_prefix}-broker-handler-app"
  role = aws_iam_role.handler_exec.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "DynamoDBAccess"
        Effect = "Allow"
        Action = [
          "dynamodb:GetItem",
          "dynamodb:PutItem",
          "dynamodb:UpdateItem",
          "dynamodb:Query",
          "dynamodb:Scan"
        ]
        Resource = [
          var.table_arn,
          var.table_index_arn_wildcard
        ]
      },
      {
        Sid    = "SSMDescribeAndSessions"
        Effect = "Allow"
        Action = [
          "ssm:DescribeInstanceInformation",
          "ssm:SendCommand",
          "ssm:GetCommandInvocation",
          "ssm:GetParameter",
          "ssm:DescribeSessions",
          "ssm:TerminateSession",
          "ec2:DescribeInstances",
          "ec2:DescribeTags"
        ]
        Resource = "*"
      },
      {
        Sid      = "StepFunctionsStart"
        Effect   = "Allow"
        Action   = ["states:StartExecution"]
        Resource = [var.state_machine_arn]
        # NOTE (ADR-0023): no StopExecution/DescribeExecution — the conductor is
        # the sole authority; end-triggers write an end-demand to the score.
      }
    ]
  })
}

###############################################################################
# Session Broker Role (ADR-0012) — reused verbatim from the POC session-broker.tf
#
# The ssm-credentials Lambda assumes THIS role with a per-request inline session
# policy narrowed to one instance. The role's own policy is the widest the vend
# can ever be; the inline policy (built in the handler, mirrors heimdall) scopes
# each vend down. STS session policies only NARROW (never widen).
###############################################################################

resource "aws_iam_role" "session_broker" {
  name        = "${var.name_prefix}-session-broker"
  description = "Assumed by the ssm-credentials Lambda to vend per-session, instance-scoped SSM credentials (ADR-0012)"
  tags        = var.tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid       = "OnlyHandlerRoleMayAssume"
      Effect    = "Allow"
      Principal = { AWS = aws_iam_role.handler_exec.arn }
      Action    = "sts:AssumeRole"
    }]
  })

  # Hard 1-hour ceiling (heimdall DurationSeconds=3600 + SSH cert cap).
  max_session_duration = 3600
}

resource "aws_iam_role_policy" "session_broker_ssm" {
  name = "${var.name_prefix}-session-broker-ssm"
  role = aws_iam_role.session_broker.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "StartSessionOnManagedNodes"
        Effect = "Allow"
        Action = ["ssm:StartSession"]
        Resource = [
          # AWS-owned session documents use an EMPTY account id ("::") — they are
          # not account-scoped; inserting an account id breaks StartSession.
          "arn:${local.partition}:ssm:*::document/AWS-StartPortForwardingSession",
          "arn:${local.partition}:ssm:*::document/AWS-StartSSHSession",
          "arn:${local.partition}:ec2:*:${local.account_id}:instance/*",
          "arn:${local.partition}:ssm:*:${local.account_id}:managed-instance/*"
        ]
      },
      {
        Sid    = "TerminateAndResumeOwnSessions"
        Effect = "Allow"
        Action = [
          "ssm:TerminateSession",
          "ssm:ResumeSession"
        ]
        Resource = "arn:${local.partition}:ssm:*:${local.account_id}:session/*"
      }
    ]
  })
}

# The single sts:AssumeRole edge in the system: the handler role -> broker role.
resource "aws_iam_role_policy" "handler_assume_broker" {
  name = "${var.name_prefix}-handler-assume-broker"
  role = aws_iam_role.handler_exec.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid      = "AssumeSessionBrokerOnly"
      Effect   = "Allow"
      Action   = "sts:AssumeRole"
      Resource = aws_iam_role.session_broker.arn
    }]
  })
}

# Read access to the SSH CA private-key secret (sign_key Lambda; ADR-0014).
resource "aws_iam_role_policy" "handler_ssh_ca" {
  name = "${var.name_prefix}-handler-ssh-ca"
  role = aws_iam_role.handler_exec.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid      = "ReadCAPrivateKey"
      Effect   = "Allow"
      Action   = ["secretsmanager:GetSecretValue"]
      Resource = [aws_secretsmanager_secret.ssh_ca_private_key.arn]
    }]
  })
}
