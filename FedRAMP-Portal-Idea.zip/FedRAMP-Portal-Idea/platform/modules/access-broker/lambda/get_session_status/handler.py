"""Lambda: GET /api/session/{requestId}

Returns the current status of an access request. The portal polls this
endpoint after calling POST /api/connect to get connection details once
provisioning completes.

Statuses: PENDING → PROVISIONING → ACTIVE → CLEANING_UP → COMPLETED | FAILED
"""

import boto3
import base64
import logging
from portal_utils import (
    get_env,
    get_user_from_event,
    json_response,
    error_response,
    parse_path_params,
)

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)

# Ambient region (AWS_REGION) — portable across regions/partitions (ADR-0017).
kms_client = boto3.client("kms")


def decrypt_field(value: str) -> str:
    """Decrypt a KMS-encrypted field, or return plaintext as-is.

    Passwords are currently stored as plaintext (ASL-side KMS encryption
    is deferred). A short value cannot be real KMS ciphertext — KMS
    ciphertext base64-decodes to ~180+ bytes. So we only attempt
    decryption for values long enough to plausibly be ciphertext.
    This avoids mangling a plaintext password that happens to be valid
    base64 (e.g. openssl rand -base64 output).
    """
    if not value:
        return ""
    # KMS ciphertext is well over 100 base64 chars; ephemeral passwords are ~24.
    if len(value) < 100:
        return value
    try:
        ciphertext = base64.b64decode(value)
        response = kms_client.decrypt(
            CiphertextBlob=ciphertext,
            KeyId=get_env("KMS_KEY_ID"),
        )
        return response["Plaintext"].decode("utf-8")
    except Exception:
        return value


def lambda_handler(event, context):
    """Handle GET /api/session/{requestId}."""
    logger.info("get-session-status invoked")

    user = get_user_from_event(event)
    path_params = parse_path_params(event)

    request_id = path_params.get("requestId")
    if not request_id:
        return error_response(400, "requestId path parameter is required")

    table_name = get_env("TABLE_NAME")
    dynamodb = boto3.client("dynamodb")  # ambient region (ADR-0017)

    # Query by request_id (hash key) — returns all items with that PK
    try:
        result = dynamodb.query(
            TableName=table_name,
            KeyConditionExpression="request_id = :rid",
            ExpressionAttributeValues={":rid": {"S": request_id}},
            ScanIndexForward=False,  # Most recent first
            Limit=1,
        )
    except Exception as e:
        logger.error(f"DynamoDB query failed: {e}")
        return error_response(500, "Failed to retrieve session status")

    items = result.get("Items", [])
    if not items:
        return error_response(404, "Access request not found")

    item = items[0]

    # Verify ownership: user can only see their own requests (unless Racker)
    is_racker = "Rackers" in user.get("groups", [])
    item_user_id = item.get("user_id", {}).get("S", "")
    if not is_racker and item_user_id != user["user_id"]:
        return error_response(403, "Access denied")

    # Build response based on status
    status = item.get("status", {}).get("S", "UNKNOWN")
    response = {
        "request_id": request_id,
        "status": status,
        "instance_id": item.get("instance_id", {}).get("S", ""),
        "region": item.get("region", {}).get("S", ""),
        "access_type": item.get("access_type", {}).get("S", ""),
        "created_at": item.get("created_at", {}).get("S", ""),
        "ttl_minutes": int(item.get("ttl_minutes", {}).get("N", "0")),
        "user_email": item.get("user_email", {}).get("S", ""),
    }

    # Include connection details only when ACTIVE
    if status == "ACTIVE":
        encrypted_password = item.get("temporary_password", {}).get("S", "")
        response["connection"] = {
            "username": item.get("provisioned_username", {}).get("S", ""),
            "auth_method": item.get("auth_method", {}).get("S", ""),
            # Decrypt the password (stored encrypted via KMS)
            "temporary_password": decrypt_field(encrypted_password) if encrypted_password else "",
            "port_forward_command": item.get("port_forward_command", {}).get("S", ""),
            "port_local": item.get("port_local", {}).get("S", "2222"),
            "port_remote": item.get("port_remote", {}).get("S", "22"),
            "expires_at": item.get("expires_at", {}).get("N", ""),
        }

    # Include error details if FAILED
    if status == "FAILED":
        response["error_detail"] = item.get("error_detail", {}).get("S", "Unknown error")

    return json_response(200, response)
