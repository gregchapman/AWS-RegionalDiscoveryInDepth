"""Shared utilities for FedRAMP Portal Lambda functions."""

import json
import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)


def get_env(key: str, default: str = "") -> str:
    """Get environment variable with optional default."""
    return os.environ.get(key, default)


def json_response(status_code: int, body: dict) -> dict:
    """Build API Gateway v2 proxy response."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "Cache-Control": "no-store",
        },
        "body": json.dumps(body, default=str),
    }


def error_response(status_code: int, message: str) -> dict:
    """Build a standard error response."""
    return json_response(status_code, {"error": message})


def get_user_from_event(event: dict) -> dict:
    """Extract user info from API Gateway JWT authorizer context."""
    claims = (
        event.get("requestContext", {})
        .get("authorizer", {})
        .get("jwt", {})
        .get("claims", {})
    )

    # cognito:groups can arrive as:
    #   - A string: "Rackers" (single group)
    #   - A comma-separated string: "Rackers,Admins"
    #   - A JSON array string: "[Rackers]" or "[\"Rackers\"]"
    #   - None/empty
    raw_groups = claims.get("cognito:groups", "")
    if isinstance(raw_groups, list):
        groups = raw_groups
    elif raw_groups:
        # Strip brackets if present
        cleaned = raw_groups.strip("[]\" ")
        groups = [g.strip().strip('"') for g in cleaned.split(",") if g.strip()]
    else:
        groups = []

    import logging
    logger = logging.getLogger("fedramp-portal")
    logger.info(f"JWT claims keys: {list(claims.keys())}")
    logger.info(f"Raw cognito:groups value: '{raw_groups}' -> parsed: {groups}")

    # Identity for attribution (ADR-0011). The access token now carries `email`
    # via the pre-token-generation trigger (cognito-triggers.tf). This fallback
    # chain is defense in depth so attribution NEVER silently lands on the
    # literal "unknown" (which produced usernames like unknown-9656) if the
    # trigger is absent/misconfigured. Order: email -> custom:email ->
    # cognito:username (only when it's NOT just the UUID sub) -> sub. `email`
    # stays keyed as-is so derive_username keeps taking the local-part.
    sub = claims.get("sub", "")
    cognito_username = claims.get("cognito:username", claims.get("username", ""))
    email = claims.get("email") or claims.get("custom:email") or ""
    if not email:
        # A username that isn't just the UUID sub is still human-meaningful.
        if cognito_username and cognito_username != sub:
            email = cognito_username
        elif sub:
            email = sub  # last resort: at least stable + traceable to the pool
        else:
            email = "unknown"

    return {
        "user_id": sub or "unknown",
        "email": email,
        "groups": groups,
        "customer_id": claims.get("custom:customer_id", ""),
    }


def utc_now() -> str:
    """Return current UTC time as ISO 8601 string."""
    return datetime.now(timezone.utc).isoformat()


def parse_query_params(event: dict) -> dict:
    """Extract query string parameters from event."""
    return event.get("queryStringParameters") or {}


def parse_path_params(event: dict) -> dict:
    """Extract path parameters from event."""
    return event.get("pathParameters") or {}


def parse_body(event: dict) -> dict:
    """Parse JSON body from event."""
    body = event.get("body", "")
    if not body:
        return {}
    try:
        return json.loads(body)
    except (json.JSONDecodeError, TypeError):
        return {}


def authorize_target_instance(instance_id: str, region: str, user: dict) -> str:
    """Authorize a target before any access-request side effect occurs."""
    target_regions = {
        value.strip()
        for value in get_env("TARGET_REGIONS", "us-east-2,us-west-1").split(",")
        if value.strip()
    }
    if region not in target_regions:
        raise PermissionError("target region is not allowed")

    try:
        ec2 = _boto3.client("ec2", region_name=region)
        response = ec2.describe_instances(InstanceIds=[instance_id])
    except Exception as exc:
        logger.warning("Target authorization lookup failed for %s: %s", instance_id, exc)
        raise PermissionError("target is not authorized") from exc

    instances = [
        instance
        for reservation in response.get("Reservations", [])
        for instance in reservation.get("Instances", [])
        if instance.get("InstanceId") == instance_id
    ]
    if not instances:
        raise PermissionError("target is not authorized")

    tags = {
        tag["Key"]: tag["Value"]
        for tag in instances[0].get("Tags", [])
        if "Key" in tag and "Value" in tag
    }
    target_customer_id = tags.get("Customer", "")
    is_operator = "Operators" in user.get("groups", [])
    if not is_operator:
        caller_customer_id = user.get("customer_id", "")
        if (
            not caller_customer_id
            or tags.get("CustomerAccess", "").lower() != "true"
            or target_customer_id.lower() != caller_customer_id.lower()
        ):
            logger.warning(
                "Denied target %s for customer %s",
                instance_id,
                caller_customer_id or "<missing>",
            )
            raise PermissionError("target is not authorized")

    return target_customer_id


def derive_username(identity: str, request_id: str, access_type: str = "ssh") -> str:
    """Derive an OS username from the authenticated identity.

    Per ADR-0011, ephemeral users are named for the real person (not a
    random token) so OS-level audit logs attribute to a human. A short
    suffix from the request_id keeps concurrent sessions by the same user
    to the same host from colliding.

    identity: the user's email or username (e.g. "greg-racker@rgs-test.local")
    request_id: the session UUID (first 4 hex chars used as suffix)
    access_type: "ssh" (Linux, 32-char limit) or "rdp" (Windows, 20-char limit)

    Examples:
      greg-racker@rgs-test.local + a751a325... -> "greg-racker-a751"
    """
    import re

    # Take the local part of an email, lowercase it
    local = identity.split("@")[0].lower()
    # Replace anything not [a-z0-9_-] with a hyphen, collapse repeats
    local = re.sub(r"[^a-z0-9_-]", "-", local)
    local = re.sub(r"-+", "-", local).strip("-")
    # Must start with a letter (Linux useradd requirement)
    if not local or not local[0].isalpha():
        local = "u-" + local
    local = local.strip("-")

    suffix = request_id.replace("-", "")[:4]

    # OS length limits: Linux 32, Windows 20. Reserve room for "-<suffix>".
    max_len = 20 if access_type == "rdp" else 32
    base_max = max_len - (len(suffix) + 1)
    base = local[:base_max].strip("-")

    return f"{base}-{suffix}"


def encrypt_field(plaintext: str, kms_key_id: str) -> str:
    """Encrypt a string with KMS and return base64-encoded ciphertext.
    
    Used to protect ephemeral credentials before writing to DynamoDB.
    Requires KMS_KEY_ID environment variable or explicit key_id parameter.
    """
    import base64
    import boto3

    if not plaintext or not kms_key_id:
        return plaintext

    # Ambient region (AWS_REGION) keeps this portable across regions/partitions (ADR-0017).
    kms = boto3.client("kms")
    response = kms.encrypt(
        KeyId=kms_key_id,
        Plaintext=plaintext.encode("utf-8"),
    )
    return base64.b64encode(response["CiphertextBlob"]).decode("utf-8")
