"""Lambda: POST /api/session/{requestId}/ssm-credentials  (ADR-0012)

Vends short-lived, instance-scoped AWS credentials so the SSM tunnel is
CREDENTIAL-LESS for the user. Login (Cognito JWT) is AUTHENTICATION; this
endpoint is the AUTHORIZATION vend: it returns temporary STS credentials that
can ONLY start an SSM session (port-forward / SSH) to the ONE instance tied to
this access request, for at most one hour.

Port of production Passport (ADR-0003/0013):
  - internal/heimdall/heimdall.go :: passportCLIPolicyDocument  (the scoping)
  - cli/connect/ssmtransport.go   :: getSSMCreds / GetSSMAPI     (the consumer)
  - server/middleware/credentials.go :: JWT identity -> scoped creds

The scoping in `_session_policy_document` is copied from passportCLIPolicyDocument
(NOT invented). The security guarantee: STS session policies can only NARROW a
role's permissions (the effective session = intersection of the broker role's
identity policy AND this inline policy). So even though the broker role can
reach any managed node in the account, each vend is clamped to a single
instance ARN + only the two AWS session documents.

Request:  POST /api/session/{requestId}/ssm-credentials   (JWT-authorized)
          (no body required)
Response: 200 {
            "access_key_id": "...",
            "secret_access_key": "...",
            "session_token": "...",
            "expiration": "2026-08-31T18:00:00+00:00",
            "region": "us-east-2",
            "instance_id": "i-0abc...",
            "port_local": "2222",
            "port_remote": "22"
          }
"""

import json
import time
import logging

import boto3

from portal_utils import (
    get_env,
    get_user_from_event,
    json_response,
    error_response,
    parse_path_params,
)

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)

MAX_VEND_TTL_SECONDS = 3600  # 1 hour hard cap (matches heimdall DurationSeconds)
MIN_VEND_TTL_SECONDS = 900   # STS AssumeRole minimum DurationSeconds is 900s

# Control-plane clients use the Lambda's ambient region (AWS_REGION), so the
# same code runs unchanged in any region/partition (ADR-0017).
_dynamodb = boto3.client("dynamodb")
_sts = boto3.client("sts")


def _lookup_access_request(request_id: str):
    """Fetch the most recent item for this request_id, or None."""
    table_name = get_env("TABLE_NAME")
    result = _dynamodb.query(
        TableName=table_name,
        KeyConditionExpression="request_id = :r",
        ExpressionAttributeValues={":r": {"S": request_id}},
        ScanIndexForward=False,
        Limit=1,
    )
    items = result.get("Items", [])
    return items[0] if items else None


def _partition_for_region(region: str) -> str:
    """Map an AWS region to its ARN partition.

    Supports both partitions this offering targets (ADR-0017 / ADR-0019):
      - Commercial (FedRAMP Moderate, CONUS): us-east-1/2, us-west-1/2 -> "aws"
      - GovCloud (IL4+):    us-gov-west-1, us-gov-east-1              -> "aws-us-gov"
    The target INSTANCE's region is the authoritative signal for the resource
    ARN partition — a control-plane env default cannot be trusted once the
    portal spans partitions. China (aws-cn) is intentionally out of scope.
    """
    if region.startswith("us-gov-"):
        return "aws-us-gov"
    return "aws"


def _instance_arn(partition: str, instance_id: str) -> str:
    """Build the resource ARN for the target, mirroring passportCLIPolicyDocument.

    EC2-native instances (i-...) live in the ec2 namespace; the SSM agent
    references them there when starting a session. Hybrid/on-prem SSM managed
    instances (mi-...) live in the ssm namespace. Any other prefix is rejected
    (heimdall raises the same error) — never emit a broad wildcard, which would
    silently defeat the per-instance scoping.
    """
    if instance_id.startswith("i-"):
        return f"arn:{partition}:ec2:*:*:instance/{instance_id}"
    if instance_id.startswith("mi-"):
        return f"arn:{partition}:ssm:*:*:managed-instance/{instance_id}"
    raise ValueError("expected instance_id to have prefix of i- or mi-")


def _session_policy_document(partition: str, instance_id: str) -> str:
    """Return the inline STS session policy scoping the vend to ONE instance.

    Copied from Passport internal/heimdall/heimdall.go passportCLIPolicyDocument
    (the security surface). Two statements:
      1. ssm:StartSession allowed ONLY on the two AWS session documents AND the
         single target instance ARN. StartSession authorizes against BOTH the
         document and the target, so listing exactly one instance restricts the
         session to that instance, reachable only via port-forward / SSH docs.
      2. ssm:TerminateSession / ResumeSession, conditioned on the session's
         target-id tag matching this instance — so the holder can only tear
         down / resume THEIR OWN session, not anyone else's.

    AWS-managed documents (names starting "AWS-") MUST use an empty account id
    (the "::") — inserting an account id breaks StartSession.
    """
    target_arn = _instance_arn(partition, instance_id)
    return json.dumps({
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": ["ssm:StartSession"],
                "Resource": [
                    f"arn:{partition}:ssm:*::document/AWS-StartPortForwardingSession",
                    f"arn:{partition}:ssm:*::document/AWS-StartSSHSession",
                    target_arn,
                ],
            },
            {
                "Effect": "Allow",
                "Action": [
                    "ssm:TerminateSession",
                    "ssm:ResumeSession",
                ],
                "Resource": "*",
                "Condition": {
                    "StringLike": {
                        "ssm:resourceTag/aws:ssmmessages:target-id": [instance_id]
                    }
                },
            },
        ],
    })


def lambda_handler(event, context):
    """Handle POST /api/session/{requestId}/ssm-credentials."""
    logger.info("ssm-credentials invoked")

    user = get_user_from_event(event)
    path_params = parse_path_params(event)

    request_id = path_params.get("requestId")
    if not request_id:
        return error_response(400, "requestId path parameter is required")

    # --- Load the access request (authoritative source of instance/owner/TTL) ---
    try:
        item = _lookup_access_request(request_id)
    except Exception as e:
        logger.error(f"DynamoDB query failed: {e}")
        return error_response(500, "Failed to retrieve access request")

    if not item:
        return error_response(404, "Access request not found")

    # --- authZ + tenant isolation (ADR-0021, fail closed) ---
    # The caller must OWN this request, unless they are a Racker. A customer can
    # never vend credentials for another tenant's request: the request record is
    # bound to the user_id that created it, and we compare against the JWT sub.
    is_racker = "Rackers" in user.get("groups", [])
    item_user_id = item.get("user_id", {}).get("S", "")
    if not is_racker and item_user_id != user["user_id"]:
        logger.warning(
            f"Denied ssm-credentials: caller {user['user_id']} != owner {item_user_id} "
            f"(request {request_id})"
        )
        return error_response(403, "Access denied")

    # --- session must be live ---
    status = item.get("status", {}).get("S", "")
    if status != "ACTIVE":
        return error_response(409, f"Session not connectable (status={status})")

    instance_id = item.get("instance_id", {}).get("S", "")
    region = item.get("region", {}).get("S", "")
    username = item.get("provisioned_username", {}).get("S", "")
    port_local = item.get("port_local", {}).get("S", "2222")
    port_remote = item.get("port_remote", {}).get("S", "22")

    if not instance_id or not region:
        return error_response(409, "Access request missing instance details")

    # --- AC-6(5) SECOND, independent tenant check at connect/vend time ---
    # The list-time filter (list_instances) already scopes by customer_id, and
    # the request is owned by this caller. But per ARCHITECTURE-WEAKNESSES AC-6(5),
    # we add an INDEPENDENT authorization at the moment we vend live credentials:
    # re-validate the caller's customer_id claim against the target instance's
    # `Customer` tag, read fresh from EC2 (not from the possibly-stale request
    # record). Rackers (multi-tenant operators) are exempt. Fail CLOSED — if the
    # tag is missing or does not match, we do NOT vend. This is defense in depth:
    # even if a request were somehow created for a mismatched instance, the vend
    # is the last gate before real AWS access and it independently denies.
    if not is_racker:
        caller_customer_id = user.get("customer_id", "")
        if not caller_customer_id:
            logger.warning(f"Denied vend: caller has no customer_id claim (request {request_id})")
            return error_response(403, "Access denied")
        try:
            ec2 = boto3.client("ec2", region_name=region)  # instance region (ADR-0017)
            tags = ec2.describe_tags(Filters=[
                {"Name": "resource-id", "Values": [instance_id]},
                {"Name": "key", "Values": ["Customer"]},
            ])
            tag_vals = [t["Value"] for t in tags.get("Tags", [])]
        except Exception as e:
            logger.error(f"Tenant re-validation lookup failed: {e}")
            return error_response(500, "Failed to authorize target instance")
        if caller_customer_id not in tag_vals:
            logger.warning(
                f"Denied vend: caller customer_id '{caller_customer_id}' does not match "
                f"instance {instance_id} Customer tag {tag_vals} (request {request_id})"
            )
            return error_response(403, "Access denied")

    # --- validity: min(remaining authorization window, 1h vend cap) ---
    # The access-request TTL is the AUTHORIZATION window (1-12h, ADR-0014,
    # matching Passport accessRequest Duration min=1/max=12). The vended STS
    # creds are the AUTHENTICATOR and are ALWAYS short-lived (<=1h): Passport
    # vends 3600s (heimdall passportCLIPolicyDocument + get_aws_credentials),
    # and — critically — we CANNOT exceed 1h here even if we wanted to. This
    # Lambda runs under an assumed execution role and calls AssumeRole on the
    # broker, which is ROLE CHAINING; AWS hard-caps a chained CLI/API session at
    # 1 hour regardless of DurationSeconds or the role's max_session_duration
    # (verified: STS AssumeRole docs). Requesting >3600 would FAIL outright. So
    # a long (e.g. 8h) authorization window is served by RE-VENDING hourly, not
    # by one long credential. This is MORE AC-12 compliant: creds auto-expire
    # every hour and are re-minted only while the window and ownership still hold.
    now = int(time.time())
    expires_at_epoch = int(item.get("expires_at", {}).get("N", str(now)))
    remaining = max(0, expires_at_epoch - now)
    if remaining <= 0:
        return error_response(409, "Session has expired")
    duration = min(remaining, MAX_VEND_TTL_SECONDS)
    # STS AssumeRole requires DurationSeconds >= 900. If under 15 min of the
    # authorization window remains, we cannot mint a compliant short cred
    # without over-vending past the window (an AC-12 violation), so we deny and
    # tell the user to extend/re-request rather than silently over-scope time.
    if duration < MIN_VEND_TTL_SECONDS:
        return error_response(409, "Session too close to expiry; extend the access request to reconnect")

    # --- build the per-request inline scoping policy (copied from heimdall) ---
    # Partition is derived from the TARGET INSTANCE's region so the resource
    # ARNs are correct in either partition (Commercial or GovCloud). The
    # PORTAL_PARTITION env is a sanity fallback for the control-plane's own
    # partition; the instance region wins. If they ever disagree, the region
    # is authoritative (that is where the instance actually lives).
    partition = _partition_for_region(region)
    try:
        session_policy = _session_policy_document(partition, instance_id)
    except ValueError as e:
        logger.error(f"Bad instance_id for policy scoping: {e}")
        return error_response(400, str(e))

    # RoleSessionName = the identity-derived username so CloudTrail attributes
    # the StartSession / session lifecycle to a real person (AU-2/AU-3/AU-12).
    # Fall back to a sanitized JWT sub if the username is somehow absent.
    role_session_name = (username or user["user_id"])[:64]

    broker_role_arn = get_env("SESSION_BROKER_ROLE_ARN")
    if not broker_role_arn:
        logger.error("SESSION_BROKER_ROLE_ARN not configured")
        return error_response(500, "Credential broker not configured")

    # --- vend: assume the broker role WITH the narrowing inline policy ---
    try:
        assumed = _sts.assume_role(
            RoleArn=broker_role_arn,
            RoleSessionName=role_session_name,
            Policy=session_policy,
            DurationSeconds=duration,
        )
    except Exception as e:
        logger.error(f"AssumeRole failed: {e}")
        return error_response(500, "Failed to vend session credentials")

    creds = assumed["Credentials"]

    # --- audit the vend (AU-2/AU-12): who, what instance, how long, no secrets ---
    logger.info(
        json.dumps({
            "event": "ssm_credentials_vended",
            "request_id": request_id,
            "caller_user_id": user["user_id"],
            "caller_email": user.get("email", ""),
            "is_racker": is_racker,
            "role_session_name": role_session_name,
            "instance_id": instance_id,
            "region": region,
            "duration_seconds": duration,
            "expiration": creds["Expiration"].isoformat(),
        })
    )

    return json_response(200, {
        "access_key_id": creds["AccessKeyId"],
        "secret_access_key": creds["SecretAccessKey"],
        "session_token": creds["SessionToken"],
        "expiration": creds["Expiration"].isoformat(),
        "region": region,
        "instance_id": instance_id,
        "username": username,
        "port_local": port_local,
        "port_remote": port_remote,
    })
