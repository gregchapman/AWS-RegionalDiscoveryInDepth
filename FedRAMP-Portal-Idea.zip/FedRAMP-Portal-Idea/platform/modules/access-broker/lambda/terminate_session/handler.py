"""Lambda: POST /api/session/{requestId}/terminate

Submits an END DEMAND for a session. This handler is a CALLER, not the
conductor (ADR-0023): it does NOT perform any teardown itself. It only records
the end demand on the session record (the "score"); the Step Function execution
(the conductor) detects it on its next poll and runs the single, verified
teardown (drop connection, remove OS user + profile, tear down the SSM tunnel)
and converges the session to a terminal state.

Explicitly NOT done here (and why):
  - No SSM cleanup. Callers must not cue musicians directly; that produced two
    divergent cleanup paths and races. cleanup_user (invoked by the conductor)
    is the single cleanup implementation.
  - No states:StopExecution. Aborting the conductor strands the record at
    CLEANING_UP forever (this caused 81 Aborted executions). The conductor must
    be allowed to finish and write the terminal state.

Only the session owner (or a Racker) may end a session. This same endpoint is
the operator-revoke path (Rackers bypass the ownership check) and the endpoint
the CLI calls on local exit — every end trigger converges here as one demand.
"""

import boto3
import logging
from portal_utils import (
    get_env,
    get_user_from_event,
    json_response,
    error_response,
    parse_path_params,
    parse_body,
    utc_now,
)

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)

# Statuses that mean the session is already ending or ended — the end demand is
# a no-op (idempotent) for these. END_REQUESTED is a caller-written end demand;
# CLEANING_UP is the conductor actively tearing down; the rest are terminal.
ALREADY_ENDING = ("END_REQUESTED", "CLEANING_UP", "COMPLETED", "CLEANUP_FAILED", "FAILED")


def lambda_handler(event, context):
    """Handle POST /api/session/{requestId}/terminate — submit an end demand."""
    logger.info("terminate-session invoked")

    user = get_user_from_event(event)
    path_params = parse_path_params(event)
    request_id = path_params.get("requestId")

    if not request_id:
        return error_response(400, "requestId path parameter is required")

    # ADR-0025/0024: every terminate is attributed; an OPERATOR revoke (a Racker
    # ending a session they do NOT own) additionally requires a justification.
    body = parse_body(event)
    reason = (body.get("reason") or "").strip()
    # end_source lets the audit trail distinguish who/what ended the session:
    # self:portal (owner via UI), operator:portal (Racker revoke), cli:exit
    # (the CLI on local exit), system:ttl (conductor at TTL). The CLI sends its
    # own source; default to self:portal for a UI-driven owner terminate.
    end_source = (body.get("source") or "").strip() or "self:portal"

    table_name = get_env("TABLE_NAME")
    dynamodb = boto3.client("dynamodb")  # ambient region (ADR-0017)

    # Look up the session record (latest item for this request_id).
    try:
        result = dynamodb.query(
            TableName=table_name,
            KeyConditionExpression="request_id = :rid",
            ExpressionAttributeValues={":rid": {"S": request_id}},
            ScanIndexForward=False,
            Limit=1,
        )
    except Exception as e:
        logger.error(f"DynamoDB query failed: {e}")
        return error_response(500, "Failed to retrieve session")

    items = result.get("Items", [])
    if not items:
        return error_response(404, "Session not found")

    item = items[0]

    # Ownership check (Rackers may end anyone's session — this is the operator
    # revoke path too).
    is_racker = "Rackers" in user.get("groups", [])
    item_user_id = item.get("user_id", {}).get("S", "")
    caller_user_id = user["user_id"]
    is_owner = item_user_id == caller_user_id
    if not is_racker and not is_owner:
        return error_response(403, "Access denied")

    # OPERATOR REVOKE = ending a session you do NOT own (only Rackers reach here
    # for a non-owned session, per the check above). ADR-0024: a privileged
    # on-behalf-of action REQUIRES a justification (ticket #), enforced
    # FAIL-CLOSED — an unattributed revoke would let a mass-termination happen
    # with no evidence of who/why (the anonymous-DoS vector). Ending your OWN
    # session does not require a reason (but is still fully attributed below).
    is_operator_revoke = not is_owner  # implies is_racker here
    if is_operator_revoke and not reason:
        logger.warning(
            f"Denied operator revoke of {request_id} by {user.get('email','?')}: "
            f"no reason supplied (reason is mandatory for on-behalf-of revoke)."
        )
        return error_response(
            400,
            "A reason (e.g. customer ticket number) is required to end another "
            "user's session.",
        )
    if is_operator_revoke:
        end_source = "operator:portal"

    created_at = item.get("created_at", {}).get("S", "")
    status = item.get("status", {}).get("S", "")

    # Idempotent: if it's already ending/ended, just report the current status.
    if status in ALREADY_ENDING:
        return json_response(200, {
            "request_id": request_id,
            "status": status,
            "message": "Session already ending or ended.",
        })

    # Submit the END DEMAND: write END_REQUESTED. That's ALL this caller does.
    # The conductor's poll-loop (CheckEndDemand) sees status != ACTIVE on its
    # next tick and runs the single verified teardown, converging to COMPLETED
    # (or CLEANUP_FAILED). We report the transitional status honestly so the
    # portal shows "Ending…" rather than claiming the work is already done.
    # Attribution (ADR-0024): stamp WHO ended it, from what SOURCE, and (for an
    # operator revoke) WHY, onto the record itself — so the session's own row
    # carries the accountable end, not just a log line. ended_at is set too.
    try:
        dynamodb.update_item(
            TableName=table_name,
            Key={"request_id": {"S": request_id}, "created_at": {"S": created_at}},
            UpdateExpression=(
                "SET #s = :s, ended_by = :by, ended_by_id = :byid, "
                "end_source = :src, end_reason = :reason, end_requested_at = :ts"
            ),
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={
                ":s": {"S": "END_REQUESTED"},
                ":by": {"S": user.get("email", "unknown")},
                ":byid": {"S": caller_user_id},
                ":src": {"S": end_source},
                # Empty reason is valid for a self-terminate; operator revoke was
                # already gated above so :reason is non-empty in that case.
                ":reason": {"S": reason},
                ":ts": {"S": utc_now()},
                ":active": {"S": "ACTIVE"},
                ":pending": {"S": "PENDING"},
                ":provisioning": {"S": "PROVISIONING"},
            },
            # Only transition from a live state — never clobber a status the
            # conductor already advanced (defensive against races).
            ConditionExpression="#s IN (:active, :pending, :provisioning)",
        )
    except dynamodb.exceptions.ConditionalCheckFailedException:
        # Someone/thing advanced the status between our read and write — that's
        # fine; the end is already in motion.
        logger.info(f"End demand no-op for {request_id}: status already advanced")
        return json_response(200, {
            "request_id": request_id,
            "status": "END_REQUESTED",
            "message": "Session already ending.",
        })
    except Exception as e:
        logger.error(f"End-demand write failed: {e}")
        return error_response(500, "Failed to record session termination")

    # Attributed audit line (ADR-0024). Operator revokes carry the reason so the
    # accountable action is greppable in logs as well as on the record.
    logger.info(
        f"End demand recorded for {request_id} by {user.get('email','?')} "
        f"(source={end_source}, operator_revoke={is_operator_revoke}, "
        f"target_user={item_user_id}, reason={reason!r})"
    )
    return json_response(200, {
        "request_id": request_id,
        "status": "END_REQUESTED",
        "message": "Session ending. The ephemeral user is being removed and the "
                   "session will finalize shortly.",
    })
