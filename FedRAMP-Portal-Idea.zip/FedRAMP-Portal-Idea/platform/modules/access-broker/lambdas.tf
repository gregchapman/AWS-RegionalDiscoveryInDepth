###############################################################################
# module: access-broker — the six access-lifecycle API handlers
#
# All handler code reused BYTE-FOR-BYTE from the POC (03-api/lambda/*). Env
# wiring matches the POC exactly, with names/ARNs threaded from module inputs.
# These carry ADR-0012 (vend), ADR-0014 (sign), ADR-0024/0025 (session listing/
# operator lens, terminate semantics). Function names follow var.name_prefix.
###############################################################################

# --- create-access-request (POST /api/connect) ---
data "archive_file" "create_access_request" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/create_access_request"
  output_path = "${path.module}/.build/create-access-request.zip"
}

resource "aws_lambda_function" "create_access_request" {
  function_name    = "${var.name_prefix}-create-access-request"
  filename         = data.archive_file.create_access_request.output_path
  source_code_hash = data.archive_file.create_access_request.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.handler_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT         = var.environment
      TABLE_NAME          = var.table_name
      STATE_MACHINE_ARN   = var.state_machine_arn
      SESSION_TTL_MINUTES = tostring(var.session_ttl_minutes)
      KMS_KEY_ID          = var.credentials_key_id
    }
  }
}

# --- get-session-status (GET /api/session/{requestId}) ---
data "archive_file" "get_session_status" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/get_session_status"
  output_path = "${path.module}/.build/get-session-status.zip"
}

resource "aws_lambda_function" "get_session_status" {
  function_name    = "${var.name_prefix}-get-session-status"
  filename         = data.archive_file.get_session_status.output_path
  source_code_hash = data.archive_file.get_session_status.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.handler_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT = var.environment
      TABLE_NAME  = var.table_name
      KMS_KEY_ID  = var.credentials_key_id
    }
  }
}

# --- list-sessions (GET /api/sessions [?scope=all] — ADR-0025 operator lens) ---
data "archive_file" "list_sessions" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/list_sessions"
  output_path = "${path.module}/.build/list-sessions.zip"
}

resource "aws_lambda_function" "list_sessions" {
  function_name    = "${var.name_prefix}-list-sessions"
  filename         = data.archive_file.list_sessions.output_path
  source_code_hash = data.archive_file.list_sessions.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.handler_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT = var.environment
      TABLE_NAME  = var.table_name
      KMS_KEY_ID  = var.credentials_key_id
    }
  }
}

# --- terminate-session (POST /api/session/{requestId}/terminate) ---
data "archive_file" "terminate_session" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/terminate_session"
  output_path = "${path.module}/.build/terminate-session.zip"
}

resource "aws_lambda_function" "terminate_session" {
  function_name    = "${var.name_prefix}-terminate-session"
  filename         = data.archive_file.terminate_session.output_path
  source_code_hash = data.archive_file.terminate_session.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.handler_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT = var.environment
      TABLE_NAME  = var.table_name
    }
  }
}

# --- ssm-credentials (POST /api/session/{requestId}/ssm-credentials — ADR-0012 vend) ---
data "archive_file" "ssm_credentials" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/ssm_credentials"
  output_path = "${path.module}/.build/ssm-credentials.zip"
}

resource "aws_lambda_function" "ssm_credentials" {
  function_name    = "${var.name_prefix}-ssm-credentials"
  filename         = data.archive_file.ssm_credentials.output_path
  source_code_hash = data.archive_file.ssm_credentials.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.handler_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT             = var.environment
      TABLE_NAME              = var.table_name
      SESSION_BROKER_ROLE_ARN = aws_iam_role.session_broker.arn
      # Partition passed explicitly (own key, not an AWS_-reserved name) for
      # GovCloud portability (ADR-0017); used to build the inline session
      # policy's SSM/EC2 ARNs.
      PORTAL_PARTITION = local.partition
    }
  }
}

# --- sign-key (POST /api/sign — SSH Certificate Authority, ADR-0014) ---
data "archive_file" "sign_key" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/sign_key"
  output_path = "${path.module}/.build/sign-key.zip"
}

resource "aws_lambda_function" "sign_key" {
  function_name    = "${var.name_prefix}-sign-key"
  filename         = data.archive_file.sign_key.output_path
  source_code_hash = data.archive_file.sign_key.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.handler_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn, aws_lambda_layer_version.crypto.arn]
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT       = var.environment
      TABLE_NAME        = var.table_name
      SSH_CA_SECRET_ARN = aws_secretsmanager_secret.ssh_ca_private_key.arn
    }
  }
}
