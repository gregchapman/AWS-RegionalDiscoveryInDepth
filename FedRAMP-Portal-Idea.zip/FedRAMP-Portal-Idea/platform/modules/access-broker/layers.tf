###############################################################################
# module: access-broker — Lambda layers (reused verbatim from the POC)
#
# shared: portal_utils.py (identity extraction, responses — used by all handlers)
# crypto: the `cryptography` package for SSH certificate signing (ADR-0014).
#   Built OUT OF BAND by lambda/layers/build-crypto-layer.sh into
#   lambda/layers/crypto/python/ (manylinux wheels matching the runtime). The
#   built tree is vendored here so the sign_key path works and validate passes.
###############################################################################

data "archive_file" "shared_layer" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/shared"
  output_path = "${path.module}/.build/shared-layer.zip"
}

resource "aws_lambda_layer_version" "shared" {
  filename            = data.archive_file.shared_layer.output_path
  source_code_hash    = data.archive_file.shared_layer.output_base64sha256
  layer_name          = "${var.name_prefix}-shared"
  compatible_runtimes = [var.lambda_runtime]
  description         = "Shared utilities for the access-broker handlers"
}

data "archive_file" "crypto_layer" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/layers/crypto"
  output_path = "${path.module}/.build/crypto-layer.zip"
}

resource "aws_lambda_layer_version" "crypto" {
  filename            = data.archive_file.crypto_layer.output_path
  source_code_hash    = data.archive_file.crypto_layer.output_base64sha256
  layer_name          = "${var.name_prefix}-crypto"
  compatible_runtimes = [var.lambda_runtime]
  description         = "cryptography package for SSH certificate signing (ADR-0014)"
}
