###############################################################################
# module: access-broker — outputs
#
# The api-edge module consumes the invoke_arn + function_name of each handler to
# build routes/integrations/lambda_permissions. The handler_exec role ARN feeds
# the kms module's credentials-key policy (lambda_exec_role_arn input) so KMS
# access flows from the key policy exactly as in the POC.
###############################################################################

output "handler_exec_role_arn" {
  description = "ARN of the broker handler execution role. Wire into kms.lambda_exec_role_arn so the credentials-key policy grants it Encrypt/Decrypt (as the POC did)."
  value       = aws_iam_role.handler_exec.arn
}

output "session_broker_role_arn" {
  description = "ARN of the session-broker role the ssm-credentials Lambda assumes (ADR-0012)."
  value       = aws_iam_role.session_broker.arn
}

output "ssh_ca_secret_arn" {
  description = "Secrets Manager ARN holding the SSH CA private key."
  value       = aws_secretsmanager_secret.ssh_ca_private_key.arn
}

output "ssh_ca_public_key_param" {
  description = "SSM parameter name holding the SSH CA public key (feed to workflow-engine.ssh_ca_public_key_param)."
  value       = aws_ssm_parameter.ssh_ca_public_key.name
}

# --- handler wiring (function_name + invoke_arn) for api-edge routes ---
output "handlers" {
  description = "Map of logical route key => { function_name, invoke_arn } for api-edge to build integrations/permissions."
  value = {
    create_access_request = {
      function_name = aws_lambda_function.create_access_request.function_name
      invoke_arn    = aws_lambda_function.create_access_request.invoke_arn
    }
    get_session_status = {
      function_name = aws_lambda_function.get_session_status.function_name
      invoke_arn    = aws_lambda_function.get_session_status.invoke_arn
    }
    list_sessions = {
      function_name = aws_lambda_function.list_sessions.function_name
      invoke_arn    = aws_lambda_function.list_sessions.invoke_arn
    }
    terminate_session = {
      function_name = aws_lambda_function.terminate_session.function_name
      invoke_arn    = aws_lambda_function.terminate_session.invoke_arn
    }
    ssm_credentials = {
      function_name = aws_lambda_function.ssm_credentials.function_name
      invoke_arn    = aws_lambda_function.ssm_credentials.invoke_arn
    }
    sign_key = {
      function_name = aws_lambda_function.sign_key.function_name
      invoke_arn    = aws_lambda_function.sign_key.invoke_arn
    }
  }
}
