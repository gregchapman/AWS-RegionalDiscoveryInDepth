###############################################################################
# module: access-broker — SSH Certificate Authority storage (ADR-0014)
#
# Reused verbatim from the POC ssh-ca.tf (the non-KMS parts; the KMS key lives
# in the kms module and its ARN arrives via var.ssh_ca_key_arn). The CA PRIVATE
# key is generated OUT OF BAND and imported into Secrets Manager (never transits
# Terraform state); Terraform only creates the empty container. The CA PUBLIC
# key lives in SSM Parameter Store (public keys are safe) for instances to trust
# via TrustedUserCAKeys — provision_user (workflow-engine) reads this param.
###############################################################################

locals {
  ssh_ca_secret_name = var.ssh_ca_secret_name != null ? var.ssh_ca_secret_name : "${var.name_prefix}/ssh-ca-private-key"
}

# Secrets Manager container for the CA PRIVATE key (OpenSSH PEM).
# Populated out-of-band by scripts/init-ssh-ca.sh — NOT by Terraform.
resource "aws_secretsmanager_secret" "ssh_ca_private_key" {
  name                    = local.ssh_ca_secret_name
  description             = "OpenSSH CA private key used to sign user certificates (ADR-0014)"
  kms_key_id              = var.ssh_ca_key_arn
  recovery_window_in_days = var.ssh_ca_secret_recovery_window_days
  tags                    = var.tags
}

# SSM Parameter for the CA PUBLIC key. Instances fetch this to configure
# TrustedUserCAKeys. Public keys are not secret. Populated by init-ssh-ca.sh.
resource "aws_ssm_parameter" "ssh_ca_public_key" {
  name        = var.ssh_ca_public_key_param_name
  description = "OpenSSH CA public key that instances trust (TrustedUserCAKeys)"
  type        = "String"
  # Placeholder; overwritten by init-ssh-ca.sh. lifecycle ignore prevents TF
  # from reverting the real value on subsequent applies.
  value = "PLACEHOLDER-run-init-ssh-ca.sh"
  tags  = var.tags

  lifecycle {
    ignore_changes = [value]
  }
}
