###############################################################################
# module: access-broker — variables
#
# Class 1 (INVARIANT CORE). THE SSM ACCESS PATH. Owns the credential-vending
# broker (ADR-0012), the SSH-CA secret/param the sign path consumes (ADR-0014),
# and the six access-lifecycle API handlers (create/get/list_sessions/terminate/
# ssm_credentials/sign_key), reused byte-for-byte. `connect` is always an
# SSM-equivalent brokered path — there is no swap seam here. See PROVENANCE.md.
#
# Depends on: kms (credentials key + ssh_ca key), data-score (table),
# workflow-engine (state machine ARN — create_access_request StartExecutions it).
###############################################################################

variable "name_prefix" {
  description = "Name prefix. Distinct from the POC ('fedramp-portal') so it stands up alongside (ADR-0032)."
  type        = string
  default     = "fedramp-platform"
}

# --- from kms ---
variable "credentials_key_arn" {
  description = "ARN of the ephemeral-credentials KMS key (handlers Encrypt/Decrypt)."
  type        = string
}

variable "credentials_key_id" {
  description = "Key id of the credentials KMS key (env KMS_KEY_ID for the handlers)."
  type        = string
}

variable "ssh_ca_key_arn" {
  description = "ARN of the SSH-CA KMS key (encrypts the CA private-key secret)."
  type        = string
}

# --- from data-score ---
variable "table_name" {
  description = "Access-request DynamoDB table name (env TABLE_NAME)."
  type        = string
}

variable "table_arn" {
  description = "Access-request table ARN (for the handler role's DynamoDB grant)."
  type        = string
}

variable "table_index_arn_wildcard" {
  description = "ARN pattern covering the table GSIs (<table_arn>/index/*)."
  type        = string
}

# --- from workflow-engine ---
variable "state_machine_arn" {
  description = "ARN of the access-lifecycle state machine. create_access_request does states:StartExecution on it."
  type        = string
}

# --- SSH CA (ADR-0014) ---
variable "ssh_ca_secret_name" {
  description = "Secrets Manager secret name for the SSH CA private key. Default under the platform prefix."
  type        = string
  default     = null
}

variable "ssh_ca_public_key_param_name" {
  description = "SSM parameter name for the SSH CA public key. Must match workflow-engine's ssh_ca_public_key_param."
  type        = string
  default     = "/fedramp-platform/ssh-ca-public-key"
}

variable "ssh_ca_secret_recovery_window_days" {
  type    = number
  default = 7
}

# --- Sessions / behavior ---
variable "session_ttl_minutes" {
  description = "Max session lifetime the create endpoint stamps (SESSION_TTL_MINUTES)."
  type        = number
  default     = 60
}

# --- Lambda packaging ---
variable "lambda_runtime" {
  type    = string
  default = "python3.12"
}

variable "lambda_timeout" {
  type    = number
  default = 30
}

variable "lambda_memory" {
  type    = number
  default = 128
}

variable "environment" {
  type    = string
  default = "platform"
}

variable "tags" {
  type = map(string)
  default = {
    Project   = "fedramp-platform"
    ManagedBy = "terraform"
    Class     = "core"
  }
}
