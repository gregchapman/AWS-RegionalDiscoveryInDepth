  jwt_issuer_url = "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_ABC123DEF"
  jwt_audiences  = ["1example23clientid456"]
  access_handlers = {
    create_access_request = { function_name = "fedramp-platform-create-access-request", invoke_arn = "arn:aws:apigateway:us-east-1:lambda:path/2015-03-31/functions/arn:aws:lambda:us-east-1:123456789012:function:fedramp-platform-create-access-request/invocations" }
    get_session_status    = { function_name = "fedramp-platform-get-session-status", invoke_arn = "arn:aws:apigateway:us-east-1:lambda:path/2015-03-31/functions/arn:aws:lambda:us-east-1:123456789012:function:fedramp-platform-get-session-status/invocations" }
    list_sessions         = { function_name = "fedramp-platform-list-sessions", invoke_arn = "arn:aws:apigateway:us-east-1:lambda:path/2015-03-31/functions/arn:aws:lambda:us-east-1:123456789012:function:fedramp-platform-list-sessions/invocations" }
    terminate_session     = { function_name = "fedramp-platform-terminate-session", invoke_arn = "arn:aws:apigateway:us-east-1:lambda:path/2015-03-31/functions/arn:aws:lambda:us-east-1:123456789012:function:fedramp-platform-terminate-session/invocations" }
    ssm_credentials       = { function_name = "fedramp-platform-ssm-credentials", invoke_arn = "arn:aws:apigateway:us-east-1:lambda:path/2015-03-31/functions/arn:aws:lambda:us-east-1:123456789012:function:fedramp-platform-ssm-credentials/invocations" }
    sign_key              = { function_name = "fedramp-platform-sign-key", invoke_arn = "arn:aws:apigateway:us-east-1:lambda:path/2015-03-31/functions/arn:aws:lambda:us-east-1:123456789012:function:fedramp-platform-sign-key/invocations" }
  }
