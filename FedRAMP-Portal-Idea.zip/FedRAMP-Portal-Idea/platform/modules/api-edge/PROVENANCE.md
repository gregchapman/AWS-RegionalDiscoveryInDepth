# PROVENANCE — module `api-edge` (THE CONTRACT FRONT DOOR)

**Extracted from:** the POC `terraform/03-api`:
- `main.tf` — the HTTP API v2 (`aws_apigatewayv2_api.portal`), the JWT
  authorizer, the `$default` stage + access-log group, and the nine
  integration/route/lambda_permission sets,
- `front-door.tf` — the regional custom domain + api mapping + Route 53 alias
  (ADR-0019),
- `lambda/{list_accounts,list_instances,serve_spa}/` — handler code,
- `lambda/shared/python/portal_utils.py` — the shared layer.
as deployed in the running POC.

**Class:** 2 — COMPLIANCE BASELINE. The contract front door: this is where the
four contracts meet the wire (consumer API + identity assertion). Graded, not
swapped.

**REUSED verbatim (byte-for-byte handler code):**
- `list_accounts`, `list_instances`, `serve_spa` handlers — unchanged. Carry the
  Racker/Customer access-filtering, fail-closed customer logic, ADR-0017
  partition-aware Organizations client, and same-origin SPA serving.
- `portal_utils.py` (shared layer) — unchanged.
- The API shape: HTTP API, JWT authorizer (audience/issuer), the nine route
  keys (exact methods + paths), `$default` -> serve_spa, `$default` stage with
  auto_deploy and JSON access logging.
- The custom-domain configuration: REGIONAL endpoint, TLS_1_2, api mapping to
  the `$default` stage, Route 53 A-alias to the regional target.

**RE-AUTHORED (packaging only):**
- No provider/terraform-backend blocks.
- Names via `var.name_prefix` (default `fedramp-platform`, distinct from POC).
- The nine POC blocks (integration + route + permission, one copy per endpoint)
  are DRY'd into a single `for_each` over `locals.routes`. Same wiring, one
  place to change — this is the "granularity to control blast radius /
  configurability" intent made concrete. Adding or removing a route is a
  one-line map edit.
- The identity seam is INPUT (`jwt_issuer_url` + `jwt_audiences`) instead of a
  direct Cognito reference (ADR-0028: identity by assurance, not mechanism) —
  any OIDC IdP that satisfies the contract works.
- The access-lifecycle handlers arrive via `var.access_handlers`
  (access-broker.handlers) instead of being defined here — this module owns the
  DOOR, access-broker owns the ACCESS.
- The front-door inputs (`spa_bucket_*`, `portal_domain`, `acm_certificate_arn`,
  `hosted_zone_id`) are the published portal/edge contract (ADR-0030 hybrid)
  instead of layer-02 remote-state locals. The custom domain + DNS are
  count-gated (optional) so the module stands up on the default endpoint alone.

**DELIBERATE BOUNDARY NOTE:**
- For this extraction pass, `serve_spa` + `list_accounts` + `list_instances`
  live here as the API's own request handlers. A later refactor may split a
  `portal-runtime` (SPA bucket + serve_spa) and `edge-dns` (domain/cert/route53)
  as separate Class 3 customer-owned modules behind these same inputs. The
  contract (inputs/outputs) is designed to allow that without disturbing callers.
- `serve_spa` gets an S3-read role; the two list endpoints get a read role
  (Organizations + SSM/EC2 describe) — both tighter than the POC's shared
  lambda_exec (AC-6). No behavior change.
- ADR-0019: NO `cors_configuration` — the SPA is same-origin behind `$default`.
  Its absence is the same-origin guarantee, reused intentionally.

**Validation:** `terraform validate` clean via the standalone-module harness
(archive provider; the four source_dirs exist; `.validate_args.hcl` supplies the
JWT seam + the access-broker handlers map).
