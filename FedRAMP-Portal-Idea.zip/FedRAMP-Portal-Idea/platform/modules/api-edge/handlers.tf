###############################################################################
# module: api-edge — the API's own read/serve handlers
#
# list_accounts (GET /api/accounts), list_instances (GET /api/instances), and
# serve_spa ($default) live here — they are the API's own request handlers, not
# part of the SSM access lifecycle. Code reused BYTE-FOR-BYTE from the POC. The
# access-lifecycle handlers (create/get/list_sessions/terminate/ssm_credentials/
# sign) come from access-broker via var.access_handlers.
#
# Roles are scoped to exactly what each handler calls (tighter than the POC's
# shared lambda_exec; AC-6): a read role (Organizations + SSM/EC2 describe) for
# the two list endpoints, and an S3-read role for serve_spa.
###############################################################################

data "aws_partition" "current" {}

locals {
  partition = data.aws_partition.current.partition
}

# --- shared layer (portal_utils) ---
data "archive_file" "shared_layer" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/shared"
  output_path = "${path.module}/.build/shared-layer.zip"
}

resource "aws_lambda_layer_version" "shared" {
  filename            = data.archive_file.shared_layer.output_path
  source_code_hash    = data.archive_file.shared_layer.output_base64sha256
  layer_name          = "${var.name_prefix}-edge-shared"
  compatible_runtimes = [var.lambda_runtime]
  description         = "Shared utilities for the api-edge read handlers"
}

###############################################################################
# Read role (list_accounts + list_instances)
###############################################################################

resource "aws_iam_role" "reader" {
  name = "${var.name_prefix}-edge-reader"
  tags = var.tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "reader_basic" {
  role       = aws_iam_role.reader.name
  policy_arn = "arn:${local.partition}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "reader_app" {
  name = "${var.name_prefix}-edge-reader-app"
  role = aws_iam_role.reader.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "OrganizationsRead"
        Effect = "Allow"
        Action = [
          "organizations:ListAccounts",
          "organizations:DescribeAccount"
        ]
        Resource = "*"
      },
      {
        Sid    = "SSMandEC2Describe"
        Effect = "Allow"
        Action = [
          "ssm:DescribeInstanceInformation",
          "ec2:DescribeInstances",
          "ec2:DescribeTags"
        ]
        Resource = "*"
      }
    ]
  })
}

# --- serve_spa S3-read role ---
resource "aws_iam_role" "spa" {
  name = "${var.name_prefix}-edge-spa"
  tags = var.tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "spa_basic" {
  role       = aws_iam_role.spa.name
  policy_arn = "arn:${local.partition}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "spa_s3" {
  count = var.spa_bucket_arn != "" ? 1 : 0
  name  = "${var.name_prefix}-edge-spa-s3"
  role  = aws_iam_role.spa.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid      = "ReadSPAAssets"
      Effect   = "Allow"
      Action   = ["s3:GetObject", "s3:ListBucket"]
      Resource = [var.spa_bucket_arn, "${var.spa_bucket_arn}/*"]
    }]
  })
}

###############################################################################
# list-accounts (GET /api/accounts)
###############################################################################

data "archive_file" "list_accounts" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/list_accounts"
  output_path = "${path.module}/.build/list-accounts.zip"
}

resource "aws_lambda_function" "list_accounts" {
  function_name    = "${var.name_prefix}-list-accounts"
  filename         = data.archive_file.list_accounts.output_path
  source_code_hash = data.archive_file.list_accounts.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.reader.arn
  layers           = [aws_lambda_layer_version.shared.arn]
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT = var.environment
    }
  }
}

###############################################################################
# list-instances (GET /api/instances)
###############################################################################

data "archive_file" "list_instances" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/list_instances"
  output_path = "${path.module}/.build/list-instances.zip"
}

resource "aws_lambda_function" "list_instances" {
  function_name    = "${var.name_prefix}-list-instances"
  filename         = data.archive_file.list_instances.output_path
  source_code_hash = data.archive_file.list_instances.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.reader.arn
  layers           = [aws_lambda_layer_version.shared.arn]
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT    = var.environment
      TARGET_REGIONS = join(",", var.target_regions)
    }
  }
}

###############################################################################
# serve-spa ($default — same-origin SPA serving, ADR-0019)
###############################################################################

data "archive_file" "serve_spa" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/serve_spa"
  output_path = "${path.module}/.build/serve-spa.zip"
}

resource "aws_lambda_function" "serve_spa" {
  function_name    = "${var.name_prefix}-serve-spa"
  filename         = data.archive_file.serve_spa.output_path
  source_code_hash = data.archive_file.serve_spa.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.spa.arn
  layers           = [aws_lambda_layer_version.shared.arn]
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT        = var.environment
      SPA_BUCKET         = var.spa_bucket_name
      SPA_INDEX_DOCUMENT = var.spa_index_document
    }
  }
}
