"""Lambda: GET /api/instances

Lists SSM-managed instances in target region(s). Returns instance ID,
platform, name, SSM ping status, and relevant tags.

Query params:
  - region: specific region to query (optional, defaults to all target regions)

Security:
  - Rackers see all instances across all target regions
  - Customers see only instances where:
    1. CustomerAccess tag is "true" AND
    2. Customer tag matches the user's customer_id claim from JWT
"""

import boto3
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from portal_utils import (
    get_env,
    get_user_from_event,
    json_response,
    error_response,
    parse_query_params,
)

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)


def get_instance_details(region: str) -> list:
    """Get SSM-managed instances with EC2 metadata for a region."""
    ssm = boto3.client("ssm", region_name=region)
    ec2 = boto3.client("ec2", region_name=region)

    # Get SSM-managed instances
    paginator = ssm.get_paginator("describe_instance_information")
    ssm_instances = {}
    for page in paginator.paginate():
        for info in page["InstanceInformationList"]:
            ssm_instances[info["InstanceId"]] = {
                "instance_id": info["InstanceId"],
                "ping_status": info["PingStatus"],
                "platform_type": info.get("PlatformType", "Unknown"),
                "platform_name": info.get("PlatformName", "Unknown"),
                "platform_version": info.get("PlatformVersion", ""),
                "agent_version": info.get("AgentVersion", ""),
                "last_ping": info.get("LastPingDateTime"),
                "region": region,
            }

    if not ssm_instances:
        return []

    # Enrich with EC2 tags (name, customer)
    instance_ids = list(ssm_instances.keys())
    try:
        ec2_paginator = ec2.get_paginator("describe_instances")
        for page in ec2_paginator.paginate(InstanceIds=instance_ids):
            for reservation in page["Reservations"]:
                for instance in reservation["Instances"]:
                    iid = instance["InstanceId"]
                    if iid in ssm_instances:
                        tags = {
                            t["Key"]: t["Value"]
                            for t in instance.get("Tags", [])
                        }
                        ssm_instances[iid]["name"] = tags.get("Name", iid)
                        ssm_instances[iid]["customer"] = tags.get("Customer", "")
                        ssm_instances[iid]["customer_access"] = tags.get("CustomerAccess", "false")
                        ssm_instances[iid]["state"] = instance["State"]["Name"]
                        ssm_instances[iid]["instance_type"] = instance.get("InstanceType", "")
                        ssm_instances[iid]["private_ip"] = instance.get("PrivateIpAddress", "")
    except Exception as e:
        logger.warning(f"Failed to get EC2 details for {region}: {e}")

    return list(ssm_instances.values())


def lambda_handler(event, context):
    """Handle GET /api/instances."""
    logger.info("list-instances invoked")

    user = get_user_from_event(event)
    params = parse_query_params(event)

    target_regions = get_env("TARGET_REGIONS", "us-east-2,us-west-1").split(",")

    # If a specific region is requested, use only that
    requested_region = params.get("region")
    if requested_region:
        if requested_region not in target_regions:
            return error_response(400, f"Region {requested_region} is not a valid target region")
        target_regions = [requested_region]

    is_racker = "Rackers" in user.get("groups", [])
    customer_id = user.get("customer_id", "")

    try:
        # Query regions in parallel for better latency
        all_instances = []
        with ThreadPoolExecutor(max_workers=len(target_regions)) as executor:
            futures = {
                executor.submit(get_instance_details, region.strip()): region
                for region in target_regions
            }
            for future in as_completed(futures):
                region = futures[future]
                try:
                    instances = future.result()
                    all_instances.extend(instances)
                except Exception as e:
                    logger.error(f"Error querying region {region}: {e}")

        # Apply access filtering
        if not is_racker:
            # Customers must pass BOTH checks:
            #   1. Instance tagged CustomerAccess=true
            #   2. Instance's Customer tag matches user's customer_id claim
            # If customer_id is empty (not set in Cognito), deny all — fail closed.
            if not customer_id:
                logger.warning(
                    f"Customer user {user['email']} has no customer_id claim. "
                    "Denying access to all instances (fail closed)."
                )
                all_instances = []
            else:
                all_instances = [
                    i for i in all_instances
                    if i.get("customer_access", "false").lower() == "true"
                    and i.get("customer", "").lower() == customer_id.lower()
                ]

        return json_response(200, {
            "instances": all_instances,
            "count": len(all_instances),
            "regions_queried": target_regions,
        })

    except Exception as e:
        logger.error(f"Error listing instances: {e}")
        return error_response(500, "Failed to list instances")
