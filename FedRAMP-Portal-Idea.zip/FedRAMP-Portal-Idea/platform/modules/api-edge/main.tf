###############################################################################
# module: api-edge — Class 2 COMPLIANCE BASELINE (THE CONTRACT FRONT DOOR)
#
# One HTTP API v2, one JWT authorizer, the nine routes, and the SPA-serving
# $default. Reused from the POC (03-api/main.tf API section). The nine POC
# blocks (integration + route + lambda_permission, repeated per endpoint) are
# DRY'd into a single for_each over locals.routes — same wiring, one place to
# change blast radius / add a route (matches the granularity intent).
#
# ADR-0019: no CloudFront; the SPA and API are same-origin behind one regional
# custom domain, so there is NO CORS configuration (a cross-origin setup would
# require it — its ABSENCE is the same-origin guarantee).
# ADR-0026: the portal is just a client; every route is reachable by any caller
# the JWT authorizer accepts — no portal-only privilege.
###############################################################################

terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    archive = {
      source  = "hashicorp/archive"
      version = "~> 2.0"
    }
  }
}

locals {
  # route key => wiring. invoke_arn is resolved from either a local handler or
  # the access-broker handlers map. authorized=false only for the SPA $default.
  local_handlers = {
    list_accounts  = aws_lambda_function.list_accounts.invoke_arn
    list_instances = aws_lambda_function.list_instances.invoke_arn
    serve_spa      = aws_lambda_function.serve_spa.invoke_arn
  }

  local_function_names = {
    list_accounts  = aws_lambda_function.list_accounts.function_name
    list_instances = aws_lambda_function.list_instances.function_name
    serve_spa      = aws_lambda_function.serve_spa.function_name
  }

  # The nine routes. handler_source = "local" | "broker" selects where the
  # function_name/invoke_arn comes from.
  routes = {
    "GET /api/accounts" = {
      handler = "list_accounts", source = "local", authorized = true
    }
    "GET /api/instances" = {
      handler = "list_instances", source = "local", authorized = true
    }
    "POST /api/connect" = {
      handler = "create_access_request", source = "broker", authorized = true
    }
    "GET /api/session/{requestId}" = {
      handler = "get_session_status", source = "broker", authorized = true
    }
    "GET /api/sessions" = {
      handler = "list_sessions", source = "broker", authorized = true
    }
    "POST /api/session/{requestId}/ssm-credentials" = {
      handler = "ssm_credentials", source = "broker", authorized = true
    }
    "POST /api/session/{requestId}/terminate" = {
      handler = "terminate_session", source = "broker", authorized = true
    }
    "POST /api/sign" = {
      handler = "sign_key", source = "broker", authorized = true
    }
    "$default" = {
      handler = "serve_spa", source = "local", authorized = false
    }
  }

  # Resolve invoke_arn + function_name per route.
  route_invoke_arn = {
    for k, r in local.routes : k => (
      r.source == "local" ? local.local_handlers[r.handler] : var.access_handlers[r.handler].invoke_arn
    )
  }
  route_function_name = {
    for k, r in local.routes : k => (
      r.source == "local" ? local.local_function_names[r.handler] : var.access_handlers[r.handler].function_name
    )
  }

  use_custom_domain = var.portal_domain != "" && var.acm_certificate_arn != ""
}

###############################################################################
# HTTP API v2 (no CORS — same-origin, ADR-0019)
###############################################################################

resource "aws_apigatewayv2_api" "portal" {
  name          = "${var.name_prefix}-api"
  protocol_type = "HTTP"
  tags          = var.tags
  # No cors_configuration block: the SPA is served same-origin via $default.
}

###############################################################################
# JWT authorizer (the identity contract seam — ADR-0028)
###############################################################################

resource "aws_apigatewayv2_authorizer" "jwt" {
  api_id           = aws_apigatewayv2_api.portal.id
  authorizer_type  = "JWT"
  identity_sources = ["$request.header.Authorization"]
  name             = "${var.name_prefix}-jwt"

  jwt_configuration {
    audience = var.jwt_audiences
    issuer   = var.jwt_issuer_url
  }
}

###############################################################################
# Integrations + routes + lambda permissions (DRY for_each over locals.routes)
###############################################################################

resource "aws_apigatewayv2_integration" "route" {
  for_each = local.routes

  api_id                 = aws_apigatewayv2_api.portal.id
  integration_type       = "AWS_PROXY"
  integration_uri        = local.route_invoke_arn[each.key]
  integration_method     = "POST"
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "route" {
  for_each = local.routes

  api_id    = aws_apigatewayv2_api.portal.id
  route_key = each.key
  target    = "integrations/${aws_apigatewayv2_integration.route[each.key].id}"

  # Every route except the SPA $default requires a valid JWT (ADR-0026).
  authorization_type = each.value.authorized ? "JWT" : "NONE"
  authorizer_id      = each.value.authorized ? aws_apigatewayv2_authorizer.jwt.id : null
}

resource "aws_lambda_permission" "route" {
  for_each = local.routes

  statement_id  = "AllowAPIGatewayInvoke-${replace(replace(replace(each.key, " ", "-"), "/", "_"), "$", "")}"
  action        = "lambda:InvokeFunction"
  function_name = local.route_function_name[each.key]
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.portal.execution_arn}/*/*"
}

###############################################################################
# Access-logged $default stage (auto-deploy)
###############################################################################

resource "aws_cloudwatch_log_group" "api_access" {
  name              = "/aws/apigateway/${var.name_prefix}-api"
  retention_in_days = var.access_log_retention_days
  tags              = var.tags
}

resource "aws_apigatewayv2_stage" "default" {
  api_id      = aws_apigatewayv2_api.portal.id
  name        = "$default"
  auto_deploy = true
  tags        = var.tags

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_access.arn
    format = jsonencode({
      requestId       = "$context.requestId"
      ip              = "$context.identity.sourceIp"
      requestTime     = "$context.requestTime"
      httpMethod      = "$context.httpMethod"
      routeKey        = "$context.routeKey"
      status          = "$context.status"
      protocol        = "$context.protocol"
      responseLength  = "$context.responseLength"
      integrationErr  = "$context.integrationErrorMessage"
      authorizerError = "$context.authorizer.error"
    })
  }
}

###############################################################################
# Regional custom domain + mapping + Route 53 alias (ADR-0019). Optional.
###############################################################################

resource "aws_apigatewayv2_domain_name" "portal" {
  count       = local.use_custom_domain ? 1 : 0
  domain_name = var.portal_domain
  tags        = var.tags

  domain_name_configuration {
    certificate_arn = var.acm_certificate_arn
    endpoint_type   = "REGIONAL"
    security_policy = "TLS_1_2"
  }
}

resource "aws_apigatewayv2_api_mapping" "portal" {
  count       = local.use_custom_domain ? 1 : 0
  api_id      = aws_apigatewayv2_api.portal.id
  domain_name = aws_apigatewayv2_domain_name.portal[0].id
  stage       = aws_apigatewayv2_stage.default.id
}

resource "aws_route53_record" "portal" {
  count   = local.use_custom_domain && var.hosted_zone_id != "" ? 1 : 0
  zone_id = var.hosted_zone_id
  name    = var.portal_domain
  type    = "A"

  alias {
    name                   = aws_apigatewayv2_domain_name.portal[0].domain_name_configuration[0].target_domain_name
    zone_id                = aws_apigatewayv2_domain_name.portal[0].domain_name_configuration[0].hosted_zone_id
    evaluate_target_health = false
  }
}
