###############################################################################
# module: api-edge — outputs
###############################################################################

output "api_id" {
  description = "HTTP API id."
  value       = aws_apigatewayv2_api.portal.id
}

output "api_endpoint" {
  description = "Default execute-api endpoint (https://<id>.execute-api.<region>.amazonaws.com)."
  value       = aws_apigatewayv2_api.portal.api_endpoint
}

output "api_execution_arn" {
  description = "API execution ARN (base for lambda permission source ARNs)."
  value       = aws_apigatewayv2_api.portal.execution_arn
}

output "stage_invoke_url" {
  description = "Invoke URL of the $default stage."
  value       = aws_apigatewayv2_stage.default.invoke_url
}

output "portal_url" {
  description = "Public portal URL (custom domain if configured, else the default stage URL)."
  value       = local.use_custom_domain ? "https://${var.portal_domain}" : aws_apigatewayv2_stage.default.invoke_url
}

output "custom_domain_target" {
  description = "Regional target domain of the custom domain (for external DNS if hosted_zone_id not supplied). Null when no custom domain."
  value       = local.use_custom_domain ? aws_apigatewayv2_domain_name.portal[0].domain_name_configuration[0].target_domain_name : null
}

output "list_accounts_function_name" {
  value = aws_lambda_function.list_accounts.function_name
}

output "list_instances_function_name" {
  value = aws_lambda_function.list_instances.function_name
}

output "serve_spa_function_name" {
  value = aws_lambda_function.serve_spa.function_name
}
