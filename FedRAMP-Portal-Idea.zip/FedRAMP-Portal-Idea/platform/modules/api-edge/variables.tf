###############################################################################
# module: api-edge — variables
#
# Class 2 (COMPLIANCE BASELINE / THE CONTRACT FRONT DOOR). One HTTP API v2, one
# JWT authorizer, the nine routes, the SPA-serving $default, and the regional
# custom domain (ADR-0019: no CloudFront, same-origin SPA+API). Reused verbatim
# from the POC (03-api/main.tf API section + front-door.tf). See PROVENANCE.md.
#
# The identity seam (ADR-0028) is an INPUT: issuer_url + audience come from
# whatever IdP implements the contract (identity-cognito is the reference). The
# access handlers arrive as an INPUT map from access-broker. list_accounts /
# list_instances / serve_spa live HERE (the API's own request handlers).
###############################################################################

variable "name_prefix" {
  description = "Name prefix. Distinct from the POC ('fedramp-portal') so it stands up alongside (ADR-0032)."
  type        = string
  default     = "fedramp-platform"
}

# --- Identity contract seam (from identity-cognito or any OIDC IdP) ---
variable "jwt_issuer_url" {
  description = "OIDC issuer URL for the JWT authorizer (identity-cognito.issuer_url)."
  type        = string
}

variable "jwt_audiences" {
  description = "Allowed JWT audiences (identity-cognito: [user_pool_client_id])."
  type        = list(string)
}

# --- Access handlers (from access-broker.handlers) ---
variable "access_handlers" {
  description = <<-EOT
    Map of route key => { function_name, invoke_arn } for the access-lifecycle
    handlers owned by access-broker. Expected keys: create_access_request,
    get_session_status, list_sessions, terminate_session, ssm_credentials,
    sign_key.
  EOT
  type = map(object({
    function_name = string
    invoke_arn    = string
  }))
}

# --- SPA + front door (published portal/edge contract, ADR-0030) ---
variable "spa_bucket_name" {
  description = "Private S3 bucket name holding the SPA assets (serve_spa reads it)."
  type        = string
  default     = ""
}

variable "spa_bucket_arn" {
  description = "ARN of the SPA bucket (for the serve_spa role's s3:GetObject grant)."
  type        = string
  default     = ""
}

variable "spa_index_document" {
  type    = string
  default = "index.html"
}

variable "portal_domain" {
  description = "Custom domain for the front door (e.g. portal.example.com). Empty = no custom domain (API default endpoint only)."
  type        = string
  default     = ""
}

variable "acm_certificate_arn" {
  description = "Regional ACM cert ARN for the custom domain. Empty = no custom domain."
  type        = string
  default     = ""
}

variable "hosted_zone_id" {
  description = "Route 53 hosted zone id for the alias record. Empty = no DNS record."
  type        = string
  default     = ""
}

# --- Target account/regions for the read endpoints ---
variable "target_regions" {
  description = "Regions list_instances enumerates (env TARGET_REGIONS)."
  type        = list(string)
  default     = ["us-east-1"]
}

# --- API access logging ---
variable "access_log_retention_days" {
  type    = number
  default = 90
}

# --- Lambda packaging (list_accounts / list_instances / serve_spa) ---
variable "lambda_runtime" {
  type    = string
  default = "python3.12"
}
variable "lambda_timeout" {
  type    = number
  default = 30
}
variable "lambda_memory" {
  type    = number
  default = 128
}
variable "environment" {
  type    = string
  default = "platform"
}

variable "tags" {
  type = map(string)
  default = {
    Project   = "fedramp-platform"
    ManagedBy = "terraform"
    Class     = "baseline"
  }
}
