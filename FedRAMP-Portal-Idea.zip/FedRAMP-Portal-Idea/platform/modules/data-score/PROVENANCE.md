# PROVENANCE — module `data-score`

**Extracted from:** the POC `terraform/03-api/main.tf`,
`aws_dynamodb_table.access_requests`, as deployed in the running POC.

**Class:** 1 — INVARIANT CORE. The "score" (ADR-0023): records session position,
drives nothing.

**REUSED verbatim:** hash/range keys (`request_id`/`created_at`), the four
attributes, both GSIs (`user-index`, `status-index`, projection ALL), TTL on
`expires_at`, PITR on.

**RE-AUTHORED (packaging only):**
- No provider/terraform-backend blocks.
- Name parameterized via `var.name_prefix` (default `fedramp-platform`, distinct
  from the POC's `fedramp-portal-access-requests`) so it stands up alongside the
  POC (ADR-0032).
- `billing_mode`, `ttl_enabled`, `point_in_time_recovery` exposed as variables.
- Added `tags`.

**Tracked note (not a change):** `ttl_enabled` carries the AU-9/AU-11 deferred
decision — TTL reaps the operational record independent of teardown outcome
(permanent audit survives in CloudTrail/CloudWatch). Left as a knob until the
800-53 refinement lands; default matches the POC.

**Bug fixes carried:** the `status-index` GSI is what the ADR-0025 operator lens
(`list_sessions ?scope=all`) queries — carried forward intact.

**Validation:** `terraform validate` clean via the standalone-module harness.
