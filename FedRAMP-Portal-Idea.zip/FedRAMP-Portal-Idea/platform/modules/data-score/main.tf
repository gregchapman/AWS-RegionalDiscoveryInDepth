###############################################################################
# module: data-score — Class 1 INVARIANT CORE
#
# REUSE of the POC's DynamoDB access-request table (03-api/main.tf
# aws_dynamodb_table.access_requests) — PROVENANCE.md. Verbatim key schema,
# GSIs, TTL, PITR. Only the name is parameterized and TTL/PITR exposed as knobs.
#
# The "score" (ADR-0023): records session position; drives nothing. Consumed by
# the conductor (workflow-engine) and the API handlers (access-broker).
###############################################################################

terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

resource "aws_dynamodb_table" "access_requests" {
  name         = "${var.name_prefix}-access-requests"
  billing_mode = var.billing_mode
  hash_key     = "request_id"
  range_key    = "created_at"
  tags         = var.tags

  attribute {
    name = "request_id"
    type = "S"
  }
  attribute {
    name = "created_at"
    type = "S"
  }
  attribute {
    name = "user_id"
    type = "S"
  }
  attribute {
    name = "status"
    type = "S"
  }

  # user-index: a user's own sessions (list_sessions self mode).
  global_secondary_index {
    name            = "user-index"
    hash_key        = "user_id"
    range_key       = "created_at"
    projection_type = "ALL"
  }

  # status-index: enumerate by status (the conductor's convergence; the operator
  # lens scope=all queries this per VISIBLE status — ADR-0025).
  global_secondary_index {
    name            = "status-index"
    hash_key        = "status"
    range_key       = "created_at"
    projection_type = "ALL"
  }

  ttl {
    attribute_name = "expires_at"
    enabled        = var.ttl_enabled
  }

  point_in_time_recovery {
    enabled = var.point_in_time_recovery
  }
}
