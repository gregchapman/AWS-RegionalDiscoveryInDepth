###############################################################################
# module: data-score — outputs (consumed by workflow-engine, access-broker)
###############################################################################

output "table_name" {
  description = "Access-request table name (env TABLE_NAME for the handlers)."
  value       = aws_dynamodb_table.access_requests.name
}

output "table_arn" {
  description = "Access-request table ARN (for IAM grants)."
  value       = aws_dynamodb_table.access_requests.arn
}

output "table_index_arn_wildcard" {
  description = "ARN pattern covering the table's GSIs (for IAM: <arn>/index/*)."
  value       = "${aws_dynamodb_table.access_requests.arn}/index/*"
}
