###############################################################################
# module: data-score — variables
#
# Class 1 (INVARIANT CORE). The DynamoDB access-request table — the "score"
# (ADR-0023): it records where each session is; it drives nothing. Reused
# verbatim from the POC (03-api/main.tf aws_dynamodb_table.access_requests).
###############################################################################

variable "name_prefix" {
  description = "Table name prefix. Distinct from the POC ('fedramp-portal') so it stands up alongside (ADR-0032)."
  type        = string
  default     = "fedramp-platform"
}

variable "billing_mode" {
  description = "DynamoDB billing mode."
  type        = string
  default     = "PAY_PER_REQUEST"
}

variable "point_in_time_recovery" {
  description = "Enable PITR (CP-9)."
  type        = bool
  default     = true
}

variable "ttl_enabled" {
  description = <<-EOT
    Enable DynamoDB TTL on `expires_at`. NOTE (AU-9/AU-11, tracked): TTL reaps
    the OPERATIONAL record independent of teardown outcome, so a CLEANUP_FAILED
    record can drop off the live view before it is actioned (the permanent audit
    survives in CloudTrail/CloudWatch). The deferred 800-53 refinement is to not
    reap non-terminal records / retain terminal ones for the audit window. Left
    as a knob until that decision lands; default matches the POC (enabled).
  EOT
  type        = bool
  default     = true
}

variable "tags" {
  description = "Tags applied to the table."
  type        = map(string)
  default = {
    Project   = "fedramp-platform"
    ManagedBy = "terraform"
    Class     = "core"
  }
}
