# PROVENANCE — module `identity-cognito`

**Extracted from:** the POC `terraform/03-api/main.tf` (Cognito user pool,
domain, SPA client, groups) and `terraform/03-api/cognito-triggers.tf` plus
`terraform/03-api/lambda/pre_token_generation/handler.py`, as deployed in the
running POC.

**Class:** 3 — CUSTOMER-OWNED. One implementation of the identity contract
(ADR-0028: identity by assurance, not mechanism). Cognito is the reference IdP;
a customer may swap it for any OIDC provider behind the same JWT-authorizer seam
that `api-edge` consumes. See `../../../docs/TARGET-ARCHITECTURE.md` §1a.

**REUSED verbatim:**
- The pre_token_generation handler (`lambda/pre_token_generation/handler.py`) —
  copied byte-for-byte. This is the ADR-0011 attribution fix (injects `email` +
  `custom:customer_id` into the ACCESS token; requires trigger V2_0).
- The pool body: `username_attributes`/`auto_verified_attributes = ["email"]`,
  the password policy values, `mfa_configuration = "ON"`, software-token MFA,
  the `lambda_config.pre_token_generation_config` with `lambda_version = "V2_0"`,
  the `verified_email` recovery, and the `role`/`customer_id` custom schema.
- The SPA client: `generate_secret = false`, `code` flow, scopes
  `openid/email/profile`, COGNITO IdP, the explicit auth flows, token validities
  (1/1/24 hours), token_validity_units.
- The two groups (Rackers/Customers) — now data-driven via `var.groups` with the
  same defaults.

**RE-AUTHORED (packaging only):**
- No provider/terraform-backend blocks (module inherits providers).
- Names via `var.name_prefix` (default `fedramp-platform`, distinct from the
  POC's `fedramp-portal-*`) so it stands up alongside the POC (ADR-0032).
- Customer-tailorable knobs exposed as variables: domain prefix, callback/logout
  URLs, password policy, MFA mode, software-token toggle, token lifetimes,
  groups map, Lambda runtime/timeout/memory. All default to the POC's values.
- `software_token_mfa_configuration` made a `dynamic` block gated by
  `var.software_token_mfa_enabled` (default true = same as POC).
- Groups converted from two hardcoded resources to `for_each` over `var.groups`.

**DELIBERATE, FAITHFUL-IN-BEHAVIOR CHANGE (documented):**
- The trigger Lambda gets its OWN minimal execution role here
  (`AWSLambdaBasicExecutionRole`, Logs only) instead of the POC's shared
  `aws_iam_role.lambda_exec`. Rationale: (1) the trigger only needs CloudWatch
  Logs — it makes no AWS API calls — so a dedicated least-privilege role is
  strictly *tighter* than the shared role (AC-6); (2) it makes this module a
  true dependency-free leaf a customer can stand up on its own. Behavior of the
  trigger is unchanged. If a customer swaps the IdP, this whole module goes with
  it — no orphaned reference into the broker.

**Cross-module cycle kept internal:** pool.lambda_config -> trigger Lambda ->
`aws_lambda_permission` (source_arn = pool.arn). All three live here so the cycle
resolves inside the module.

**Bug fixes carried:** the ADR-0011 attribution fix (the reason this trigger
exists) is carried intact — this is the fix, not a workaround.

**Validation:** `terraform validate` clean via the standalone-module harness
(archive provider present so the archive_file data source plans).
