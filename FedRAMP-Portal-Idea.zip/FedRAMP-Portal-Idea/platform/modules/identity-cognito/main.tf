###############################################################################
# module: identity-cognito — Class 3 CUSTOMER-OWNED
#
# One implementation of the identity contract (ADR-0028). REUSE of the POC's
# Cognito pool + client + domain + groups (03-api/main.tf) and the
# pre_token_generation trigger (03-api/cognito-triggers.tf + lambda/) —
# PROVENANCE.md. Resource bodies preserved; only names/URLs/policy knobs are
# parameterized.
#
# SELF-CONTAINED LEAF: the pool <-> trigger-Lambda <-> invoke-permission cycle
# lives entirely here, and the trigger gets its OWN minimal execution role
# (CloudWatch Logs only) instead of the POC's shared lambda_exec role — so this
# module depends on nothing and a customer can stand identity up independently.
# See PROVENANCE.md for why that is faithful in behavior.
#
# Controls: IA-2 (MFA), IA-5/AC-7 (password policy), AU-2/AU-3/AC-2 (the
# attribution trigger, ADR-0011).
###############################################################################

terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    archive = {
      source  = "hashicorp/archive"
      version = "~> 2.0"
    }
  }
}

data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}

locals {
  account_id    = data.aws_caller_identity.current.account_id
  partition     = data.aws_partition.current.partition
  domain_prefix = var.domain_prefix != null ? var.domain_prefix : "${var.name_prefix}-${local.account_id}"
}

###############################################################################
# Pre Token Generation trigger (ADR-0011 attribution fix) — code reused verbatim
###############################################################################

# Minimal own execution role (Logs only). See module header / PROVENANCE.
resource "aws_iam_role" "pre_token_generation" {
  name = "${var.name_prefix}-pre-token-generation"
  tags = var.tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "pre_token_generation_logs" {
  role       = aws_iam_role.pre_token_generation.name
  policy_arn = "arn:${local.partition}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

data "archive_file" "pre_token_generation" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/pre_token_generation"
  output_path = "${path.module}/.build/pre-token-generation.zip"
}

resource "aws_lambda_function" "pre_token_generation" {
  function_name    = "${var.name_prefix}-pre-token-generation"
  filename         = data.archive_file.pre_token_generation.output_path
  source_code_hash = data.archive_file.pre_token_generation.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.pre_token_generation.arn
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT = var.environment
    }
  }
}

# Allow Cognito to invoke the trigger for THIS user pool only.
resource "aws_lambda_permission" "cognito_pre_token_generation" {
  statement_id  = "AllowCognitoInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.pre_token_generation.function_name
  principal     = "cognito-idp.amazonaws.com"
  source_arn    = aws_cognito_user_pool.portal.arn
}

###############################################################################
# Cognito User Pool
###############################################################################

resource "aws_cognito_user_pool" "portal" {
  name = "${var.name_prefix}-users"
  tags = var.tags

  username_attributes      = ["email"]
  auto_verified_attributes = ["email"]

  password_policy {
    minimum_length                   = var.password_minimum_length
    require_lowercase                = var.password_require_lowercase
    require_numbers                  = var.password_require_numbers
    require_symbols                  = var.password_require_symbols
    require_uppercase                = var.password_require_uppercase
    temporary_password_validity_days = var.temporary_password_validity_days
  }

  mfa_configuration = var.mfa_configuration

  dynamic "software_token_mfa_configuration" {
    for_each = var.software_token_mfa_enabled ? [1] : []
    content {
      enabled = true
    }
  }

  # V2_0 REQUIRED to customize ACCESS-token claims (V1_0 only touches the ID
  # token). Injects email + custom:customer_id so downstream handlers and
  # CloudTrail attribute to a real person (ADR-0011). Trigger defined above.
  lambda_config {
    pre_token_generation_config {
      lambda_arn     = aws_lambda_function.pre_token_generation.arn
      lambda_version = "V2_0"
    }
  }

  account_recovery_setting {
    recovery_mechanism {
      name     = "verified_email"
      priority = 1
    }
  }

  schema {
    attribute_data_type = "String"
    name                = "role"
    mutable             = true
    string_attribute_constraints {
      min_length = 1
      max_length = 50
    }
  }

  schema {
    attribute_data_type = "String"
    name                = "customer_id"
    mutable             = true
    string_attribute_constraints {
      min_length = 0
      max_length = 50
    }
  }
}

resource "aws_cognito_user_pool_domain" "portal" {
  domain       = local.domain_prefix
  user_pool_id = aws_cognito_user_pool.portal.id
}

resource "aws_cognito_user_pool_client" "portal" {
  name         = "${var.name_prefix}-spa"
  user_pool_id = aws_cognito_user_pool.portal.id

  generate_secret = false # SPA cannot hold secrets

  allowed_oauth_flows_user_pool_client = true
  allowed_oauth_flows                  = ["code"]
  allowed_oauth_scopes                 = ["openid", "email", "profile"]
  supported_identity_providers         = ["COGNITO"]

  callback_urls = var.callback_urls
  logout_urls   = var.logout_urls

  explicit_auth_flows = [
    "ALLOW_REFRESH_TOKEN_AUTH",
    "ALLOW_USER_SRP_AUTH"
  ]

  access_token_validity  = var.access_token_validity_hours
  id_token_validity      = var.id_token_validity_hours
  refresh_token_validity = var.refresh_token_validity_hours

  token_validity_units {
    access_token  = "hours"
    id_token      = "hours"
    refresh_token = "hours"
  }
}

# Role-based groups (customer-tailorable).
resource "aws_cognito_user_group" "groups" {
  for_each     = var.groups
  name         = each.key
  user_pool_id = aws_cognito_user_pool.portal.id
  description  = each.value
}
