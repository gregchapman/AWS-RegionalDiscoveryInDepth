###############################################################################
# module: identity-cognito — outputs
#
# These are the identity-contract seam values the api-edge JWT authorizer and
# the SPA consume. A different IdP implementation would publish the same shape.
###############################################################################

output "user_pool_id" {
  description = "Cognito user pool id."
  value       = aws_cognito_user_pool.portal.id
}

output "user_pool_arn" {
  description = "Cognito user pool ARN."
  value       = aws_cognito_user_pool.portal.arn
}

output "user_pool_endpoint" {
  description = "Pool endpoint (issuer host) for the JWT authorizer."
  value       = aws_cognito_user_pool.portal.endpoint
}

output "user_pool_client_id" {
  description = "SPA app-client id (JWT audience)."
  value       = aws_cognito_user_pool_client.portal.id
}

output "user_pool_domain" {
  description = "Cognito hosted-UI domain prefix."
  value       = aws_cognito_user_pool_domain.portal.domain
}

output "issuer_url" {
  description = "OIDC issuer URL for the JWT authorizer (https://cognito-idp.<region>.amazonaws.com/<pool-id>)."
  value       = "https://${aws_cognito_user_pool.portal.endpoint}"
}
