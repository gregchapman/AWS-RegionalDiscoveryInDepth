###############################################################################
# module: identity-cognito — variables
#
# Class 3 (CUSTOMER-OWNED). One implementation of the identity contract
# (ADR-0028: identity by assurance, not mechanism). Cognito is the reference
# IdP; a customer may swap it for another OIDC provider behind the same JWT
# authorizer seam. Reused verbatim from the POC (03-api main.tf Cognito blocks +
# cognito-triggers.tf pre_token_generation). See PROVENANCE.md.
#
# Everything a customer legitimately tailors is a variable here: pool naming,
# domain prefix, callback/logout URLs, groups, password policy, MFA, token
# lifetimes, and the tenant-scoping custom attributes. What is NOT negotiable
# (MFA available, attribution trigger present) has secure defaults.
###############################################################################

variable "name_prefix" {
  description = "Name prefix for identity resources. Distinct from the POC ('fedramp-portal') so it stands up alongside (ADR-0032)."
  type        = string
  default     = "fedramp-platform"
}

variable "domain_prefix" {
  description = <<-EOT
    Cognito hosted-UI domain prefix. Must be globally unique. The POC used
    "fedramp-portal-<account_id>"; default here appends the account id to
    name_prefix for the same collision-avoidance property.
  EOT
  type        = string
  default     = null
}

# --- OAuth callback / logout URLs (branding + portal DNS are customer choices)
variable "callback_urls" {
  description = "OAuth2 callback URLs for the SPA client (e.g. https://portal.example.com/callback)."
  type        = list(string)
  default     = ["http://localhost:5173/callback"]
}

variable "logout_urls" {
  description = "OAuth2 logout URLs for the SPA client."
  type        = list(string)
  default     = ["http://localhost:5173"]
}

# --- Password policy (AC-7 / IA-5). Defaults match the POC.
variable "password_minimum_length" {
  type    = number
  default = 12
}
variable "password_require_lowercase" {
  type    = bool
  default = true
}
variable "password_require_uppercase" {
  type    = bool
  default = true
}
variable "password_require_numbers" {
  type    = bool
  default = true
}
variable "password_require_symbols" {
  type    = bool
  default = true
}
variable "temporary_password_validity_days" {
  type    = number
  default = 1
}

# --- MFA (IA-2). "ON" is the platform default and should stay on; a customer
#     with a stronger external IdP MFA may set "OPTIONAL"/"OFF" knowingly.
variable "mfa_configuration" {
  description = "Cognito MFA mode: ON | OPTIONAL | OFF. Platform default ON (IA-2)."
  type        = string
  default     = "ON"
  validation {
    condition     = contains(["ON", "OPTIONAL", "OFF"], var.mfa_configuration)
    error_message = "mfa_configuration must be ON, OPTIONAL, or OFF."
  }
}

variable "software_token_mfa_enabled" {
  description = "Enable TOTP software-token MFA."
  type        = bool
  default     = true
}

# --- Token lifetimes (hours). Defaults match the POC.
variable "access_token_validity_hours" {
  type    = number
  default = 1
}
variable "id_token_validity_hours" {
  type    = number
  default = 1
}
variable "refresh_token_validity_hours" {
  type    = number
  default = 24
}

# --- Role groups. The POC ships Rackers (multi-account) + Customers
#     (single-account). A customer can rename/replace these to their org model.
variable "groups" {
  description = "Map of group name => description to create in the pool."
  type        = map(string)
  default = {
    Rackers   = "Operator engineers with multi-account access"
    Customers = "Customer users with single-account access"
  }
}

# --- Lambda packaging for the pre_token_generation trigger.
variable "lambda_runtime" {
  type    = string
  default = "python3.12"
}
variable "lambda_timeout" {
  type    = number
  default = 10
}
variable "lambda_memory" {
  type    = number
  default = 128
}
variable "environment" {
  description = "Environment tag passed to the trigger Lambda."
  type        = string
  default     = "platform"
}

variable "tags" {
  type = map(string)
  default = {
    Project   = "fedramp-platform"
    ManagedBy = "terraform"
    Class     = "customer-owned"
  }
}
