# PROVENANCE — module `kms`

**Extracted from:** the POC `terraform/03-api/kms.tf` (the `credentials` key +
alias) and the KMS portion of `terraform/03-api/ssh-ca.tf` (the `ssh_ca` key +
alias), as deployed in the running POC.

**Class:** 1 — INVARIANT CORE (SC-12/SC-13 crypto foundation the conductor and
broker depend on). See `../README.md` and `../../../docs/TARGET-ARCHITECTURE.md`
§1a.

**What was REUSED verbatim (proven asset):**
- The `credentials` key: rotation on, 14-day deletion window, and the exact
  policy statements — root full access + Lambda Encrypt/Decrypt/GenerateDataKey
  + Step Functions Encrypt/GenerateDataKey.
- The `ssh_ca` key: rotation on, and the exact policy — root full access +
  Lambda Decrypt/GenerateDataKey.

**What was RE-AUTHORED (packaging only):**
- No `provider`/`terraform{backend}` blocks (module inherits providers).
- Alias names parameterized via `var.name_prefix` (default `fedramp-platform`,
  distinct from the POC's `fedramp-portal`) so keys stand up ALONGSIDE the POC
  (ADR-0032). POC aliases were `alias/fedramp-portal-credentials` /
  `alias/fedramp-portal-ssh-ca`.
- COUPLING made explicit: the POC key policies referenced
  `aws_iam_role.lambda_exec.arn` / `aws_iam_role.sfn_exec.arn` directly (those
  roles live in other layers). Here those are OPTIONAL input variables
  (`lambda_exec_role_arn`, `sfn_exec_role_arn`); when null the corresponding
  grant statement is omitted and only root access remains — so the module can be
  created before the roles exist, then the caller wires the ARNs. Considered the
  looser `aws_kms_grant` / ViaService approach and REJECTED it for now to stay
  faithful to the proven key-policy structure (don't redesign the security model
  under the banner of modularity).
- `deletion_window_in_days` / `enable_key_rotation` exposed as variables.

**What was DELIBERATELY LEFT OUT (belongs to access-broker, not kms):**
- `aws_secretsmanager_secret.ssh_ca_private_key`, `aws_ssm_parameter`
  `ssh_ca_public_key`, and `aws_iam_role_policy.lambda_ssh_ca` from ssh-ca.tf —
  these CONSUME the ssh_ca key and are the SSH-cert-signing path; they move to
  the `access-broker` module.

**Bug fixes carried:** none specific (KMS wasn't implicated in I8/I9/I10).

**Validation:** `terraform validate` clean via the standalone-module harness
(provider stub + module block; init -backend=false + validate).
