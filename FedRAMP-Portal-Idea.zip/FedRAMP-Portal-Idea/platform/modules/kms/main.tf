###############################################################################
# module: kms — Class 1 INVARIANT CORE
#
# REUSE of the POC's credential + SSH-CA KMS keys (03-api/kms.tf and the KMS
# portion of 03-api/ssh-ca.tf) — PROVENANCE.md. Policies preserved verbatim in
# intent; the consuming role ARNs are INPUTS (optional) rather than in-module
# references, so this module has no dependency on the conductor/broker modules.
#
# Controls: SC-12 / SC-13 (approved crypto, managed keys, rotation on).
#
# NOTE: the Secrets Manager secret + SSM param + Lambda IAM that the POC bundled
# into ssh-ca.tf are NOT here — they belong to the access-broker module (they
# CONSUME the ssh_ca key). This module owns only the keys + aliases.
###############################################################################

terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  partition  = data.aws_partition.current.partition # aws | aws-us-gov (ADR-0017)

  root_stmt = {
    Sid       = "RootAccountFullAccess"
    Effect    = "Allow"
    Principal = { AWS = "arn:${local.partition}:iam::${local.account_id}:root" }
    Action    = "kms:*"
    Resource  = "*"
  }

  # Credentials-key grants (only included when the role ARN is supplied).
  cred_lambda_stmt = var.lambda_exec_role_arn == null ? [] : [{
    Sid       = "LambdaEncryptDecrypt"
    Effect    = "Allow"
    Principal = { AWS = var.lambda_exec_role_arn }
    Action    = ["kms:Encrypt", "kms:Decrypt", "kms:GenerateDataKey"]
    Resource  = "*"
  }]
  cred_sfn_stmt = var.sfn_exec_role_arn == null ? [] : [{
    Sid       = "StepFunctionEncrypt"
    Effect    = "Allow"
    Principal = { AWS = var.sfn_exec_role_arn }
    Action    = ["kms:Encrypt", "kms:GenerateDataKey"]
    Resource  = "*"
  }]

  # SSH-CA-key grant (Lambda decrypt only).
  ssh_ca_lambda_stmt = var.lambda_exec_role_arn == null ? [] : [{
    Sid       = "SignLambdaDecrypt"
    Effect    = "Allow"
    Principal = { AWS = var.lambda_exec_role_arn }
    Action    = ["kms:Decrypt", "kms:GenerateDataKey"]
    Resource  = "*"
  }]
}

###############################################################################
# Credentials key — encrypts ephemeral credentials in DynamoDB (SC-28 path)
###############################################################################

resource "aws_kms_key" "credentials" {
  description             = "Encrypts ephemeral credentials in DynamoDB"
  deletion_window_in_days = var.deletion_window_in_days
  enable_key_rotation     = var.enable_key_rotation
  tags                    = var.tags

  policy = jsonencode({
    Version   = "2012-10-17"
    Statement = concat([local.root_stmt], local.cred_lambda_stmt, local.cred_sfn_stmt)
  })
}

resource "aws_kms_alias" "credentials" {
  name          = "alias/${var.name_prefix}-credentials"
  target_key_id = aws_kms_key.credentials.key_id
}

###############################################################################
# SSH-CA key — encrypts the SSH CA private key secret (ADR-0014)
###############################################################################

resource "aws_kms_key" "ssh_ca" {
  description             = "Encrypts the SSH CA private key"
  deletion_window_in_days = var.deletion_window_in_days
  enable_key_rotation     = var.enable_key_rotation
  tags                    = var.tags

  policy = jsonencode({
    Version   = "2012-10-17"
    Statement = concat([local.root_stmt], local.ssh_ca_lambda_stmt)
  })
}

resource "aws_kms_alias" "ssh_ca" {
  name          = "alias/${var.name_prefix}-ssh-ca"
  target_key_id = aws_kms_key.ssh_ca.key_id
}
