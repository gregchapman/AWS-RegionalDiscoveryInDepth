###############################################################################
# module: kms — outputs (consumed by data-score, workflow-engine, access-broker)
###############################################################################

output "credentials_key_arn" {
  description = "ARN of the ephemeral-credentials KMS key."
  value       = aws_kms_key.credentials.arn
}

output "credentials_key_id" {
  description = "Key id of the ephemeral-credentials KMS key."
  value       = aws_kms_key.credentials.key_id
}

output "credentials_key_alias" {
  description = "Alias of the credentials KMS key."
  value       = aws_kms_alias.credentials.name
}

output "ssh_ca_key_arn" {
  description = "ARN of the SSH-CA KMS key (encrypts the CA private-key secret)."
  value       = aws_kms_key.ssh_ca.arn
}

output "ssh_ca_key_alias" {
  description = "Alias of the SSH-CA KMS key."
  value       = aws_kms_alias.ssh_ca.name
}
