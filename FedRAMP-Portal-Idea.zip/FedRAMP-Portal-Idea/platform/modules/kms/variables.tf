###############################################################################
# module: kms — variables
#
# Class 1 (INVARIANT CORE). Two keys, reused verbatim from the POC (03-api
# kms.tf + the KMS portion of ssh-ca.tf) — see PROVENANCE.md.
#
# COUPLING DECISION (documented): the POC's key policies name the consuming IAM
# roles (lambda_exec, sfn_exec) as principals. We preserve that proven policy
# structure exactly, but the consuming role ARNs are INPUTS here so the kms
# module has no hidden dependency on other modules. They are OPTIONAL (default
# null) so the keys can be created before the roles exist; when null, the
# corresponding grant statement is omitted (root-account access always remains).
###############################################################################

variable "name_prefix" {
  description = "Resource/alias name prefix. Distinct from the POC ('fedramp-portal') so keys stand up alongside it (ADR-0032)."
  type        = string
  default     = "fedramp-platform"
}

variable "deletion_window_in_days" {
  description = "KMS key deletion window."
  type        = number
  default     = 14
}

variable "enable_key_rotation" {
  description = "Enable automatic annual key rotation (SC-12)."
  type        = bool
  default     = true
}

# --- Consuming role ARNs (from the workflow-engine / access-broker modules).
#     Optional: when null, that grant statement is omitted (root access remains).
variable "lambda_exec_role_arn" {
  description = "ARN of the Lambda execution role granted Encrypt/Decrypt on the credentials key and Decrypt on the SSH-CA key. Null = omit."
  type        = string
  default     = null
}

variable "sfn_exec_role_arn" {
  description = "ARN of the Step Functions execution role granted Encrypt/GenerateDataKey on the credentials key. Null = omit."
  type        = string
  default     = null
}

variable "tags" {
  description = "Tags applied to the KMS keys."
  type        = map(string)
  default = {
    Project   = "fedramp-platform"
    ManagedBy = "terraform"
    Class     = "core"
  }
}
