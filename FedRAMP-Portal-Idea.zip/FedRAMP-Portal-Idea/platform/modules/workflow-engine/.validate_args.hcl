  table_arn = "arn:aws:dynamodb:us-east-1:123456789012:table/fedramp-platform-access-requests"
