# PROVENANCE — module `workflow-engine` (THE CONDUCTOR)

**Extracted from:** the POC `terraform/03-api`:
- `state-machine/access-lifecycle.asl.json` (the ASL definition),
- `main.tf` — the `aws_sfn_state_machine.access_lifecycle` resource, its
  `aws_cloudwatch_log_group.sfn`, and the `sfn_exec` role + `sfn_app` policy,
- `lambda/provision_user/handler.py` and `lambda/cleanup_user/handler.py`.
as deployed in the running POC.

**Class:** 1 — INVARIANT CORE. This is the conductor (ADR-0023): the sole
teardown authority. There is no swap seam here — the orchestration engine IS the
gold (Passport V2). See `../../../docs/TARGET-ARCHITECTURE.md` §1a.

**REUSED verbatim (the proven, hard-won assets):**
- `lambda/provision_user/handler.py` — copied byte-for-byte. Passwordless Linux
  (ADR-0014, CA-trust install), Windows password path, attributable SSM Comment.
- `lambda/cleanup_user/handler.py` — copied byte-for-byte. THIS CARRIES:
  - **I8** — the Linux "user currently used by process" bug: lock account ->
    `loginctl terminate-user` -> pkill TERM/KILL -> `userdel -r -f` with retries,
    so the still-established SSH login session is ended BEFORE userdel (the
    two-click / session-survives bug).
  - **I10** — the Windows disconnected-session bug: resolve the account SID,
    force-logoff EVERY session bound to it (connected or Disc) via
    `query session`, unload the profile hive by SID, then delete; honest
    verification (account + dir + session + ProfileList all gone) before OK.
  - **ADR-0023** — the `verified in {OK, INCOMPLETE}` contract (never None), and
    best-effort `teardown_tunnels` that does NOT gate verification.
- The ASL state logic — copied verbatim into `access-lifecycle.asl.json.tftpl`.
  Poll-loop (ADR-0022/0023): detect end-demand via the score, bounded-retry
  verified cleanup, terminal COMPLETED or CLEANUP_FAILED (AU-6), never a silent
  success. The ADR-0023 comment removing StepFunctions StopExecution is honored.
- The `sfn_exec` role assume policy and the `sfn_app` policy statements (SSM
  RunCommand, DynamoDB UpdateItem/GetItem, scoped lambda:InvokeFunction,
  CloudWatch Logs delivery).
- The state machine logging_configuration (level ALL, include_execution_data).

**RE-AUTHORED (packaging only):**
- No provider/terraform-backend blocks.
- `file(...)` -> `templatefile(...)` for the ASL so the two invoked
  `FunctionName` values follow `var.name_prefix`. The ASL referenced the Lambdas
  by STATIC name (`fedramp-portal-provision-user` / `-cleanup-user`), so this
  substitution is REQUIRED for the renamed platform functions to be invoked.
  Nothing else in the ASL changed.
- Names via `var.name_prefix` (default `fedramp-platform`, distinct from the
  POC's `fedramp-portal-*`) so it stands up alongside the POC (ADR-0032).
- `table_arn` is an INPUT (from data-score) used only for the sfn role's
  DynamoDB grant. The table NAME reaches the ASL at runtime via the execution
  input (`$.table_name`) — the POC passes it from create_access_request — so the
  module does not hardcode it.
- `ssh_ca_public_key_param` is an INPUT (from access-broker) provision_user
  reads; default path matches the POC pattern under the platform prefix.

**DELIBERATE, FAITHFUL-IN-BEHAVIOR CHANGE (documented):**
- provision_user + cleanup_user get a DEDICATED `provisioner` role scoped to
  exactly what they call (SSM SendCommand/GetCommandInvocation +
  DescribeSessions/TerminateSession + GetParameter for the CA pubkey + Logs),
  instead of the POC's shared `lambda_exec` role that also carried DynamoDB,
  Organizations, and StepFunctions-start permissions those two handlers never
  use. Strictly tighter (AC-6); behavior unchanged. The `ssm:GetParameter` grant
  can be scoped to the CA-pubkey parameter ARN via `ssh_ca_public_key_param_arn`
  (default `*`, matching the POC's broad SSM grant).

**Validation:** `terraform validate` clean via the standalone-module harness
(archive provider present; the templatefile ASL renders and parses; the two
lambda source_dirs exist for archive_file).
