###############################################################################
# module: workflow-engine — Class 1 INVARIANT CORE (THE CONDUCTOR, ADR-0023)
#
# REUSE of the POC's Step Functions state machine (03-api/state-machine/
# access-lifecycle.asl.json), its sfn_exec role/policy (03-api/main.tf), and the
# provision_user + cleanup_user Lambdas (03-api/lambda/*, byte-for-byte) —
# PROVENANCE.md. The ASL logic is unchanged; only the two invoked FunctionName
# values are templated so they follow var.name_prefix.
#
# The conductor is the sole teardown authority: end-triggers write an end-demand
# to the score (DynamoDB); the state machine detects it, runs VERIFIED cleanup
# with bounded retries, and converges to COMPLETED or the terminal
# CLEANUP_FAILED — never a silent success (ADR-0023). This carries I8/I10.
#
# Controls: AC-2/AC-12 (ephemeral account lifecycle, verified removal), AU-6
# (CLEANUP_FAILED surfaces residuals), AU-2/AU-3 (attributable SSM commands).
###############################################################################

terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    archive = {
      source  = "hashicorp/archive"
      version = "~> 2.0"
    }
  }
}

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
data "aws_partition" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  region     = data.aws_region.current.name
  partition  = data.aws_partition.current.partition

  provision_function_name = "${var.name_prefix}-provision-user"
  cleanup_function_name   = "${var.name_prefix}-cleanup-user"

  ssm_param_grant_resource = var.ssh_ca_public_key_param_arn != null ? var.ssh_ca_public_key_param_arn : "*"
}

###############################################################################
# Provisioner Lambda execution role
#
# The POC ran provision/cleanup under the shared lambda_exec role. Here they get
# a DEDICATED, tighter role scoped to exactly what the two handlers call:
#   provision_user: ssm SendCommand / GetCommandInvocation / GetParameter (CA pubkey)
#   cleanup_user  : ssm SendCommand / GetCommandInvocation
#                   + DescribeSessions / TerminateSession (tunnel teardown)
# Faithful in behavior, stricter in privilege (AC-6). See PROVENANCE.md.
###############################################################################

resource "aws_iam_role" "provisioner" {
  name = "${var.name_prefix}-provisioner"
  tags = var.tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "provisioner_basic" {
  role       = aws_iam_role.provisioner.name
  policy_arn = "arn:${local.partition}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "provisioner_app" {
  name = "${var.name_prefix}-provisioner-app"
  role = aws_iam_role.provisioner.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "SSMRunCommandOnInstances"
        Effect = "Allow"
        Action = [
          "ssm:SendCommand",
          "ssm:GetCommandInvocation"
        ]
        Resource = "*"
      },
      {
        Sid    = "SSMTunnelTeardown"
        Effect = "Allow"
        Action = [
          "ssm:DescribeSessions",
          "ssm:TerminateSession"
        ]
        Resource = "*"
      },
      {
        Sid      = "SSMReadCAPublicKey"
        Effect   = "Allow"
        Action   = ["ssm:GetParameter"]
        Resource = local.ssm_param_grant_resource
      }
    ]
  })
}

###############################################################################
# provision_user Lambda (code reused verbatim; ADR-0014 passwordless SSH path)
###############################################################################

data "archive_file" "provision_user" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/provision_user"
  output_path = "${path.module}/.build/provision-user.zip"
}

resource "aws_lambda_function" "provision_user" {
  function_name    = local.provision_function_name
  filename         = data.archive_file.provision_user.output_path
  source_code_hash = data.archive_file.provision_user.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.provisioner.arn
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT             = var.environment
      SSH_CA_PUBLIC_KEY_PARAM = var.ssh_ca_public_key_param
    }
  }
}

###############################################################################
# cleanup_user Lambda (code reused verbatim; carries I8 Linux + I10 Windows fix)
###############################################################################

data "archive_file" "cleanup_user" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/cleanup_user"
  output_path = "${path.module}/.build/cleanup-user.zip"
}

resource "aws_lambda_function" "cleanup_user" {
  function_name    = local.cleanup_function_name
  filename         = data.archive_file.cleanup_user.output_path
  source_code_hash = data.archive_file.cleanup_user.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.provisioner.arn
  tags             = var.tags

  environment {
    variables = {
      ENVIRONMENT = var.environment
    }
  }
}

###############################################################################
# Step Functions execution role (reused verbatim from the POC sfn_exec)
###############################################################################

resource "aws_iam_role" "sfn_exec" {
  name = "${var.name_prefix}-sfn-exec"
  tags = var.tags

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "states.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy" "sfn_app" {
  name = "${var.name_prefix}-sfn-app"
  role = aws_iam_role.sfn_exec.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "SSMRunCommand"
        Effect = "Allow"
        Action = [
          "ssm:SendCommand",
          "ssm:GetCommandInvocation",
          "ssm:ListCommandInvocations"
        ]
        Resource = "*"
      },
      {
        Sid    = "DynamoDBUpdate"
        Effect = "Allow"
        Action = [
          "dynamodb:UpdateItem",
          "dynamodb:GetItem"
        ]
        Resource = var.table_arn
      },
      {
        Sid      = "LambdaInvoke"
        Effect   = "Allow"
        Action   = "lambda:InvokeFunction"
        Resource = "arn:${local.partition}:lambda:${local.region}:${local.account_id}:function:${var.name_prefix}-*"
      },
      {
        Sid    = "CloudWatchLogs"
        Effect = "Allow"
        Action = [
          "logs:CreateLogDelivery",
          "logs:GetLogDelivery",
          "logs:UpdateLogDelivery",
          "logs:DeleteLogDelivery",
          "logs:ListLogDeliveries",
          "logs:PutResourcePolicy",
          "logs:DescribeResourcePolicies",
          "logs:DescribeLogGroups"
        ]
        Resource = "*"
      }
    ]
  })
}

###############################################################################
# The conductor state machine (ASL logic verbatim; FunctionNames templated)
###############################################################################

resource "aws_cloudwatch_log_group" "sfn" {
  name              = "/aws/states/${var.name_prefix}-access-lifecycle"
  retention_in_days = var.sfn_log_retention_days
  tags              = var.tags
}

resource "aws_sfn_state_machine" "access_lifecycle" {
  name     = "${var.name_prefix}-access-lifecycle"
  role_arn = aws_iam_role.sfn_exec.arn
  tags     = var.tags

  definition = templatefile("${path.module}/state-machine/access-lifecycle.asl.json.tftpl", {
    provision_function_name = local.provision_function_name
    cleanup_function_name   = local.cleanup_function_name
  })

  logging_configuration {
    log_destination        = "${aws_cloudwatch_log_group.sfn.arn}:*"
    include_execution_data = true
    level                  = "ALL"
  }
}
