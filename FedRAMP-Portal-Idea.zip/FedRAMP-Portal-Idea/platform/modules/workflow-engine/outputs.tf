###############################################################################
# module: workflow-engine — outputs
#
# The state machine ARN is consumed by access-broker's create_access_request
# handler (STATE_MACHINE_ARN env) which does states:StartExecution.
###############################################################################

output "state_machine_arn" {
  description = "ARN of the access-lifecycle state machine (the conductor). create_access_request StartExecutions this."
  value       = aws_sfn_state_machine.access_lifecycle.arn
}

output "state_machine_name" {
  description = "Name of the access-lifecycle state machine."
  value       = aws_sfn_state_machine.access_lifecycle.name
}

output "sfn_exec_role_arn" {
  description = "ARN of the Step Functions execution role."
  value       = aws_iam_role.sfn_exec.arn
}

output "provisioner_role_arn" {
  description = "ARN of the provision/cleanup Lambda execution role."
  value       = aws_iam_role.provisioner.arn
}

output "provision_function_name" {
  description = "provision_user Lambda function name."
  value       = aws_lambda_function.provision_user.function_name
}

output "cleanup_function_name" {
  description = "cleanup_user Lambda function name."
  value       = aws_lambda_function.cleanup_user.function_name
}
