###############################################################################
# module: workflow-engine — variables
#
# Class 1 (INVARIANT CORE). THE CONDUCTOR (ADR-0023): the Step Functions state
# machine that provisions an ephemeral user, polls the score for an end demand
# or TTL expiry, then VERIFIES teardown and converges to a terminal state. This
# is where I8 (Linux "user in use" session teardown) and I10 (Windows Disc
# session hive/SID cleanup) live — in the provision/cleanup Lambda code, reused
# byte-for-byte. See PROVENANCE.md.
#
# Depends on: kms (credentials key — actually consumed by the API handlers, not
# here) and data-score (the table the ASL reads/writes). The table name arrives
# at RUNTIME in the execution input ($.table_name), so this module needs only
# the table ARN for the sfn role's IAM grant.
###############################################################################

variable "name_prefix" {
  description = "Name prefix. Distinct from the POC ('fedramp-portal') so it stands up alongside (ADR-0032)."
  type        = string
  default     = "fedramp-platform"
}

# --- from data-score ---
variable "table_arn" {
  description = "ARN of the access-request DynamoDB table (for the sfn role's UpdateItem/GetItem grant)."
  type        = string
}

# --- from access-broker (the SSH-CA public-key SSM parameter provision_user reads) ---
variable "ssh_ca_public_key_param" {
  description = "SSM parameter NAME holding the SSH CA public key (provision_user fetches it to install TrustedUserCAKeys). Default matches the POC path."
  type        = string
  default     = "/fedramp-platform/ssh-ca-public-key"
}

variable "ssh_ca_public_key_param_arn" {
  description = "ARN of the SSH-CA public-key SSM parameter, for a scoped ssm:GetParameter grant. Null = grant on '*' (matches the POC's broad SSM grant)."
  type        = string
  default     = null
}

# --- Lambda packaging (provision_user / cleanup_user) ---
variable "lambda_runtime" {
  type    = string
  default = "python3.12"
}

variable "lambda_timeout" {
  description = "Timeout (s) for provision/cleanup. POC used 90 (they poll SSM command completion)."
  type        = number
  default     = 90
}

variable "lambda_memory" {
  type    = number
  default = 128
}

variable "environment" {
  type    = string
  default = "platform"
}

# --- Step Functions logging ---
variable "sfn_log_retention_days" {
  type    = number
  default = 90
}

variable "tags" {
  type = map(string)
  default = {
    Project   = "fedramp-platform"
    ManagedBy = "terraform"
    Class     = "core"
  }
}
