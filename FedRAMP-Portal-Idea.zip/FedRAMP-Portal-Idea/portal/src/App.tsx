import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './auth/AuthContext';
import { SessionsProvider } from './api/SessionsContext';
import { setTokenProvider } from './api/client';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import RackerDashboard from './pages/RackerDashboard';
import CustomerDashboard from './pages/CustomerDashboard';
import CallbackPage from './pages/CallbackPage';
import { useEffect, type ReactNode } from 'react';

function TokenSetup() {
  const { getAccessToken } = useAuth();
  useEffect(() => {
    setTokenProvider(getAccessToken);
  }, [getAccessToken]);
  return null;
}

function ProtectedRoute({ children, requireRacker = false }: { children: ReactNode; requireRacker?: boolean }) {
  const { isAuthenticated, isLoading, user } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-pulse text-navy-200">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (requireRacker && !user?.isRacker) {
    return <Navigate to="/customer" replace />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  const { isAuthenticated, user } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/callback" element={<CallbackPage />} />

      <Route
        path="/racker"
        element={
          <ProtectedRoute requireRacker>
            <Layout>
              <RackerDashboard />
            </Layout>
          </ProtectedRoute>
        }
      />

      <Route
        path="/customer"
        element={
          <ProtectedRoute>
            <Layout>
              <CustomerDashboard />
            </Layout>
          </ProtectedRoute>
        }
      />

      {/* Default redirect based on role */}
      <Route
        path="/"
        element={
          isAuthenticated ? (
            <Navigate to={user?.isRacker ? '/racker' : '/customer'} replace />
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <TokenSetup />
      <SessionsProvider>
        <AppRoutes />
      </SessionsProvider>
    </AuthProvider>
  );
}
