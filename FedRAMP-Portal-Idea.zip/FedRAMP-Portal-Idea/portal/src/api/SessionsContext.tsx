import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { api } from './client';
import type { SessionStatus, SessionsResponse } from './types';
import { useAuth } from '../auth/AuthContext';

interface SessionsContextType {
  /** Map of instance_id -> active SessionStatus */
  activeSessions: Record<string, SessionStatus>;
  /** Reload active sessions from the backend */
  refresh: () => Promise<void>;
  /** Register a newly created session locally (avoids a round-trip) */
  addSession: (session: SessionStatus) => void;
  /**
   * Optimistically mark a session as ending after the user submits the end
   * demand, so the row flips to "Ending…" instantly. Takes instance_id (map
   * key) + request_id (to only touch the SAME session, not a new one that
   * reused the instance). Returns the reconcile promise. The backend/conductor
   * remains the source of truth (ADR-0023) — this is just instant feedback.
   */
  markEnding: (instanceId: string, requestId: string) => Promise<void>;
  loading: boolean;
}

const SessionsContext = createContext<SessionsContextType | undefined>(undefined);

export function SessionsProvider({ children }: { children: ReactNode }) {
  const { isAuthenticated } = useAuth();
  const [activeSessions, setActiveSessions] = useState<Record<string, SessionStatus>>({});
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!isAuthenticated) {
      setActiveSessions({});
      setLoading(false);
      return;
    }
    setLoading(true);
    const res = await api.get<SessionsResponse>('/api/sessions');
    if (res.data) {
      // ADR-0023: DynamoDB (via list_sessions) is the source of truth and the
      // conductor converges every session to a terminal state fast (~10s poll).
      // list_sessions returns only VISIBLE states (live + ending) — terminal
      // states are already excluded server-side. So we simply reflect what the
      // backend reports: whatever is here is either connectable (ACTIVE) or
      // ending (END_REQUESTED / CLEANING_UP). No client-side suppression games
      // are needed anymore (that complexity existed only to paper over the old
      // race, now fixed at the source). Readers reflect the truth.
      const map: Record<string, SessionStatus> = {};
      for (const s of res.data.sessions) {
        map[s.instance_id] = s;
      }
      setActiveSessions(map);
    }
    setLoading(false);
  }, [isAuthenticated]);

  useEffect(() => {
    refresh();

    // Adaptive poll so the UI reflects the backend (the source of truth)
    // without feeling stale. Poll fast (3s) whenever anything is in a
    // TRANSITIONAL or ENDING state (PENDING/PROVISIONING/END_REQUESTED/
    // CLEANING_UP) so the "Ending…" pill clears within a few seconds of the
    // conductor finalizing; slow (15s) at rest.
    let interval: ReturnType<typeof setInterval>;
    const inFlight = Object.values(activeSessions).some((s) =>
      ['PENDING', 'PROVISIONING', 'END_REQUESTED', 'CLEANING_UP'].includes(s.status),
    );
    interval = setInterval(refresh, inFlight ? 3000 : 15000);

    // Refresh when the tab regains focus (user comes back to the portal)
    const onVisible = () => {
      if (document.visibilityState === 'visible') refresh();
    };
    document.addEventListener('visibilitychange', onVisible);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [refresh, activeSessions]);

  // Client-side TTL expiry: drop sessions whose countdown has hit zero,
  // even before the next backend poll confirms cleanup.
  useEffect(() => {
    const ttlCheck = setInterval(() => {
      setActiveSessions((prev) => {
        const now = Date.now();
        let changed = false;
        const next: Record<string, SessionStatus> = {};
        for (const [instanceId, session] of Object.entries(prev)) {
          const expiresAt = session.connection?.expires_at
            ? parseInt(session.connection.expires_at, 10) * 1000
            : 0;
          if (expiresAt && now >= expiresAt) {
            changed = true; // expired — drop it
          } else {
            next[instanceId] = session;
          }
        }
        return changed ? next : prev;
      });
    }, 5000);
    return () => clearInterval(ttlCheck);
  }, []);

  function addSession(session: SessionStatus) {
    setActiveSessions((prev) => ({ ...prev, [session.instance_id]: session }));
  }

  async function markEnding(instanceId: string, requestId: string): Promise<void> {
    // Optimistic: flip the row to END_REQUESTED so it immediately shows
    // "Ending…" (and is no longer connectable/re-endable). Only touch the same
    // session (guard against a new session that reused the instance slot). The
    // backend is authoritative; the next refresh reconciles to CLEANING_UP ->
    // (gone) as the conductor finalizes.
    setActiveSessions((prev) => {
      const cur = prev[instanceId];
      if (!cur || cur.request_id !== requestId) return prev;
      return { ...prev, [instanceId]: { ...cur, status: 'END_REQUESTED' } };
    });
    await refresh();
  }

  return (
    <SessionsContext.Provider
      value={{ activeSessions, refresh, addSession, markEnding, loading }}
    >
      {children}
    </SessionsContext.Provider>
  );
}

export function useSessions() {
  const ctx = useContext(SessionsContext);
  if (!ctx) {
    throw new Error('useSessions must be used within a SessionsProvider');
  }
  return ctx;
}
