/**
 * Client-side ed25519 SSH keypair generation + OpenSSH serialization.
 *
 * Used by the cert-based connect flow (ADR-0014): generate a keypair in the
 * browser, send the OpenSSH-format public key to /api/sign, receive a signed
 * certificate, and hand the user the private key + cert to connect.
 *
 * NOTE: This is the interim browser-based flow. The production-grade path is
 * the Passport CLI (ADR-0012), which handles keygen/sign/connect natively.
 * Browsers can generate Ed25519 via Web Crypto (modern browsers), but OpenSSH
 * wire-format encoding must be done by hand — that's what this module does.
 */

// --- OpenSSH wire-format primitives ---

function encodeUint32(n: number): Uint8Array {
  const b = new Uint8Array(4);
  new DataView(b.buffer).setUint32(0, n, false); // big-endian
  return b;
}

/** Length-prefixed byte string per RFC 4251 (string = uint32 len || bytes). */
function encodeString(bytes: Uint8Array): Uint8Array {
  const len = encodeUint32(bytes.length);
  const out = new Uint8Array(len.length + bytes.length);
  out.set(len, 0);
  out.set(bytes, len.length);
  return out;
}

function concat(...arrs: Uint8Array[]): Uint8Array {
  const total = arrs.reduce((s, a) => s + a.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const a of arrs) {
    out.set(a, off);
    off += a.length;
  }
  return out;
}

function toBase64(bytes: Uint8Array): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

const textEnc = new TextEncoder();

export interface GeneratedKey {
  /** OpenSSH-format public key line: "ssh-ed25519 AAAA... comment" */
  publicKeyOpenSSH: string;
  /** OpenSSH-format private key (PEM-like "-----BEGIN OPENSSH PRIVATE KEY-----"). */
  privateKeyOpenSSH: string;
}

/**
 * Generate an ed25519 keypair and return both in OpenSSH format.
 * Requires a browser with Web Crypto Ed25519 support (Chrome/Edge 137+,
 * Safari 17+, Firefox with flag). Falls back to throwing a clear error.
 */
export async function generateEd25519OpenSSH(comment = 'passport'): Promise<GeneratedKey> {
  let keyPair: CryptoKeyPair;
  try {
    keyPair = (await crypto.subtle.generateKey(
      { name: 'Ed25519' } as unknown as AlgorithmIdentifier,
      true,
      ['sign', 'verify']
    )) as CryptoKeyPair;
  } catch {
    throw new Error(
      'Your browser does not support in-browser Ed25519 key generation. ' +
        'Use the Passport CLI, or generate a key with ssh-keygen and use the manual flow.'
    );
  }

  // Export raw public key (32 bytes) and PKCS8 private key.
  const rawPub = new Uint8Array(await crypto.subtle.exportKey('raw', keyPair.publicKey));
  const pkcs8 = new Uint8Array(await crypto.subtle.exportKey('pkcs8', keyPair.privateKey));
  // The ed25519 32-byte seed is the last 32 bytes of the PKCS8 structure.
  const seed = pkcs8.slice(pkcs8.length - 32);

  const keyTypeBytes = textEnc.encode('ssh-ed25519');
  const commentBytes = textEnc.encode(comment);

  // --- Public key blob ---
  const pubBlob = concat(encodeString(keyTypeBytes), encodeString(rawPub));
  const publicKeyOpenSSH = `ssh-ed25519 ${toBase64(pubBlob)} ${comment}`;

  // --- Private key (OpenSSH format, unencrypted) ---
  // https://coolaj86.com/articles/the-openssh-private-key-format/
  const AUTH_MAGIC = textEnc.encode('openssh-key-v1\0');
  const none = textEnc.encode('none');
  const empty = new Uint8Array(0);

  // 64-byte private scalar for OpenSSH = seed(32) || pubkey(32)
  const privConcat = concat(seed, rawPub);

  const checkint = crypto.getRandomValues(new Uint8Array(4));
  const privateSection = concat(
    checkint,
    checkint,
    encodeString(keyTypeBytes),
    encodeString(rawPub),
    encodeString(privConcat),
    encodeString(commentBytes)
  );
  // Pad to block size 8
  const padded = (() => {
    const blockSize = 8;
    const padLen = (blockSize - (privateSection.length % blockSize)) % blockSize;
    const pad = new Uint8Array(padLen);
    for (let i = 0; i < padLen; i++) pad[i] = i + 1;
    return concat(privateSection, pad);
  })();

  const body = concat(
    AUTH_MAGIC,
    encodeString(none),      // ciphername
    encodeString(none),      // kdfname
    encodeString(empty),     // kdfoptions
    encodeUint32(1),         // number of keys
    encodeString(pubBlob),   // public key
    encodeString(padded)     // private section
  );

  const b64 = toBase64(body).replace(/(.{70})/g, '$1\n');
  const privateKeyOpenSSH =
    '-----BEGIN OPENSSH PRIVATE KEY-----\n' + b64 + '\n-----END OPENSSH PRIVATE KEY-----\n';

  return { publicKeyOpenSSH, privateKeyOpenSSH };
}
