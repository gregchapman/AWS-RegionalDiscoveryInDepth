/** API response types matching the Lambda return shapes */

export interface Account {
  id: string;
  name: string;
  region?: string;
  email?: string;
  status: string;
}

export interface AccountsResponse {
  accounts: Account[];
  mode: 'simulated' | 'live';
  count: number;
}

export interface Instance {
  instance_id: string;
  name: string;
  ping_status: string;
  platform_type: string;
  platform_name: string;
  platform_version: string;
  agent_version: string;
  last_ping: string;
  region: string;
  customer: string;
  customer_access: string;
  state: string;
  instance_type: string;
  private_ip: string;
}

export interface InstancesResponse {
  instances: Instance[];
  count: number;
  regions_queried: string[];
}

export interface ConnectRequest {
  instance_id: string;
  region: string;
  access_type: 'ssh' | 'rdp';
  ttl_minutes?: number;
}

export interface ConnectResponse {
  request_id: string;
  status: string;
  message: string;
  ttl_minutes: number;
  poll_url: string;
}

export interface ConnectionDetails {
  username: string;
  auth_method: string;
  temporary_password: string;
  port_forward_command: string;
  port_local: string;
  port_remote: string;
  expires_at: string;
}

export interface SessionStatus {
  request_id: string;
  status:
    | 'PENDING'
    | 'PROVISIONING'
    | 'ACTIVE'
    | 'END_REQUESTED'
    | 'CLEANING_UP'
    | 'COMPLETED'
    | 'CLEANUP_FAILED'
    | 'FAILED';
  instance_id: string;
  region: string;
  access_type: string;
  created_at: string;
  ttl_minutes: number;
  user_email: string;
  connection?: ConnectionDetails;
  error_detail?: string;
}

export interface SessionsResponse {
  sessions: SessionStatus[];
  count: number;
  scope?: 'self' | 'all';
  customer_id?: string;
}

/**
 * Operator view of ANOTHER user's live session (ADR-0025, GET
 * /api/sessions?scope=all — Rackers only). Deliberately carries WHO holds the
 * access and WHICH tenant it targets, plus end-attribution — but NO session
 * secret (no connection block / password): an operator sees who has access to
 * what, not the credentials (least privilege).
 */
export interface OperatorSession {
  request_id: string;
  status:
    | 'PENDING'
    | 'PROVISIONING'
    | 'ACTIVE'
    | 'END_REQUESTED'
    | 'CLEANING_UP';
  instance_id: string;
  region: string;
  access_type: string;
  created_at: string;
  ttl_minutes: number;
  user_email: string;
  user_id: string;
  customer_id: string;
  provisioned_username: string;
  ended_by: string;
  end_source: string;
  end_reason: string;
}

export interface OperatorSessionsResponse {
  sessions: OperatorSession[];
  count: number;
  scope: 'all';
  customer_id: string;
}

export interface SignResponse {
  certificate: string;   // OpenSSH user certificate
  key_id: string;        // passport_<username>_<epoch>
  username: string;
  valid_before: number;
  valid_seconds: number;
}
