import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { getCurrentUser, signOut, signInWithRedirect, fetchAuthSession } from 'aws-amplify/auth';
import { Hub } from 'aws-amplify/utils';

interface User {
  userId: string;
  email: string;
  groups: string[];
  isRacker: boolean;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: () => void;
  logout: () => Promise<void>;
  getAccessToken: () => Promise<string | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkAuth();

    // Listen for auth events (e.g., after OAuth redirect)
    const unsubscribe = Hub.listen('auth', ({ payload }) => {
      if (payload.event === 'signInWithRedirect') {
        checkAuth();
      }
      if (payload.event === 'signInWithRedirect_failure') {
        setIsLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  async function checkAuth() {
    try {
      const currentUser = await getCurrentUser();
      const session = await fetchAuthSession();
      const idToken = session.tokens?.idToken;

      const groups = (idToken?.payload?.['cognito:groups'] as string[]) || [];
      const email = (idToken?.payload?.email as string) || '';

      setUser({
        userId: currentUser.userId,
        email,
        groups,
        isRacker: groups.includes('Rackers'),
      });
    } catch {
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }

  function login() {
    // Use Amplify's built-in OAuth redirect (handles code exchange automatically)
    signInWithRedirect();
  }

  async function logout() {
    await signOut();
    setUser(null);
  }

  async function getAccessToken(): Promise<string | null> {
    try {
      const session = await fetchAuthSession();
      // Use ID token (contains cognito:groups claim) rather than access token
      return session.tokens?.idToken?.toString() || null;
    } catch {
      return null;
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        logout,
        getAccessToken,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}


