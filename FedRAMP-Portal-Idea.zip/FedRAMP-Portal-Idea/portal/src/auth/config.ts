import type { ResourcesConfig } from 'aws-amplify';

/**
 * Amplify configuration for Cognito auth.
 *
 * In production, these values come from environment variables populated
 * at build time (Vite injects import.meta.env.VITE_*).
 *
 * For local development, create a .env.local file in portal/ with:
 *   VITE_COGNITO_USER_POOL_ID=us-east-1_XXXXXX
 *   VITE_COGNITO_CLIENT_ID=xxxxxxxxxxxxxxxxxxxxxxxxxx
 *   VITE_COGNITO_DOMAIN=fedramp-portal-XXXXXXXXXXXX
 *   VITE_API_URL=https://xxxxxxxxxx.execute-api.us-east-1.amazonaws.com
 */

const userPoolId = import.meta.env.VITE_COGNITO_USER_POOL_ID || 'us-east-1_PLACEHOLDER';
const userPoolClientId = import.meta.env.VITE_COGNITO_CLIENT_ID || 'PLACEHOLDER';
const cognitoDomain = import.meta.env.VITE_COGNITO_DOMAIN || 'fedramp-portal-placeholder';
const region = userPoolId.split('_')[0] || 'us-east-1';

export const amplifyConfig: ResourcesConfig = {
  Auth: {
    Cognito: {
      userPoolId,
      userPoolClientId,
      loginWith: {
        oauth: {
          domain: `${cognitoDomain}.auth.${region}.amazoncognito.com`,
          scopes: ['openid', 'email', 'profile'],
          redirectSignIn: [window.location.origin + '/callback'],
          redirectSignOut: [window.location.origin],
          responseType: 'code',
        },
      },
    },
  },
};

/**
 * API base URL.
 *
 * SAME-ORIGIN (ADR-0019): in a deployed build the SPA and the API share one
 * host (portal.<domain>) behind a single API Gateway. VITE_API_URL is set to
 * an empty string at build time, so requests go to a RELATIVE path
 * (e.g. `/api/sessions`) on the SPA's own origin — no CORS, no cross-origin.
 *
 * We must distinguish "defined but empty" (deployed same-origin -> relative)
 * from "undefined" (local `vite dev` with no .env.local -> talk to a local
 * dev API). `??` (not `||`) preserves an intentional empty string.
 */
export const apiUrl = import.meta.env.VITE_API_URL ?? 'http://localhost:3001';
