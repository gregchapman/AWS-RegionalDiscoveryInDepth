import { useState } from 'react';
import { useSessions } from '../api/SessionsContext';
import type { Instance, SessionStatus } from '../api/types';
import SessionDrawer from './SessionDrawer';

interface ConnectButtonProps {
  instance: Instance;
}

export default function ConnectButton({ instance }: ConnectButtonProps) {
  const { activeSessions, markEnding } = useSessions();
  // The drawer is either an INSTRUCTIONS drawer (Connect clicked, no session yet
  // — ADR-0025: the portal provisions NOTHING; it hands off the passport
  // command) or the LIVE session drawer (a real CLI-created session exists).
  const [drawerOpen, setDrawerOpen] = useState(false);

  const accessType = instance.platform_type === 'Windows' ? 'rdp' : 'ssh';
  const isOnline = instance.ping_status === 'Online';

  // The session for this instance, exactly as the backend reports it (ADR-0023:
  // readers reflect the truth). list_sessions returns only visible states
  // (live + ending); terminal states are excluded server-side.
  const activeSession: SessionStatus | undefined = activeSessions[instance.instance_id];

  // Three display buckets:
  //  - ACTIVE                         -> connectable ("View Session").
  //  - PENDING/PROVISIONING           -> "Provisioning…" (non-actionable).
  //  - END_REQUESTED/CLEANING_UP      -> "Ending…" (non-actionable). You cannot
  //    "end" a session that is already ending — this makes the old two-click
  //    impossible by construction.
  const isSessionActive = activeSession?.status === 'ACTIVE';
  const isSessionProvisioning =
    activeSession?.status === 'PENDING' || activeSession?.status === 'PROVISIONING';
  const isSessionEnding =
    activeSession?.status === 'END_REQUESTED' || activeSession?.status === 'CLEANING_UP';

  // ADR-0025 §1: clicking Connect provisions NOTHING. It opens the instructions
  // drawer with the one-time install + `passport connect` command. The security
  // event (and the single authoritative session record) only begins when the
  // user actually runs the CLI, which authenticates (MFA) and creates the
  // session. So there is no /api/connect call here, no polling, no phantom
  // record, and no ephemeral user until real access happens.
  function openInstructions() {
    if (!isOnline) return;
    setDrawerOpen(true);
  }

  return (
    <>
      <div className="space-y-1">
        {isSessionActive ? (
          <button
            onClick={() => setDrawerOpen(true)}
            className="inline-flex items-center text-xs bg-green-900/50 text-green-300 px-2 py-1 rounded hover:bg-green-900/70 transition-colors"
            aria-label={`View session for ${instance.name}`}
          >
            <span className="w-1.5 h-1.5 bg-green-400 rounded-full mr-1.5 animate-pulse" />
            Active — View Session
          </button>
        ) : isSessionProvisioning ? (
          <span
            className="inline-flex items-center text-xs bg-amber-900/40 text-amber-300 px-2 py-1 rounded"
            aria-label={`Session provisioning for ${instance.name}`}
          >
            <span className="animate-spin w-3 h-3 border border-amber-300 border-t-transparent rounded-full mr-1.5" />
            Provisioning...
          </span>
        ) : isSessionEnding ? (
          <span
            className="inline-flex items-center text-xs bg-orange-900/40 text-orange-300 px-2 py-1 rounded"
            aria-label={`Session ending for ${instance.name}`}
          >
            <span className="animate-spin w-3 h-3 border border-orange-300 border-t-transparent rounded-full mr-1.5" />
            Ending...
          </span>
        ) : (
          <button
            onClick={openInstructions}
            disabled={!isOnline}
            className="btn-primary text-xs py-1 px-3"
            aria-label={`Connect to ${instance.name} via ${accessType.toUpperCase()}`}
          >
            {`Connect (${accessType.toUpperCase()})`}
          </button>
        )}
      </div>

      {/* Drawer. Two modes (ADR-0025):
          - LIVE: a real CLI-created session exists -> show it (countdown + End).
          - INSTRUCTIONS: Connect clicked, no session yet -> show the install +
            passport connect command only (no countdown, no End — nothing exists
            to end). Built from the Instance, not a session record. */}
      {drawerOpen && isSessionActive && activeSession ? (
        <SessionDrawer
          session={activeSession}
          onClose={() => setDrawerOpen(false)}
          onTerminated={async () => {
            await markEnding(instance.instance_id, activeSession.request_id);
          }}
        />
      ) : drawerOpen ? (
        <SessionDrawer
          instructionsFor={{
            instance_id: instance.instance_id,
            region: instance.region,
            access_type: accessType,
          }}
          onClose={() => setDrawerOpen(false)}
        />
      ) : null}
    </>
  );
}
