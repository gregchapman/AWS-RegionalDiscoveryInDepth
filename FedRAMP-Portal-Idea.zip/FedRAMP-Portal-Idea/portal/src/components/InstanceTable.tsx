import { useState } from 'react';
import type { Instance } from '../api/types';
import ConnectButton from './ConnectButton';

interface InstanceTableProps {
  instances: Instance[];
  loading: boolean;
}

export default function InstanceTable({ instances, loading }: InstanceTableProps) {
  const [filter, setFilter] = useState('');

  const filtered = instances.filter(
    (i) =>
      i.name.toLowerCase().includes(filter.toLowerCase()) ||
      i.instance_id.toLowerCase().includes(filter.toLowerCase()) ||
      i.platform_name.toLowerCase().includes(filter.toLowerCase()) ||
      i.region.toLowerCase().includes(filter.toLowerCase())
  );

  if (loading) {
    return (
      <div className="card">
        <div className="animate-pulse space-y-3">
          <div className="h-4 bg-navy-400 rounded w-1/3" />
          <div className="h-4 bg-navy-400 rounded w-full" />
          <div className="h-4 bg-navy-400 rounded w-full" />
          <div className="h-4 bg-navy-400 rounded w-2/3" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Search/filter */}
      <input
        type="text"
        placeholder="Filter instances by name, ID, platform, or region..."
        value={filter}
        onChange={(e) => setFilter(e.target.value)}
        className="input-field"
        aria-label="Filter instances"
      />

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full" role="table">
          <thead>
            <tr className="text-left text-sm text-navy-200 border-b border-navy-400">
              <th className="pb-3 pr-4">Name</th>
              <th className="pb-3 pr-4">Instance ID</th>
              <th className="pb-3 pr-4">Platform</th>
              <th className="pb-3 pr-4">Region</th>
              <th className="pb-3 pr-4">Status</th>
              <th className="pb-3">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-navy-600">
            {filtered.map((instance) => (
              <tr key={instance.instance_id} className="hover:bg-navy-600/50">
                <td className="py-3 pr-4">
                  <span className="font-medium text-white">{instance.name}</span>
                </td>
                <td className="py-3 pr-4 text-sm text-navy-200 font-mono">
                  {instance.instance_id}
                </td>
                <td className="py-3 pr-4 text-sm">
                  <span className={`inline-flex items-center ${
                    instance.platform_type === 'Windows' ? 'text-blue-300' : 'text-green-300'
                  }`}>
                    {instance.platform_type === 'Windows' ? '⊞' : '⬡'}{' '}
                    {instance.platform_name}
                  </span>
                </td>
                <td className="py-3 pr-4 text-sm text-navy-200">
                  {instance.region}
                </td>
                <td className="py-3 pr-4">
                  <PingBadge status={instance.ping_status} />
                </td>
                <td className="py-3">
                  <ConnectButton instance={instance} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filtered.length === 0 && (
          <p className="text-center text-navy-300 py-8">
            {instances.length === 0 ? 'No instances found.' : 'No instances match your filter.'}
          </p>
        )}
      </div>

      <p className="text-xs text-navy-300">
        Showing {filtered.length} of {instances.length} instances
      </p>
    </div>
  );
}

function PingBadge({ status }: { status: string }) {
  const isOnline = status === 'Online';
  return (
    <span
      className={`inline-flex items-center text-xs px-2 py-0.5 rounded ${
        isOnline
          ? 'bg-green-900/50 text-green-300'
          : 'bg-red-900/50 text-red-300'
      }`}
    >
      <span className={`w-1.5 h-1.5 rounded-full mr-1 ${isOnline ? 'bg-green-400' : 'bg-red-400'}`} />
      {status}
    </span>
  );
}
