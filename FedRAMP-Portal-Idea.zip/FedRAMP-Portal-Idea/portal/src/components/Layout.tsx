import { type ReactNode } from 'react';
import { useAuth } from '../auth/AuthContext';

export default function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-navy-700 border-b border-navy-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo / Brand */}
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-accent rounded flex items-center justify-center">
                <span className="text-white font-bold text-sm">R</span>
              </div>
              <div>
                <h1 className="text-lg font-semibold text-white">
                  RGS Access Portal
                </h1>
                <p className="text-xs text-navy-200">FedRAMP Zero-Trust</p>
              </div>
            </div>

            {/* User info + logout */}
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-white">{user?.email}</p>
                <p className="text-xs text-navy-200">
                  {user?.isRacker ? 'Racker' : 'Customer'}
                </p>
              </div>
              <button
                onClick={logout}
                className="btn-secondary text-sm"
                aria-label="Sign out"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-navy-700 border-t border-navy-400 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-xs text-navy-300">
            Rackspace Government Solutions &middot; FedRAMP Authorized &middot; IL4
          </p>
        </div>
      </footer>
    </div>
  );
}
