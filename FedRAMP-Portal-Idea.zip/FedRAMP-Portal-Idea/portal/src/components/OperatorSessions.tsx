import { useCallback, useEffect, useState } from 'react';
import { api } from '../api/client';
import type { OperatorSession, OperatorSessionsResponse } from '../api/types';

/**
 * Operator session console (ADR-0025 / ADR-0024).
 *
 * A Racker's cross-user view of every LIVE/ENDING session, so an operator can
 * SEE and revoke another user's access (e.g. a customer ticket: "end
 * Customer1 / Joe"). Backed by GET /api/sessions?scope=all (Rackers only,
 * fail-closed server-side; tenant-scopable via customer_id).
 *
 * Ending someone else's session is a privileged, on-behalf-of action, so the
 * End button here REQUIRES a reason (ticket #) — enforced by a dialog that
 * cannot submit empty, and backed fail-closed by the server. The reason is
 * recorded on the session and in the audit log.
 */
export default function OperatorSessions() {
  const [sessions, setSessions] = useState<OperatorSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [customerFilter, setCustomerFilter] = useState('');

  // Reason dialog state (per-session revoke).
  const [revokeTarget, setRevokeTarget] = useState<OperatorSession | null>(null);
  const [reason, setReason] = useState('');
  const [revoking, setRevoking] = useState(false);
  const [revokeError, setRevokeError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const qs = customerFilter.trim()
      ? `?scope=all&customer_id=${encodeURIComponent(customerFilter.trim())}`
      : '?scope=all';
    const res = await api.get<OperatorSessionsResponse>(`/api/sessions${qs}`);
    if (res.data) {
      setSessions(res.data.sessions);
      setError(null);
    } else if (res.error) {
      setError(res.error);
    }
    setLoading(false);
  }, [customerFilter]);

  useEffect(() => {
    load();
    // Poll so the operator view reflects teardown in near-real-time.
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, [load]);

  function openRevoke(s: OperatorSession) {
    setRevokeTarget(s);
    setReason('');
    setRevokeError(null);
  }

  async function submitRevoke() {
    if (!revokeTarget) return;
    const trimmed = reason.trim();
    if (!trimmed) {
      setRevokeError('A reason (e.g. customer ticket number) is required.');
      return;
    }
    setRevoking(true);
    setRevokeError(null);
    // Operator revoke: attributed as operator:portal WITH the mandatory reason
    // (ADR-0024). The server independently enforces the reason fail-closed.
    const res = await api.post(`/api/session/${revokeTarget.request_id}/terminate`, {
      reason: trimmed,
      source: 'operator:portal',
    });
    setRevoking(false);
    if (res.error) {
      setRevokeError(res.error);
      return;
    }
    setRevokeTarget(null);
    setReason('');
    load(); // reflect END_REQUESTED immediately
  }

  const isEnding = (s: OperatorSession) =>
    s.status === 'END_REQUESTED' || s.status === 'CLEANING_UP';

  return (
    <section aria-labelledby="operator-sessions-heading">
      <div className="flex items-center justify-between mb-3">
        <h3 id="operator-sessions-heading" className="text-lg font-semibold text-white">
          Active Sessions (All Users)
        </h3>
        <div className="flex items-center gap-2">
          <input
            value={customerFilter}
            onChange={(e) => setCustomerFilter(e.target.value)}
            placeholder="Filter by customer_id"
            className="text-xs bg-navy-800 border border-navy-400 text-white px-2 py-1 rounded"
            aria-label="Filter sessions by customer_id"
          />
          <button
            onClick={load}
            className="text-xs bg-navy-600 hover:bg-navy-500 text-white px-2 py-1 rounded"
          >
            Refresh
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded mb-3">
          {error}
        </div>
      )}

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-navy-200 text-xs uppercase tracking-wide border-b border-navy-400">
              <th className="text-left py-2 px-2">User</th>
              <th className="text-left py-2 px-2">Customer</th>
              <th className="text-left py-2 px-2">Instance</th>
              <th className="text-left py-2 px-2">Region</th>
              <th className="text-left py-2 px-2">Type</th>
              <th className="text-left py-2 px-2">OS User</th>
              <th className="text-left py-2 px-2">Started</th>
              <th className="text-left py-2 px-2">Status</th>
              <th className="text-right py-2 px-2">Action</th>
            </tr>
          </thead>
          <tbody>
            {sessions.map((s) => (
              <tr key={s.request_id} className="border-b border-navy-600/50">
                <td className="py-2 px-2 text-white">{s.user_email || s.user_id}</td>
                <td className="py-2 px-2 text-navy-100 font-mono">{s.customer_id || '—'}</td>
                <td className="py-2 px-2 text-navy-100 font-mono">{s.instance_id}</td>
                <td className="py-2 px-2 text-navy-200">{s.region}</td>
                <td className="py-2 px-2 text-navy-200">{s.access_type.toUpperCase()}</td>
                <td className="py-2 px-2 text-navy-200 font-mono">{s.provisioned_username}</td>
                <td className="py-2 px-2 text-navy-300">
                  {s.created_at ? new Date(s.created_at).toLocaleString() : '—'}
                </td>
                <td className="py-2 px-2">
                  <StatusPill status={s.status} />
                </td>
                <td className="py-2 px-2 text-right">
                  {isEnding(s) ? (
                    <span className="text-xs text-orange-300">Ending…</span>
                  ) : (
                    <button
                      onClick={() => openRevoke(s)}
                      className="text-xs bg-accent hover:bg-accent-600 text-white px-2 py-1 rounded"
                      aria-label={`End ${s.user_email}'s session on ${s.instance_id}`}
                    >
                      End Session
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {sessions.length === 0 && !loading && (
              <tr>
                <td colSpan={9} className="py-4 px-2 text-center text-navy-300">
                  No active sessions{customerFilter.trim() ? ` for ${customerFilter.trim()}` : ''}.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Reason dialog — operator revoke REQUIRES a justification (ADR-0024). */}
      {revokeTarget && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-navy-700 border border-navy-400 rounded-lg shadow-2xl w-full max-w-md p-5">
            <h4 className="text-white font-semibold mb-2">End another user's session</h4>
            <p className="text-xs text-navy-200 mb-3">
              You are ending{' '}
              <span className="text-white">{revokeTarget.user_email || revokeTarget.user_id}</span>'s{' '}
              {revokeTarget.access_type.toUpperCase()} session on{' '}
              <span className="font-mono">{revokeTarget.instance_id}</span>
              {revokeTarget.customer_id ? (
                <> (customer <span className="font-mono">{revokeTarget.customer_id}</span>)</>
              ) : null}
              . This is recorded against you in the audit trail.
            </p>
            <label className="block text-xs text-navy-200 mb-1" htmlFor="revoke-reason">
              Reason (customer ticket # or justification) — required
            </label>
            <textarea
              id="revoke-reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
              className="w-full bg-navy-800 border border-navy-400 text-white text-sm px-2 py-1 rounded mb-2"
              placeholder="e.g. INC0012345 — customer requested access revocation for Joe"
              autoFocus
            />
            {revokeError && (
              <p className="text-xs text-red-400 mb-2">{revokeError}</p>
            )}
            <div className="flex justify-end gap-2 mt-2">
              <button
                onClick={() => setRevokeTarget(null)}
                disabled={revoking}
                className="text-sm px-3 py-1 rounded bg-navy-600 text-navy-100 hover:text-white disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={submitRevoke}
                disabled={revoking || !reason.trim()}
                className="text-sm px-3 py-1 rounded bg-accent text-white hover:bg-accent-600 disabled:opacity-50"
              >
                {revoking ? 'Ending…' : 'End Session'}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function StatusPill({ status }: { status: string }) {
  const styles: Record<string, string> = {
    ACTIVE: 'bg-green-900/50 text-green-300',
    PENDING: 'bg-yellow-900/50 text-yellow-300',
    PROVISIONING: 'bg-blue-900/50 text-blue-300',
    END_REQUESTED: 'bg-orange-900/50 text-orange-300',
    CLEANING_UP: 'bg-orange-900/50 text-orange-300',
  };
  return (
    <span className={`inline-flex items-center text-xs px-2 py-1 rounded font-medium ${styles[status] || 'bg-navy-400 text-navy-200'}`}>
      {status}
    </span>
  );
}
