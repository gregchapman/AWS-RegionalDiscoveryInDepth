import { useEffect, useState, useRef } from 'react';
import type { SessionStatus } from '../api/types';
import { api } from '../api/client';

/** Minimal target for the INSTRUCTIONS-only mode (no session exists yet). */
interface InstructionsTarget {
  instance_id: string;
  region: string;
  access_type: 'ssh' | 'rdp';
}

interface SessionDrawerProps {
  /** A live, CLI-created session (LIVE mode: countdown + End). */
  session?: SessionStatus;
  /** A target to show connect instructions for (INSTRUCTIONS mode: no session
   *  exists yet — ADR-0025 §1). Exactly one of session / instructionsFor is set. */
  instructionsFor?: InstructionsTarget;
  onClose: () => void;
  onTerminated?: () => void | Promise<void>;
}

export default function SessionDrawer({ session, instructionsFor, onClose, onTerminated }: SessionDrawerProps) {
  const [timeRemaining, setTimeRemaining] = useState('');
  const [copied, setCopied] = useState<string | null>(null);
  const [terminating, setTerminating] = useState(false);
  const [installOS, setInstallOS] = useState<'bash' | 'pwsh'>('bash');
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // The one command (ADR-0012/0016): the `passport` CLI authenticates the user
  // itself (Cognito + MFA) and brokers the whole flow — request, scoped
  // credential vend, SSM tunnel, then SSH (Linux) or an RDP tunnel (Windows).
  // No AWS credentials, and NO token handoff from the browser: the CLI earns
  // its own token via MFA. Run after a one-time install. `--rdp` selects the
  // Windows path (opens the 3389 tunnel and prints the values for your RDP
  // client instead of dropping into a shell).
  // Normalized target works in BOTH modes: from the live session, or from the
  // instructions target when no session exists yet (ADR-0025).
  const target = session
    ? { instance_id: session.instance_id, region: session.region, access_type: session.access_type }
    : instructionsFor!;
  const isLive = !!session; // LIVE mode (real session) vs INSTRUCTIONS mode.

  const connectCommand =
    target.access_type === 'rdp'
      ? `passport connect ${target.instance_id} --region ${target.region} --rdp`
      : `passport connect ${target.instance_id} --region ${target.region}`;

  // One-time, checksum-verified installers (download-verify-install, not
  // curl|bash of logic — CM-5/SI-7). Shown once; the CLI persists on PATH.
  const installBash =
    'curl -fsSL https://portal.takahe.click/cli/releases/LATEST/install.sh -o /tmp/install.sh && bash /tmp/install.sh';
  const installPwsh =
    'iwr https://portal.takahe.click/cli/releases/LATEST/install.ps1 -OutFile install.ps1; powershell -ExecutionPolicy Bypass -File .\\install.ps1';

  async function handleTerminate() {
    if (!confirm('End this session now? The temporary user will be removed from the instance immediately.')) {
      return;
    }
    if (!session) return; // Only the LIVE drawer can end a session.
    setTerminating(true);
    // Self-terminate (owner ending their own session): attributed as
    // self:portal, no reason required (ADR-0024/0025). Operator revoke of
    // ANOTHER user's session happens in the operator console, which supplies a
    // mandatory reason.
    const res = await api.post(`/api/session/${session.request_id}/terminate`, {
      source: 'self:portal',
    });
    if (res.error) {
      setTerminating(false);
      alert(`Failed to end session: ${res.error}`);
      return;
    }
    // Terminate succeeded. CLOSE THE DRAWER IMMEDIATELY: the drawer renders from
    // its frozen `session` prop (captured ACTIVE at open time), so leaving it
    // open even briefly shows a stale "Active" — which read as the two-click
    // bug (the row underneath was already correct). Closing first gives instant
    // feedback; onTerminated (removeSession -> refresh) then reconciles the
    // context in the background. suppression-by-request_id (SessionsContext)
    // guarantees the just-ended session isn't re-added while the backend
    // finishes finalizing it.
    setTerminating(false);
    onClose();
    if (onTerminated) void onTerminated();
  }

  useEffect(() => {
    if (!isLive) return; // INSTRUCTIONS mode: no countdown.
    updateCountdown();
    intervalRef.current = setInterval(updateCountdown, 1000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, isLive]);

  function updateCountdown() {
    if (!session?.connection?.expires_at) {
      setTimeRemaining('Unknown');
      return;
    }

    const expiresAt = parseInt(session.connection.expires_at, 10) * 1000;
    const now = Date.now();
    const diff = expiresAt - now;

    if (diff <= 0) {
      setTimeRemaining('Expired');
      if (intervalRef.current) clearInterval(intervalRef.current);
      return;
    }

    const hours = Math.floor(diff / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);

    if (hours > 0) {
      setTimeRemaining(`${hours}h ${minutes}m ${seconds}s`);
    } else if (minutes > 0) {
      setTimeRemaining(`${minutes}m ${seconds}s`);
    } else {
      setTimeRemaining(`${seconds}s`);
    }
  }

  async function copyToClipboard(text: string, label: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      // Fallback for older browsers
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(label);
      setTimeout(() => setCopied(null), 2000);
    }
  }

  const isExpired = timeRemaining === 'Expired';

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 z-40"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer */}
      <aside
        className="fixed right-0 top-0 h-full w-full max-w-md bg-navy-700 border-l border-navy-400 z-50 overflow-y-auto shadow-2xl"
        role="dialog"
        aria-modal="true"
        aria-labelledby="session-drawer-title"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-navy-400">
          <h2 id="session-drawer-title" className="text-lg font-semibold text-white">
            {isLive ? 'Active Session' : 'Connect to Instance'}
          </h2>
          <button
            onClick={onClose}
            className="text-navy-200 hover:text-white p-1 rounded"
            aria-label="Close session drawer"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Countdown — LIVE mode only (no session, no timer). */}
        {isLive && session && (
          <div className={`p-4 border-b border-navy-400 ${isExpired ? 'bg-red-900/30' : 'bg-navy-600'}`}>
            <p className="text-xs text-navy-200 uppercase tracking-wide">Time Remaining</p>
            <p className={`text-2xl font-mono font-bold mt-1 ${isExpired ? 'text-red-400' : 'text-white'}`}>
              {timeRemaining}
            </p>
            {!isExpired && (
              <div className="mt-2 w-full bg-navy-400 rounded-full h-1.5">
                <div
                  className="bg-accent h-1.5 rounded-full transition-all duration-1000"
                  style={{
                    width: `${Math.max(0, getProgressPercent(session))}%`,
                  }}
                />
              </div>
            )}
          </div>
        )}

        {/* INSTRUCTIONS-mode banner: make it explicit that nothing is
            provisioned until the user runs the CLI (ADR-0025). */}
        {!isLive && (
          <div className="p-4 border-b border-navy-400 bg-navy-600">
            <p className="text-xs text-navy-200">
              Run the command below to connect. Nothing is provisioned and no
              access is granted until you run it and authenticate — the session
              appears here once it is live.
            </p>
          </div>
        )}

        {/* Connection Details */}
        <div className="p-4 space-y-4">
          {/* Instance info */}
          <section>
            <h3 className="text-xs text-navy-200 uppercase tracking-wide mb-2">Target</h3>
            <div className="card space-y-2">
              <DetailRow label="Instance" value={target.instance_id} />
              <DetailRow label="Region" value={target.region} />
              <DetailRow label="Access Type" value={target.access_type.toUpperCase()} />
            </div>
          </section>

          {/* No CREDENTIALS section by design: connect creds are never shown in
              the portal. SSH is passwordless (cert). For RDP the passport CLI
              prints the short-lived password in-context when it opens the
              tunnel — rendering it here too would just be a second exposure
              surface (browser DOM / shoulder-surf / screenshot) for no value.
              The identity-named username appears in the connect instructions. */}

          {/* SSH: install the passport CLI once, then one command per connect
              (ADR-0012/0016). The CLI does its OWN Cognito+MFA login — no token
              handoff from the browser, no AWS credentials on the machine.
              Shown in BOTH modes (the command is what the user runs to create
              the session in the first place — ADR-0025). */}
          {target.access_type === 'ssh' && (
            <section>
              <h3 className="text-xs text-navy-200 uppercase tracking-wide mb-2">
                Connect with the Passport CLI
              </h3>
              <div className="card space-y-3">
                <p className="text-xs text-navy-200">
                  The <code className="text-accent-300">passport</code> CLI logs you in (with MFA) and connects
                  you over SSM. No AWS credentials, no passwords, nothing to download per session.
                </p>

                <div>
                  <p className="text-xs text-navy-200 mb-1">One-time install</p>
                  <div className="flex gap-2 mb-1">
                    <button
                      onClick={() => setInstallOS('bash')}
                      className={`text-xs px-2 py-0.5 rounded ${installOS === 'bash' ? 'bg-accent text-white' : 'bg-navy-600 text-navy-200'}`}
                    >
                      Linux / macOS / WSL
                    </button>
                    <button
                      onClick={() => setInstallOS('pwsh')}
                      className={`text-xs px-2 py-0.5 rounded ${installOS === 'pwsh' ? 'bg-accent text-white' : 'bg-navy-600 text-navy-200'}`}
                    >
                      Windows
                    </button>
                  </div>
                  <div className="relative">
                    <pre className="text-xs text-accent-300 font-mono whitespace-pre-wrap break-all bg-navy-800 p-3 rounded">
                      {installOS === 'bash' ? installBash : installPwsh}
                    </pre>
                    <button
                      onClick={() => copyToClipboard(installOS === 'bash' ? installBash : installPwsh, 'install')}
                      className="absolute top-2 right-2 text-xs bg-navy-600 hover:bg-navy-500 text-white px-2 py-1 rounded"
                      aria-label="Copy install command"
                    >
                      {copied === 'install' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <p className="text-xs text-navy-300 mt-1">
                    Downloads a checksum-verified binary from the portal. Requires the SSM Session Manager plugin.
                  </p>
                </div>

                <div>
                  <p className="text-xs text-navy-200 mb-1">Connect</p>
                  <div className="relative">
                    <pre className="text-xs text-accent-300 font-mono whitespace-pre-wrap break-all bg-navy-800 p-3 rounded">
                      {connectCommand}
                    </pre>
                    <button
                      onClick={() => copyToClipboard(connectCommand, 'connectcmd')}
                      className="absolute top-2 right-2 text-xs bg-navy-600 hover:bg-navy-500 text-white px-2 py-1 rounded"
                      aria-label="Copy connect command"
                    >
                      {copied === 'connectcmd' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <p className="text-xs text-navy-300 mt-1">
                    You'll be prompted for your portal login + MFA, then dropped straight into a shell as your
                    identity-named session user. Your access window can be up to 12h — just re-run to reconnect.
                  </p>
                </div>
              </div>
            </section>
          )}

          {/* RDP: same Passport CLI, `--rdp` mode (ADR-0022 = Passport V2
              pattern: SSM tunnel to 3389 + your native RDP client). The CLI
              logs you in (MFA), opens the tunnel, and prints the values to
              paste into Remote Desktop. No AWS credentials, no raw `aws ssm`. */}
          {target.access_type === 'rdp' && (
            <section>
              <h3 className="text-xs text-navy-200 uppercase tracking-wide mb-2">
                Connect with the Passport CLI (RDP)
              </h3>
              <div className="card space-y-3">
                <p className="text-xs text-navy-200">
                  The <code className="text-accent-300">passport</code> CLI logs you in (with MFA), opens the
                  SSM tunnel to this instance, and prints what to type into your RDP client. No AWS credentials
                  on your machine.
                </p>

                <div>
                  <p className="text-xs text-navy-200 mb-1">One-time install</p>
                  <div className="flex gap-2 mb-1">
                    <button
                      onClick={() => setInstallOS('pwsh')}
                      className={`text-xs px-2 py-0.5 rounded ${installOS === 'pwsh' ? 'bg-accent text-white' : 'bg-navy-600 text-navy-200'}`}
                    >
                      Windows
                    </button>
                    <button
                      onClick={() => setInstallOS('bash')}
                      className={`text-xs px-2 py-0.5 rounded ${installOS === 'bash' ? 'bg-accent text-white' : 'bg-navy-600 text-navy-200'}`}
                    >
                      Linux / macOS / WSL
                    </button>
                  </div>
                  <div className="relative">
                    <pre className="text-xs text-accent-300 font-mono whitespace-pre-wrap break-all bg-navy-800 p-3 rounded">
                      {installOS === 'bash' ? installBash : installPwsh}
                    </pre>
                    <button
                      onClick={() => copyToClipboard(installOS === 'bash' ? installBash : installPwsh, 'install')}
                      className="absolute top-2 right-2 text-xs bg-navy-600 hover:bg-navy-500 text-white px-2 py-1 rounded"
                      aria-label="Copy install command"
                    >
                      {copied === 'install' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <p className="text-xs text-navy-300 mt-1">
                    Checksum-verified binary from the portal. Requires the SSM Session Manager plugin.
                  </p>
                </div>

                <div>
                  <p className="text-xs text-navy-200 mb-1">Open the tunnel</p>
                  <div className="relative">
                    <pre className="text-xs text-accent-300 font-mono whitespace-pre-wrap break-all bg-navy-800 p-3 rounded">
                      {connectCommand}
                    </pre>
                    <button
                      onClick={() => copyToClipboard(connectCommand, 'connectcmd')}
                      className="absolute top-2 right-2 text-xs bg-navy-600 hover:bg-navy-500 text-white px-2 py-1 rounded"
                      aria-label="Copy connect command"
                    >
                      {copied === 'connectcmd' ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <p className="text-xs text-navy-300 mt-1">
                    Prompts for your portal login + MFA, opens the tunnel, then prints the exact
                    Host / Username / Password to use. Leave it running while you use the session; Ctrl-C ends it.
                  </p>
                </div>

                <div>
                  <p className="text-xs text-navy-200 mb-1">Then in your RDP client (mstsc / Microsoft Remote Desktop)</p>
                  <p className="text-xs text-navy-300">
                    Use the <span className="text-accent-300">Host</span>,{' '}
                    <span className="text-accent-300">Username</span>, and{' '}
                    <span className="text-accent-300">Password</span> that the CLI prints — those are the
                    authoritative values for your session (each connect gets a fresh username, port, and
                    short-lived password). Enter the username exactly as printed, including the leading{' '}
                    <code className="text-accent-300">.\</code>, which forces a LOCAL account login so your
                    client does not append a corporate domain.
                  </p>
                </div>
              </div>
            </section>
          )}

          {/* Status + End — LIVE mode only. In INSTRUCTIONS mode there is no
              session to show a status for or to end (ADR-0025). */}
          {isLive && session && (
            <>
              <section>
                <h3 className="text-xs text-navy-200 uppercase tracking-wide mb-2">Status</h3>
                <div className="card">
                  <StatusBadge status={session.status} />
                  <p className="text-xs text-navy-300 mt-2">
                    Session will be automatically cleaned up when the timer expires.
                    The ephemeral user will be removed from the instance.
                  </p>
                </div>
              </section>

              <section>
                <button
                  onClick={handleTerminate}
                  disabled={terminating}
                  className="w-full px-4 py-2 bg-accent text-white font-medium rounded-md hover:bg-accent-600 transition-colors disabled:opacity-50"
                  aria-label="End session now"
                >
                  {terminating ? 'Ending session...' : 'End Session Now'}
                </button>
                <p className="text-xs text-navy-300 mt-2 text-center">
                  Removes the temporary user immediately instead of waiting for the timer.
                </p>
              </section>
            </>
          )}
        </div>
      </aside>
    </>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-xs text-navy-200">{label}</span>
      <span className="text-sm text-white font-mono">{value}</span>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    ACTIVE: 'bg-green-900/50 text-green-300',
    PENDING: 'bg-yellow-900/50 text-yellow-300',
    PROVISIONING: 'bg-blue-900/50 text-blue-300',
    END_REQUESTED: 'bg-orange-900/50 text-orange-300',
    CLEANING_UP: 'bg-orange-900/50 text-orange-300',
    COMPLETED: 'bg-navy-400 text-navy-200',
    CLEANUP_FAILED: 'bg-red-900/50 text-red-300',
    FAILED: 'bg-red-900/50 text-red-300',
  };

  return (
    <span className={`inline-flex items-center text-xs px-2 py-1 rounded font-medium ${styles[status] || styles.PENDING}`}>
      {status}
    </span>
  );
}

function getProgressPercent(session: SessionStatus): number {
  if (!session.connection?.expires_at || !session.created_at) return 100;

  const createdAt = new Date(session.created_at).getTime();
  const expiresAt = parseInt(session.connection.expires_at, 10) * 1000;
  const now = Date.now();

  const total = expiresAt - createdAt;
  const elapsed = now - createdAt;

  return Math.max(0, Math.min(100, 100 - (elapsed / total) * 100));
}
