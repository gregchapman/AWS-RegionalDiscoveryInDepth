import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

/**
 * OAuth callback page. Amplify handles the code exchange automatically
 * when it detects the authorization code in the URL. We just wait for
 * auth state to settle and redirect.
 */
export default function CallbackPage() {
  const { isAuthenticated, isLoading, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      navigate(user?.isRacker ? '/racker' : '/customer', { replace: true });
    } else if (!isLoading && !isAuthenticated) {
      navigate('/login', { replace: true });
    }
  }, [isLoading, isAuthenticated, user, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-navy">
      <div className="text-center">
        <div className="animate-spin w-8 h-8 border-2 border-accent border-t-transparent rounded-full mx-auto mb-4" />
        <p className="text-navy-200">Completing sign-in...</p>
      </div>
    </div>
  );
}
