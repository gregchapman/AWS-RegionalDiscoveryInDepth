import { useEffect, useState } from 'react';
import { api } from '../api/client';
import type { Instance, InstancesResponse } from '../api/types';
import InstanceTable from '../components/InstanceTable';

export default function CustomerDashboard() {
  const [instances, setInstances] = useState<Instance[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadInstances();
  }, []);

  async function loadInstances() {
    setLoading(true);
    setError(null);
    const res = await api.get<InstancesResponse>('/api/instances');
    if (res.data) {
      setInstances(res.data.instances);
    } else if (res.error) {
      setError(res.error);
    }
    setLoading(false);
  }

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div>
        <h2 className="text-2xl font-bold text-white">My Instances</h2>
        <p className="text-navy-200 mt-1">
          Access your infrastructure via secure SSM sessions
        </p>
      </div>

      {error && (
        <div className="bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded">
          {error}
        </div>
      )}

      <InstanceTable instances={instances} loading={loading} />
    </div>
  );
}
