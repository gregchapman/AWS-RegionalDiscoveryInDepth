import { useAuth } from '../auth/AuthContext';
import { Navigate } from 'react-router-dom';

export default function LoginPage() {
  const { isAuthenticated, login, user } = useAuth();

  if (isAuthenticated) {
    return <Navigate to={user?.isRacker ? '/racker' : '/customer'} replace />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-navy">
      <div className="card max-w-md w-full mx-4 text-center">
        {/* Brand */}
        <div className="mb-8">
          <div className="w-16 h-16 bg-accent rounded-lg flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-2xl">R</span>
          </div>
          <h1 className="text-2xl font-bold text-white">
            RGS Access Portal
          </h1>
          <p className="text-navy-200 mt-2">
            Zero-Trust Infrastructure Access
          </p>
        </div>

        {/* Login button */}
        <button
          onClick={login}
          className="btn-primary w-full text-lg py-3"
        >
          Sign In with SSO
        </button>

        {/* Footer text */}
        <p className="mt-6 text-xs text-navy-300">
          FedRAMP Moderate &middot; NIST 800-53 &middot; IL4 Authorized
        </p>
        <p className="mt-2 text-xs text-navy-300">
          Rackspace Government Solutions
        </p>
      </div>
    </div>
  );
}
