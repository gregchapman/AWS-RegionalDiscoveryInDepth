import { useEffect, useState } from 'react';
import { api } from '../api/client';
import type { Account, AccountsResponse, Instance, InstancesResponse } from '../api/types';
import InstanceTable from '../components/InstanceTable';
import OperatorSessions from '../components/OperatorSessions';

export default function RackerDashboard() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [instances, setInstances] = useState<Instance[]>([]);
  const [selectedRegion, setSelectedRegion] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadAccounts();
    loadInstances();
  }, []);

  async function loadAccounts() {
    const res = await api.get<AccountsResponse>('/api/accounts');
    if (res.data) {
      setAccounts(res.data.accounts);
    }
  }

  async function loadInstances(region?: string) {
    setLoading(true);
    setError(null);
    const path = region ? `/api/instances?region=${region}` : '/api/instances';
    const res = await api.get<InstancesResponse>(path);
    if (res.data) {
      setInstances(res.data.instances);
    } else if (res.error) {
      setError(res.error);
    }
    setLoading(false);
  }

  function handleRegionFilter(region: string) {
    setSelectedRegion(region);
    loadInstances(region || undefined);
  }

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div>
        <h2 className="text-2xl font-bold text-white">Racker Console</h2>
        <p className="text-navy-200 mt-1">
          Multi-account access management — all customer environments
        </p>
      </div>

      {/* Account cards */}
      <section aria-labelledby="accounts-heading">
        <h3 id="accounts-heading" className="text-lg font-semibold text-white mb-3">
          Customer Accounts
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {accounts.map((account) => (
            <div
              key={account.id}
              className={`card text-left transition-colors ${
                selectedRegion === account.region
                  ? 'border-accent'
                  : 'hover:border-navy-300'
              }`}
            >
              <button
                onClick={() => handleRegionFilter(account.region || '')}
                className="w-full text-left"
              >
                <p className="font-medium text-white">{account.name}</p>
                <p className="text-sm text-navy-200 mt-1">
                  {account.region || account.id}
                </p>
                <span className="inline-block mt-2 text-xs bg-green-900 text-green-300 px-2 py-0.5 rounded">
                  {account.status}
                </span>
              </button>
            </div>
          ))}
          {accounts.length === 0 && (
            <p className="text-navy-300 col-span-3">No accounts available.</p>
          )}
        </div>
      </section>

      {/* Filter bar */}
      <div className="flex items-center space-x-4">
        <button
          onClick={() => handleRegionFilter('')}
          className={`text-sm px-3 py-1 rounded ${
            !selectedRegion ? 'bg-accent text-white' : 'bg-navy-600 text-navy-200 hover:text-white'
          }`}
        >
          All Regions
        </button>
        {accounts.map((a) => (
          <button
            key={a.region}
            onClick={() => handleRegionFilter(a.region || '')}
            className={`text-sm px-3 py-1 rounded ${
              selectedRegion === a.region ? 'bg-accent text-white' : 'bg-navy-600 text-navy-200 hover:text-white'
            }`}
          >
            {a.region}
          </button>
        ))}
      </div>

      {/* Operator session console (ADR-0025): all live sessions across users,
          tenant-scopable, with attributed + justified revoke. */}
      <OperatorSessions />

      {/* Instance table */}
      {error && (
        <div className="bg-red-900/50 border border-red-700 text-red-200 px-4 py-3 rounded">
          {error}
        </div>
      )}

      <InstanceTable instances={instances} loading={loading} />
    </div>
  );
}
