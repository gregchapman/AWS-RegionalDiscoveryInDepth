/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#1B2838',
          50: '#E8EBF0',
          100: '#D1D7E0',
          200: '#A3AFC1',
          300: '#7587A2',
          400: '#485F83',
          500: '#1B2838',
          600: '#162030',
          700: '#111828',
          800: '#0C1020',
          900: '#070818',
        },
        accent: {
          DEFAULT: '#C8102E',
          50: '#FDEAED',
          100: '#FAD5DA',
          200: '#F5ABB6',
          300: '#F08191',
          400: '#EB576D',
          500: '#C8102E',
          600: '#A00D25',
          700: '#780A1C',
          800: '#500712',
          900: '#280309',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
