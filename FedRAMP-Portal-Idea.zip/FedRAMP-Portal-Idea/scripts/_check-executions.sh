#!/usr/bin/env bash
# Diagnostic: recent state-machine executions across ALL statuses, with age +
# ttl, so we can see whether terminated/expired sessions leave RUNNING orphans
# or resolve (SUCCEEDED/ABORTED) correctly.
set -euo pipefail
SM="arn:aws:states:us-east-1:675405875014:stateMachine:fedramp-portal-access-lifecycle"
REGION="us-east-1"
AWS="${AWS_BIN:-/home/greg/.local/bin/aws}"
NOW=$(date +%s)

echo "== RUNNING =="
"$AWS" stepfunctions list-executions --state-machine-arn "$SM" --status-filter RUNNING \
  --region "$REGION" --max-items 50 --query 'length(executions)' --output text

echo "== last 20 executions (all statuses): name | status | age_min | ttl_min =="
"$AWS" stepfunctions list-executions --state-machine-arn "$SM" \
  --region "$REGION" --max-items 20 --query 'executions[].[executionArn,status,startDate]' --output text \
| while read -r ARN STATUS START; do
    START_S=${START%.*}
    AGE_MIN=$(( (NOW - START_S) / 60 ))
    TTL=$("$AWS" stepfunctions describe-execution --execution-arn "$ARN" --region "$REGION" \
            --query 'input' --output text 2>/dev/null | python3 -c 'import sys,json; print(json.load(sys.stdin).get("ttl_minutes","?"))' 2>/dev/null || echo "?")
    printf '  %-14s | %-9s | %4s | %s\n' "${ARN##*:}" "$STATUS" "$AGE_MIN" "$TTL"
  done
