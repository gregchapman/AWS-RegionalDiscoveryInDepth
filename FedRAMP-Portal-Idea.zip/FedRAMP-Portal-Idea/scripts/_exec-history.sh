#!/usr/bin/env bash
# Show the event history of one execution: which states entered/exited, and
# where it was sitting when it stopped. Reveals whether the Wait ever fired.
set -euo pipefail
REGION="us-east-1"
AWS="${AWS_BIN:-/home/greg/.local/bin/aws}"
ARN="arn:aws:states:us-east-1:675405875014:execution:fedramp-portal-access-lifecycle:${1:?usage: <execution-name>}"

"$AWS" stepfunctions get-execution-history --execution-arn "$ARN" --region "$REGION" \
  --max-items 40 \
  --query 'events[].{id:id,type:type,ts:timestamp,state:(stateEnteredEventDetails.name || stateExitedEventDetails.name)}' \
  --output text
