#!/usr/bin/env bash
# Inspect one execution's input + the state it spent time in, to find why the
# Wait ran far past ttl_seconds.
set -euo pipefail
REGION="us-east-1"
AWS="${AWS_BIN:-/home/greg/.local/bin/aws}"
ARN="arn:aws:states:us-east-1:675405875014:execution:fedramp-portal-access-lifecycle:${1:?usage: _inspect-exec.sh <execution-name>}"

echo "== input =="
"$AWS" stepfunctions describe-execution --execution-arn "$ARN" --region "$REGION" \
  --query 'input' --output text | python3 -m json.tool 2>/dev/null || \
  "$AWS" stepfunctions describe-execution --execution-arn "$ARN" --region "$REGION" --query 'input' --output text

echo "== key timing fields =="
"$AWS" stepfunctions describe-execution --execution-arn "$ARN" --region "$REGION" \
  --query 'input' --output text | python3 -c 'import sys,json; d=json.load(sys.stdin); print("ttl_minutes =", d.get("ttl_minutes")); print("ttl_seconds =", d.get("ttl_seconds"))'
