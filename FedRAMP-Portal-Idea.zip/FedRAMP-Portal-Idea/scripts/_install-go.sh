#!/usr/bin/env bash
# One-time Go toolchain install to a user-local path (no root needed).
# Go 1.24.x: current AWS SDK for Go v2 requires >= 1.24; using a current
# toolchain is the right baseline for a new tool (rather than pinning to
# ancient SDK versions).
set -euo pipefail
VER="go1.24.5"
cd /tmp
echo "downloading ${VER}..."
curl -fsSL -o "${VER}.linux-amd64.tar.gz" "https://go.dev/dl/${VER}.linux-amd64.tar.gz"
rm -rf "${HOME}/.local/go-sdk"
mkdir -p "${HOME}/.local/go-sdk"
tar -C "${HOME}/.local/go-sdk" -xzf "${VER}.linux-amd64.tar.gz"
rm -f "${VER}.linux-amd64.tar.gz"
"${HOME}/.local/go-sdk/go/bin/go" version
