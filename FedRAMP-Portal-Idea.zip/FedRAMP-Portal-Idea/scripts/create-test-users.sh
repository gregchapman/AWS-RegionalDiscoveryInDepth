#!/usr/bin/env bash
###############################################################################
# create-test-users.sh
#
# Creates test users in the COGNITO User Pool for portal login (ADR-0005).
# Cognito is the portal's identity store. The customer_id values below
# (customer1, customer2) match the `Customer` tags on the layer-04 EC2 instances
# — that match is what scopes a customer to only their own instances.
# Run AFTER layer 03-api is deployed (needs the Cognito pool + front-door URL).
#
# IMPORTANT: the pool has username_attributes = ["email"] (terraform/03-api/
# main.tf), so the USERNAME IS THE EMAIL. Users log in with the email address.
#
# Creates:
#   - greg-racker@rgs-test.local     (Rackers group)   — full multi-account view
#   - greg-readonly@rgs-test.local   (Rackers group)   — read-only persona test
#   - customer-user-1@rgs-test.local (Customers, customer_id=customer1) — sees only customer1 instances
#   - customer-user-2@rgs-test.local (Customers, customer_id=customer2) — sees only customer2 instances
#
# All users get temporary password "FedRAMP-Test-2026!" which must be changed
# on first login (Cognito forces this). MFA setup is also required on first login.
#
# Usage:
#   ./scripts/create-test-users.sh
#
# Requirements:
#   - AWS CLI v2 configured (AWS_PROFILE or env creds)
#   - Layer 03-api deployed
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
TF_API_DIR="$PROJECT_DIR/terraform/03-api"
REGION="us-east-1"
TEMP_PASSWORD="FedRAMP-Test-2026!"

echo "=============================================="
echo " FedRAMP Portal — Create Test Users"
echo "=============================================="
echo ""

# Get Cognito User Pool ID from terraform output
if [ ! -d "$TF_API_DIR/.terraform" ]; then
  echo "ERROR: Layer 03-api hasn't been initialized. Deploy it first."
  exit 1
fi

POOL_ID=$(cd "$TF_API_DIR" && terraform output -raw cognito_user_pool_id 2>/dev/null)
if [ -z "$POOL_ID" ]; then
  echo "ERROR: Could not get cognito_user_pool_id from terraform output."
  echo "       Make sure layer 03-api is deployed."
  exit 1
fi

echo "  User Pool ID: $POOL_ID"
echo ""

create_user() {
  local email="$1"
  local group="$2"
  local customer_id="${3:-}"

  # The pool has username_attributes = ["email"] (see terraform/03-api/main.tf),
  # so the USERNAME **is** the email address. Passing a bare handle like
  # "greg-racker" is rejected by Cognito. Every admin-* call below therefore uses
  # the email as --username. Errors are NOT swallowed — a failed create/group/
  # attribute call prints the AWS error and aborts (set -e), so the script can
  # never falsely report success (the bug that left the pool with one user).
  local username="$email"

  printf "  %-32s " "$username"

  # Create the user. AlreadyExists is the ONE tolerated error (idempotent re-run);
  # anything else is fatal and surfaced.
  local create_err
  if create_err=$(aws cognito-idp admin-create-user \
    --user-pool-id "$POOL_ID" \
    --username "$username" \
    --user-attributes \
      "Name=email,Value=$email" \
      "Name=email_verified,Value=true" \
    --temporary-password "$TEMP_PASSWORD" \
    --message-action SUPPRESS \
    --region "$REGION" 2>&1 >/dev/null); then
    echo -n "created, "
  elif grep -q "UsernameExistsException" <<<"$create_err"; then
    echo -n "exists, "
  else
    echo "FAILED"
    echo "    admin-create-user error: $create_err" >&2
    return 1
  fi

  # Add to group (idempotent — re-adding is a no-op, not an error).
  aws cognito-idp admin-add-user-to-group \
    --user-pool-id "$POOL_ID" \
    --username "$username" \
    --group-name "$group" \
    --region "$REGION"
  echo -n "group=$group"

  # Set custom:customer_id for Customers (tenant scope — must match the EC2
  # `Customer` tag; see layer 04). Racker users omit it.
  if [ -n "$customer_id" ]; then
    aws cognito-idp admin-update-user-attributes \
      --user-pool-id "$POOL_ID" \
      --username "$username" \
      --user-attributes "Name=custom:customer_id,Value=$customer_id" \
      --region "$REGION"
    echo -n ", customer_id=$customer_id"
  fi

  echo " OK"
}

echo "-> Creating Racker users..."
create_user "greg-racker@rgs-test.local"    "Rackers"
create_user "greg-readonly@rgs-test.local"  "Rackers"

echo ""
echo "-> Creating Customer users..."
create_user "customer-user-1@rgs-test.local" "Customers" "customer1"
create_user "customer-user-2@rgs-test.local" "Customers" "customer2"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✓ All test users created"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  Temporary password: $TEMP_PASSWORD"
echo "  (Must be changed on first login)"
echo ""
echo "  Login URL: $(cd "$TF_API_DIR" && terraform output -raw portal_front_door_url 2>/dev/null || echo 'https://portal.takahe.click')"
echo ""
echo "  Test accounts (log in with the EMAIL as the username):"
echo "    Racker:          greg-racker@rgs-test.local     / $TEMP_PASSWORD"
echo "    Racker (RO):     greg-readonly@rgs-test.local   / $TEMP_PASSWORD"
echo "    Customer 1:      customer-user-1@rgs-test.local / $TEMP_PASSWORD  (customer_id=customer1)"
echo "    Customer 2:      customer-user-2@rgs-test.local / $TEMP_PASSWORD  (customer_id=customer2)"
echo ""
echo "  On first login, each user must:"
echo "    1. Change their password (12+ chars, upper+lower+number+symbol)"
echo "    2. Set up MFA (scan QR code with authenticator app)"
echo ""
