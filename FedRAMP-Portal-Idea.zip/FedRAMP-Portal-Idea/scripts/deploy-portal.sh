#!/usr/bin/env bash
# Build + publish the SPA to the static bucket — SAFELY.
#
# WHY THIS SCRIPT EXISTS: the CLI release artifacts live in the SAME bucket
# under cli/releases/. A naive `aws s3 sync dist/ s3://bucket/ --delete` treats
# the CLI tree as "not in dist/" and DELETES it (this bit us: the SPA sync wiped
# passport binaries + install scripts, and downloads started 500'ing). This
# script scopes --delete so it prunes stale SPA assets but NEVER touches the
# cli/ prefix.
#
# SoD (ADR-0018): DEPLOY step — run with AWS_PROFILE set.
#   AWS_PROFILE=personal-faws ./scripts/deploy-portal.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BUCKET="${PORTAL_STATIC_BUCKET:-fedramp-portal-static-675405875014}"
AWS="${AWS_BIN:-/home/greg/.local/bin/aws}"
command -v "$AWS" >/dev/null 2>&1 || AWS="aws"

echo "== building SPA =="
cd "$PROJECT_DIR/portal"
npm run build

echo "== syncing dist/ -> s3://$BUCKET/ (preserving cli/ artifacts) =="
# CACHE STRATEGY (critical — see docs/ARCHITECTURE.md §3.4). Vite produces
# content-hashed asset filenames (assets/index-<hash>.js), so those are
# immutable and can be cached forever. index.html is NOT hashed and references
# the current hashed assets, so it MUST be no-cache — otherwise a browser keeps
# a stale index.html that points at OLD bundles, and NEW deploys never take
# effect (this masked several SPA fixes: the browser loaded old JS).
#
# Two passes:
#   1) Everything EXCEPT index.html -> long immutable cache. --delete prunes
#      stale SPA files; --exclude "cli/*" protects the CLI release tree that
#      shares this bucket (do NOT drop it).
#   2) index.html -> no-cache, must-revalidate (uploaded last).
"$AWS" s3 sync dist/ "s3://$BUCKET/" --delete \
  --exclude "cli/*" \
  --exclude "index.html" \
  --cache-control "public, max-age=31536000, immutable"

"$AWS" s3 cp dist/index.html "s3://$BUCKET/index.html" \
  --cache-control "no-cache, no-store, must-revalidate" \
  --content-type "text/html"

echo "== verify =="
echo -n "  portal:      "; curl -s -o /dev/null -w '%{http_code}\n' https://portal.takahe.click/
echo -n "  cli install: "; curl -s -o /dev/null -w '%{http_code}\n' https://portal.takahe.click/cli/releases/LATEST/install.sh
echo -n "  index.html cache-control: "; "$AWS" s3api head-object --bucket "$BUCKET" --key index.html --query 'CacheControl' --output text
echo "Done. Expect portal 200; cli install 302 (installer redirects to a presigned S3 URL);"
echo "index.html cache-control must be 'no-cache, no-store, must-revalidate'."
