#!/usr/bin/env bash
###############################################################################
# init-ssh-ca.sh
#
# One-time setup of the SSH Certificate Authority (ADR-0014).
# Generates an ed25519 CA keypair OUT OF BAND, uploads the PRIVATE key to
# Secrets Manager and the PUBLIC key to SSM Parameter Store. The private key
# is shredded locally afterward so it exists only in Secrets Manager.
#
# Run AFTER terraform apply of layer 03-api (which creates the secret + param).
#
# Usage:
#   AWS_PROFILE=personal-faws ./scripts/init-ssh-ca.sh
#
# Re-running ROTATES the CA key. After rotation, instances must re-fetch the
# public key (re-run instance CA-trust config) and any outstanding certs
# signed by the old CA become invalid.
###############################################################################

set -euo pipefail

REGION="us-east-1"
SECRET_NAME="fedramp-portal/ssh-ca-private-key"
PARAM_NAME="/fedramp-portal/ssh-ca-public-key"

PROFILE_ARG=""
if [ -n "${AWS_PROFILE:-}" ]; then
  PROFILE_ARG="--profile $AWS_PROFILE"
fi

echo "=============================================="
echo " FedRAMP Portal — Initialize SSH CA"
echo "=============================================="
echo ""

TMPDIR="$(mktemp -d)"
trap 'rm -rf "$TMPDIR"' EXIT

CA_KEY="$TMPDIR/passport_ca"

echo "-> Generating ed25519 CA keypair..."
ssh-keygen -t ed25519 -f "$CA_KEY" -N "" -C "fedramp-portal-ssh-ca" -q

echo "-> Uploading PRIVATE key to Secrets Manager ($SECRET_NAME)..."
aws secretsmanager put-secret-value \
  --secret-id "$SECRET_NAME" \
  --secret-string "file://$CA_KEY" \
  --region "$REGION" $PROFILE_ARG >/dev/null

echo "-> Uploading PUBLIC key to SSM Parameter Store ($PARAM_NAME)..."
aws ssm put-parameter \
  --name "$PARAM_NAME" \
  --type String \
  --overwrite \
  --value "$(cat "$CA_KEY.pub")" \
  --region "$REGION" $PROFILE_ARG >/dev/null

echo ""
echo "-> CA public key (instances trust this):"
echo "   $(cat "$CA_KEY.pub")"
echo ""

# Shred the local private key
if command -v shred >/dev/null 2>&1; then
  shred -u "$CA_KEY" 2>/dev/null || rm -f "$CA_KEY"
else
  rm -f "$CA_KEY"
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  SSH CA initialized."
echo "  Private key: Secrets Manager ($SECRET_NAME) — local copy shredded."
echo "  Public key:  SSM ($PARAM_NAME)."
echo ""
echo "  Next: instances must fetch the public key and set TrustedUserCAKeys."
echo "  The provision step handles this automatically for portal-managed"
echo "  connections (see ADR-0014)."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
