#!/usr/bin/env bash
###############################################################################
# passport-connect.sh  (ADR-0012 — credential-less connect)
#
# One command that connects a user to a target instance over SSM WITHOUT the
# user holding ANY AWS credentials. This is the interim CLI (pre Go rewrite,
# ADR-0016) that folds the whole flow into one step and proves the portal is
# the sole source of authorization:
#
#   1. authenticate to the portal (Cognito JWT — this is IDENTITY only)
#   2. POST /api/connect                      -> create the access request
#   3. poll GET /api/session/{id}             -> wait for status ACTIVE
#   4. ssh-keygen an EPHEMERAL keypair (mktemp, shredded on exit)
#      POST /api/sign {request_id, public_key} -> short-lived SSH cert
#   5. POST /api/session/{id}/ssm-credentials -> VEND scoped STS creds
#   6. export those temp creds *for the tunnel only* and
#      aws ssm start-session (AWS-StartPortForwardingSession) -> local port
#   7. ssh over the tunnel using the cert (no password, no ambient AWS creds)
#
# VALIDITY MODEL (matches production Passport + ADR-0014):
#   The access request is an AUTHORIZATION window of 1-12h (--ttl, in minutes).
#   The vended STS creds and the SSH cert are short-lived AUTHENTICATORS: the
#   STS creds are ALWAYS <=1h (this Lambda-assumes-broker path is role chaining,
#   which AWS hard-caps at 1h — you cannot vend longer). So one run of this
#   script gives you a tunnel good for up to 1h. To reconnect later within the
#   authorization window, just RE-RUN this script (it re-vends + re-signs) — no
#   re-approval needed until the window itself expires. Long-lived authorization,
#   short-lived authenticators.
#
# PARTITION: works in Commercial (FedRAMP Moderate, CONUS: us-east-*/us-west-*)
# and GovCloud (us-gov-*). The aws CLI resolves the partition from --region, and
# the endpoint scopes the vended policy to the instance region's partition.
#
# The AWS credentials used for the tunnel come ENTIRELY from step 5 (the
# ssm-credentials endpoint). The user's shell never needs AWS_PROFILE or any
# AWS keys. That is the whole point (gap #2 + #3 in todo.md).
#
# ---------------------------------------------------------------------------
# THE CREDENTIAL-LESS PROOF (ADR-0018) — read this before you "verify":
#   Run this in a SCRUBBED shell:
#     env -u AWS_PROFILE -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY \
#         -u AWS_SESSION_TOKEN bash
#   Confirm `aws sts get-caller-identity` FAILS first. THEN run this script.
#   If it still tunnels + sshs, the creds came from the endpoint, not your
#   laptop. If it only works with personal-faws present, it is NOT done — that
#   is the trap (personal-faws never expires and silently satisfies the SSM
#   calls). This script deliberately does NOT read AWS_PROFILE for the tunnel.
# ---------------------------------------------------------------------------
#
# Usage:
#   PORTAL_TOKEN=<cognito-id-or-access-jwt> \
#     ./scripts/passport-connect.sh \
#       --instance i-0abc123 --region us-east-2 [--type ssh] [--ttl 60] \
#       [--base-url https://portal.takahe.click]
#
#   # or pass the token on the CLI:
#   ./scripts/passport-connect.sh --token <jwt> --instance i-... --region ...
#
# Get a token: log into the portal in the browser and copy the Cognito access
# token from the session, or use an org-approved token issuer. (SRP + required
# MFA is impractical to script here; the Go CLI in ADR-0016 will own real
# device-auth. This interim script takes the token as input.)
#
# Requirements: bash, curl, jq, ssh, ssh-keygen, aws CLI v2 + the SSM
# session-manager-plugin.
###############################################################################

set -euo pipefail

# --- defaults ---
BASE_URL="${PORTAL_BASE_URL:-https://portal.takahe.click}"
TOKEN="${PORTAL_TOKEN:-}"
INSTANCE=""
REGION=""
ACCESS_TYPE="ssh"
TTL_MINUTES="60"
POLL_TIMEOUT_SECONDS=120

# --- parse args ---
while [ $# -gt 0 ]; do
  case "$1" in
    --token)     TOKEN="$2"; shift 2 ;;
    --instance)  INSTANCE="$2"; shift 2 ;;
    --region)    REGION="$2"; shift 2 ;;
    --type)      ACCESS_TYPE="$2"; shift 2 ;;
    --ttl)       TTL_MINUTES="$2"; shift 2 ;;
    --base-url)  BASE_URL="$2"; shift 2 ;;
    -h|--help)
      grep '^#' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done

die() { echo "ERROR: $*" >&2; exit 1; }

# --- preflight ---
for bin in curl jq ssh ssh-keygen aws; do
  command -v "$bin" >/dev/null 2>&1 || die "required command not found: $bin"
done
[ -n "$INSTANCE" ] || die "missing --instance <i-... | mi-...>"
[ -n "$REGION" ]   || die "missing --region <aws-region>"
case "$ACCESS_TYPE" in ssh) ;; rdp) die "this interim script handles ssh only; rdp is browser-side for now" ;; *) die "--type must be ssh" ;; esac

# Token = the portal IDENTITY token (Cognito access token), NOT an AWS credential.
# If not supplied via PORTAL_TOKEN/--token, prompt for it with hidden input so it
# never lands in shell history or the process list (bearer token hygiene). Paste
# the access token from the portal (the drawer's "Copy connect token" button).
if [ -z "$TOKEN" ]; then
  if [ -t 0 ]; then
    printf 'Paste your portal access token (input hidden): ' >&2
    read -rs TOKEN
    printf '\n' >&2
  fi
fi
[ -n "$TOKEN" ] || die "no token: set PORTAL_TOKEN, pass --token <jwt>, or paste when prompted"

BASE_URL="${BASE_URL%/}"  # strip any trailing slash

# --- ephemeral workspace: keys + cert live here, shredded on ANY exit ---
WORKDIR="$(mktemp -d "${TMPDIR:-/tmp}/passport-connect.XXXXXX")"
SSM_PID=""

cleanup() {
  # Tear down the tunnel first so the vended creds stop being used.
  if [ -n "$SSM_PID" ] && kill -0 "$SSM_PID" 2>/dev/null; then
    kill "$SSM_PID" 2>/dev/null || true
    wait "$SSM_PID" 2>/dev/null || true
  fi
  # Shred key material, then remove the dir.
  if command -v shred >/dev/null 2>&1; then
    find "$WORKDIR" -type f -exec shred -u {} + 2>/dev/null || true
  fi
  rm -rf "$WORKDIR"
}
trap cleanup EXIT INT TERM

# --- authenticated portal call helper (JWT bearer; NEVER sends AWS creds) ---
# api() is always called via $(...) (a subshell), so it CANNOT export a global
# back to the caller. Instead it prints the HTTP status as the FIRST line,
# followed by the response body. Callers split them with api_status / api_body.
api() {
  local method="$1" path="$2" body="${3:-}"
  local tmp; tmp="$(mktemp "$WORKDIR/resp.XXXXXX")"
  local code
  if [ -n "$body" ]; then
    code="$(curl -sS -o "$tmp" -w '%{http_code}' -X "$method" \
      -H "Authorization: Bearer $TOKEN" \
      -H "Content-Type: application/json" \
      --data "$body" "$BASE_URL$path")"
  else
    code="$(curl -sS -o "$tmp" -w '%{http_code}' -X "$method" \
      -H "Authorization: Bearer $TOKEN" \
      "$BASE_URL$path")"
  fi
  printf '%s\n' "$code"
  cat "$tmp"
  rm -f "$tmp"
}

# First line of an api() result = HTTP status.
api_status() { printf '%s' "$1" | head -n1; }
# Everything after the first line = response body.
api_body() { printf '%s' "$1" | tail -n +2; }

echo "=============================================="
echo " Passport Connect (credential-less) — ADR-0012"
echo "=============================================="
echo "  portal:   $BASE_URL"
echo "  target:   $INSTANCE ($REGION), type=$ACCESS_TYPE, ttl=${TTL_MINUTES}m"
echo ""

# --- 1+2. create the access request -----------------------------------------
echo "-> [1/6] creating access request (POST /api/connect)..."
CONNECT_BODY="$(jq -nc \
  --arg i "$INSTANCE" --arg r "$REGION" --arg t "$ACCESS_TYPE" \
  --argjson ttl "$TTL_MINUTES" \
  '{instance_id:$i, region:$r, access_type:$t, ttl_minutes:$ttl}')"
CONNECT_OUT="$(api POST /api/connect "$CONNECT_BODY")"
CONNECT_STATUS="$(api_status "$CONNECT_OUT")"; CONNECT_RESP="$(api_body "$CONNECT_OUT")"
[ "$CONNECT_STATUS" = "202" ] || die "connect failed (HTTP $CONNECT_STATUS): $(echo "$CONNECT_RESP" | jq -r '.error // .' 2>/dev/null)"
REQUEST_ID="$(echo "$CONNECT_RESP" | jq -r '.request_id')"
[ -n "$REQUEST_ID" ] && [ "$REQUEST_ID" != "null" ] || die "no request_id in connect response"
echo "   request_id: $REQUEST_ID"

# --- 3. poll for ACTIVE ------------------------------------------------------
echo "-> [2/6] waiting for session to become ACTIVE (poll GET /api/session/{id})..."
USERNAME=""
PORT_LOCAL=""
PORT_REMOTE=""
deadline=$(( $(date +%s) + POLL_TIMEOUT_SECONDS ))
while :; do
  SESS_OUT="$(api GET "/api/session/$REQUEST_ID")"
  SESS_STATUS="$(api_status "$SESS_OUT")"; SESS_RESP="$(api_body "$SESS_OUT")"
  [ "$SESS_STATUS" = "200" ] || die "session status failed (HTTP $SESS_STATUS): $(echo "$SESS_RESP" | jq -r '.error // .' 2>/dev/null)"
  STATUS="$(echo "$SESS_RESP" | jq -r '.status')"
  case "$STATUS" in
    ACTIVE)
      USERNAME="$(echo "$SESS_RESP" | jq -r '.connection.username // empty')"
      PORT_LOCAL="$(echo "$SESS_RESP" | jq -r '.connection.port_local // "2222"')"
      PORT_REMOTE="$(echo "$SESS_RESP" | jq -r '.connection.port_remote // "22"')"
      echo "   status: ACTIVE (user=$USERNAME, local:$PORT_LOCAL -> remote:$PORT_REMOTE)"
      break
      ;;
    FAILED)
      die "provisioning FAILED: $(echo "$SESS_RESP" | jq -r '.error_detail // "unknown"')"
      ;;
    *)
      [ "$(date +%s)" -lt "$deadline" ] || die "timed out waiting for ACTIVE (last status: $STATUS)"
      printf '   status: %s ...\r' "$STATUS"
      sleep 3
      ;;
  esac
done

# --- 4. ephemeral keypair + signed SSH certificate ---------------------------
echo "-> [3/6] generating ephemeral SSH keypair + requesting certificate (POST /api/sign)..."
KEY="$WORKDIR/id"
ssh-keygen -t ed25519 -f "$KEY" -N "" -C "passport-$REQUEST_ID" -q
PUBKEY="$(cat "$KEY.pub")"

SIGN_BODY="$(jq -nc --arg rid "$REQUEST_ID" --arg pk "$PUBKEY" \
  '{request_id:$rid, public_key:$pk}')"
SIGN_OUT="$(api POST /api/sign "$SIGN_BODY")"
SIGN_STATUS="$(api_status "$SIGN_OUT")"; SIGN_RESP="$(api_body "$SIGN_OUT")"
[ "$SIGN_STATUS" = "200" ] || die "sign failed (HTTP $SIGN_STATUS): $(echo "$SIGN_RESP" | jq -r '.error // .' 2>/dev/null)"
# ssh auto-loads the cert when it sits next to the key as <key>-cert.pub.
echo "$SIGN_RESP" | jq -r '.certificate' > "$KEY-cert.pub"
[ -s "$KEY-cert.pub" ] || die "empty certificate returned"
# username from the request is authoritative; sign echoes it too.
USERNAME="$(echo "$SIGN_RESP" | jq -r --arg u "$USERNAME" '.username // $u')"
echo "   certificate issued (valid_seconds: $(echo "$SIGN_RESP" | jq -r '.valid_seconds // "?"'))"

# --- 5. VEND scoped SSM credentials (the credential-less core) ----------------
echo "-> [4/6] vending scoped SSM credentials (POST /api/session/{id}/ssm-credentials)..."
CRED_OUT="$(api POST "/api/session/$REQUEST_ID/ssm-credentials")"
CRED_STATUS="$(api_status "$CRED_OUT")"; CRED_RESP="$(api_body "$CRED_OUT")"
[ "$CRED_STATUS" = "200" ] || die "credential vend failed (HTTP $CRED_STATUS): $(echo "$CRED_RESP" | jq -r '.error // .' 2>/dev/null)"

VEND_AK="$(echo "$CRED_RESP" | jq -r '.access_key_id')"
VEND_SK="$(echo "$CRED_RESP" | jq -r '.secret_access_key')"
VEND_ST="$(echo "$CRED_RESP" | jq -r '.session_token')"
[ -n "$VEND_AK" ] && [ "$VEND_AK" != "null" ] || die "no credentials in vend response"
echo "   vended STS creds (expire: $(echo "$CRED_RESP" | jq -r '.expiration'))"
echo "   these creds can ONLY start an SSM session to $INSTANCE — nothing else."

# --- 6. open the SSM port-forward tunnel using ONLY the vended creds ----------
echo "-> [5/6] opening SSM port-forward tunnel (localhost:$PORT_LOCAL -> $INSTANCE:$PORT_REMOTE)..."
SSM_PARAMS="$(jq -nc --arg pr "$PORT_REMOTE" --arg pl "$PORT_LOCAL" \
  '{portNumber:[$pr], localPortNumber:[$pl]}')"

# CRITICAL: the tunnel subshell gets ONLY the vended creds. We scrub any
# ambient AWS_* AND isolate from the shared credentials/config files, so a
# stray personal profile (env OR ~/.aws default profile) can NEVER be what
# makes this work — that is the ADR-0018 trap: env-only scrubbing still falls
# back to the [default] profile in ~/.aws/credentials. Empty isolated files
# guarantee the vended creds are the ONLY credential source. If they are bad,
# the tunnel fails — the correct, honest failure.
EMPTY_AWS_DIR="$WORKDIR/aws-empty"
mkdir -p "$EMPTY_AWS_DIR"
: > "$EMPTY_AWS_DIR/credentials"
: > "$EMPTY_AWS_DIR/config"
(
  env -u AWS_PROFILE -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY -u AWS_SESSION_TOKEN \
    AWS_SHARED_CREDENTIALS_FILE="$EMPTY_AWS_DIR/credentials" \
    AWS_CONFIG_FILE="$EMPTY_AWS_DIR/config" \
    AWS_ACCESS_KEY_ID="$VEND_AK" \
    AWS_SECRET_ACCESS_KEY="$VEND_SK" \
    AWS_SESSION_TOKEN="$VEND_ST" \
    aws ssm start-session \
      --region "$REGION" \
      --target "$INSTANCE" \
      --document-name AWS-StartPortForwardingSession \
      --parameters "$SSM_PARAMS"
) &
SSM_PID=$!

# Wait for the local port to accept connections (bounded).
echo "   waiting for tunnel to come up..."
tunnel_up=false
for _ in $(seq 1 30); do
  if bash -c "exec 3<>/dev/tcp/127.0.0.1/$PORT_LOCAL" 2>/dev/null; then
    exec 3>&- 3<&- 2>/dev/null || true
    tunnel_up=true
    break
  fi
  kill -0 "$SSM_PID" 2>/dev/null || die "SSM session exited before the tunnel opened (check the vended creds / instance)"
  sleep 1
done
[ "$tunnel_up" = true ] || die "tunnel did not open on localhost:$PORT_LOCAL"
echo "   tunnel is up."

# --- 7. ssh over the tunnel using the cert (no password) ----------------------
echo "-> [6/6] connecting via SSH (certificate auth, no password)..."
echo ""
ssh \
  -o StrictHostKeyChecking=no \
  -o UserKnownHostsFile=/dev/null \
  -o IdentitiesOnly=yes \
  -i "$KEY" \
  -p "$PORT_LOCAL" \
  "$USERNAME@localhost"

# On ssh exit, trap cleanup tears down the tunnel and shreds the keys.
echo ""
echo "Session closed. Tunnel torn down, ephemeral key material shredded."
