#!/usr/bin/env bash
###############################################################################
# prove-credential-less.sh  (ADR-0018 — the ONLY proof that counts)
#
# Proves the SSM tunnel is credential-less for the user: the AWS credentials
# come from the portal's ssm-credentials endpoint, NOT from the operator's
# machine. This is the difference between "works on your laptop" and "works
# for a credential-less customer".
#
# WHY THIS SCRIPT EXISTS (the trap it defeats):
#   Scrubbing only the four AWS_* env vars is NOT enough. The AWS CLI also
#   reads ~/.aws/credentials — and this box HAS a [default] profile there.
#   If that default is valid (e.g. after a personal-faws refresh), an
#   env-only-scrubbed test would SILENTLY pass using the default profile, not
#   the vended creds — the exact false-positive ADR-0018 warns about. This
#   harness isolates BOTH sources: it unsets the env vars AND repoints
#   AWS_SHARED_CREDENTIALS_FILE / AWS_CONFIG_FILE at empty files. Only then is
#   the environment genuinely credential-less.
#
# WHAT IT DOES:
#   1. Builds a truly credential-less environment (env scrubbed + empty
#      ~/.aws files).
#   2. ASSERTS `aws sts get-caller-identity` FAILS in that environment. If it
#      SUCCEEDS, the box still has ambient creds and the proof is INVALID —
#      the script aborts and tells you so. (Do NOT "fix" this by adding creds.)
#   3. Runs passport-connect.sh inside that same environment. If it still
#      tunnels + sshs, the creds provably came from the endpoint.
#
# Usage:
#   PORTAL_TOKEN=<jwt> ./scripts/prove-credential-less.sh \
#     --instance i-0abc123 --region us-east-2 [--ttl 60] \
#     [--base-url https://portal.takahe.click]
#
# NOTE (SoD, ADR-0018): DEPLOY steps (terraform apply, portal build/upload)
# are run by greg with AWS_PROFILE=personal-faws. THIS script is the
# BROKER-TEST and must be run with the profile NOT present — that is the
# entire point. It refuses to run if it detects working ambient credentials.
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONNECT="$SCRIPT_DIR/passport-connect.sh"

die() { echo "ERROR: $*" >&2; exit 1; }

[ -f "$CONNECT" ] || die "passport-connect.sh not found next to this script"
[ -n "${PORTAL_TOKEN:-}" ] || die "set PORTAL_TOKEN=<jwt> (identity only — NOT an AWS credential)"

# Empty, isolated AWS credential/config files so there is NO shared-file
# fallback. Combined with unsetting the env vars, the environment is genuinely
# credential-less.
ISO_DIR="$(mktemp -d "${TMPDIR:-/tmp}/prove-credless.XXXXXX")"
trap 'rm -rf "$ISO_DIR"' EXIT
: > "$ISO_DIR/credentials"
: > "$ISO_DIR/config"

# The scrubbing prefix applied to every command in the proof environment.
scrubbed() {
  env -u AWS_PROFILE -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY -u AWS_SESSION_TOKEN \
    AWS_SHARED_CREDENTIALS_FILE="$ISO_DIR/credentials" \
    AWS_CONFIG_FILE="$ISO_DIR/config" \
    "$@"
}

echo "=============================================="
echo " ADR-0018 Credential-less Proof"
echo "=============================================="
echo ""
echo "-> Step 1: assert the environment has NO usable AWS credentials..."

# We EXPECT this to fail. If it succeeds, the proof is invalid.
if scrubbed aws sts get-caller-identity >/dev/null 2>&1; then
  echo ""
  echo "  !!! get-caller-identity SUCCEEDED in the scrubbed environment."
  echo "  !!! That means ambient AWS credentials are still reachable, so a"
  echo "  !!! successful connect would NOT prove the endpoint vended the creds."
  echo "  !!! The proof is INVALID. Investigate the credential source; do NOT"
  echo "  !!! proceed. (This is the ADR-0018 false-positive trap.)"
  die "environment is not credential-less"
fi
echo "   OK: aws sts get-caller-identity FAILS (no ambient creds). Good."
echo ""

echo "-> Step 2: run passport-connect.sh in that same credential-less environment..."
echo "   If this tunnels + sshs, the creds came from the endpoint. That is the proof."
echo ""

# Run the real connect flow inside the credential-less environment. Any success
# from here on cannot be attributed to laptop credentials.
scrubbed env PORTAL_TOKEN="$PORTAL_TOKEN" bash "$CONNECT" "$@"
