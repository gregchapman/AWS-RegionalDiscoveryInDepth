#!/usr/bin/env python3
"""One-time data cleanup: converge stranded session records to a terminal state.

Background (ADR-0023)
---------------------
Before the conductor redesign, `terminate_session` called
`states:StopExecution`, which ABORTED the Step Function execution before it
could write a terminal status. That stranded the session record at a
non-terminal status (CLEANING_UP or END_REQUESTED) forever: no conductor is
left running to finish the teardown, so the record never converges. This
produced ~81 Aborted executions and a matching pile of stuck records.

After the redesign no new records can get stranded this way (the conductor is
never aborted). But the ALREADY-stranded rows remain, cluttering the portal's
session list (list_sessions now returns END_REQUESTED / CLEANING_UP as
"Ending…") and the operator view. This script is the ONE-TIME sweep for that
pre-existing debris.

What it does
------------
Finds every record whose status is CLEANING_UP or END_REQUESTED and marks it
COMPLETED, stamping an audit note so the row's history stays honest for the
FedRAMP audit trail (AC-2 / AU-2). Records are NOT deleted — the account of
who had access and when is preserved; only the lifecycle status is corrected.

Safety
------
  * DRY-RUN BY DEFAULT. It prints exactly what it would change and touches
    nothing until you pass --apply.
  * Idempotent: re-running after --apply finds nothing (the rows are now
    terminal) and is a no-op.
  * Optional --older-than-minutes guard so an in-flight teardown that is
    legitimately mid-CLEANING_UP right now is not clobbered. Default 15 min —
    comfortably longer than a real teardown (poll 10s + bounded cleanup retry).
  * Uses a ConditionExpression so it only writes if the status is STILL the
    stranded value it read (never races the live conductor).

Usage
-----
    # See what's stranded (safe, read-only):
    AWS_PROFILE=personal-faws python3 scripts/purge-stranded-sessions.py

    # Actually converge them:
    AWS_PROFILE=personal-faws python3 scripts/purge-stranded-sessions.py --apply

    # Only touch rows stranded for > 60 minutes:
    AWS_PROFILE=personal-faws python3 scripts/purge-stranded-sessions.py \
        --apply --older-than-minutes 60

    # Delete instead of marking COMPLETED (not recommended — loses audit trail):
    AWS_PROFILE=personal-faws python3 scripts/purge-stranded-sessions.py \
        --apply --delete
"""

import argparse
import datetime as dt
import os
import sys

import boto3
from botocore.exceptions import ClientError

TABLE_NAME = "fedramp-portal-access-requests"
STATUS_INDEX = "status-index"
STRANDED_STATUSES = ("CLEANING_UP", "END_REQUESTED")

# ISO-8601 timestamps in this table are written with a trailing 'Z' (UTC).
_ISO_FORMATS = ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S")


def _parse_created_at(value: str):
    """Best-effort parse of a created_at string into a tz-naive UTC datetime.

    Returns None if it can't be parsed (in which case the age guard treats the
    row as OLD — stranded rows should be swept, and an unparseable timestamp on
    an already-stuck row shouldn't shield it forever).
    """
    if not value:
        return None
    for fmt in _ISO_FORMATS:
        try:
            return dt.datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


def find_stranded(ddb):
    """Query the status-index GSI for each stranded status. Returns list of items."""
    stranded = []
    for status in STRANDED_STATUSES:
        params = {
            "TableName": TABLE_NAME,
            "IndexName": STATUS_INDEX,
            "KeyConditionExpression": "#s = :s",
            "ExpressionAttributeNames": {"#s": "status"},
            "ExpressionAttributeValues": {":s": {"S": status}},
        }
        while True:
            resp = ddb.query(**params)
            stranded.extend(resp.get("Items", []))
            lek = resp.get("LastEvaluatedKey")
            if not lek:
                break
            params["ExclusiveStartKey"] = lek
    return stranded


def is_old_enough(item, older_than_minutes: int) -> bool:
    """True if the row is older than the guard window (safe to touch)."""
    if older_than_minutes <= 0:
        return True
    created = _parse_created_at(item.get("created_at", {}).get("S", ""))
    if created is None:
        return True  # unparseable timestamp on a stuck row -> sweep it
    age = dt.datetime.utcnow() - created
    return age >= dt.timedelta(minutes=older_than_minutes)


def converge(ddb, item, delete: bool):
    """Mark one stranded row COMPLETED (or delete it). Condition-guarded."""
    request_id = item.get("request_id", {}).get("S", "")
    created_at = item.get("created_at", {}).get("S", "")
    current = item.get("status", {}).get("S", "")
    key = {"request_id": {"S": request_id}, "created_at": {"S": created_at}}

    if delete:
        ddb.delete_item(
            TableName=TABLE_NAME,
            Key=key,
            ConditionExpression="#s = :cur",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":cur": {"S": current}},
        )
        return

    note = (
        "Converged by purge-stranded-sessions.py (ADR-0023): execution was "
        "aborted by the old stop_execution path before writing a terminal "
        f"state; original stranded status was {current}."
    )
    ddb.update_item(
        TableName=TABLE_NAME,
        Key=key,
        UpdateExpression="SET #s = :done, purge_note = :note, purged_at = :ts",
        ConditionExpression="#s = :cur",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={
            ":done": {"S": "COMPLETED"},
            ":cur": {"S": current},
            ":note": {"S": note},
            ":ts": {"S": dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")},
        },
    )


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--apply", action="store_true",
        help="Actually write changes. Without this the script is a dry run.",
    )
    parser.add_argument(
        "--delete", action="store_true",
        help="Delete stranded rows instead of marking COMPLETED "
             "(loses audit trail; not recommended).",
    )
    parser.add_argument(
        "--older-than-minutes", type=int, default=15,
        help="Only touch rows stranded longer than this (default 15) so a "
             "legitimately in-flight teardown is not clobbered. 0 = no guard.",
    )
    parser.add_argument(
        "--region", default=os.environ.get("AWS_REGION")
        or os.environ.get("AWS_DEFAULT_REGION") or "us-east-1",
        help="Region the access-requests table lives in. Defaults to "
             "$AWS_REGION / $AWS_DEFAULT_REGION, else us-east-1 (the portal "
             "management region).",
    )
    args = parser.parse_args(argv)

    # The table is in the management region (us-east-1). A bare AWS_PROFILE with
    # no configured region leaves boto3 with nothing (NoRegionError), so we
    # resolve it explicitly here rather than relying on ambient config.
    ddb = boto3.client("dynamodb", region_name=args.region)  # creds from profile/env

    try:
        items = find_stranded(ddb)
    except ClientError as e:
        print(f"ERROR querying {TABLE_NAME}: {e}", file=sys.stderr)
        return 2

    if not items:
        print("No stranded records (status in "
              f"{', '.join(STRANDED_STATUSES)}). Nothing to do.")
        return 0

    eligible = [i for i in items if is_old_enough(i, args.older_than_minutes)]
    skipped = len(items) - len(eligible)

    action = "DELETE" if args.delete else "mark COMPLETED"
    mode = "APPLY" if args.apply else "DRY-RUN"
    print(f"[{mode}] Found {len(items)} stranded record(s); "
          f"{len(eligible)} eligible to {action}"
          + (f" ({skipped} within the {args.older_than_minutes}-min guard, "
             f"skipped)" if skipped else "") + ".\n")

    changed = 0
    for item in eligible:
        rid = item.get("request_id", {}).get("S", "")
        created = item.get("created_at", {}).get("S", "")
        status = item.get("status", {}).get("S", "")
        email = item.get("user_email", {}).get("S", "") or \
            item.get("user_id", {}).get("S", "")
        line = f"  {status:12s} {rid}  created={created}  user={email}"
        if not args.apply:
            print(line + "   -> would " + action)
            continue
        try:
            converge(ddb, item, args.delete)
            changed += 1
            print(line + "   -> " + action + " OK")
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code == "ConditionalCheckFailedException":
                print(line + "   -> SKIPPED (status changed under us; "
                      "conductor likely finished it)")
            else:
                print(line + f"   -> ERROR: {e}")

    print()
    if args.apply:
        print(f"Done. {changed} record(s) converged.")
    else:
        print("Dry run only. Re-run with --apply to converge these records.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
