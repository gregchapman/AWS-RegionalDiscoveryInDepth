#!/usr/bin/env bash
###############################################################################
# verify-deployment.sh
#
# Post-deployment verification: confirms each resource exists and is reachable.
# Run after collect-outputs.sh to validate the deployment actually works.
#
# Usage:
#   ./scripts/verify-deployment.sh
#
# Checks (ADR-0019: CloudFront removed; front door is the API Gateway):
#   - S3 SPA bucket exists and is PRIVATE
#   - Route 53 hosted zone + ACM cert ISSUED
#   - API Gateway /api/* requires auth (401); front door serves SPA (200)
#   - Cognito User Pool, DynamoDB table, Step Function exist
#   - Lambda functions exist (incl. serve_spa front door + sign_key SSH CA)
#   - SSH CA secret + public-key param populated
#   - EC2 instances running with SSM agent online
#   - CloudTrail logging + SSM session document (layer 05)
###############################################################################

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
TF_DIR="$PROJECT_DIR/terraform"

PASS=0
FAIL=0
SKIP=0

check() {
  local description="$1"
  local command="$2"

  printf "  %-50s" "$description"
  if eval "$command" >/dev/null 2>&1; then
    echo "✓ PASS"
    PASS=$((PASS + 1))
  else
    echo "✗ FAIL"
    FAIL=$((FAIL + 1))
  fi
}

skip() {
  local description="$1"
  printf "  %-50s" "$description"
  echo "— SKIP"
  SKIP=$((SKIP + 1))
}

echo "=============================================="
echo " FedRAMP Portal — Deployment Verification"
echo "=============================================="
echo ""

# --- Layer 00: Backend ---
echo "▸ 00-backend"
if cd "$TF_DIR/00-backend" 2>/dev/null && [ -d ".terraform" ]; then
  BUCKET=$(terraform output -raw state_bucket_name 2>/dev/null || echo "")
  TABLE=$(terraform output -raw lock_table_name 2>/dev/null || echo "")
  check "S3 state bucket exists" "aws s3api head-bucket --bucket '$BUCKET'"
  check "DynamoDB lock table exists" "aws dynamodb describe-table --table-name '$TABLE' --region us-east-1"
else
  skip "00-backend (not deployed)"
  skip "00-backend (not deployed)"
fi
echo ""

# --- Layer 01: Identity Center ---
echo "▸ 01-identity-center"
if cd "$TF_DIR/01-identity-center" 2>/dev/null && [ -d ".terraform" ]; then
  PS_ARN=$(terraform output -raw rgs_admin_permission_set_arn 2>/dev/null || echo "")
  IC_ARN=$(terraform output -raw identity_center_arn 2>/dev/null || echo "")
  check "Identity Center instance exists" "aws sso-admin list-instances --region us-east-1"
  check "RGS-Admin permission set exists" "aws sso-admin describe-permission-set --instance-arn '$IC_ARN' --permission-set-arn '$PS_ARN' --region us-east-1"
else
  skip "01-identity-center (not deployed)"
  skip "01-identity-center (not deployed)"
fi
echo ""

# --- Layer 02: Portal Hosting (SPA bucket + Route 53 zone + ACM cert) ---
# ADR-0019: CloudFront removed. This layer is now the hosting substrate.
echo "▸ 02-portal-hosting"
if cd "$TF_DIR/02-portal-hosting" 2>/dev/null && [ -d ".terraform" ]; then
  SPA_BUCKET=$(terraform output -raw spa_bucket_name 2>/dev/null || echo "")
  ZONE_ID=$(terraform output -raw hosted_zone_id 2>/dev/null || echo "")
  CERT_ARN=$(terraform output -raw acm_certificate_arn 2>/dev/null || echo "")
  check "SPA S3 bucket exists (private)" "aws s3api head-bucket --bucket '$SPA_BUCKET'"
  check "SPA bucket blocks public access" "aws s3api get-public-access-block --bucket '$SPA_BUCKET' --query 'PublicAccessBlockConfiguration.RestrictPublicBuckets' --output text | grep -qi true"
  check "Route 53 hosted zone exists" "aws route53 get-hosted-zone --id '$ZONE_ID'"
  check "ACM certificate ISSUED" "aws acm describe-certificate --certificate-arn '$CERT_ARN' --region us-east-1 --query 'Certificate.Status' --output text | grep -q ISSUED"
else
  skip "02-portal-hosting (not deployed)"
  skip "02-portal-hosting (not deployed)"
  skip "02-portal-hosting (not deployed)"
  skip "02-portal-hosting (not deployed)"
fi
echo ""

# --- Layer 03: API + front door (SPA serving, SSH CA, WAF, custom domain) ---
echo "▸ 03-api"
if cd "$TF_DIR/03-api" 2>/dev/null && [ -d ".terraform" ]; then
  API_URL=$(terraform output -raw api_gateway_url 2>/dev/null || echo "")
  POOL_ID=$(terraform output -raw cognito_user_pool_id 2>/dev/null || echo "")
  TABLE_NAME=$(terraform output -raw dynamodb_table_name 2>/dev/null || echo "")
  SFN_ARN=$(terraform output -raw step_function_arn 2>/dev/null || echo "")
  PORTAL_DOMAIN=$(terraform output -raw portal_custom_domain 2>/dev/null || echo "")

  # /api/* is JWT-protected: 401 = authorizer working.
  check "API /api/* requires auth (401)" "curl -sf -o /dev/null -w '%{http_code}' '${API_URL}api/accounts' | grep -q '401'"
  check "Cognito User Pool exists" "aws cognito-idp describe-user-pool --user-pool-id '$POOL_ID' --region us-east-1"
  check "DynamoDB access-requests table exists" "aws dynamodb describe-table --table-name '$TABLE_NAME' --region us-east-1"
  check "Step Function state machine exists" "aws stepfunctions describe-state-machine --state-machine-arn '$SFN_ARN' --region us-east-1"
  check "Lambda: list-accounts exists" "aws lambda get-function --function-name fedramp-portal-list-accounts --region us-east-1"
  check "Lambda: list-instances exists" "aws lambda get-function --function-name fedramp-portal-list-instances --region us-east-1"
  check "Lambda: create-access-request exists" "aws lambda get-function --function-name fedramp-portal-create-access-request --region us-east-1"
  check "Lambda: get-session-status exists" "aws lambda get-function --function-name fedramp-portal-get-session-status --region us-east-1"
  check "Lambda: sign-key (SSH CA) exists" "aws lambda get-function --function-name fedramp-portal-sign-key --region us-east-1"
  check "Lambda: serve-spa (front door) exists" "aws lambda get-function --function-name fedramp-portal-serve-spa --region us-east-1"
  check "SSH CA secret exists" "aws secretsmanager describe-secret --secret-id fedramp-portal/ssh-ca-private-key --region us-east-1"
  check "SSH CA public-key param populated (not placeholder)" "aws ssm get-parameter --name /fedramp-portal/ssh-ca-public-key --region us-east-1 --query 'Parameter.Value' --output text | grep -q '^ssh-'"

  # Front door: SPA served same-origin over the custom domain (public shell = 200).
  if [ -n "$PORTAL_DOMAIN" ]; then
    check "Front door serves SPA (200 at https://$PORTAL_DOMAIN)" "curl -sf -o /dev/null -w '%{http_code}' 'https://$PORTAL_DOMAIN/' | grep -q '200'"
    check "Front door /api/* requires auth (401)" "curl -sf -o /dev/null -w '%{http_code}' 'https://$PORTAL_DOMAIN/api/accounts' | grep -q '401'"
  else
    skip "Front door custom domain (not configured yet)"
    skip "Front door /api auth (not configured yet)"
  fi
else
  skip "03-api (not deployed)"
fi
echo ""

# --- Layer 04: Test Environment ---
echo "▸ 04-test-environment"
if cd "$TF_DIR/04-test-environment" 2>/dev/null && [ -d ".terraform" ]; then
  LINUX_1=$(terraform output -raw customer1_linux_instance_id 2>/dev/null || echo "")
  WIN_1=$(terraform output -raw customer1_windows_instance_id 2>/dev/null || echo "")
  LINUX_2=$(terraform output -raw customer2_linux_instance_id 2>/dev/null || echo "")
  WIN_2=$(terraform output -raw customer2_windows_instance_id 2>/dev/null || echo "")

  check "customer1 Linux running" "aws ec2 describe-instance-status --instance-id '$LINUX_1' --region us-east-2 --query 'InstanceStatuses[0].InstanceState.Name' --output text | grep running"
  check "customer1 Windows running" "aws ec2 describe-instance-status --instance-id '$WIN_1' --region us-east-2 --query 'InstanceStatuses[0].InstanceState.Name' --output text | grep running"
  check "customer2 Linux running" "aws ec2 describe-instance-status --instance-id '$LINUX_2' --region us-west-1 --query 'InstanceStatuses[0].InstanceState.Name' --output text | grep running"
  check "customer2 Windows running" "aws ec2 describe-instance-status --instance-id '$WIN_2' --region us-west-1 --query 'InstanceStatuses[0].InstanceState.Name' --output text | grep running"

  # SSM agent connectivity
  check "SSM agent online: customer1 Linux" "aws ssm describe-instance-information --filters Key=InstanceIds,Values='$LINUX_1' --region us-east-2 --query 'InstanceInformationList[0].PingStatus' --output text | grep Online"
  check "SSM agent online: customer1 Windows" "aws ssm describe-instance-information --filters Key=InstanceIds,Values='$WIN_1' --region us-east-2 --query 'InstanceInformationList[0].PingStatus' --output text | grep Online"
  check "SSM agent online: customer2 Linux" "aws ssm describe-instance-information --filters Key=InstanceIds,Values='$LINUX_2' --region us-west-1 --query 'InstanceInformationList[0].PingStatus' --output text | grep Online"
  check "SSM agent online: customer2 Windows" "aws ssm describe-instance-information --filters Key=InstanceIds,Values='$WIN_2' --region us-west-1 --query 'InstanceInformationList[0].PingStatus' --output text | grep Online"
else
  skip "04-test-environment (not deployed)"
fi
echo ""

# --- Layer 05: Security Baseline (CloudTrail + SSM session logging) ---
# GuardDuty/SecurityHub/Config are org-managed (enable_*=false); only CloudTrail
# + SSM session logging deploy here.
echo "▸ 05-security-baseline"
if cd "$TF_DIR/05-security-baseline" 2>/dev/null && [ -d ".terraform" ]; then
  check "CloudTrail trail exists + logging" "aws cloudtrail get-trail-status --name fedramp-portal-trail --region us-east-1 --query 'IsLogging' --output text | grep -qi true"
  check "CloudTrail log-file validation enabled" "aws cloudtrail describe-trails --trail-name-list fedramp-portal-trail --region us-east-1 --query 'trailList[0].LogFileValidationEnabled' --output text | grep -qi true"
  check "SSM session document exists" "aws ssm describe-document --name SSM-SessionManagerRunShell --region us-east-1"
else
  skip "05-security-baseline (not deployed)"
  skip "05-security-baseline (not deployed)"
  skip "05-security-baseline (not deployed)"
fi
echo ""

# --- Summary ---
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Results: $PASS passed, $FAIL failed, $SKIP skipped"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ $FAIL -gt 0 ]; then
  exit 1
fi
