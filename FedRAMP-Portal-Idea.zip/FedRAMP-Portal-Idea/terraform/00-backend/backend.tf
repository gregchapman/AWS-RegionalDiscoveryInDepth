# After first apply, this migrates state into the bucket this layer created.
# Run: terraform init -migrate-state

terraform {
  backend "s3" {
    bucket         = "fedramp-portal-tfstate-675405875014"
    key            = "00-backend/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "fedramp-portal-tflock"
    encrypt        = true
  }
}
