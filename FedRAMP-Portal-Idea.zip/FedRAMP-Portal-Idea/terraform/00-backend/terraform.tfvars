###############################################################################
# 00-backend: Terraform State Backend Configuration
#
# This layer creates the S3 bucket and DynamoDB table that store Terraform
# state for ALL other layers. Deploy this first, with local state, then
# migrate state into the bucket (see backend.tf for instructions).
#
# Account: 675405875014 (AWS Commercial)
# Region:  us-east-1 (management region for all FedRAMP Portal infra)
###############################################################################

# AWS region where the state backend lives.
# This should be the same region used for all management-plane resources.
# Default: "us-east-1"
# Possible: Any AWS region, but us-east-1 is conventional for state.
aws_region = "us-east-1"

# Environment tag applied to all resources in this layer.
# Default: "dev"
# Possible: "dev", "staging", "prod"
environment = "dev"

# S3 bucket name for Terraform state files.
# MUST be globally unique across all AWS accounts.
# Convention: <project>-tfstate or <project>-<account-id>-tfstate
# Default: "fedramp-portal-tfstate"
state_bucket_name = "fedramp-portal-tfstate-675405875014"

# DynamoDB table name for state locking.
# Prevents concurrent terraform apply from corrupting state.
# Default: "fedramp-portal-tflock"
lock_table_name = "fedramp-portal-tflock"
