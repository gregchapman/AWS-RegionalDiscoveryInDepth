###############################################################################
# 02-portal-hosting: SPA asset bucket + DNS + TLS certificate
#
# REBUILT per ADR-0019: CloudFront is banned (not a GovCloud service, global/
# non-CONUS edge -> violates SC-7/SC-8/PE for IL4). This layer no longer fronts
# the portal. Its job is now the "hosting substrate" the layer-03 API Gateway
# front door consumes:
#   - a PRIVATE S3 bucket holding the built React SPA assets (served by a Lambda
#     on the layer-03 HTTP API $default route — NOT public, NO website hosting)
#   - the Route 53 PUBLIC hosted zone for the portal domain
#   - the ACM (regional) certificate for the portal custom domain, DNS-validated
#     via a CNAME in the zone above (ADR-0019: API Gateway REGIONAL custom domain)
#
# Layer 03 reads the outputs here (bucket, zone, cert, domain) and attaches the
# custom domain to its HTTP API, adds the Route 53 ALIAS record, and serves the
# SPA. Dependencies point backward (02 < 03), honoring ADR-0009.
#
# DRIFT/DESTROY POLICY (owner directive): this layer must return "No changes" on
# every subsequent apply and must never destroy-recreate the zone/cert/bucket.
# The hosted zone is the sensitive one — recreating it yields a NEW NS set,
# breaking registrar delegation + ACM validation. prevent_destroy guards these.
#
# NOTE: DNSSEC is intentionally NOT included for the commercial POC (adds a KMS
# KSK + registrar DS-record coordination + more drift surface). It is an
# inheritance win (ADR-0020) to add for the GovCloud/IL4 build, tracked in todo.
###############################################################################

terraform {
  required_version = ">= 1.5"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "fedramp-portal"
      Layer       = "02-portal-hosting"
      ManagedBy   = "terraform"
      Environment = var.environment
    }
  }
}

data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}

locals {
  partition = data.aws_partition.current.partition # "aws" | "aws-us-gov" (ADR-0017)
  # Full portal host, e.g. "portal.takahe.click"
  portal_domain = "${var.portal_subdomain}.${var.domain_name}"

  # CREATE-vs-CONSUME (ADR-0017): in the POC we CREATE the zone + cert; in
  # production we CONSUME a pre-existing agency domain + (imported) cert. The
  # outputs below resolve to whichever path is active, so layer 03 consumes a
  # single stable interface regardless of mode.
  hosted_zone_id = var.manage_dns ? aws_route53_zone.portal[0].zone_id : var.existing_hosted_zone_id
  certificate_arn = var.manage_certificate ? aws_acm_certificate_validation.portal[0].certificate_arn : var.existing_certificate_arn
}

###############################################################################
# S3 Bucket — SPA static assets (PRIVATE; served via layer-03 Lambda)
#
# No public access, no S3 website hosting, no bucket policy granting read to
# anyone. The layer-03 SPA Lambda (its execution role) is the only reader, via
# s3:GetObject granted in layer 03. This keeps the bucket fully private and the
# origin protected by the regional front door (replaces CloudFront OAC).
###############################################################################

resource "aws_s3_bucket" "spa" {
  bucket = var.portal_bucket_name

  # Do not allow accidental destroy — assets are re-uploaded, but the bucket
  # name is referenced by layer 03 and is globally unique (painful to churn).
  lifecycle {
    prevent_destroy = true
  }
}

resource "aws_s3_bucket_versioning" "spa" {
  bucket = aws_s3_bucket.spa.id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "spa" {
  bucket = aws_s3_bucket.spa.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_public_access_block" "spa" {
  bucket = aws_s3_bucket.spa.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Expire old asset versions (each deploy re-uploads; keep history bounded).
resource "aws_s3_bucket_lifecycle_configuration" "spa" {
  bucket = aws_s3_bucket.spa.id

  rule {
    id     = "expire-old-asset-versions"
    status = "Enabled"

    filter {} # empty filter = whole bucket (avoids provider "one of filter/prefix" warning)

    noncurrent_version_expiration {
      noncurrent_days = 30
    }
  }
}

###############################################################################
# Route 53 — PUBLIC hosted zone for the portal domain
#
# The domain itself is REGISTERED out of band by the owner (purchase + DEPLOY,
# ADR-0018). If registered IN Route 53, delegation to this zone's NS set is
# automatic. If registered elsewhere, set the registrar's nameservers to this
# zone's `name_servers` output (one-time) before ACM can validate.
###############################################################################

resource "aws_route53_zone" "portal" {
  count = var.manage_dns ? 1 : 0 # CONSUME a pre-existing zone in production (ADR-0017)
  name  = var.domain_name

  # Recreating the zone assigns a NEW NS set -> breaks registrar delegation and
  # ACM validation. Never destroy it via terraform.
  lifecycle {
    prevent_destroy = true
  }
}

###############################################################################
# ACM — regional public certificate for the portal host (ADR-0019)
#
# Regional (in var.aws_region) because it is attached to a REGIONAL API Gateway
# custom domain in layer 03 — NOT a CLOUDFRONT-scope cert. DNS-validated via a
# CNAME that ACM returns and we publish into the zone above; validation is
# near-instant because the zone is authoritative in the same account.
###############################################################################

# CONSUME mode (production): set manage_certificate=false and pass an existing
# (typically IMPORTED) cert ARN. ACM does NOT auto-renew imported certificates
# (AWS docs) — renewal is owned by the agency PKI process, which is exactly the
# production requirement. All three resources below are POC-only (count gated).
resource "aws_acm_certificate" "portal" {
  count             = var.manage_certificate ? 1 : 0
  domain_name       = local.portal_domain
  validation_method = "DNS"

  lifecycle {
    create_before_destroy = true
    prevent_destroy       = true
  }
}

# Publish the ACM validation record(s). Type is driven by ACM
# (resource_record_type = "CNAME") rather than hard-coded, so it self-corrects.
resource "aws_route53_record" "acm_validation" {
  for_each = var.manage_certificate ? {
    for dvo in aws_acm_certificate.portal[0].domain_validation_options : dvo.domain_name => {
      name   = dvo.resource_record_name
      record = dvo.resource_record_value
      type   = dvo.resource_record_type
    }
  } : {}

  zone_id         = local.hosted_zone_id
  name            = each.value.name
  type            = each.value.type
  records         = [each.value.record]
  ttl             = 60
  allow_overwrite = true
}

# Gate that completes only once the CNAME(s) resolve and ACM marks the cert
# ISSUED. Layer 03 depends (via remote_state) on the cert ARN; this resource is
# what makes "apply 02, then apply 03" safe.
resource "aws_acm_certificate_validation" "portal" {
  count                   = var.manage_certificate ? 1 : 0
  certificate_arn         = aws_acm_certificate.portal[0].arn
  validation_record_fqdns = [for r in aws_route53_record.acm_validation : r.fqdn]
}
