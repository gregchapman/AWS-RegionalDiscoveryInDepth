###############################################################################
# Outputs — consumed by layer 03-api via terraform_remote_state.
# These REPLACE the old cloudfront_* outputs. Layer 03's remote-state.tf reads
# these to attach the custom domain, serve the SPA, and repoint Cognito URLs.
###############################################################################

output "spa_bucket_name" {
  description = "PRIVATE S3 bucket holding the built SPA assets (layer-03 Lambda reads from it)"
  value       = aws_s3_bucket.spa.id
}

output "spa_bucket_arn" {
  description = "ARN of the SPA asset bucket (layer 03 grants its Lambda s3:GetObject on this)"
  value       = aws_s3_bucket.spa.arn
}

output "hosted_zone_id" {
  description = "Route 53 public hosted zone ID (layer 03 writes the API Gateway ALIAS record here). Resolves to the created zone (POC) or the consumed existing zone (production)."
  value       = local.hosted_zone_id
}

output "hosted_zone_name" {
  description = "Apex domain name (e.g. takahe.click)"
  value       = var.domain_name
}

output "hosted_zone_name_servers" {
  description = "NS set for the created zone (POC only). If the domain is registered OUTSIDE Route 53, point the registrar's nameservers at these (one-time) so ACM can validate. Empty in consume mode."
  value       = var.manage_dns ? aws_route53_zone.portal[0].name_servers : []
}

output "acm_certificate_arn" {
  description = "Regional ACM certificate ARN for the portal host (layer 03 attaches it to the API Gateway custom domain). Resolves to the validated created cert (POC) or the consumed existing/imported cert (production)."
  value       = local.certificate_arn
}

output "portal_domain" {
  description = "Full portal host (e.g. portal.takahe.click) — the API Gateway custom domain and Cognito callback host"
  value       = local.portal_domain
}

output "portal_url" {
  description = "Full HTTPS URL for the portal"
  value       = "https://${local.portal_domain}"
}
