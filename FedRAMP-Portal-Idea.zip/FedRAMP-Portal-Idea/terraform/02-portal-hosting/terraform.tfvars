###############################################################################
# 02-portal-hosting: SPA asset bucket + DNS + TLS certificate
#
# REBUILT per ADR-0019 (CloudFront removed). This layer is the hosting substrate
# the layer-03 API Gateway front door consumes: private SPA bucket, Route 53
# public zone, and the regional ACM cert for the portal host.
#
# Account: 675405875014 (AWS Commercial)
# Region:  us-east-1 (matches the layer-03 API Gateway region)
#
# DEPLOY NOTE: the domain (domain_name) must be REGISTERED out of band by the
# owner first. If registered in Route 53, delegation is automatic. If elsewhere,
# point the registrar NS at this zone's `hosted_zone_name_servers` output before
# ACM validates. See DEPLOYMENT runbook.
###############################################################################

# Region for the SPA bucket, zone records, and the REGIONAL ACM cert.
# Must equal the layer-03 API Gateway region.
aws_region = "us-east-1"

# Environment tag.
environment = "dev"

# PRIVATE S3 bucket for built React SPA assets. Globally unique. Not public.
portal_bucket_name = "fedramp-portal-static-675405875014"

# Registered apex domain this zone is authoritative for.
# COMMERCIAL-POC THROWAWAY domain (ADR-0019). Production IL4 needs .gov/agency.
domain_name = "takahe.click"

# Portal host label -> portal.takahe.click
portal_subdomain = "portal"
