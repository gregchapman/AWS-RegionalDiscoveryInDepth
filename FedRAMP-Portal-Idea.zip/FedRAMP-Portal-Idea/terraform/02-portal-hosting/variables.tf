variable "aws_region" {
  description = "AWS region for the SPA bucket, hosted zone records, and the regional ACM cert. Must match the region where the layer-03 API Gateway front door lives."
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
  default     = "dev"
}

variable "portal_bucket_name" {
  description = "Name of the PRIVATE S3 bucket for the built React SPA assets. Globally unique. Served by the layer-03 SPA Lambda, not public."
  type        = string
  default     = "fedramp-portal-static"
}

variable "domain_name" {
  description = "Registered apex domain that this Route 53 public zone is authoritative for (e.g. takahe.click). Registered out of band by the owner (ADR-0018)."
  type        = string
}

variable "portal_subdomain" {
  description = "Subdomain label for the portal host. Combined with domain_name -> <portal_subdomain>.<domain_name> (e.g. portal.takahe.click). This is the ACM cert SAN and the API Gateway custom domain."
  type        = string
  default     = "portal"
}

###############################################################################
# CREATE-vs-CONSUME toggles (ADR-0017 portability)
#
# POC/model (defaults): manage_dns=true, manage_certificate=true — this layer
# CREATES the Route 53 zone and the ACM cert.
# Production: set both to false and provide existing_hosted_zone_id +
# existing_certificate_arn — this layer CONSUMES a pre-existing agency domain
# and (imported, non-auto-renewing) certificate. Same code, config-driven.
###############################################################################

variable "manage_dns" {
  description = "true = create the Route 53 public hosted zone (POC). false = consume an existing zone via existing_hosted_zone_id (production)."
  type        = bool
  default     = true
}

variable "manage_certificate" {
  description = "true = create + DNS-validate an ACM cert (POC; auto-renews, free). false = consume an existing/imported cert via existing_certificate_arn (production; ACM does NOT auto-renew imported certs — agency PKI owns renewal)."
  type        = bool
  default     = true
}

variable "existing_hosted_zone_id" {
  description = "Pre-existing Route 53 hosted zone ID to consume when manage_dns=false. Ignored when manage_dns=true."
  type        = string
  default     = ""
}

variable "existing_certificate_arn" {
  description = "Pre-existing (regional) ACM certificate ARN to consume when manage_certificate=false. Ignored when manage_certificate=true."
  type        = string
  default     = ""
}
