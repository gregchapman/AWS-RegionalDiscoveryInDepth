#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "== py_compile handlers =="
python3 -m py_compile lambda/terminate_session/handler.py lambda/create_access_request/handler.py && echo "PY_OK"
echo "== ASL well-formed + transition check =="
python3 - <<'PY'
import json,sys
d=json.load(open("state-machine/access-lifecycle.asl.json"))
states=d["States"]
names=set(states)
print("states:",len(names))
# collect all Next / Choice targets / Catch Next / Default
targets=set()
def add(t):
    if t: targets.add(t)
for n,s in states.items():
    add(s.get("Next"))
    add(s.get("Default"))
    for c in s.get("Choices",[]) or []:
        add(c.get("Next"))
    for c in s.get("Catch",[]) or []:
        add(c.get("Next"))
missing=targets-names
print("transition targets:",sorted(targets))
assert not missing, f"MISSING target states: {missing}"
# reachability from StartAt
start=d["StartAt"]; seen=set(); stack=[start]
while stack:
    x=stack.pop()
    if x in seen: continue
    seen.add(x); s=states[x]
    for t in [s.get("Next"),s.get("Default")]:
        if t: stack.append(t)
    for c in s.get("Choices",[]) or []:
        if c.get("Next"): stack.append(c["Next"])
    for c in s.get("Catch",[]) or []:
        if c.get("Next"): stack.append(c["Next"])
unreached=names-seen
print("unreachable states:",sorted(unreached) or "none")
assert not unreached, f"UNREACHABLE: {unreached}"
# terminal states
terms=[n for n,s in states.items() if s.get("End")]
print("terminal states:",terms)
print("ASL_OK")
PY
