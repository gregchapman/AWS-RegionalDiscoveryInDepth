terraform {
  backend "s3" {
    bucket         = "fedramp-portal-tfstate-675405875014"
    key            = "03-api/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "fedramp-portal-tflock"
    encrypt        = true
  }
}
