###############################################################################
# Cognito Pre Token Generation trigger (ADR-0011 attribution fix)
#
# The Cognito ACCESS token (validated by the API Gateway JWT authorizer, and the
# token our handlers read identity from) does not carry `email` — only the ID
# token does. That made username derivation fall back to "unknown". This trigger
# copies `email` (+ custom:customer_id) INTO the access token at issuance, fixing
# attribution at the source for every consumer (AU-2/AU-3/AC-2, ADR-0011).
#
# Requires trigger version V2_0 (set on the pool's lambda_config in main.tf) —
# V1_0 cannot customize access-token claims.
###############################################################################

data "archive_file" "pre_token_generation" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/pre_token_generation"
  output_path = "${path.module}/.build/pre-token-generation.zip"
}

resource "aws_lambda_function" "pre_token_generation" {
  function_name    = "fedramp-portal-pre-token-generation"
  filename         = data.archive_file.pre_token_generation.output_path
  source_code_hash = data.archive_file.pre_token_generation.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn

  environment {
    variables = {
      ENVIRONMENT = var.environment
    }
  }
}

# Allow Cognito to invoke the trigger for THIS user pool only.
resource "aws_lambda_permission" "cognito_pre_token_generation" {
  statement_id  = "AllowCognitoInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.pre_token_generation.function_name
  principal     = "cognito-idp.amazonaws.com"
  source_arn    = aws_cognito_user_pool.portal.arn
}
