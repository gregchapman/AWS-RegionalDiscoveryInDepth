###############################################################################
# Front door (ADR-0019): SPA serving + custom domain + DNS alias
#
# CloudFront is banned for IL4 (commercial-only global edge). This layer 03
# HTTP API is now the SINGLE, same-origin front door for BOTH the SPA and the
# /api/* routes. Pieces:
#   1. serve_spa Lambda on the $default route (authorization_type = NONE) —
#      serves the PUBLIC app shell from layer 02's private SPA bucket.
#   2. Regional custom domain (portal.<domain>) using layer 02's ACM cert +
#      api mapping to the $default stage.
#   3. Route 53 A/AAAA alias in layer 02's zone -> the regional domain target.
#   4. s3:GetObject grant so the SPA Lambda can read the private bucket.
#
# NOTE: there is deliberately NO WAF here. WAFv2 cannot associate to an API
# Gateway HTTP API (v2); the edge-WAF gap (SC-7) is tracked in the compliance
# matrix in docs/ARCHITECTURE.md and in ARCHITECTURE-WEAKNESSES.md. A WAF-bearing
# edge (ALB or REST API v1) is the documented remediation. Do NOT reintroduce
# CloudFront (ADR-0019).
###############################################################################

# --- 1. SPA-serving Lambda + $default route (PUBLIC, no JWT) -----------------

data "archive_file" "serve_spa" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/serve_spa"
  output_path = "${path.module}/.build/serve-spa.zip"
}

resource "aws_lambda_function" "serve_spa" {
  function_name    = "fedramp-portal-serve-spa"
  filename         = data.archive_file.serve_spa.output_path
  source_code_hash = data.archive_file.serve_spa.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn
  # No shared layer: this handler returns asset bodies, not JSON, and imports
  # only stdlib + boto3.

  environment {
    variables = {
      ENVIRONMENT = var.environment
      SPA_BUCKET  = local.spa_bucket_name # from layer 02 remote state
      SPA_INDEX   = "index.html"
    }
  }
}

resource "aws_apigatewayv2_integration" "serve_spa" {
  api_id                 = aws_apigatewayv2_api.portal.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.serve_spa.invoke_arn
  payload_format_version = "2.0"
}

# $default catches everything not matched by a more specific /api/* route.
# authorization_type = NONE: the app shell is PUBLIC; data stays behind the
# JWT-authorized /api/* routes.
resource "aws_apigatewayv2_route" "serve_spa_default" {
  api_id             = aws_apigatewayv2_api.portal.id
  route_key          = "$default"
  target             = "integrations/${aws_apigatewayv2_integration.serve_spa.id}"
  authorization_type = "NONE"
}

resource "aws_lambda_permission" "apigw_serve_spa" {
  statement_id  = "AllowAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.serve_spa.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.portal.execution_arn}/*/*"
}

# --- 5. Let the SPA Lambda read the private SPA bucket (layer 02) -------------

resource "aws_iam_role_policy" "lambda_serve_spa_s3" {
  name = "fedramp-portal-lambda-serve-spa-s3"
  role = aws_iam_role.lambda_exec.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "ReadSPAAssets"
        Effect   = "Allow"
        Action   = ["s3:GetObject"]
        Resource = ["${local.spa_bucket_arn}/*"]
      }
    ]
  })
}

# --- 2. Regional custom domain + API mapping ---------------------------------
# Uses layer 02's regional ACM cert. Only created once a portal domain + cert
# are available (POC: both exist after layer 02 applies). count-guarded so the
# layer still applies cleanly if 02 outputs aren't present yet.

resource "aws_apigatewayv2_domain_name" "portal" {
  count       = local.portal_domain != "" && local.acm_certificate_arn != "" ? 1 : 0
  domain_name = local.portal_domain

  domain_name_configuration {
    certificate_arn = local.acm_certificate_arn
    endpoint_type   = "REGIONAL" # NEVER edge-optimized (that is CloudFront) — ADR-0019
    security_policy = "TLS_1_2"
  }
}

resource "aws_apigatewayv2_api_mapping" "portal" {
  count       = local.portal_domain != "" && local.acm_certificate_arn != "" ? 1 : 0
  api_id      = aws_apigatewayv2_api.portal.id
  domain_name = aws_apigatewayv2_domain_name.portal[0].id
  stage       = aws_apigatewayv2_stage.main.id
}

# --- 4. Route 53 alias record (into layer 02's zone) -------------------------

# Guard MUST include acm_certificate_arn: this record references
# aws_apigatewayv2_domain_name.portal[0], which only exists when the cert is
# present. Keeping the guards identical prevents an index-out-of-range if the
# zone were somehow available without the cert.
resource "aws_route53_record" "portal_alias" {
  count   = local.portal_domain != "" && local.acm_certificate_arn != "" && local.hosted_zone_id != "" ? 1 : 0
  zone_id = local.hosted_zone_id
  name    = local.portal_domain
  type    = "A"

  alias {
    name                   = aws_apigatewayv2_domain_name.portal[0].domain_name_configuration[0].target_domain_name
    zone_id                = aws_apigatewayv2_domain_name.portal[0].domain_name_configuration[0].hosted_zone_id
    evaluate_target_health = false
  }
}

# --- Outputs -----------------------------------------------------------------

output "portal_custom_domain" {
  description = "Portal custom domain attached to the API Gateway front door"
  value       = local.portal_domain
}

output "portal_front_door_url" {
  description = "HTTPS URL of the portal front door (SPA + API, same origin)"
  value       = local.portal_url
}
