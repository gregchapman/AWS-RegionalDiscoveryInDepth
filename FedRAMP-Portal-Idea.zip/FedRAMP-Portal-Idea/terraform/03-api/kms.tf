###############################################################################
# KMS Key for Ephemeral Credential Encryption
#
# Used to encrypt temporary passwords before writing to DynamoDB.
# The Step Function writes encrypted ciphertext; get-session-status Lambda
# decrypts on read. Even if DynamoDB is accessed directly, passwords are
# unreadable without KMS Decrypt permission.
###############################################################################

resource "aws_kms_key" "credentials" {
  description             = "Encrypts ephemeral credentials in DynamoDB"
  deletion_window_in_days = 14
  enable_key_rotation     = true

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "RootAccountFullAccess"
        Effect    = "Allow"
        Principal = { AWS = "arn:${local.partition}:iam::${local.account_id}:root" }
        Action    = "kms:*"
        Resource  = "*"
      },
      {
        Sid    = "LambdaEncryptDecrypt"
        Effect = "Allow"
        Principal = {
          AWS = aws_iam_role.lambda_exec.arn
        }
        Action = [
          "kms:Encrypt",
          "kms:Decrypt",
          "kms:GenerateDataKey"
        ]
        Resource = "*"
      },
      {
        Sid    = "StepFunctionEncrypt"
        Effect = "Allow"
        Principal = {
          AWS = aws_iam_role.sfn_exec.arn
        }
        Action = [
          "kms:Encrypt",
          "kms:GenerateDataKey"
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_kms_alias" "credentials" {
  name          = "alias/fedramp-portal-credentials"
  target_key_id = aws_kms_key.credentials.key_id
}
