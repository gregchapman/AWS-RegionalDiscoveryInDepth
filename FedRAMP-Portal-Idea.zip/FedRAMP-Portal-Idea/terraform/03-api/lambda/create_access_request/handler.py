"""Lambda: POST /api/connect

Creates an access request and kicks off the Step Function that provisions
an ephemeral user on the target instance.

Request body:
  {
    "instance_id": "i-0123456789abcdef0",
    "region": "us-east-2",
    "access_type": "ssh" | "rdp",
    "ttl_minutes": 60  (optional, defaults to env SESSION_TTL_MINUTES)
  }
"""

import uuid
import boto3
import logging
from datetime import datetime, timezone, timedelta
from portal_utils import (
    get_env,
    get_user_from_event,
    json_response,
    error_response,
    parse_body,
    utc_now,
    derive_username,
    authorize_target_instance,
)

logger = logging.getLogger("fedramp-portal")
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    """Handle POST /api/connect."""
    logger.info("create-access-request invoked")

    user = get_user_from_event(event)
    body = parse_body(event)

    # Validate required fields
    instance_id = body.get("instance_id")
    region = body.get("region")
    access_type = body.get("access_type", "ssh")

    if not instance_id:
        return error_response(400, "instance_id is required")
    if not region:
        return error_response(400, "region is required")
    if access_type not in ("ssh", "rdp"):
        return error_response(400, "access_type must be 'ssh' or 'rdp'")

    # Authorize before writing a session record or starting the conductor.
    # Credential vending performs a second check, but it must never be the
    # first tenant gate because provisioning mutates the target host.
    try:
        target_customer_id = authorize_target_instance(instance_id, region, user)
    except PermissionError:
        return error_response(403, "Target instance is not authorized")

    # Access-request TTL (the AUTHORIZATION window). Matches production
    # Passport's 1/4/8/12-hour options. Note this is distinct from the SSH
    # CERTIFICATE lifetime, which sign_key caps at 1 hour independently
    # (ADR-0014: long-lived authorization, short-lived authenticators). The
    # user can reconnect any number of times within this window by signing a
    # fresh cert each time.
    default_ttl = int(get_env("SESSION_TTL_MINUTES", "60"))
    ttl_minutes = body.get("ttl_minutes", default_ttl)
    ttl_minutes = min(max(int(ttl_minutes), 15), 720)  # Clamp: 15 min to 12 hours

    # Build access request record
    request_id = str(uuid.uuid4())
    now = utc_now()
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=ttl_minutes)

    # Port mapping (see below) — compute before building the record
    import random
    if access_type == "rdp":
        port_remote = "3389"
        port_local = str(random.randint(33389, 33999))
    else:
        port_remote = "22"
        port_local = str(random.randint(2222, 2999))

    # Identity-derived username (ADR-0011): the OS user is named for the
    # authenticated person, not a random token, so OS/CloudTrail/SSM logs
    # attribute to a real human.
    username = derive_username(user["email"], request_id, access_type)
    logger.info(f"Derived username '{username}' for identity '{user['email']}'")

    record = {
        "request_id": {"S": request_id},
        "created_at": {"S": now},
        "user_id": {"S": user["user_id"]},
        "user_email": {"S": user["email"]},
        "instance_id": {"S": instance_id},
        "region": {"S": region},
        "access_type": {"S": access_type},
        "ttl_minutes": {"N": str(ttl_minutes)},
        "status": {"S": "PENDING"},
        "expires_at": {"N": str(int(expires_at.timestamp()))},
        "port_local": {"S": port_local},
        "port_remote": {"S": port_remote},
        "provisioned_username": {"S": username},
        # Target tenant (ADR-0025): the customer whose instance this targets.
        "customer_id": {"S": target_customer_id},
    }

    # Write to DynamoDB
    table_name = get_env("TABLE_NAME")
    # Ambient region (AWS_REGION) — portable across regions/partitions (ADR-0017).
    dynamodb = boto3.client("dynamodb")

    try:
        dynamodb.put_item(TableName=table_name, Item=record)
    except Exception as e:
        logger.error(f"DynamoDB put failed: {e}")
        return error_response(500, "Failed to create access request")

    # Start Step Function execution
    sfn_arn = get_env("STATE_MACHINE_ARN")
    sfn = boto3.client("stepfunctions")  # ambient region (ADR-0017)

    sfn_input = {
        "request_id": request_id,
        "created_at": now,
        "instance_id": instance_id,
        "region": region,
        "access_type": access_type,
        "ttl_minutes": ttl_minutes,
        "ttl_seconds": ttl_minutes * 60,
        # ISO8601 expiry — the state machine's poll-loop compares this against
        # $$.State.EnteredTime (also ISO8601) to self-expire at TTL. Must be a
        # timestamp string Step Functions accepts (RFC3339 with offset).
        "expires_at_iso": expires_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "port_remote": port_remote,
        "port_local": port_local,
        "username": username,
        "user_email": user["email"],
        "user_id": user["user_id"],
        "table_name": table_name,
    }

    try:
        execution = sfn.start_execution(
            stateMachineArn=sfn_arn,
            name=f"access-{request_id}",
            input=__import__("json").dumps(sfn_input),
        )
        logger.info(f"Started execution: {execution['executionArn']}")
        # Store the execution ARN so we can terminate it early if requested
        dynamodb.update_item(
            TableName=table_name,
            Key={"request_id": {"S": request_id}, "created_at": {"S": now}},
            UpdateExpression="SET execution_arn = :ea",
            ExpressionAttributeValues={":ea": {"S": execution["executionArn"]}},
        )
    except Exception as e:
        logger.error(f"Step Function start failed: {e}")
        # Update DynamoDB status to FAILED
        dynamodb.update_item(
            TableName=table_name,
            Key={"request_id": {"S": request_id}, "created_at": {"S": now}},
            UpdateExpression="SET #s = :s",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={":s": {"S": "FAILED"}},
        )
        return error_response(500, "Failed to start access provisioning")

    return json_response(202, {
        "request_id": request_id,
        "status": "PENDING",
        "message": "Access request created. Provisioning in progress.",
        "ttl_minutes": ttl_minutes,
        "poll_url": f"/api/session/{request_id}",
    })
