###############################################################################
# 03-api: API Gateway + Cognito + Lambda + DynamoDB + Step Functions
#
# This layer deploys the backend API for the FedRAMP Portal:
#   - Cognito User Pool (auth, groups for Racker vs Customer)
#   - HTTP API Gateway with Cognito JWT authorizer
#   - Lambda functions for each API endpoint
#   - DynamoDB table for access request state
#   - Step Functions state machine for access lifecycle
###############################################################################

terraform {
  required_version = ">= 1.5"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    archive = {
      source  = "hashicorp/archive"
      version = "~> 2.0"
    }
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "fedramp-portal"
      Layer       = "03-api"
      ManagedBy   = "terraform"
      Environment = var.environment
    }
  }
}

data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
data "aws_partition" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  region     = data.aws_region.current.name
  partition  = data.aws_partition.current.partition # "aws" (commercial) or "aws-us-gov" (ADR-0017)

  # Portal URL: the custom domain from layer 02 (ADR-0019 front door), with a
  # manual-override fallback. Replaces the former CloudFront URL derivation.
  resolved_portal_url = local.portal_url != "" ? local.portal_url : var.portal_cloudfront_url

  # Callback URLs: always include localhost for dev; add the portal domain when
  # available. Same-origin now — the SPA and the OAuth callback share the host.
  callback_urls = local.resolved_portal_url != "" ? concat(
    var.cognito_callback_urls,
    ["${local.resolved_portal_url}/callback", local.resolved_portal_url]
  ) : var.cognito_callback_urls

  logout_urls = local.resolved_portal_url != "" ? concat(
    var.cognito_logout_urls,
    [local.resolved_portal_url]
  ) : var.cognito_logout_urls
}

###############################################################################
# Cognito User Pool
###############################################################################

resource "aws_cognito_user_pool" "portal" {
  name = "fedramp-portal-users"

  username_attributes      = ["email"]
  auto_verified_attributes = ["email"]

  password_policy {
    minimum_length                   = 12
    require_lowercase                = true
    require_numbers                  = true
    require_symbols                  = true
    require_uppercase                = true
    temporary_password_validity_days = 1
  }

  mfa_configuration = "ON"

  software_token_mfa_configuration {
    enabled = true
  }

  # Pre Token Generation trigger (ADR-0011 attribution fix). V2_0 is REQUIRED to
  # customize ACCESS-token claims (V1_0 only touches the ID token). This injects
  # `email` (+ custom:customer_id) into the access token so downstream handlers
  # and CloudTrail attribute to a real person, not "unknown". Defined in
  # cognito-triggers.tf.
  lambda_config {
    pre_token_generation_config {
      lambda_arn     = aws_lambda_function.pre_token_generation.arn
      lambda_version = "V2_0"
    }
  }

  account_recovery_setting {
    recovery_mechanism {
      name     = "verified_email"
      priority = 1
    }
  }

  schema {
    attribute_data_type = "String"
    name                = "role"
    mutable             = true
    string_attribute_constraints {
      min_length = 1
      max_length = 50
    }
  }

  schema {
    attribute_data_type = "String"
    name                = "customer_id"
    mutable             = true
    string_attribute_constraints {
      min_length = 0
      max_length = 50
    }
  }
}

resource "aws_cognito_user_pool_domain" "portal" {
  domain       = "fedramp-portal-${local.account_id}"
  user_pool_id = aws_cognito_user_pool.portal.id
}

resource "aws_cognito_user_pool_client" "portal" {
  name         = "fedramp-portal-spa"
  user_pool_id = aws_cognito_user_pool.portal.id

  generate_secret = false # SPA cannot hold secrets

  allowed_oauth_flows_user_pool_client = true
  allowed_oauth_flows                  = ["code"]
  allowed_oauth_scopes                 = ["openid", "email", "profile"]
  supported_identity_providers         = ["COGNITO"]

  callback_urls = local.callback_urls
  logout_urls   = local.logout_urls

  explicit_auth_flows = [
    "ALLOW_REFRESH_TOKEN_AUTH",
    "ALLOW_USER_SRP_AUTH"
  ]

  access_token_validity  = 1  # hours
  id_token_validity      = 1  # hours
  refresh_token_validity = 24 # hours

  token_validity_units {
    access_token  = "hours"
    id_token      = "hours"
    refresh_token = "hours"
  }
}

# Cognito groups for role-based access
resource "aws_cognito_user_group" "rackers" {
  name         = "Rackers"
  user_pool_id = aws_cognito_user_pool.portal.id
  description  = "Racker engineers with multi-account access"
}

resource "aws_cognito_user_group" "customers" {
  name         = "Customers"
  user_pool_id = aws_cognito_user_pool.portal.id
  description  = "Customer users with single-account access"
}

###############################################################################
# DynamoDB — Access Requests Table
###############################################################################

resource "aws_dynamodb_table" "access_requests" {
  name         = "fedramp-portal-access-requests"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "request_id"
  range_key    = "created_at"

  attribute {
    name = "request_id"
    type = "S"
  }

  attribute {
    name = "created_at"
    type = "S"
  }

  attribute {
    name = "user_id"
    type = "S"
  }

  attribute {
    name = "status"
    type = "S"
  }

  global_secondary_index {
    name            = "user-index"
    hash_key        = "user_id"
    range_key       = "created_at"
    projection_type = "ALL"
  }

  global_secondary_index {
    name            = "status-index"
    hash_key        = "status"
    range_key       = "created_at"
    projection_type = "ALL"
  }

  ttl {
    attribute_name = "expires_at"
    enabled        = true
  }

  point_in_time_recovery {
    enabled = true
  }
}

###############################################################################
# IAM — Lambda Execution Role
###############################################################################

resource "aws_iam_role" "lambda_exec" {
  name = "fedramp-portal-lambda-exec"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "lambda_basic" {
  role       = aws_iam_role.lambda_exec.name
  policy_arn = "arn:${local.partition}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "lambda_app" {
  name = "fedramp-portal-lambda-app"
  role = aws_iam_role.lambda_exec.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "DynamoDBAccess"
        Effect = "Allow"
        Action = [
          "dynamodb:GetItem",
          "dynamodb:PutItem",
          "dynamodb:UpdateItem",
          "dynamodb:Query",
          "dynamodb:Scan"
        ]
        Resource = [
          aws_dynamodb_table.access_requests.arn,
          "${aws_dynamodb_table.access_requests.arn}/index/*"
        ]
      },
      {
        Sid    = "SSMDescribeInstances"
        Effect = "Allow"
        Action = [
          "ssm:DescribeInstanceInformation",
          "ssm:SendCommand",
          "ssm:GetCommandInvocation",
          "ssm:GetParameter",
          "ssm:DescribeSessions",
          "ssm:TerminateSession",
          "ec2:DescribeInstances",
          "ec2:DescribeTags"
        ]
        Resource = "*"
      },
      {
        Sid    = "OrganizationsReadOnly"
        Effect = "Allow"
        Action = [
          "organizations:ListAccounts",
          "organizations:DescribeAccount"
        ]
        Resource = "*"
      },
      {
        # StartExecution acts on the STATE MACHINE arn.
        Sid    = "StepFunctionsStart"
        Effect = "Allow"
        Action = [
          "states:StartExecution"
        ]
        Resource = [
          aws_sfn_state_machine.access_lifecycle.arn
        ]
      }
      # NOTE (ADR-0023): the former StepFunctionsExecutionControl statement
      # (states:StopExecution + states:DescribeExecution on the execution arn)
      # was removed. Under the conductor model no caller aborts the execution:
      # end-triggers write an end-demand to DynamoDB and the Step Function is the
      # sole authority that verifies teardown and converges to a terminal state.
      # Aborting the execution was the root cause of stranded CLEANING_UP records.
      # If reconciliation-on-read is added later, restore states:DescribeExecution
      # (scoped to the execution arn) only.
    ]
  })
}

###############################################################################
# IAM — Step Functions Execution Role
###############################################################################

resource "aws_iam_role" "sfn_exec" {
  name = "fedramp-portal-sfn-exec"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "states.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy" "sfn_app" {
  name = "fedramp-portal-sfn-app"
  role = aws_iam_role.sfn_exec.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "SSMRunCommand"
        Effect = "Allow"
        Action = [
          "ssm:SendCommand",
          "ssm:GetCommandInvocation",
          "ssm:ListCommandInvocations"
        ]
        Resource = "*"
      },
      {
        Sid    = "DynamoDBUpdate"
        Effect = "Allow"
        Action = [
          "dynamodb:UpdateItem",
          "dynamodb:GetItem"
        ]
        Resource = aws_dynamodb_table.access_requests.arn
      },
      {
        Sid      = "LambdaInvoke"
        Effect   = "Allow"
        Action   = "lambda:InvokeFunction"
        Resource = "arn:${local.partition}:lambda:${local.region}:${local.account_id}:function:fedramp-portal-*"
      },
      {
        Sid    = "CloudWatchLogs"
        Effect = "Allow"
        Action = [
          "logs:CreateLogDelivery",
          "logs:GetLogDelivery",
          "logs:UpdateLogDelivery",
          "logs:DeleteLogDelivery",
          "logs:ListLogDeliveries",
          "logs:PutResourcePolicy",
          "logs:DescribeResourcePolicies",
          "logs:DescribeLogGroups"
        ]
        Resource = "*"
      }
    ]
  })
}

###############################################################################
# Lambda Functions — Package & Deploy
###############################################################################

# Shared Lambda layer for common utilities
data "archive_file" "lambda_layer" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/shared"
  output_path = "${path.module}/.build/shared-layer.zip"
}

resource "aws_lambda_layer_version" "shared" {
  filename            = data.archive_file.lambda_layer.output_path
  source_code_hash    = data.archive_file.lambda_layer.output_base64sha256
  layer_name          = "fedramp-portal-shared"
  compatible_runtimes = [var.lambda_runtime]
  description         = "Shared utilities for FedRAMP Portal Lambdas"
}

# cryptography layer (for the SSH CA sign_key Lambda — ADR-0014).
# Built by lambda/layers/build-crypto-layer.sh into lambda/layers/crypto/python/
# (manylinux wheels matching the Lambda runtime). Zipped here at apply time.
data "archive_file" "crypto_layer" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/layers/crypto"
  output_path = "${path.module}/.build/crypto-layer.zip"
}

resource "aws_lambda_layer_version" "crypto" {
  filename            = data.archive_file.crypto_layer.output_path
  source_code_hash    = data.archive_file.crypto_layer.output_base64sha256
  layer_name          = "fedramp-portal-crypto"
  compatible_runtimes = [var.lambda_runtime]
  description         = "cryptography package for SSH certificate signing (ADR-0014)"
}

# --- list-accounts ---
data "archive_file" "list_accounts" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/list_accounts"
  output_path = "${path.module}/.build/list-accounts.zip"
}

resource "aws_lambda_function" "list_accounts" {
  function_name    = "fedramp-portal-list-accounts"
  filename         = data.archive_file.list_accounts.output_path
  source_code_hash = data.archive_file.list_accounts.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]

  environment {
    variables = {
      ENVIRONMENT    = var.environment
      TARGET_REGIONS = join(",", var.target_regions)
    }
  }
}

# --- list-instances ---
data "archive_file" "list_instances" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/list_instances"
  output_path = "${path.module}/.build/list-instances.zip"
}

resource "aws_lambda_function" "list_instances" {
  function_name    = "fedramp-portal-list-instances"
  filename         = data.archive_file.list_instances.output_path
  source_code_hash = data.archive_file.list_instances.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]

  environment {
    variables = {
      ENVIRONMENT    = var.environment
      TARGET_REGIONS = join(",", var.target_regions)
    }
  }
}

# --- create-access-request ---
data "archive_file" "create_access_request" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/create_access_request"
  output_path = "${path.module}/.build/create-access-request.zip"
}

resource "aws_lambda_function" "create_access_request" {
  function_name    = "fedramp-portal-create-access-request"
  filename         = data.archive_file.create_access_request.output_path
  source_code_hash = data.archive_file.create_access_request.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]

  environment {
    variables = {
      ENVIRONMENT         = var.environment
      TABLE_NAME          = aws_dynamodb_table.access_requests.name
      STATE_MACHINE_ARN   = aws_sfn_state_machine.access_lifecycle.arn
      SESSION_TTL_MINUTES = tostring(var.session_ttl_minutes)
      KMS_KEY_ID          = aws_kms_key.credentials.key_id
    }
  }
}

# --- get-session-status ---
data "archive_file" "get_session_status" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/get_session_status"
  output_path = "${path.module}/.build/get-session-status.zip"
}

resource "aws_lambda_function" "get_session_status" {
  function_name    = "fedramp-portal-get-session-status"
  filename         = data.archive_file.get_session_status.output_path
  source_code_hash = data.archive_file.get_session_status.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]

  environment {
    variables = {
      ENVIRONMENT = var.environment
      TABLE_NAME  = aws_dynamodb_table.access_requests.name
      KMS_KEY_ID  = aws_kms_key.credentials.key_id
    }
  }
}

# --- list-sessions ---
data "archive_file" "list_sessions" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/list_sessions"
  output_path = "${path.module}/.build/list-sessions.zip"
}

resource "aws_lambda_function" "list_sessions" {
  function_name    = "fedramp-portal-list-sessions"
  filename         = data.archive_file.list_sessions.output_path
  source_code_hash = data.archive_file.list_sessions.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]

  environment {
    variables = {
      ENVIRONMENT = var.environment
      TABLE_NAME  = aws_dynamodb_table.access_requests.name
      KMS_KEY_ID  = aws_kms_key.credentials.key_id
    }
  }
}

# --- sign-key (SSH Certificate Authority — ADR-0014) ---
data "archive_file" "sign_key" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/sign_key"
  output_path = "${path.module}/.build/sign-key.zip"
}

resource "aws_lambda_function" "sign_key" {
  function_name    = "fedramp-portal-sign-key"
  filename         = data.archive_file.sign_key.output_path
  source_code_hash = data.archive_file.sign_key.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn, aws_lambda_layer_version.crypto.arn]

  environment {
    variables = {
      ENVIRONMENT       = var.environment
      TABLE_NAME        = aws_dynamodb_table.access_requests.name
      SSH_CA_SECRET_ARN = aws_secretsmanager_secret.ssh_ca_private_key.arn
    }
  }
}

# --- provision-user (invoked by Step Function, region-aware SSM) ---
data "archive_file" "provision_user" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/provision_user"
  output_path = "${path.module}/.build/provision-user.zip"
}

resource "aws_lambda_function" "provision_user" {
  function_name    = "fedramp-portal-provision-user"
  filename         = data.archive_file.provision_user.output_path
  source_code_hash = data.archive_file.provision_user.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = 90
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn

  environment {
    variables = {
      ENVIRONMENT             = var.environment
      SSH_CA_PUBLIC_KEY_PARAM = aws_ssm_parameter.ssh_ca_public_key.name
    }
  }
}

# --- cleanup-user (invoked by Step Function, region-aware SSM) ---
data "archive_file" "cleanup_user" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/cleanup_user"
  output_path = "${path.module}/.build/cleanup-user.zip"
}

resource "aws_lambda_function" "cleanup_user" {
  function_name    = "fedramp-portal-cleanup-user"
  filename         = data.archive_file.cleanup_user.output_path
  source_code_hash = data.archive_file.cleanup_user.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = 90
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn

  environment {
    variables = {
      ENVIRONMENT = var.environment
    }
  }
}

# --- terminate-session ---
data "archive_file" "terminate_session" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/terminate_session"
  output_path = "${path.module}/.build/terminate-session.zip"
}

resource "aws_lambda_function" "terminate_session" {
  function_name    = "fedramp-portal-terminate-session"
  filename         = data.archive_file.terminate_session.output_path
  source_code_hash = data.archive_file.terminate_session.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]

  environment {
    variables = {
      ENVIRONMENT = var.environment
      TABLE_NAME  = aws_dynamodb_table.access_requests.name
    }
  }
}

# --- ssm-credentials (credential-vending endpoint — ADR-0012) ---
data "archive_file" "ssm_credentials" {
  type        = "zip"
  source_dir  = "${path.module}/lambda/ssm_credentials"
  output_path = "${path.module}/.build/ssm-credentials.zip"
}

resource "aws_lambda_function" "ssm_credentials" {
  function_name    = "fedramp-portal-ssm-credentials"
  filename         = data.archive_file.ssm_credentials.output_path
  source_code_hash = data.archive_file.ssm_credentials.output_base64sha256
  handler          = "handler.lambda_handler"
  runtime          = var.lambda_runtime
  timeout          = var.lambda_timeout
  memory_size      = var.lambda_memory
  role             = aws_iam_role.lambda_exec.arn
  layers           = [aws_lambda_layer_version.shared.arn]

  environment {
    variables = {
      ENVIRONMENT             = var.environment
      TABLE_NAME              = aws_dynamodb_table.access_requests.name
      SESSION_BROKER_ROLE_ARN = aws_iam_role.session_broker.arn
      # AWS_REGION is ambient. The partition is passed explicitly (own key, not
      # an AWS_-reserved name) for GovCloud portability (ADR-0017). Used to
      # build the SSM/EC2 resource ARNs in the inline session policy.
      PORTAL_PARTITION = local.partition
    }
  }
}

###############################################################################
# API Gateway (HTTP API v2)
###############################################################################

resource "aws_apigatewayv2_api" "portal" {
  name          = "fedramp-portal-api"
  protocol_type = "HTTP"
  description   = "FedRAMP Portal — single front door: serves the SPA + the API"

  # NO cors_configuration (ADR-0019): the SPA and the API are now SAME-ORIGIN
  # (both served from this one HTTP API behind portal.<domain>). Cross-origin
  # rules are unnecessary and would only widen the attack surface. For local
  # dev (Vite on localhost:5173 calling a deployed API) use a dev-only proxy or
  # a temporary override — do not reintroduce prod CORS here.
}

resource "aws_apigatewayv2_authorizer" "cognito" {
  api_id           = aws_apigatewayv2_api.portal.id
  authorizer_type  = "JWT"
  identity_sources = ["$request.header.Authorization"]
  name             = "cognito-jwt"

  jwt_configuration {
    audience = [aws_cognito_user_pool_client.portal.id]
    issuer   = "https://cognito-idp.${local.region}.amazonaws.com/${aws_cognito_user_pool.portal.id}"
  }
}

resource "aws_apigatewayv2_stage" "main" {
  api_id      = aws_apigatewayv2_api.portal.id
  name        = "$default"
  auto_deploy = true

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_access.arn
    format = jsonencode({
      requestId      = "$context.requestId"
      ip             = "$context.identity.sourceIp"
      requestTime    = "$context.requestTime"
      httpMethod     = "$context.httpMethod"
      routeKey       = "$context.routeKey"
      status         = "$context.status"
      protocol       = "$context.protocol"
      responseLength = "$context.responseLength"
      errorMessage   = "$context.error.message"
    })
  }
}

resource "aws_cloudwatch_log_group" "api_access" {
  name              = "/aws/apigateway/fedramp-portal"
  retention_in_days = 90
}

# --- Route: GET /api/accounts ---
resource "aws_apigatewayv2_integration" "list_accounts" {
  api_id                 = aws_apigatewayv2_api.portal.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.list_accounts.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "list_accounts" {
  api_id             = aws_apigatewayv2_api.portal.id
  route_key          = "GET /api/accounts"
  target             = "integrations/${aws_apigatewayv2_integration.list_accounts.id}"
  authorization_type = "JWT"
  authorizer_id      = aws_apigatewayv2_authorizer.cognito.id
}

resource "aws_lambda_permission" "apigw_list_accounts" {
  statement_id  = "AllowAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.list_accounts.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.portal.execution_arn}/*/*"
}

# --- Route: GET /api/instances ---
resource "aws_apigatewayv2_integration" "list_instances" {
  api_id                 = aws_apigatewayv2_api.portal.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.list_instances.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "list_instances" {
  api_id             = aws_apigatewayv2_api.portal.id
  route_key          = "GET /api/instances"
  target             = "integrations/${aws_apigatewayv2_integration.list_instances.id}"
  authorization_type = "JWT"
  authorizer_id      = aws_apigatewayv2_authorizer.cognito.id
}

resource "aws_lambda_permission" "apigw_list_instances" {
  statement_id  = "AllowAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.list_instances.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.portal.execution_arn}/*/*"
}

# --- Route: POST /api/connect ---
resource "aws_apigatewayv2_integration" "create_access_request" {
  api_id                 = aws_apigatewayv2_api.portal.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.create_access_request.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "create_access_request" {
  api_id             = aws_apigatewayv2_api.portal.id
  route_key          = "POST /api/connect"
  target             = "integrations/${aws_apigatewayv2_integration.create_access_request.id}"
  authorization_type = "JWT"
  authorizer_id      = aws_apigatewayv2_authorizer.cognito.id
}

resource "aws_lambda_permission" "apigw_create_access_request" {
  statement_id  = "AllowAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.create_access_request.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.portal.execution_arn}/*/*"
}

# --- Route: GET /api/session/{requestId} ---
resource "aws_apigatewayv2_integration" "get_session_status" {
  api_id                 = aws_apigatewayv2_api.portal.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.get_session_status.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "get_session_status" {
  api_id             = aws_apigatewayv2_api.portal.id
  route_key          = "GET /api/session/{requestId}"
  target             = "integrations/${aws_apigatewayv2_integration.get_session_status.id}"
  authorization_type = "JWT"
  authorizer_id      = aws_apigatewayv2_authorizer.cognito.id
}

resource "aws_lambda_permission" "apigw_get_session_status" {
  statement_id  = "AllowAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.get_session_status.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.portal.execution_arn}/*/*"
}

# --- Route: POST /api/sign  (SSH Certificate Authority — ADR-0014) ---
resource "aws_apigatewayv2_integration" "sign_key" {
  api_id                 = aws_apigatewayv2_api.portal.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.sign_key.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "sign_key" {
  api_id             = aws_apigatewayv2_api.portal.id
  route_key          = "POST /api/sign"
  target             = "integrations/${aws_apigatewayv2_integration.sign_key.id}"
  authorization_type = "JWT"
  authorizer_id      = aws_apigatewayv2_authorizer.cognito.id
}

resource "aws_lambda_permission" "apigw_sign_key" {
  statement_id  = "AllowAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.sign_key.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.portal.execution_arn}/*/*"
}

# --- Route: GET /api/sessions ---
resource "aws_apigatewayv2_integration" "list_sessions" {
  api_id                 = aws_apigatewayv2_api.portal.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.list_sessions.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "list_sessions" {
  api_id             = aws_apigatewayv2_api.portal.id
  route_key          = "GET /api/sessions"
  target             = "integrations/${aws_apigatewayv2_integration.list_sessions.id}"
  authorization_type = "JWT"
  authorizer_id      = aws_apigatewayv2_authorizer.cognito.id
}

resource "aws_lambda_permission" "apigw_list_sessions" {
  statement_id  = "AllowAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.list_sessions.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.portal.execution_arn}/*/*"
}

# --- Route: POST /api/session/{requestId}/terminate ---
resource "aws_apigatewayv2_integration" "terminate_session" {
  api_id                 = aws_apigatewayv2_api.portal.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.terminate_session.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "terminate_session" {
  api_id             = aws_apigatewayv2_api.portal.id
  route_key          = "POST /api/session/{requestId}/terminate"
  target             = "integrations/${aws_apigatewayv2_integration.terminate_session.id}"
  authorization_type = "JWT"
  authorizer_id      = aws_apigatewayv2_authorizer.cognito.id
}

resource "aws_lambda_permission" "apigw_terminate_session" {
  statement_id  = "AllowAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.terminate_session.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.portal.execution_arn}/*/*"
}

# --- Route: POST /api/session/{requestId}/ssm-credentials  (ADR-0012) ---
resource "aws_apigatewayv2_integration" "ssm_credentials" {
  api_id                 = aws_apigatewayv2_api.portal.id
  integration_type       = "AWS_PROXY"
  integration_uri        = aws_lambda_function.ssm_credentials.invoke_arn
  payload_format_version = "2.0"
}

resource "aws_apigatewayv2_route" "ssm_credentials" {
  api_id             = aws_apigatewayv2_api.portal.id
  route_key          = "POST /api/session/{requestId}/ssm-credentials"
  target             = "integrations/${aws_apigatewayv2_integration.ssm_credentials.id}"
  authorization_type = "JWT"
  authorizer_id      = aws_apigatewayv2_authorizer.cognito.id
}

resource "aws_lambda_permission" "apigw_ssm_credentials" {
  statement_id  = "AllowAPIGateway"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.ssm_credentials.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.portal.execution_arn}/*/*"
}

###############################################################################
# Step Functions — Access Lifecycle State Machine
###############################################################################

resource "aws_sfn_state_machine" "access_lifecycle" {
  name     = "fedramp-portal-access-lifecycle"
  role_arn = aws_iam_role.sfn_exec.arn

  definition = file("${path.module}/state-machine/access-lifecycle.asl.json")

  logging_configuration {
    log_destination        = "${aws_cloudwatch_log_group.sfn.arn}:*"
    include_execution_data = true
    level                  = "ALL"
  }
}

resource "aws_cloudwatch_log_group" "sfn" {
  name              = "/aws/states/fedramp-portal-access-lifecycle"
  retention_in_days = 90
}
