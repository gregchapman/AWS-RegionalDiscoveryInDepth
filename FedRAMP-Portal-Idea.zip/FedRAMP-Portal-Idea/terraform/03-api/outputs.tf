output "api_gateway_url" {
  description = "API Gateway invoke URL"
  value       = aws_apigatewayv2_stage.main.invoke_url
}

output "api_gateway_id" {
  description = "API Gateway ID"
  value       = aws_apigatewayv2_api.portal.id
}

output "cognito_user_pool_id" {
  description = "Cognito User Pool ID"
  value       = aws_cognito_user_pool.portal.id
}

output "cognito_user_pool_client_id" {
  description = "Cognito User Pool App Client ID"
  value       = aws_cognito_user_pool_client.portal.id
}

output "cognito_domain" {
  description = "Cognito hosted UI domain"
  value       = "https://${aws_cognito_user_pool_domain.portal.domain}.auth.${var.aws_region}.amazoncognito.com"
}

output "dynamodb_table_name" {
  description = "DynamoDB table for access requests"
  value       = aws_dynamodb_table.access_requests.name
}

output "step_function_arn" {
  description = "ARN of the access lifecycle Step Function"
  value       = aws_sfn_state_machine.access_lifecycle.arn
}

output "lambda_list_accounts_arn" {
  description = "ARN of the list-accounts Lambda"
  value       = aws_lambda_function.list_accounts.arn
}

output "lambda_list_instances_arn" {
  description = "ARN of the list-instances Lambda"
  value       = aws_lambda_function.list_instances.arn
}

output "lambda_create_access_request_arn" {
  description = "ARN of the create-access-request Lambda"
  value       = aws_lambda_function.create_access_request.arn
}

output "lambda_get_session_status_arn" {
  description = "ARN of the get-session-status Lambda"
  value       = aws_lambda_function.get_session_status.arn
}

output "cognito_user_pool_arn" {
  description = "ARN of the Cognito User Pool"
  value       = aws_cognito_user_pool.portal.arn
}

output "dynamodb_table_arn" {
  description = "ARN of the DynamoDB access-requests table"
  value       = aws_dynamodb_table.access_requests.arn
}

output "lambda_execution_role_arn" {
  description = "ARN of the Lambda execution IAM role"
  value       = aws_iam_role.lambda_exec.arn
}

output "step_function_role_arn" {
  description = "ARN of the Step Functions execution IAM role"
  value       = aws_iam_role.sfn_exec.arn
}

output "api_log_group" {
  description = "CloudWatch log group for API Gateway access logs"
  value       = aws_cloudwatch_log_group.api_access.name
}

output "sfn_log_group" {
  description = "CloudWatch log group for Step Functions execution logs"
  value       = aws_cloudwatch_log_group.sfn.name
}

output "portal_env_config" {
  description = "Values to put in portal/.env.local after deployment"
  value = {
    VITE_COGNITO_USER_POOL_ID      = aws_cognito_user_pool.portal.id
    VITE_COGNITO_CLIENT_ID         = aws_cognito_user_pool_client.portal.id
    VITE_COGNITO_DOMAIN            = aws_cognito_user_pool_domain.portal.domain
    # Same-origin now: the SPA calls the API at a relative /api path on its own
    # host, so VITE_API_URL is empty (relative). Kept for override/dev only.
    VITE_API_URL                   = ""
    VITE_PORTAL_URL                = local.resolved_portal_url
  }
}

output "kms_credentials_key_arn" {
  description = "ARN of the KMS key used to encrypt ephemeral credentials"
  value       = aws_kms_key.credentials.arn
}

output "kms_credentials_key_alias" {
  description = "Alias of the credentials KMS key"
  value       = aws_kms_alias.credentials.name
}
