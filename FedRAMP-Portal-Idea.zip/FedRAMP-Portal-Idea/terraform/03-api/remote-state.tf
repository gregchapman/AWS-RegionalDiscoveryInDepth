###############################################################################
# Remote State References
#
# Pulls outputs from prior layers so we don't have to manually copy values
# between layers. The state files live in the same S3 bucket, each under
# its own key.
#
# Dependencies:
#   02-portal-hosting → SPA bucket, Route 53 zone, ACM cert, portal domain
#                       (this layer is the front door and attaches them)
###############################################################################

locals {
  state_bucket = "fedramp-portal-tfstate-675405875014"
  state_region = "us-east-1"
}

data "terraform_remote_state" "portal_hosting" {
  backend = "s3"

  config = {
    bucket = local.state_bucket
    key    = "02-portal-hosting/terraform.tfstate"
    region = local.state_region
  }
}

# Convenience locals — use these throughout main.tf instead of the long paths
locals {
  # From 02-portal-hosting (REBUILT per ADR-0019: no more CloudFront).
  # 02 now provides the SPA asset bucket, the Route 53 zone, the ACM cert, and
  # the portal custom domain. Layer 03 is the front door and consumes these.
  spa_bucket_name     = try(data.terraform_remote_state.portal_hosting.outputs.spa_bucket_name, "")
  spa_bucket_arn      = try(data.terraform_remote_state.portal_hosting.outputs.spa_bucket_arn, "")
  hosted_zone_id      = try(data.terraform_remote_state.portal_hosting.outputs.hosted_zone_id, "")
  acm_certificate_arn = try(data.terraform_remote_state.portal_hosting.outputs.acm_certificate_arn, "")
  portal_domain       = try(data.terraform_remote_state.portal_hosting.outputs.portal_domain, "")
  portal_url          = try(data.terraform_remote_state.portal_hosting.outputs.portal_url, "")
}
