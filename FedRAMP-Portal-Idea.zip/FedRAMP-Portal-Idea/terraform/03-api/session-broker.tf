###############################################################################
# Session Broker Role (ADR-0012 — credential-vending endpoint)
#
# Makes the SSM tunnel credential-less for the USER (customer or Racker with no
# AWS account). The portal authenticates the user (Cognito JWT), then VENDS
# short-lived, tightly-scoped AWS credentials for exactly one session. This is
# the port of production Passport's heimdall credential broker (ADR-0003/0013):
#   - internal/heimdall/heimdall.go :: passportCLIPolicyDocument  (the scoping)
#   - cli/connect/ssmtransport.go   :: getSSMCreds / GetSSMAPI     (the client)
#
# MECHANISM (verified against AWS docs):
#   The ssm-credentials Lambda calls sts:AssumeRole on THIS broker role and
#   passes an inline session `Policy` at assume time. The resulting session's
#   permissions are the INTERSECTION of this role's identity policy and that
#   inline policy (STS session policies can only NARROW, never widen — see
#   IAM UserGuide "Permissions for AssumeRole"). So:
#
#     broker role identity policy  = the full SSM-connect capability (below)
#     per-request inline policy    = narrowed to the ONE target instance ARN
#                                    + only the port-forward / SSH documents
#                                    (built in the Lambda, mirrors heimdall)
#
#   The broker role by itself can reach any managed node in the account; it is
#   NEVER handed out with its full identity policy. Every vend is scoped down
#   to a single instance by the inline policy. The RoleSessionName is set to
#   the identity-derived username so CloudTrail attributes StartSession to a
#   real person (AU-2/AU-3/AU-12).
###############################################################################

# Trust policy: ONLY the portal's Lambda execution role may assume the broker.
resource "aws_iam_role" "session_broker" {
  name        = "fedramp-portal-session-broker"
  description = "Assumed by the ssm-credentials Lambda to vend per-session, instance-scoped SSM credentials (ADR-0012)"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "OnlyLambdaExecMayAssume"
        Effect = "Allow"
        Principal = {
          AWS = aws_iam_role.lambda_exec.arn
        }
        Action = "sts:AssumeRole"
      }
    ]
  })

  # Cap any vended session at 1 hour, matching heimdall's DurationSeconds=3600
  # and the SSH cert cap. The inline session policy sets the request duration;
  # this is the hard ceiling the role itself enforces.
  max_session_duration = 3600
}

# The broker role's OWN capability: start/terminate/resume SSM sessions using
# the port-forward + SSH documents, on managed nodes in THIS account. This is
# the widest the role can ever be; the Lambda's inline session policy narrows
# each vend to a single instance. Mirrors passportCLIPolicyDocument's actions.
resource "aws_iam_role_policy" "session_broker_ssm" {
  name = "fedramp-portal-session-broker-ssm"
  role = aws_iam_role.session_broker.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "StartSessionOnManagedNodes"
        Effect = "Allow"
        Action = ["ssm:StartSession"]
        Resource = [
          # AWS-managed session documents: referenced with an EMPTY account id
          # (the "::"), because AWS-owned documents (names starting "AWS-") are
          # not account-scoped. Inserting an account id here breaks StartSession.
          "arn:${local.partition}:ssm:*::document/AWS-StartPortForwardingSession",
          "arn:${local.partition}:ssm:*::document/AWS-StartSSHSession",
          # EC2-native instances (i-...) are referenced via the ec2 namespace.
          "arn:${local.partition}:ec2:*:${local.account_id}:instance/*",
          # Hybrid / on-prem SSM managed instances (mi-...).
          "arn:${local.partition}:ssm:*:${local.account_id}:managed-instance/*"
        ]
      },
      {
        Sid    = "TerminateAndResumeOwnSessions"
        Effect = "Allow"
        Action = [
          "ssm:TerminateSession",
          "ssm:ResumeSession"
        ]
        Resource = "arn:${local.partition}:ssm:*:${local.account_id}:session/*"
      }
    ]
  })
}

# Grant the Lambda execution role permission to assume the broker role — and
# ONLY the broker role. This is the single sts:AssumeRole edge in the system.
resource "aws_iam_role_policy" "lambda_assume_broker" {
  name = "fedramp-portal-lambda-assume-broker"
  role = aws_iam_role.lambda_exec.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "AssumeSessionBrokerOnly"
        Effect   = "Allow"
        Action   = "sts:AssumeRole"
        Resource = aws_iam_role.session_broker.arn
      }
    ]
  })
}

output "session_broker_role_arn" {
  description = "ARN of the session-broker role the ssm-credentials Lambda assumes (ADR-0012)"
  value       = aws_iam_role.session_broker.arn
}
