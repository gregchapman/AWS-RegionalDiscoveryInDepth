###############################################################################
# SSH Certificate Authority (ADR-0014)
#
# The CA private key signs short-lived SSH user certificates so Linux access
# is passwordless and attributed (KeyId = identity). Instances trust the CA
# public key via sshd's TrustedUserCAKeys.
#
# SECURITY: the CA private key is generated OUT OF BAND and imported into
# Secrets Manager so it never transits Terraform state. Terraform creates the
# empty secret container + KMS key; you populate the value once with
# scripts/init-ssh-ca.sh. The CA PUBLIC key is stored in SSM Parameter Store
# (public keys are safe to expose) for instances to fetch and trust.
###############################################################################

# Dedicated KMS key for the CA secret
resource "aws_kms_key" "ssh_ca" {
  description             = "Encrypts the SSH CA private key"
  deletion_window_in_days = 14
  enable_key_rotation     = true

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "RootAccountFullAccess"
        Effect    = "Allow"
        Principal = { AWS = "arn:${local.partition}:iam::${local.account_id}:root" }
        Action    = "kms:*"
        Resource  = "*"
      },
      {
        Sid    = "SignLambdaDecrypt"
        Effect = "Allow"
        Principal = {
          AWS = aws_iam_role.lambda_exec.arn
        }
        Action = [
          "kms:Decrypt",
          "kms:GenerateDataKey"
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_kms_alias" "ssh_ca" {
  name          = "alias/fedramp-portal-ssh-ca"
  target_key_id = aws_kms_key.ssh_ca.key_id
}

# Secrets Manager container for the CA PRIVATE key (OpenSSH PEM).
# Populated out-of-band by scripts/init-ssh-ca.sh — NOT by Terraform.
resource "aws_secretsmanager_secret" "ssh_ca_private_key" {
  name                    = "fedramp-portal/ssh-ca-private-key"
  description             = "OpenSSH CA private key used to sign user certificates (ADR-0014)"
  kms_key_id              = aws_kms_key.ssh_ca.arn
  recovery_window_in_days = 7
}

# SSM Parameter for the CA PUBLIC key. Instances fetch this to configure
# TrustedUserCAKeys. Public keys are not secret. Populated by init-ssh-ca.sh.
resource "aws_ssm_parameter" "ssh_ca_public_key" {
  name        = "/fedramp-portal/ssh-ca-public-key"
  description = "OpenSSH CA public key that instances trust (TrustedUserCAKeys)"
  type        = "String"
  # Placeholder; overwritten by init-ssh-ca.sh. lifecycle ignore prevents TF
  # from reverting the real value on subsequent applies.
  value = "PLACEHOLDER-run-init-ssh-ca.sh"

  lifecycle {
    ignore_changes = [value]
  }
}

# Grant the Lambda exec role read access to the CA private key secret.
resource "aws_iam_role_policy" "lambda_ssh_ca" {
  name = "fedramp-portal-lambda-ssh-ca"
  role = aws_iam_role.lambda_exec.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ReadCAPrivateKey"
        Effect = "Allow"
        Action = ["secretsmanager:GetSecretValue"]
        Resource = [aws_secretsmanager_secret.ssh_ca_private_key.arn]
      }
    ]
  })
}

output "ssh_ca_secret_arn" {
  description = "Secrets Manager ARN holding the SSH CA private key"
  value       = aws_secretsmanager_secret.ssh_ca_private_key.arn
}

output "ssh_ca_public_key_param" {
  description = "SSM parameter name holding the SSH CA public key"
  value       = aws_ssm_parameter.ssh_ca_public_key.name
}
