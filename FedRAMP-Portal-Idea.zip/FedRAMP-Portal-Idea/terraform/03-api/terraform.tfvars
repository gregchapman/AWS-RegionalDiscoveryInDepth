###############################################################################
# 03-api: API Gateway + Cognito + Lambda + DynamoDB + Step Functions
#
# Deploys the backend API layer. Cognito handles auth (JWT), API Gateway
# routes requests to Lambda functions, DynamoDB stores access request state,
# and Step Functions orchestrate the access lifecycle.
#
# Account: 675405875014 (AWS Commercial)
# Region:  us-east-1 (API + Cognito in management region)
###############################################################################

# AWS region for the API layer.
# Default: "us-east-1"
aws_region = "us-east-1"

# Environment tag.
# Default: "dev"
# Possible: "dev", "staging", "prod"
# NOTE: In "dev" mode, the list-accounts Lambda returns simulated accounts
# (regions as customers) instead of calling Organizations API.
environment = "dev"

# Cognito callback URLs — where Cognito redirects after login.
# Must include your local dev server AND the deployed CloudFront URL.
# Default: ["https://localhost:5173/callback", "https://localhost:5173"]
# Add your CloudFront URL here after deploying 02-portal-hosting:
#   e.g., "https://d1234567890.cloudfront.net/callback"
cognito_callback_urls = [
  "https://localhost:5173/callback",
  "https://localhost:5173",
  "http://localhost:5173/callback",
  "http://localhost:5173"
]

# Cognito logout URLs — where Cognito redirects after logout.
# Default: ["https://localhost:5173"]
cognito_logout_urls = [
  "https://localhost:5173",
  "http://localhost:5173"
]

# CloudFront URL for the deployed portal (from 02-portal-hosting output).
# NOTE: This is now AUTO-POPULATED via terraform_remote_state from layer 02.
# You only need to set this manually if 02-portal-hosting hasn't been deployed yet
# or if you want to override the auto-detected value.
# Default: "" (auto-reads from 02-portal-hosting state)
# Example: "https://d1234567890.cloudfront.net"
portal_cloudfront_url = ""

# Lambda runtime version.
# Default: "python3.12"
# Possible: "python3.11", "python3.12", "python3.13"
lambda_runtime = "python3.12"

# Lambda timeout in seconds.
# Default: 30
# list-instances may need more time if querying multiple regions.
# Max allowed: 900 (15 minutes)
lambda_timeout = 30

# Lambda memory in MB.
# Default: 256
# Possible: 128 to 10240 (in 1MB increments)
# Higher memory = more CPU = faster execution (and higher cost).
lambda_memory = 256

# Default session TTL in minutes for access requests.
# How long the ephemeral user exists on the target instance before cleanup.
# Default: 60
# Min: 15, Max: 480 (8 hours)
# Users can request shorter via the API, but cannot exceed this max.
session_ttl_minutes = 60

# Regions where customer instances live.
# The list-instances Lambda queries SSM in each of these regions.
# Must match the regions deployed in 04-test-environment.
# Default: ["us-east-2", "us-west-1"]
target_regions = ["us-east-1", "us-east-2", "us-west-1", "us-west-2"]
