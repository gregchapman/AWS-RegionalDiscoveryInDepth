variable "aws_region" {
  description = "AWS region for the API layer"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
  default     = "dev"
}

variable "cognito_callback_urls" {
  description = "Allowed callback URLs for Cognito app client"
  type        = list(string)
  default     = ["https://localhost:5173/callback", "https://localhost:5173"]
}

variable "cognito_logout_urls" {
  description = "Allowed logout URLs for Cognito app client"
  type        = list(string)
  default     = ["https://localhost:5173"]
}

variable "portal_cloudfront_url" {
  description = "CloudFront URL for the portal (added to callback URLs in production)"
  type        = string
  default     = ""
}

variable "lambda_runtime" {
  description = "Lambda runtime"
  type        = string
  default     = "python3.12"
}

variable "lambda_timeout" {
  description = "Lambda timeout in seconds"
  type        = number
  default     = 30
}

variable "lambda_memory" {
  description = "Lambda memory in MB"
  type        = number
  default     = 256
}

variable "session_ttl_minutes" {
  description = "Default session TTL in minutes for access requests"
  type        = number
  default     = 60
}

variable "target_regions" {
  description = "Regions where customer instances live (for cross-region API calls)"
  type        = list(string)
  default     = ["us-east-2", "us-west-1"]
}
