###############################################################################
# 04-test-environment: Simulated customer environments in multiple regions
#
# Deploys VPC + EC2 (Linux + Windows) per region to simulate separate
# customer accounts. Instances use SSM for access (no inbound ports).
#
# us-east-2: Customer 1
# us-west-1: Customer 2
###############################################################################

terraform {
  required_version = ">= 1.5"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

# Default provider (us-east-1 for IAM resources that are global)
provider "aws" {
  region = "us-east-1"

  default_tags {
    tags = {
      Project     = "fedramp-portal"
      Layer       = "04-test-environment"
      ManagedBy   = "terraform"
      Environment = var.environment
    }
  }
}

provider "aws" {
  alias  = "us_east_2"
  region = "us-east-2"

  default_tags {
    tags = {
      Project     = "fedramp-portal"
      Layer       = "04-test-environment"
      ManagedBy   = "terraform"
      Environment = var.environment
    }
  }
}

provider "aws" {
  alias  = "us_west_1"
  region = "us-west-1"

  default_tags {
    tags = {
      Project     = "fedramp-portal"
      Layer       = "04-test-environment"
      ManagedBy   = "terraform"
      Environment = var.environment
    }
  }
}

###############################################################################
# IAM Instance Profile for SSM (global, used in all regions)
###############################################################################

data "aws_partition" "current" {}

locals {
  partition = data.aws_partition.current.partition # "aws" or "aws-us-gov" (ADR-0017)
}

resource "aws_iam_role" "ssm_instance" {
  name = "fedramp-portal-ssm-instance"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ec2.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "ssm_core" {
  role       = aws_iam_role.ssm_instance.name
  policy_arn = "arn:${local.partition}:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_instance_profile" "ssm" {
  name = "fedramp-portal-ssm-instance-profile"
  role = aws_iam_role.ssm_instance.name
}

###############################################################################
# Customer Environment Modules (one per region)
###############################################################################

module "customer_1" {
  source = "./modules/customer-vpc"

  providers = {
    aws = aws.us_east_2
  }

  region                = "us-east-2"
  customer_name         = "customer1"
  vpc_cidr              = "10.100.0.0/16"
  instance_type         = var.instance_type
  windows_instance_type = var.windows_instance_type
  instance_profile_name = aws_iam_instance_profile.ssm.name
  key_name              = var.key_name
  environment           = var.environment
}

module "customer_2" {
  source = "./modules/customer-vpc"

  providers = {
    aws = aws.us_west_1
  }

  region                = "us-west-1"
  customer_name         = "customer2"
  vpc_cidr              = "10.200.0.0/16"
  instance_type         = var.instance_type
  windows_instance_type = var.windows_instance_type
  instance_profile_name = aws_iam_instance_profile.ssm.name
  key_name              = var.key_name
  environment           = var.environment
}
