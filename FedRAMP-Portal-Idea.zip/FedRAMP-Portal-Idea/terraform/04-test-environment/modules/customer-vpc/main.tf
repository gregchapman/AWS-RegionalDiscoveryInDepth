###############################################################################
# Module: customer-vpc
#
# Deploys a customer-simulated environment:
#   - VPC with public + private subnets
#   - NAT Gateway for SSM agent outbound
#   - 1 Linux EC2 (Amazon Linux 2023) in private subnet
#   - 1 Windows EC2 (Windows Server 2022) in private subnet
#   - No inbound SSH/RDP — SSM only
#   - VPC endpoints for SSM (optional, NAT is sufficient)
###############################################################################

terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

data "aws_availability_zones" "available" {
  state = "available"
}

locals {
  az_a = data.aws_availability_zones.available.names[0]
  az_b = length(data.aws_availability_zones.available.names) > 1 ? data.aws_availability_zones.available.names[1] : data.aws_availability_zones.available.names[0]

  # Derive subnets from VPC CIDR
  # e.g., 10.100.0.0/16 → public: 10.100.0.0/24, private_a: 10.100.10.0/24, private_b: 10.100.11.0/24
  public_cidr    = cidrsubnet(var.vpc_cidr, 8, 0)
  private_a_cidr = cidrsubnet(var.vpc_cidr, 8, 10)
  private_b_cidr = cidrsubnet(var.vpc_cidr, 8, 11)
}

###############################################################################
# VPC
###############################################################################

resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-vpc"
    Customer = var.customer_name
  }
}

###############################################################################
# Subnets
###############################################################################

resource "aws_subnet" "public_a" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = local.public_cidr
  availability_zone       = local.az_a
  map_public_ip_on_launch = false

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-public-a"
    Customer = var.customer_name
    Tier     = "public"
  }
}

resource "aws_subnet" "private_a" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = local.private_a_cidr
  availability_zone = local.az_a

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-private-a"
    Customer = var.customer_name
    Tier     = "private"
  }
}

resource "aws_subnet" "private_b" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = local.private_b_cidr
  availability_zone = local.az_b

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-private-b"
    Customer = var.customer_name
    Tier     = "private"
  }
}

###############################################################################
# Internet Gateway + NAT Gateway
###############################################################################

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-igw"
    Customer = var.customer_name
  }
}

resource "aws_eip" "nat" {
  domain = "vpc"

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-nat-eip"
    Customer = var.customer_name
  }
}

resource "aws_nat_gateway" "main" {
  allocation_id = aws_eip.nat.id
  subnet_id     = aws_subnet.public_a.id

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-nat"
    Customer = var.customer_name
  }

  depends_on = [aws_internet_gateway.main]
}

###############################################################################
# Route Tables
###############################################################################

resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main.id
  }

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-public-rt"
    Customer = var.customer_name
  }
}

resource "aws_route_table_association" "public_a" {
  subnet_id      = aws_subnet.public_a.id
  route_table_id = aws_route_table.public.id
}

resource "aws_route_table" "private" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.main.id
  }

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-private-rt"
    Customer = var.customer_name
  }
}

resource "aws_route_table_association" "private_a" {
  subnet_id      = aws_subnet.private_a.id
  route_table_id = aws_route_table.private.id
}

resource "aws_route_table_association" "private_b" {
  subnet_id      = aws_subnet.private_b.id
  route_table_id = aws_route_table.private.id
}

###############################################################################
# Security Group — No Inbound Management Ports
###############################################################################

resource "aws_security_group" "instances" {
  name_prefix = "fedramp-${lower(var.customer_name)}-instances-"
  description = "No inbound SSH/RDP. SSM agent communicates outbound only."
  vpc_id      = aws_vpc.main.id

  # No inbound rules — SSM agent initiates outbound on 443

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Allow all outbound (SSM agent needs 443 to AWS endpoints)"
  }

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-instances-sg"
    Customer = var.customer_name
  }

  lifecycle {
    create_before_destroy = true
  }
}

###############################################################################
# EC2 Instances — AMI Lookups
###############################################################################

data "aws_ami" "amazon_linux" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }

  filter {
    name   = "state"
    values = ["available"]
  }
}

data "aws_ami" "windows" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["Windows_Server-2022-English-Full-Base-*"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }

  filter {
    name   = "state"
    values = ["available"]
  }
}

###############################################################################
# EC2 Instances
###############################################################################

resource "aws_instance" "linux" {
  ami                    = data.aws_ami.amazon_linux.id
  instance_type          = var.instance_type
  subnet_id              = aws_subnet.private_a.id
  vpc_security_group_ids = [aws_security_group.instances.id]
  iam_instance_profile   = var.instance_profile_name
  key_name               = var.key_name != "" ? var.key_name : null

  metadata_options {
    http_tokens   = "required" # IMDSv2 only
    http_endpoint = "enabled"
  }

  root_block_device {
    volume_type = "gp3"
    volume_size = 30
    encrypted   = true
  }

  tags = {
    Name           = "fedramp-${lower(var.customer_name)}-linux"
    Customer       = var.customer_name
    CustomerAccess = "true"
    OS             = "linux"
    Platform       = "Amazon Linux 2023"
  }
}

resource "aws_instance" "windows" {
  ami                    = data.aws_ami.windows.id
  instance_type          = var.windows_instance_type
  subnet_id              = aws_subnet.private_a.id
  vpc_security_group_ids = [aws_security_group.instances.id]
  iam_instance_profile   = var.instance_profile_name
  key_name               = var.key_name != "" ? var.key_name : null

  metadata_options {
    http_tokens   = "required" # IMDSv2 only
    http_endpoint = "enabled"
  }

  root_block_device {
    volume_type = "gp3"
    volume_size = 50
    encrypted   = true
  }

  tags = {
    Name           = "fedramp-${lower(var.customer_name)}-windows"
    Customer       = var.customer_name
    CustomerAccess = "true"
    OS             = "windows"
    Platform       = "Windows Server 2022"
  }
}
