output "vpc_id" {
  description = "VPC ID"
  value       = aws_vpc.main.id
}

output "linux_instance_id" {
  description = "Linux EC2 instance ID"
  value       = aws_instance.linux.id
}

output "windows_instance_id" {
  description = "Windows EC2 instance ID"
  value       = aws_instance.windows.id
}

output "private_subnet_ids" {
  description = "Private subnet IDs"
  value       = [aws_subnet.private_a.id, aws_subnet.private_b.id]
}

output "public_subnet_ids" {
  description = "Public subnet IDs"
  value       = [aws_subnet.public_a.id]
}
