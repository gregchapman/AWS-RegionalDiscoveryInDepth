variable "region" {
  description = "AWS region for this customer environment"
  type        = string
}

variable "customer_name" {
  description = "Customer name for tagging"
  type        = string
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
}

variable "instance_type" {
  description = "Instance type for Linux instances"
  type        = string
  default     = "t3.micro"
}

variable "windows_instance_type" {
  description = "Instance type for Windows instances"
  type        = string
  default     = "t3.small"
}

variable "instance_profile_name" {
  description = "IAM instance profile name for SSM"
  type        = string
}

variable "key_name" {
  description = "SSH key pair name (optional)"
  type        = string
  default     = ""
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "dev"
}
