###############################################################################
# VPC Endpoints for SSM
#
# Interface endpoints keep SSM traffic on the AWS backbone (no internet path).
# Required endpoints for SSM Session Manager:
#   - com.amazonaws.<region>.ssm
#   - com.amazonaws.<region>.ssmmessages
#   - com.amazonaws.<region>.ec2messages
#
# With these in place, SSM works even without a NAT Gateway. The NAT is
# retained for OS updates and other outbound traffic, but SSM no longer
# depends on it.
###############################################################################

resource "aws_security_group" "vpc_endpoints" {
  name_prefix = "fedramp-${lower(var.customer_name)}-vpce-"
  description = "Allow HTTPS inbound for VPC endpoints"
  vpc_id      = aws_vpc.main.id

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
    description = "HTTPS from VPC CIDR for SSM endpoints"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-vpce-sg"
    Customer = var.customer_name
  }

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_endpoint" "ssm" {
  vpc_id              = aws_vpc.main.id
  service_name        = "com.amazonaws.${var.region}.ssm"
  vpc_endpoint_type   = "Interface"
  private_dns_enabled = true

  subnet_ids         = [aws_subnet.private_a.id, aws_subnet.private_b.id]
  security_group_ids = [aws_security_group.vpc_endpoints.id]

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-vpce-ssm"
    Customer = var.customer_name
  }
}

resource "aws_vpc_endpoint" "ssmmessages" {
  vpc_id              = aws_vpc.main.id
  service_name        = "com.amazonaws.${var.region}.ssmmessages"
  vpc_endpoint_type   = "Interface"
  private_dns_enabled = true

  subnet_ids         = [aws_subnet.private_a.id, aws_subnet.private_b.id]
  security_group_ids = [aws_security_group.vpc_endpoints.id]

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-vpce-ssmmessages"
    Customer = var.customer_name
  }
}

resource "aws_vpc_endpoint" "ec2messages" {
  vpc_id              = aws_vpc.main.id
  service_name        = "com.amazonaws.${var.region}.ec2messages"
  vpc_endpoint_type   = "Interface"
  private_dns_enabled = true

  subnet_ids         = [aws_subnet.private_a.id, aws_subnet.private_b.id]
  security_group_ids = [aws_security_group.vpc_endpoints.id]

  tags = {
    Name     = "fedramp-${lower(var.customer_name)}-vpce-ec2messages"
    Customer = var.customer_name
  }
}
