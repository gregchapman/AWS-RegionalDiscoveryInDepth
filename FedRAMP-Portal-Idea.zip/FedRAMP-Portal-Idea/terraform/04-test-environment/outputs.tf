output "customer1_vpc_id" {
  description = "VPC ID for customer1 in us-east-2"
  value       = module.customer_1.vpc_id
}

output "customer1_linux_instance_id" {
  description = "Linux instance ID for customer1"
  value       = module.customer_1.linux_instance_id
}

output "customer1_windows_instance_id" {
  description = "Windows instance ID for customer1"
  value       = module.customer_1.windows_instance_id
}

output "customer1_private_subnet_ids" {
  description = "Private subnet IDs for customer1"
  value       = module.customer_1.private_subnet_ids
}

output "customer2_vpc_id" {
  description = "VPC ID for customer2 in us-west-1"
  value       = module.customer_2.vpc_id
}

output "customer2_linux_instance_id" {
  description = "Linux instance ID for customer2"
  value       = module.customer_2.linux_instance_id
}

output "customer2_windows_instance_id" {
  description = "Windows instance ID for customer2"
  value       = module.customer_2.windows_instance_id
}

output "customer2_private_subnet_ids" {
  description = "Private subnet IDs for customer2"
  value       = module.customer_2.private_subnet_ids
}

output "ssm_instance_profile_name" {
  description = "Instance profile name used for SSM access"
  value       = aws_iam_instance_profile.ssm.name
}

output "ssm_instance_role_arn" {
  description = "IAM role ARN for the SSM instance profile"
  value       = aws_iam_role.ssm_instance.arn
}

output "all_instance_ids" {
  description = "All instance IDs for quick SSM testing"
  value = {
    "us-east-2-linux"   = module.customer_1.linux_instance_id
    "us-east-2-windows" = module.customer_1.windows_instance_id
    "us-west-1-linux"   = module.customer_2.linux_instance_id
    "us-west-1-windows" = module.customer_2.windows_instance_id
  }
}
