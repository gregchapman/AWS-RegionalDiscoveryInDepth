###############################################################################
# Remote State References
#
# Pulls outputs from prior layers. Currently used for tagging instances with
# metadata about the portal (API URL, management region). Could also be used
# to pass SSM document names from layer 03 to instance user-data if needed.
#
# Dependencies:
#   03-api → API URL, DynamoDB table name (for instance-level SSM automation)
###############################################################################

locals {
  state_bucket = "fedramp-portal-tfstate-675405875014"
  state_region = "us-east-1"
}

data "terraform_remote_state" "api" {
  backend = "s3"

  config = {
    bucket = local.state_bucket
    key    = "03-api/terraform.tfstate"
    region = local.state_region
  }
}

# Convenience locals
locals {
  api_gateway_url   = try(data.terraform_remote_state.api.outputs.api_gateway_url, "")
  step_function_arn = try(data.terraform_remote_state.api.outputs.step_function_arn, "")
}
