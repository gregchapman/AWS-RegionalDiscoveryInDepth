###############################################################################
# 04-test-environment: Simulated Customer Environments
#
# Deploys VPC + EC2 instances in multiple regions to simulate separate
# customer accounts (per ADR-0002: regions as test boundaries).
#
# Account: 675405875014 (AWS Commercial)
# Regions:
#   us-east-2 — Customer 1
#   us-west-1 — Customer 2
###############################################################################

# Environment tag.
# Default: "dev"
# Possible: "dev", "staging", "prod"
environment = "dev"

# EC2 instance type for Linux test instances.
# Default: "t3.micro" (free tier eligible, sufficient for SSM testing)
# Possible: Any x86_64 instance type. t3.micro/t3.small for testing.
# NOTE: t3.micro gets 2 vCPU, 1GB RAM — enough for SSM agent + user creation.
instance_type = "t3.micro"

# EC2 instance type for Windows test instances.
# Default: "t3.small" (Windows needs more RAM than Linux)
# Possible: t3.small minimum for Windows Server (2GB RAM).
# t3.medium (4GB) if you need smoother RDP experience.
windows_instance_type = "t3.small"

# SSH key pair name (optional).
# With SSM-only access (ADR-0006), you do NOT need an SSH key.
# Only set this if you want a fallback way to access instances.
# Default: "" (no key pair — SSM only, no inbound ports)
# To create: aws ec2 create-key-pair --key-name fedramp-test --region us-east-2
key_name = ""

# Customer region configuration is hardcoded in main.tf (separate module blocks
# per region because Terraform doesn't support dynamic provider assignment).
# To add a new customer region:
#   1. Add a provider block in main.tf
#   2. Add a new module block pointing to modules/customer-vpc/
#   3. Update target_regions in 03-api/terraform.tfvars
#
# Current regions:
#   us-east-2: Customer 1, VPC CIDR 10.100.0.0/16
#   us-west-1: Customer 2, VPC CIDR 10.200.0.0/16
