variable "environment" {
  description = "Environment name"
  type        = string
  default     = "dev"
}

variable "customer_regions" {
  description = "Map of simulated customer regions with their config"
  type = map(object({
    customer_name = string
    vpc_cidr      = string
  }))
  default = {
    "us-east-2" = {
      customer_name = "customer1"
      vpc_cidr      = "10.100.0.0/16"
    }
    "us-west-1" = {
      customer_name = "customer2"
      vpc_cidr      = "10.200.0.0/16"
    }
  }
}

variable "instance_type" {
  description = "EC2 instance type for test instances"
  type        = string
  default     = "t3.micro"
}

variable "windows_instance_type" {
  description = "EC2 instance type for Windows test instances"
  type        = string
  default     = "t3.small"
}

variable "key_name" {
  description = "SSH key pair name (optional, not needed with SSM-only access)"
  type        = string
  default     = ""
}
