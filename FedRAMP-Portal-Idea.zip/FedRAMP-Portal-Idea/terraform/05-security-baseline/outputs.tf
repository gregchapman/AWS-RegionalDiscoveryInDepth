output "guardduty_detector_id" {
  description = "GuardDuty detector ID (us-east-1), empty if managed by org"
  value       = var.enable_guardduty ? aws_guardduty_detector.main[0].id : "managed-by-org"
}

output "security_hub_arn" {
  description = "Security Hub account ARN, empty if managed by org"
  value       = var.enable_security_hub ? aws_securityhub_account.main[0].arn : "managed-by-org"
}

output "config_recorder_name" {
  description = "AWS Config recorder name, empty if managed by org"
  value       = var.enable_config ? aws_config_configuration_recorder.main[0].name : "managed-by-org"
}

output "cloudtrail_arn" {
  description = "CloudTrail trail ARN"
  value       = aws_cloudtrail.main.arn
}

output "cloudtrail_bucket_name" {
  description = "S3 bucket for CloudTrail logs"
  value       = aws_s3_bucket.cloudtrail.id
}

output "config_bucket_name" {
  description = "S3 bucket for Config snapshots, empty if managed by org"
  value       = var.enable_config ? aws_s3_bucket.config[0].id : "managed-by-org"
}

output "ssm_session_log_bucket" {
  description = "S3 bucket for SSM session logs"
  value       = aws_s3_bucket.ssm_sessions.id
}

output "ssm_session_log_group" {
  description = "CloudWatch log group for SSM session logs"
  value       = aws_cloudwatch_log_group.ssm_sessions.name
}

output "cloudtrail_log_group" {
  description = "CloudWatch log group for CloudTrail"
  value       = aws_cloudwatch_log_group.cloudtrail.name
}
