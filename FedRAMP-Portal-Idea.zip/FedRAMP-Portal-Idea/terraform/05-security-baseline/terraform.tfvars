###############################################################################
# 05-security-baseline: Account-Level Security Services
#
# Enables GuardDuty, Security Hub, AWS Config, CloudTrail, and SSM session
# logging. Deploy once after layers 00-04. Rarely changes.
#
# Account: 675405875014 (AWS Commercial)
# Region:  us-east-1 (primary), with GuardDuty also in us-east-2, us-west-1
#
# Controls addressed:
#   SI-4  — GuardDuty
#   CA-7  — Security Hub + NIST 800-53 v5 standards
#   CM-6  — AWS Config + conformance rules
#   AU-9  — CloudTrail to dedicated bucket
#   AU-12 — SSM Session Manager logging
###############################################################################

# Primary region for security services.
# Default: "us-east-1"
aws_region = "us-east-1"

# Environment tag.
# Default: "dev"
environment = "dev"

# Days to retain CloudTrail logs before expiration.
# FedRAMP requires 1 year minimum (365 days).
# Logs transition to Glacier at 90 days for cost savings.
# Default: 365
cloudtrail_log_retention_days = 365

# Additional regions where GuardDuty is enabled.
# Should match wherever customer instances live.
# Default: ["us-east-2", "us-west-1"]
customer_regions = ["us-east-2", "us-west-1"]

# Enable/disable services already managed at the Organization level.
# This account (675405875014) is managed by org o-f3683cif5v, which already
# enables GuardDuty, Security Hub, and Config via SCPs/delegated admin.
# Set these to false to skip creating resources that already exist.
#
# Default: true (for standalone accounts)
# Set to false when the org already manages these:
enable_guardduty    = false
enable_security_hub = false
enable_config       = false

# S3 prefix for SSM session log files.
# Default: "ssm-sessions/"
ssm_session_log_bucket_prefix = "ssm-sessions/"
