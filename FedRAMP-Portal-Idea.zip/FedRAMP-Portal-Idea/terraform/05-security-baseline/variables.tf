variable "aws_region" {
  description = "Primary AWS region for security services"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "dev"
}

variable "cloudtrail_log_retention_days" {
  description = "Days to retain CloudTrail logs before expiration"
  type        = number
  default     = 365
}

variable "enable_guardduty" {
  description = "Create GuardDuty detectors. Set false if already enabled by Organization."
  type        = bool
  default     = true
}

variable "enable_security_hub" {
  description = "Enable Security Hub. Set false if already enabled by Organization."
  type        = bool
  default     = true
}

variable "enable_config" {
  description = "Create Config recorder. Set false if blocked by SCP or already managed by Organization."
  type        = bool
  default     = true
}

variable "ssm_session_log_bucket_prefix" {
  description = "S3 prefix for SSM session logs"
  type        = string
  default     = "ssm-sessions/"
}

variable "customer_regions" {
  description = "Additional regions where GuardDuty/Config should be enabled"
  type        = list(string)
  default     = ["us-east-2", "us-west-1"]
}
