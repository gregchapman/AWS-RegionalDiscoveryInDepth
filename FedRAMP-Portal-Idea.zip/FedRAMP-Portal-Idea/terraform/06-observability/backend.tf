###############################################################################
# 06-observability: backend
#
# Separate state key. This layer is additive and read-only against the rest of
# the system (a CloudWatch dashboard reads existing logs/metrics; it creates no
# resource on the access path), so it is safe to apply/destroy independently.
###############################################################################

terraform {
  required_version = ">= 1.5"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  backend "s3" {
    bucket         = "fedramp-portal-tfstate-675405875014"
    key            = "06-observability/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "fedramp-portal-tflock"
    encrypt        = true
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "fedramp-portal"
      Layer       = "06-observability"
      ManagedBy   = "terraform"
      Environment = var.environment
    }
  }
}
