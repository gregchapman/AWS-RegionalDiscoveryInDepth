###############################################################################
# 06-observability: Operator Single-Pane-of-Glass (SPoG) CloudWatch dashboard
#
# The "demi-god" view: ALL portal activity across ALL users, in one console
# page. It combines a Logs Insights widget (every portal action, newest-first,
# stitched across the management-plane log groups) with metric widgets for the
# access lifecycle (Step Functions), the serverless control plane (Lambda), and
# the front door (API Gateway).
#
# This layer is ADDITIVE and off the access path — a dashboard only READS
# existing logs/metrics. It creates nothing that can affect a live session, so
# it is safe to apply or destroy independently of the rest of the stack.
#
# Control alignment: AU-6 (audit review) interim tooling. The durable evidence
# pipeline (subscription-filter fan-in / OpenSearch) remains the tracked build;
# this dashboard is the operator-usable first step.
###############################################################################

data "aws_caller_identity" "current" {}

locals {
  region     = var.aws_region
  account_id = data.aws_caller_identity.current.account_id

  # Management-plane log groups (all in var.aws_region). The Logs Insights
  # widget stitches these into one timeline. NOTE: SSM *session* logs live in
  # the customer regions and are surfaced via the CLI/console per-region — see
  # the caveat text widget. CloudTrail is intentionally EXCLUDED from the live
  # widget (its CW delivery lags minutes; use it for after-the-fact review).
  portal_log_groups = [
    "/aws/lambda/fedramp-portal-create-access-request",
    "/aws/lambda/fedramp-portal-sign-key",
    "/aws/lambda/fedramp-portal-ssm-credentials",
    "/aws/lambda/fedramp-portal-get-session-status",
    "/aws/lambda/fedramp-portal-list-sessions",
    "/aws/lambda/fedramp-portal-list-instances",
    "/aws/lambda/fedramp-portal-terminate-session",
    "/aws/lambda/fedramp-portal-provision-user",
    "/aws/lambda/fedramp-portal-cleanup-user",
    "/aws/states/fedramp-portal-access-lifecycle",
    "/aws/apigateway/fedramp-portal",
  ]

  lambda_function_names = [
    "fedramp-portal-create-access-request",
    "fedramp-portal-sign-key",
    "fedramp-portal-ssm-credentials",
    "fedramp-portal-get-session-status",
    "fedramp-portal-list-sessions",
    "fedramp-portal-list-instances",
    "fedramp-portal-terminate-session",
    "fedramp-portal-provision-user",
    "fedramp-portal-cleanup-user",
  ]

  state_machine_arn = "arn:aws:states:${local.region}:${local.account_id}:stateMachine:fedramp-portal-access-lifecycle"

  # The unified "all actions, all users" query. Newest first. Extracts a coarse
  # stage from the log-group name and surfaces the raw message (which carries
  # the identity-named username / request_id for attribution).
  all_actions_query = join(" ", [
    "fields @timestamp, @log, @message",
    "| sort @timestamp desc",
    "| limit 200",
  ])

  # Lambda error metric expressions (one Errors series per function).
  lambda_error_metrics = [
    for i, fn in local.lambda_function_names :
    ["AWS/Lambda", "Errors", "FunctionName", fn, { stat = "Sum", label = fn }]
  ]

  lambda_invocation_metrics = [
    for i, fn in local.lambda_function_names :
    ["AWS/Lambda", "Invocations", "FunctionName", fn, { stat = "Sum", label = fn }]
  ]
}

resource "aws_cloudwatch_dashboard" "operations" {
  dashboard_name = var.dashboard_name

  dashboard_body = jsonencode({
    widgets = [
      # ---- Header / orientation -------------------------------------------
      {
        type   = "text"
        x      = 0
        y      = 0
        width  = 24
        height = 3
        properties = {
          markdown = join("\n", [
            "# RGS FedRAMP Portal - Operations (single pane of glass)",
            "All portal activity across **all users**. The log panel below is the unified action timeline (request -> sign -> vend -> provision -> session -> cleanup), newest first. Metrics show lifecycle health.",
            "",
            "**Caveats:** CloudTrail is excluded here (its CloudWatch delivery lags minutes; use CloudTrail/Athena for after-the-fact review). SSM **session** logs are written in the customer regions (${join(", ", var.customer_regions)}); this dashboard's log panel is ${local.region}-scoped, so in-session keystroke logs are reviewed per-region. Attribution key: the identity-named ephemeral user (e.g. `greg-racker-a751`) appears in every stream.",
          ])
        }
      },

      # ---- Unified action timeline (the demi-god panel) -------------------
      # A dashboard "log" widget runs a Logs Insights query. The log groups are
      # specified with one SOURCE clause each (SOURCE is the API/dashboard way to
      # attach log groups to a query), then the pipe'd Insights commands.
      {
        type   = "log"
        x      = 0
        y      = 3
        width  = 24
        height = 12
        properties = {
          title  = "All portal actions (all users) - unified timeline"
          region = local.region
          view   = "table"
          query  = "${join(" | ", [for lg in local.portal_log_groups : "SOURCE '${lg}'"])} | ${local.all_actions_query}"
        }
      },

      # ---- Access lifecycle (Step Functions) ------------------------------
      {
        type   = "metric"
        x      = 0
        y      = 15
        width  = 12
        height = 6
        properties = {
          title  = "Access lifecycle (Step Functions)"
          region = local.region
          view   = "timeSeries"
          stat   = "Sum"
          period = 60
          metrics = [
            ["AWS/States", "ExecutionsStarted", "StateMachineArn", local.state_machine_arn, { label = "Started" }],
            ["AWS/States", "ExecutionsSucceeded", "StateMachineArn", local.state_machine_arn, { label = "Succeeded" }],
            ["AWS/States", "ExecutionsFailed", "StateMachineArn", local.state_machine_arn, { label = "Failed" }],
            ["AWS/States", "ExecutionsAborted", "StateMachineArn", local.state_machine_arn, { label = "Aborted" }],
          ]
        }
      },

      # ---- Front door (API Gateway) ---------------------------------------
      {
        type   = "metric"
        x      = 12
        y      = 15
        width  = 12
        height = 6
        properties = {
          title  = "Front door (API Gateway)"
          region = local.region
          view   = "timeSeries"
          period = 60
          metrics = [
            ["AWS/ApiGateway", "Count", "ApiId", local.api_id, { stat = "Sum", label = "Requests" }],
            ["AWS/ApiGateway", "4xx", "ApiId", local.api_id, { stat = "Sum", label = "4xx" }],
            ["AWS/ApiGateway", "5xx", "ApiId", local.api_id, { stat = "Sum", label = "5xx" }],
            ["AWS/ApiGateway", "Latency", "ApiId", local.api_id, { stat = "Average", label = "Latency (ms, avg)", yAxis = "right" }],
          ]
        }
      },

      # ---- Control plane errors (Lambda) ----------------------------------
      {
        type   = "metric"
        x      = 0
        y      = 21
        width  = 12
        height = 6
        properties = {
          title   = "Control-plane errors (Lambda)"
          region  = local.region
          view    = "timeSeries"
          period  = 60
          metrics = local.lambda_error_metrics
        }
      },

      # ---- Control plane invocations (Lambda) -----------------------------
      {
        type   = "metric"
        x      = 12
        y      = 21
        width  = 12
        height = 6
        properties = {
          title   = "Control-plane invocations (Lambda)"
          region  = local.region
          view    = "timeSeries"
          period  = 60
          metrics = local.lambda_invocation_metrics
        }
      },
    ]
  })
}
