output "dashboard_name" {
  description = "CloudWatch dashboard name."
  value       = aws_cloudwatch_dashboard.operations.dashboard_name
}

output "dashboard_url" {
  description = "Direct console URL to the operator single-pane-of-glass."
  value       = "https://${local.region}.console.aws.amazon.com/cloudwatch/home?region=${local.region}#dashboards:name=${aws_cloudwatch_dashboard.operations.dashboard_name}"
}
