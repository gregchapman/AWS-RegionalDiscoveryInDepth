###############################################################################
# Read the API Gateway id from 03-api so the front-door metric widget targets
# the real ApiId (no hardcoded value). Read-only.
###############################################################################

data "terraform_remote_state" "api" {
  backend = "s3"

  config = {
    bucket = "fedramp-portal-tfstate-675405875014"
    key    = "03-api/terraform.tfstate"
    region = "us-east-1"
  }
}

locals {
  api_id = try(data.terraform_remote_state.api.outputs.api_gateway_id, "")
}
