variable "aws_region" {
  description = "Primary region (management plane / dashboard home)."
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment tag."
  type        = string
  default     = "dev"
}

variable "dashboard_name" {
  description = "CloudWatch dashboard name (the operator single-pane-of-glass)."
  type        = string
  default     = "fedramp-portal-operations"
}

# The customer regions whose SSM session logs an operator also wants to watch.
# The management plane (API/Lambda/Step Functions) lives in aws_region; SSM
# session logs are written per-region. Logs Insights widgets can only span log
# groups in the DASHBOARD's region, so cross-region session-log tailing is called
# out as a documented limitation (see the dashboard text widget) rather than
# silently omitted.
variable "customer_regions" {
  description = "Regions where customer EC2 + SSM session logs live."
  type        = list(string)
  default     = ["us-east-2", "us-west-1"]
}
