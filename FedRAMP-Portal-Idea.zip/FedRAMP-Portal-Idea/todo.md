# FedRAMP Portal — TODO

## Current Status — 2026-09-29

The access POC remains frozen and deployed. The active platform track now has:

- ADR-0037 evidence and assurance plane with machine-readable evidence/claim
  schemas, a provisional NIST 800-53 Moderate registry, evaluator tests, CFN
  durable evidence storage, AWS posture collection, structured audit ingestion,
  alarms, and `/audit`/`/compliance`/human-review runtime handlers.
- ADR-0038 multi-IdP and AD-optional decision. Cognito remains the only runtime
  identity provider today; SAML/OIDC provider resources, issuer/subject
  lifecycle, and two-provider integration tests remain production-hardening.
- Target authorization is fail-closed before session creation in the POC,
  platform-module, and CFN connect handlers.

The platform evidence and CFN changes are authored and statically validated;
they have not yet been deployed and exercised in a real AWS Organization. Do
not describe the evidence plane or multi-IdP path as production-proven until
that deployment and its negative tests exist.

## Project Context

Zero-trust access portal replacing AD + VPN + JumpHosts for RGS FedRAMP
environments. Built on Cognito (standalone user pool; production federates to a
real IdP) + SSM + Passport V2. Serves both Racker engineers (multi-account VM
access) and customers (single-account VM access, expandable to full console).

NOTE (2026-09-01): the `01-identity-center` Terraform layer was REMOVED — it was
never in the auth path (the portal authenticates against Cognito). The unused
WAFv2 ACL was also REMOVED (WAFv2 can't attach to HTTP API v2; SC-7 edge-WAF is a
tracked gap with an ALB/REST-edge remediation). Per-control compliance status now
lives in `docs/ARCHITECTURE.md` §8 (Compliant/Inherited/Traded-off/Needs-dev).

**Testing model:** Single AWS account, regions as security boundaries.
- us-east-1: RGS management (portal, API, Identity Center)
- us-east-2: Customer A simulation
- us-west-1: Customer B simulation
In production we'll need to be able to deploy the pattern based on AWS Organizations membership in Commercial and GovCloud partitions for our MSP employees. Customers will see only their own resources on login to the portal.

Testing will be performed in 675405875014 (AWS Commercial) in CONUS regions

**Branding:** Steal style from rackspace.com/industry/government — clean,
professional, federal/government tone. Dark navy + white + red accent.

**Compliance target:** NIST 800-53, FedRAMP Moderate, IL4, 20x-ready.

**Dependencies from Passport V2** (source at
`\\wsl.localhost\Ubuntu-20.04\home\greg\Chappies-Tools\passport\`):
- `passport` — backend API patterns, Step Function flows, Lambda patterns
- `resources-ui` — React component patterns (PassportDrawer, instance tables)
- `platform-central` — deployment architecture standards

**PRODUCT DIRECTION (as of 2026-09-08) — the context above describes the POC; the
active work has moved beyond it.** The POC proved the mechanism; the goal now is a
PRODUCTIZABLE PLATFORM (`platform/`) that a third party adopts and tailors
(branding, IdP, MFA, portal DNS, target clouds, DevOps) WITHOUT re-solving 800-53.
The single-account, regions-as-tenants model in the "Testing model" above is the
POC's model and the platform's *getting-started profile* — but the intended
production target is an **AWS Organization (multi-account, Commercial + GovCloud
partitions)**, and the **next use of this code is AS A 3RD-PARTY ADOPTER** in such
an Org (greg has no access to that environment yet). The four contracts + the
`_baseline` module are how the 800-53 weight is carried for the adopter. See
`docs/TARGET-ARCHITECTURE.md`, `platform/ADOPTER-GUIDE.md`, and ADRs 0026–0033.

**INFORMATION SENSITIVITY (ADR-0034, always-on).** Classify everything
Green/Yellow/Red; default Yellow-unless-clearly-Green. **The POC and platform
CODE/patterns are GREEN** — a solution path to the general problem, not
customer-specific (the only Rackspace coupling is consuming Passport V2 /
Resources / Janus as prior art). What is NOT Green is **deployment values** (real
account ids, regions, instance ids, live domains, customer footprint) — those are
Yellow/Red. Aggregation rule: the recon picture is rebuilt by CORRELATION across
conversations, so **disclose only a fixed PAIR of the sensitive elements and never
a third, consistently, everywhere** — this binds todo.md, ADRs, and chat output
collectively. Secrets by reference, never value.

---

## Current State (as of 2026-09-08)

There are now TWO tracks in this repo. Read both — conflating them is the main
way "where are we" gets misread.

**TRACK 1 — the POC (repo root: `cli/ portal/ scripts/ terraform/`). DEPLOYED +
VERIFIED, now FROZEN.** Deployed end-to-end to account 675405875014, portal live
at **https://portal.takahe.click** (same-origin API Gateway REGIONAL front door +
ACM + Route 53, ADR-0019; CloudFront removed). Passwordless SSH-cert login,
credential-vending (ADR-0012), the conductor + verified teardown (ADR-0023), the
operator lens (ADR-0025) all confirmed live. This is the "try it, see it run"
reference and is deliberately NOT touched during platform work (ADR-0032).
Detailed POC history is in the dated entries below (newest-first).

**TRACK 2 — the PLATFORM (`platform/`). AUTHORED + VALIDATED, never applied.**
The contract-first, module-composed, brandable product extracted from the POC's
proven code (byte-for-byte reuse; only TF packaging re-authored, ADR-0032). This
is where the ACTIVE work is. Status, three honest sub-tracks:
  - **Modules — DONE.** 8 modules under `platform/modules/` (_baseline, kms,
    data-score, identity-cognito, workflow-engine, access-broker, api-edge),
    `terraform validate` clean individually + composed in
    `platform/live/poc-commercial/`. Each has a PROVENANCE.md.
  - **Contracts — DONE (offline).** `platform/contracts/openapi/consumer-api.v1.yaml`
    complete + validated (14 paths, 12 schemas, 0 unresolved refs); the resource +
    identity-assertion JSON Schemas are finished as copy-ready blocks inside the
    schemas/*.md (see the .schema.json tool-block note in START HERE).
  - **Org-readiness — DESIGNED, NOT BUILT.** The platform is single-account /
    regions-as-tenants at the RUNTIME level; the next real use is a 3rd-party
    adopter in an AWS ORGANIZATION. ADR-0033 + `platform/ADOPTER-GUIDE.md` map the
    target model and the deferred cross-account engineering honestly. NOTHING in
    `platform/` has been `terraform plan`/`apply`'d against AWS.

**The immediate next action** is in "NEXT SESSION — START HERE" (newest entry):
the code-grounded Org investigation is DONE; remaining is the cross-account
retrofit (needs an actual Org) + optionally lifting the finished JSON Schemas into
real .schema.json files. SoD (ADR-0018): Kiro authors; greg plan/applies — but the
plan/apply now belongs to the future Org environment, not this account.

Prior POC (pre-rebuild) ran on CloudFront (d3vajblionbscp.cloudfront.net) — that
is GONE. Do not reference it.

### Validated this session
- Cross-region connects (all 4 CONUS regions) via region-aware provision/cleanup Lambdas
- Concurrent SSH + RDP sessions with unique per-session local ports
- SSH login (password auth, StrictHostKeyChecking disabled over SSM tunnel)
- RDP login (requires `.\username` local-context prefix — Windows appends domain otherwise)
- End Session Now — terminates SSM session, logs off Windows session (fixed disconnected-session quser parsing), removes ephemeral user
- Session persistence across page reload via GET /api/sessions + SessionsContext
- Background polling (15s interval + on tab-focus) reconciles UI with DynamoDB truth
- Client-side TTL expiry drops expired session cards

### THE PIVOT (design direction going forward — see ADR-0011)
The product's hard problems are SOLVED (access works, state is managed). The
remaining problem is now **Accounting to an identifiable person**, not access.
Core realization: **you cannot escape local users** — privilege on any OS
requires a local principal. Teleport confirms this (its auto-provisioned-user
mode creates identity-named local users too; and Teleport still needs AD for
Windows unless a local user already exists). So we GOVERN the local user:
identity-named, role-scoped, cert-auth (Linux), ephemeral, correlated to session.

**NEXT BUILD (Option 1 — starting now):** replace random `p-xxxx` usernames
with identity-derived usernames so OS logs, auditd, CloudTrail, and SSM session
logs all attribute to a real person. Verify CloudTrail captures the identity
for StartSession / SendCommand / session lifecycle. This is the Accounting fix.

**What exists:**
- `terraform/00-backend/` — S3 state bucket (KMS, versioned, lifecycle) + DynamoDB lock table.
- `terraform/01-identity-center/` — REMOVED 2026-09-01 (orphaned; portal auth is Cognito, not Identity Center).
- `terraform/02-portal-hosting/` — S3 + CloudFront (OAC, TLS 1.2, HTTP/2+3, SPA routing) + WAF + logs.
- `terraform/03-api/` — HTTP API Gateway v2 with REGIONAL WAF, Cognito User Pool (MFA REQUIRED, Rackers/Customers groups), JWT authorizer, 4 Lambda functions (Python 3.12), DynamoDB access-requests table (GSIs, TTL), Step Functions state machine, shared Lambda layer, KMS key for credential encryption. CORS is env-aware (prod: CloudFront-only). Customer_id enforcement in list-instances (fail-closed). Parallel region queries.
- `terraform/03-api/lambda/` — list_accounts, list_instances, create_access_request, get_session_status handlers + shared/python/portal_utils.py (includes encrypt_field, decrypt via KMS).
- `terraform/03-api/state-machine/access-lifecycle.asl.json` — Full lifecycle: provision Linux/Windows user → wait TTL → cleanup. Passport V2 pattern.
- `terraform/04-test-environment/` — VPC + EC2 (Linux AL2023 + Windows 2022) per customer region via reusable module. SSM only, no inbound ports. IMDSv2, encrypted EBS. VPC endpoints for SSM (ssm, ssmmessages, ec2messages).
- `terraform/05-security-baseline/` — GuardDuty (3 regions), Security Hub (NIST 800-53 v5 + Foundational), AWS Config (recorder + required-tags + ec2-managed-by-ssm + restricted-ssh), CloudTrail (multi-region, S3+CW, validation, 365-day Glacier retention), SSM Session logging (S3 + CloudWatch streaming).
- `portal/` — Complete React SPA: Vite 5, React 18, TypeScript, Tailwind CSS (navy/accent branding), AWS Amplify 6 auth. Routes: /login, /callback, /racker (multi-account), /customer. Components: Layout, InstanceTable, ConnectButton, SessionDrawer (countdown), ConsoleAccessButton. API client with JWT Bearer auth.
- `scripts/` — collect-outputs.sh (consolidates terraform outputs → outputs.json + auto-generates .env.local), verify-deployment.sh (post-deploy smoke tests).

**DEPLOYED.** Live in account 675405875014.

### Key deployment learnings (this session)
- **Identity Center is an ACCOUNT instance** (not org) — no permission sets/assignments. Layer 01 made mode-aware via `instance_type` var. Console buttons are cosmetic in this mode.
- **Org already manages GuardDuty/Security Hub/Config** (org o-f3683cif5v) — layer 05 has `enable_*` flags set to false to skip those; only CloudTrail + SSM logging deploy.
- **Step Functions native SSM integration is region-locked to us-east-1.** Replaced with region-aware Lambdas (`provision_user`, `cleanup_user`) that call boto3 with `region_name`. THIS was the big fix for cross-region connects.
- **Per-session random local ports** (SSH 2222-2999, RDP 33389-33999) stored in DynamoDB — prevents tunnel collisions for concurrent sessions.
- **SSH command uses `StrictHostKeyChecking=no`** — acceptable over authenticated SSM tunnel (tracked in ARCHITECTURE-WEAKNESSES.md).
- **Passwords are plaintext in DynamoDB** — decrypt_field falls back to plaintext. KMS encrypt-side still deferred.
- **AWS CLI CRT bug in venv** — deactivate venv or use /home/greg/.local/bin/aws for S3 sync.
- **State machine changes require stopping RUNNING executions first** (they hold it in WaitForSessionExpiry).
- **Crypto-layer build host gotcha (Ubuntu 20.04 / focal).** Host `python3` is
  3.8.10; modern `cryptography` needs >=3.9 to even resolve, and driving pip
  with `python3.12 -m pip` loads the SYSTEM pip (built for 3.8) which imports
  `distutils` — gone in 3.12 — and crashes. FIX (now baked into
  build-crypto-layer.sh): create a throwaway venv from python3.12, upgrade pip
  inside it, and run the cross-target `pip install --platform manylinux2014_x86_64
  --python-version 3.12 --only-binary=:all: --target .../crypto/python cryptography`
  from that venv. The abi3 (`cp311-abi3`) wheel is correct for 3.12. Script also
  strips the stray `bin/` shim from the layer. Verified 2026-08-28.

---

## NEXT SESSION — START HERE

### 2026-09-09 (newest) — CloudFormation delivery BUILT + Rackers→Operators rename DONE

Executed the ADR-0036 CFN re-authoring and the operator-role rename as one pass.
All six CFN templates authored + **cfn-lint clean**; handlers ported + renamed +
py_compile clean. Under platform/cfn/:
  - member-iam/target-access-role.yaml — the deterministic ${NamePrefix}-target-access
    role (trusts control acct's broker-handler+provisioner), least-priv SSM/EC2/
    param; optional log-forwarder role. StackSet, per OU.
  - member-resources/log-forwarding.yaml — per-acct session LogGroup + optional
    cross-acct subscription filter to the control sink. StackSet.
  - control-iam/control-plane-roles.yaml — all control-plane roles (broker-handler,
    session-broker, provisioner, sfn-exec, edge-reader, edge-spa, pre-token-gen),
    deterministic names, Export their ARNs. Cross-acct: broker/provisioner/reader
    get sts:AssumeRole on arn:*:role/${MemberTargetAccessRoleName}.
  - control-resources/foundation.yaml — 2 KMS keys (policy names roles by ARN),
    DDB score table + GSIs + TTL + PITR, ssh-ca secret/param, private SPA bucket,
    Cognito pool + Operators/Tenants groups + V2_0 pre-token trigger; Exports.
    (Cognito custom attr kept as customer_id to match code.)
  - control-resources/application.yaml — layers, provision/cleanup workers,
    conductor StateMachine (ASL via S3 + DefinitionSubstitutions), 9 handlers,
    HTTP API v2 (no CORS) + JWT authorizer + $default stage.
  - control-resources/application-routes.yaml — 9 integrations/routes/permissions
    (nested-stack params). JWT all routes except $default SPA.
  - control-resources/lambda/** — the 13 handlers + shared layer, PORTED.

RENAME DONE (task): Rackers→Operators, is_racker→is_operator, "Customers"→"Tenants"
across 9 handler files (Python rename script, verified 0 residue, all py_compile
clean). customer_id (claim/attr/DDB field) INTENTIONALLY kept — it's the internal
tenant-scoping id, not a brand term; Cognito custom:customer_id matches.

CROSS-ACCOUNT (ADR-0033): added portal_utils.target_client(service, region,
target_account_id="") — assumes the member target-access role when an account is
given, ambient/local otherwise (backward compatible). WIRED as reference in
list_instances.get_instance_details. NOT yet wired in provision_user/cleanup_user/
ssm_credentials — deliberately deferred (they carry I8/I10/ADR-0023, can't be
runtime-tested without a real Org; a half-wired write path is worse than a clean
seam). Documented in platform/cfn/control-resources/lambda/PORTING-NOTES.md.

DEPLOY ORDER (in ADOPTER-GUIDE.md, ADR-0035 §7): member-iam SS → member-resources
SS → control-iam → foundation → application → application-routes → ssh-ca init +
log-agg. Needs: StackSets service-managed + an artifact S3 bucket with the lambda/
layer zips + ASL (build from control-resources/lambda/; rebuild crypto layer for
runtime). platform/README + cfn/README updated; TF marked superseded-for-delivery.

REMAINING (next session, all TESTABLE once an Org is reachable — greg SoD):
  1. Finish cross-account wiring in provision_user/cleanup_user/ssm_credentials
     per PORTING-NOTES (one-line target_client switch each + thread target_account_id
     onto the access-request record at create time).
  2. Package lambda/layer zips + ASL to the artifact bucket; build crypto layer.
  3. Deploy in order against a real Org + plan/verify (the first real AWS check).
  4. Optional: customer_id→tenant_id data-model rename (wider; not this pass).

### 2026-09-09 (latest) — ADR-0036 (all-CFN) + sanitization pass

**ADR-0036 written — the whole delivery goes CloudFormation, Terraform retired.**
greg: take the enterprise/Org manager's needs as paramount (governance posture);
Terraform is cattle not a prized cow — it served its purpose (demand +
decomposition proof). Supersedes-in-part ADR-0032 (module-first-in-TF) and
ADR-0035 §1 (control-plane IaC was open). Key points: both planes are CFN
(member data plane = StackSets per ADR-0035; control plane = CFN deployed once,
CDK-synth allowed but shipped artifact is CFN). The reused ASSETS are
IaC-agnostic (handlers w/ I8/I10/ADR-0023, ASL, contracts, IAM policy SHAPES,
KMS/Cognito config) — only TF PACKAGING is thrown away, which ADR-0032 already
called the disposable layer. Existing TF (platform/modules + live/poc-commercial)
LEFT IN PLACE marked superseded (validated reference for the CFN port), NOT
deleted. Contract-first thesis + 3-class taxonomy + ADR-0033 split + ADR-0035
four-family matrix all UNCHANGED (substrate-neutral). Follow-ups: skeleton
platform/cfn/{member-iam,member-resources,control-iam,control-resources}/; port
reused assets verbatim; ordered runbook to ADOPTER-GUIDE; decide if live/ TF gets
archived once CFN reaches parity.

**Sanitization pass (scope: ONLY C:\RGS-Code\FedRAMP-Portal-Idea, per greg).**
Rules (greg): scrub genuine LEAKAGE (real customer names + footprint aggregation,
IPs/CIDRs, secrets) from the DISTRIBUTABLE product surface; EXEMPT = the POC's own
values, ADRs referencing vendors (attribution/best-of-breed is fine + honest), and
todo/ADR references to POC specifics or educational provenance (Teleport/ScaleFT/
Rackspace Passport borrowing). Spirit = honest/transparent, don't accidentally
cross the leakage line (ethics + 800-53).
  - DONE: genericized the real account id out of the 3 PRODUCT-SURFACE spots
    (platform/modules/kms/PROVENANCE.md, _baseline/PROVENANCE.md, platform/README.md)
    — replaced with "the running POC" / "the target account." These sit in the
    distributable platform/, so placeholder is strictly better even though they
    were POC-attributed (aggregation hygiene, ADR-0034).
  - LEFT AS-IS (correctly, per greg's rules): the real account id + takahe.click in
    the ADRs (0013/0017/0018/0019/0029) and docs/ (ARCHITECTURE.md, OPERATOR-
    RUNBOOK.md) — those are POC decision-history + POC docs (exempt). The .hcl
    validate args are already dummy placeholders (123456789012). Crypto-layer
    hashes = library internals, not secrets.
  - VERIFIED (WSL grep): no real account id / live domain remains in platform/; no
    real customer names (Instem/N-Able) anywhere in platform/ or docs/. Genuine
    leakage in the distributable surface = none.
  - RESOLVED (greg 2026-09-09): genericize `rackspace-passport` AND make the
    contract role-correct. greg's framing: labels like this wrongly answer "who
    manages what a principal can see/do under 800-53" by naming a VENDOR instead
    of a ROLE. The control model has three roles, ALL bound by 800-53: the
    framework (800-53), the OPERATOR (manages what others see/do, itself under the
    controls), and the TENANT (managed/scoped, also under the controls). Product
    must be TRULY variable-driven with ZERO dependency on corporate/institutional
    identity. Chosen vocabulary: **Operators** + **Tenants**. Done in the CONTRACT
    + SCHEMAS (docs, safe):
      - rackspace-passport → example-idp; "Rackspace Passport" → "Example Identity
        Provider"; swissbit → hardware-token; "RGS portal" → "reference portal";
        RGS-IdP/Swissbit-FIDO2 prose → enterprise IdP / hardware-FIDO2; example
        subject "greg"→"user-0472", tenant "customer1"→"tenant-a", groups
        ["operator"]→["Operators"]. Verified: no institutional identity remains in
        platform/contracts/.
      - ADDED the audit-loop-closing reason at session CREATION: POST
        /resources/{id}/connect now requires `reason` (free-text "why" OR ticket
        ref), mandatory, minLength 1, + 400 response — matches the terminate-reason
        spec, same ADR-0024 spirit ("no anonymous access; attributed to principal
        AND purpose before brokering"). OpenAPI re-validated: 14 paths, 12 schemas,
        0 unresolved refs; all 4 schema JSON blocks parse.
  - CODE-SIDE rename still deferred to the CFN re-author (ADR-0036): `Rackers`/
    `is_racker` → `Operators`/`is_operator` and Cognito group defaults
    Rackers/Customers → Operators/Tenants, across ~6 handlers + identity module.
    The CONTRACT now leads with the correct vocabulary; the reused CODE follows
    during CFN packaging (one coherent refactor, don't double-touch the auth path).
  - NOTE (product-neutrality, NOT leakage — fold into the ADR-0036 CFN re-author,
    do NOT treat as a scrub): `Rackers`/`is_racker` is the operator group name
    woven through ~6 reused handlers + identity-cognito group defaults + the auth
    checks. It's brand-flavored but NOT leakage/secret. Rename to generic
    `Operators`/`is_operator` (the CONTRACT already uses is_operator) as ONE
    coherent refactor when re-authoring to CFN — not now (would double-touch the
    auth path). greg to confirm the generic term.

  IMPORTANT TOOLING NOTE for next session: the `grep_search` tool gives FALSE
  NEGATIVES against absolute `c:\RGS-Code\FedRAMP-Portal-Idea\...` include patterns
  (resolves against the wrong workspace root). USE WSL grep
  (`wsl.exe -d Ubuntu-20.04 -- bash -lc "grep -rInE ... /mnt/c/RGS-Code/..."`) for
  any repo-wide content search here, or you'll wrongly conclude files are clean.

### 2026-09-09 (later) — ADR-0035: deployment moves to CFN StackSets (Org-fit), NOT all-Terraform

Design conversation (no code yet) that resolves HOW an Org adopter actually
deploys this. Key reframe: Terraform/CDK fit "one team one product"; an AWS Org
manager needs the PUSH model — StackSets, service-managed, OU-targeted,
auto-enroll on account join. This is fit-for-scope, and it slots onto ADR-0033's
control-plane/target-access-role split cleanly (the target-access role is exactly
what StackSets distributes).

**Decisions captured in ADR-0035 (see the file for full detail):**
  - **Two planes / two tools:** data plane (wide/replicated per member account) =
    CFN StackSets from the mgmt or delegated-admin account; control plane
    (deep/singular application) = deployed ONCE into the control account (may stay
    Terraform, or CFN/CDK if the Org team mandates one language — OPEN, follow-up).
  - **Four template families:** {control-account single-stack, member-account
    StackSet} × {IAM, resources}. Nothing spans cells.
  - **IAM NEVER in the same template as resources.** PRIMARY reason (greg's, from
    scar tissue): StackSets + named IAM produce "IAM already exists" failures when
    permissions/IAM-resource-types/service-API-privileges change; ops aren't
    transactional across accounts so you chase failed operation instances per
    account. Isolate → touch the fragile create-surface rarely + shrink blast
    radius to a thin importable StackSet. Secondary: capability/rollback coupling.
    Mitigations: additive slow IAM templates, stable names, import-over-recreate.
  - **Deterministic target-access role name** (no CFN random suffix) — required by
    ADR-0033 ARN construction, which is WHY the IAM discipline is mandatory (det.
    names remove CFN's collision avoidance).
  - **CloudTrail consolidation = inherit by reference** (org trail / Control
    Tower), do NOT rebuild (ADR-0020) — link in the guide.
  - **BAKE ourselves:** CloudWatch Logs consolidation + cross-account log-stream
    aggregation to the control account + a unified "rule them all" dashboard —
    these are C2-plane product features, not generic Org hygiene.
  - **Sequenced deploy order is IN the ADR** (greg: "we can't get lazy"): member-IAM
    → member-resources → control-IAM → control-resources → log-aggregation-wiring.
    No cross-StackSet DependsOn, so order is documented principle; literal command
    runbook goes in ADOPTER-GUIDE.

**OPEN / NEXT (ADR-0035 follow-ups, in order):**
  1. Skeleton the 4 template families under platform/ (e.g.
     platform/stacksets/{member-iam,member-resources}/ +
     platform/control-plane/{iam,resources}/), each header stating its cell +
     IAM/resources-never-mix.
  2. Ordered deploy runbook (steps 1–5) into platform/ADOPTER-GUIDE.md + the
     import-over-recreate remediation for IAM "already exists."
  3. DECIDE control-plane IaC: keep the validated Terraform (modules + live root
     already done) vs re-express as CFN/CDK for single-language Org teams. This
     gates whether the 8 TF modules get a CFN twin. greg's call.
  4. Design cross-account log-aggregation IAM + the unified dashboard.
  5. Reference org-trail/Control Tower setup in the guide.

NOTE the tension to resolve at #3: the platform's 8 modules + live/poc-commercial
are TERRAFORM and validate clean. ADR-0035 keeps TF viable for the control plane
but mandates StackSets (CFN) for the member-account data plane. So the member data
plane (target-access role + log wiring) needs CFN templates authored FRESH — the
TF for that part does not carry over. The control-plane TF may stay.

### 2026-09-09 — ADR-0034 Information Sensitivity added + filled (always-on classification policy)

greg added `.kiro/steering/adr-0034-Information-sensitivity.md` (inclusion:auto)
with the Green/Yellow/Red taxonomy + the recon-aggregation-vector diagram. Kiro
inferred + wrote the Decision/Consequences/Follow-ups. Two greg refinements
folded in:
  1. **The POC (and the platform code) are GREEN** — a solution path to the
     general problem, NOT customer-specific. Only Rackspace coupling = consuming
     Passport V2 / Resources / Janus repos as prior art (that provenance is Green
     too; it names sources, not footprint). "The recipe is Green; a specific
     kitchen's inventory is not." Deployment VALUES (account/region/instance/
     domain/customer footprint) are the only Yellow/Red bits.
  2. **Aggregation rule corrected from "count per artifact" to "fixed pair,
     never a third."** The real threat is CORRELATION across conversations/
     artifacts/time — an adversary pulls 2 elements here + 2 there and rebuilds
     the picture. Proven CUI practice: pick the SAME allowed pair of elements and
     consistently disclose only that pair, never a third, ANYWHERE. Consistency
     is the control; per-document counting is not (it misses cross-doc union).
     This binds todo.md + ADRs + session notes + chat collectively.

ADR-0034 registered in the Design Decisions table + Project Context + Current
State. Elements in the vector: customer identity + AWS account + region +
workload purpose + network topology + security controls + vulnerability.

**OPEN (greg to decide / next session):**
  - The specific fixed PAIR allowed for shared artifacts is not yet chosen — the
    rule is defined but the concrete pair per customer/engagement is a greg call.
  - ADR-0034 Follow-ups (backlog): (1) remediate todo.md deployment values to
    placeholders/reference (the Green solution narrative stays); (2) sweep
    platform docs/PROVENANCE/ADR-0033/docs for real values; (3) optional Kiro
    hook to grep staged content for account-ids/customer-names/private-ARNs/
    secrets pre-write; (4) define the controlled location for per-customer
    Yellow/Red artifacts; (5) note in ADOPTER-GUIDE that adopters apply this to
    their own outputs. NOTE: todo.md remediation NOT yet done — flagged, awaiting
    greg's go (sanitizing working notes is a judgment call about where real
    values should live).

### 2026-09-08 (latest) — DIRECTION CORRECTED: next use is as a 3rd-PARTY ADOPTER in an AWS ORGANIZATION

**Read this first — it reframes everything below.** greg clarified the real
next-use scenario, and it changes what "ready" means:

- The **next time this code is touched, it will be in an AWS ORGANIZATION
  (multi-account) environment greg does NOT have access to today**, and greg will
  come to it COLD — **as if a third-party adopter**, not as the author. No warm
  context, no ability to ask Kiro to patch a collision in the moment.
- Therefore the bar for "done" is: **can a competent stranger stand this up and
  build against it using ONLY what's written in the repo?**
- This DEMOTES the `terraform plan`/`apply` step (greg can't run it today anyway,
  and when he can it'll be a DIFFERENT account type — an Org, not the
  single-account POC). It PROMOTES: (1) finalized contracts, (2) an
  Organization-aware deployment path, (3) a cold-start adopter runbook.

**CRITICAL GAP identified (not yet investigated in depth — a context-gatherer
run was started then interrupted):** the whole platform was authored/validated
against the POC's SINGLE-ACCOUNT model where AWS REGIONS act as tenant
boundaries. An adopter in an ORG has ACCOUNTS as boundaries. Known suspects to
investigate + fix next session:
  - `api-edge/lambda/list_accounts/handler.py` — has a dev-mode "SIMULATED_ACCOUNTS"
    path vs a "live" `organizations:ListAccounts` path; need to confirm exactly
    what triggers each (ENVIRONMENT in dev/test => simulated) and what a real Org
    needs.
  - `api-edge/lambda/list_instances/handler.py` — enumerates `TARGET_REGIONS` and
    filters by the `Customer` tag; in an Org, instances live in MEMBER accounts,
    not other regions of one account. How does SSM/EC2 describe reach member
    accounts? Almost certainly needs a cross-account role assumption per member
    account — NOT present today.
  - `live/poc-commercial/main.tf` + `variables.tf` — parameterizes `region` +
    `secondary_region` + `target_regions`; NO org/account-list input, NO
    cross-account provider config, NO per-member-account role. Portal/API/DDB all
    assumed in ONE account.
  - The `_baseline` module `enable_*` singletons default OFF because greg's POC
    org already manages GuardDuty/Config — an ADOPTER org may or may not; the
    adopter runbook must make this an explicit decision.
  - Likely need: an `account_id`/`org` input, a documented cross-account
    "target-account role" the adopter deploys into member accounts (the thing
    list_instances/provision/cleanup assume-into), and provider aliasing per
    target account OR a documented single-target-account starting profile.

**DONE 2026-09-08 (this stretch):**
  - **Investigation COMPLETE** (context-gatherer, code-grounded — trust it, don't
    redo). Confirmed the single-account/region-as-tenant model is baked into the
    RUNTIME not just config: list_instances/provision_user/cleanup_user/
    ssm_credentials all use ambient creds + region_name only, NO cross-account
    AssumeRole; the one runtime AssumeRole (ssm_credentials→session-broker) is
    same-account role-chaining; session-broker role only reaches ${account_id};
    list_accounts has dev/SIMULATED_ACCOUNTS vs live organizations path switched
    by ENVIRONMENT (defaults to simulated); live root parameterizes only regions+
    name_prefix (account from caller-identity); _baseline enable_* default OFF +
    single-account (not org) CloudTrail. No aws_organizations_* resources, no
    cross-account providers, no per-member-account role exist (absence = the gap).
  - **ADR-0033 written** (.kiro/steering/adr-0033-organization-deployment-model.md,
    inclusion:auto): control-plane vs member-account split; the "target-access
    role" per member account as the AWS-provider data-plane contract (ADR-0027);
    single-account model RETAINED as a profile (ADR-0029); explicit SHIPS-TODAY vs
    DEFERRED list (deferred = in-Lambda assume-and-fan-out in the 4 handlers +
    StackSet for the role + cross-account providers + customer_id→account_id in
    IdP + org-trail decision). Principle: a half-built cross-account path that
    silently returns empty is WORSE than a documented boundary.
  - **platform/ADOPTER-GUIDE.md written** — the cold-start runbook: §0 the single
    most important fact (single-account, never applied); §2 decision table; §4
    single-account deploy + what-to-check-in-plan + SSH-CA init; §5 baseline
    inherited-vs-owned; §6 the deferred Org engineering in priority order; §7
    inheritance manifest start (inherited vs your-responsibility vs graded-not-
    certified).
  - **platform/README.md** — added a prominent ADOPTER-GUIDE pointer at top;
    bumped ADR range to 0026–0033.

  - **CONTRACTS FINALIZED** (the 3rd-party-adopter gate):
    - `contracts/openapi/consumer-api.v1.yaml` — completed: the 4 stubbed
      endpoints (/me/permissions, /me/tenants, /audit, /compliance/frameworks/{f})
      now have real response schemas; added components EffectivePermissions,
      TenantRef, AuditEvent, ControlStatus, CompliancePosture. VALIDATED: well-
      formed YAML, 14 paths, 12 schemas, ZERO unresolved $refs (python yaml+ref
      check).
    - `contracts/schemas/resource-model.md` + `identity-assertion.md` — upgraded
      from prose to carry the COMPLETE machine-readable JSON Schema (draft
      2020-12, with $schema/$id headers) as copy-ready fenced ```json blocks +
      example instances. All 4 embedded JSON blocks parse OK (verified).
    - TOOL CONSTRAINT HIT + WORKAROUND (important for next session): fs_write
      REFUSES to create `*.schema.json` files — it detects JSON-Schema-shaped
      content ("type":"object"+"properties", or a $schema URL) and blocks with
      "Cannot use this tool to write Remote JSON Schema in Supervised mode". Not
      the URL alone — the filename+shape. WORKAROUND USED: embed the finished
      schema as a ```json block inside the `.md` descriptor (tool accepts .md),
      with a note telling the adopter to copy it into `resource.schema.json` /
      `identity-assertion.schema.json` (the $schema/$id header is already in the
      block). If a future session/mode can write .schema.json, just lift the two
      blocks into real files — content is done, only the file-creation is blocked.

**TODO NEXT SESSION (priority order, all authoring — Kiro side, no AWS needed):**
  1. ~~Investigate the single-account assumptions~~ DONE (see above; do NOT redo).
  1b. ~~Finalize the contracts~~ DONE (see above). If the .schema.json write-block
      is gone, lift the two embedded JSON Schema blocks from the schemas/*.md into
      real `.schema.json` files (content is final + validated).
  2. **Make the deployment Org-aware (or document the Org starting profile
     honestly).** Minimum: a `live/` profile or documented inputs for
     account/region scope + a cross-account target-account role pattern so
     list_instances/provision/cleanup can reach member-account instances. If a
     full multi-account provider mesh is too big for one session, at minimum
     WRITE DOWN precisely what the adopter must supply and stub the inputs.
  3. **Finalize the contracts** (the 3rd-party-adopter gate — the reason this all
     matters): `contracts/openapi/consumer-api.v1.yaml` against the POC's REAL
     request/response shapes; convert `schemas/resource-model.md` +
     `identity-assertion.md` descriptors into machine-readable JSON Schema.
  4. **Write a COLD-START ADOPTER RUNBOOK** (new doc, e.g.
     `platform/ADOPTER-GUIDE.md`): prerequisites (Org, accounts, IdP choice,
     domain/cert), the exact inputs to set, what's INHERITED vs
     CUSTOMER-RESPONSIBILITY (ADR-0020), and the deploy order. Must be followable
     with zero warm context.
  5. Only AFTER an adopter can actually reach an Org: `terraform plan`/`apply`
     (greg, SoD) — now against the Org, not the POC account.

**STATE OF PLAY (what's actually done vs not):**
  - DONE: 8 modules implemented (reuse POC code byte-for-byte, `terraform
    validate` clean individually + composed); `live/poc-commercial/` validates
    whole (no cycles; kms<->access-broker cycle broken via deterministic role
    ARNs constructed in root). See the `2026-09-08 (later)` entry below for the
    full module detail. platform/README.md `## Status` was corrected today to
    tell the truth (modules implemented-not-applied; reference deploy
    validated-not-deployed; contracts still skeletons = the adopter gate).
  - NOT DONE: contracts still skeletons; deployment is single-account-only (the
    Org gap above); no adopter runbook; nothing ever plan/apply'd against AWS.
  - README edit today (done): reconciled `## Layout` to the 8 real modules, noted
    mfa/portal-runtime/edge-dns/provider-aws folded into identity-cognito/api-edge,
    marked contracts as skeletons, rewrote `## Status` into 3 honest tracks.

**SoD reminder (ADR-0018):** Kiro authors (contracts, Org-aware TF, adopter
guide — all doable with no AWS). greg runs plan/apply — but NOT today and NOT in
this account; that step now belongs to the future Org environment.

### 2026-09-08 (later) — Platform module extraction COMPLETE — all 8 modules + live root VALIDATE clean

Extracted the proven POC Terraform into `platform/modules/` as eight modules and
composed them into a deployable reference root. Reuse-first per ADR-0032: app
code + bug fixes copied BYTE-FOR-BYTE; only the TF packaging was re-authored. The
POC was NOT touched (still frozen/running). Kiro authored; greg deploys/tests
(ADR-0018 SoD) — nothing here has been `terraform apply`/`plan`'d against AWS yet.

**Three-class taxonomy realized (TARGET-ARCHITECTURE §1a):**
- Class 1 INVARIANT CORE: `kms`, `data-score`, `workflow-engine` (the conductor),
  `access-broker` (the SSM path).
- Class 2 COMPLIANCE BASELINE: `_baseline`, `api-edge` (the contract front door).
- Class 3 CUSTOMER-OWNED: `identity-cognito` (reference IdP behind ADR-0028).

**Each module:** reuses POC resource bodies verbatim; strips provider/backend
blocks (inherits from root); `var.name_prefix` default `fedramp-platform`
(DISTINCT from POC `fedramp-portal-*` so it stands up ALONGSIDE, ADR-0032); has a
`PROVENANCE.md` (what was reused vs re-authored + any faithful-in-behavior
change); validates clean via `platform/_validate_module.sh <mod>`.

**What carries the hard-won fixes (byte-for-byte):**
- `workflow-engine` = the conductor. `lambda/provision_user` + `lambda/cleanup_user`
  carry I8 (Linux session-teardown-before-userdel), I10 (Windows Disc-session /
  profile-hive / SID cleanup), and the ADR-0023 verified-teardown contract. ASL
  copied verbatim into `.asl.json.tftpl` (only the two invoked FunctionNames are
  templated — the POC referenced them by static name via `file()`).
- `access-broker` = the SSM access path. The six access-lifecycle handlers
  (create/get/list_sessions/terminate/ssm_credentials/sign) carry ADR-0012 (vend),
  ADR-0014 (SSH CA sign), ADR-0024/0025 (operator lens, terminate semantics).
  Session-broker role, ssh-ca secret+param, shared+crypto layers all reused.

**Key packaging decisions (all documented in the PROVENANCE files):**
- POC used ONE shared `lambda_exec` role for ~10 Lambdas across 3 future modules.
  Each module now scopes its OWN least-privilege role(s) — tighter than the POC
  (AC-6), behavior unchanged. (e.g. workflow-engine `provisioner` role;
  access-broker `broker-handler` role = shared role minus Organizations, which
  moved to api-edge's `reader` role; api-edge `reader` + `spa` roles.)
- KMS access stays in the credentials-key POLICY naming the consuming roles
  (POC-faithful), NOT an explicit role statement.
- `api-edge` DRY'd the POC's nine repeated integration/route/permission blocks
  into ONE `for_each` over `locals.routes` (source=local|broker) — one place to
  change blast radius / add a route. JWT authorizer takes issuer+audience as
  INPUTS (identity seam). No CORS (ADR-0019 same-origin). Custom domain/route53
  count-gated optional. `serve_spa`/`list_accounts`/`list_instances` live here
  for now (documented boundary: can later split `portal-runtime`+`edge-dns`).
- `mfa`/`portal-runtime`/`edge-dns`/`provider-aws` from the taxonomy were folded
  into `identity-cognito`/`api-edge` for this pass (not separate modules yet).

**live/poc-commercial (the reference composition) VALIDATES WHOLE:**
`terraform init` resolved all 8 modules and `terraform validate` = Success, no
warnings. The one real risk — a `kms <-> access-broker` MODULE cycle (kms needs
the consuming role ARNs for its key policy; access-broker needs the key ARNs for
Lambda env) — was broken by CONSTRUCTING the deterministic role ARNs
(`arn:${partition}:iam::${account}:role/${prefix}-broker-handler` and
`...-sfn-exec`) in the root from caller-identity+partition data and handing those
to `kms`, so `kms` depends only on root data, not on the other modules.

**Files:** `platform/modules/{_baseline,kms,data-score,identity-cognito,
workflow-engine,access-broker,api-edge}/` (each: *.tf + PROVENANCE.md + copied
`lambda/`), `platform/live/poc-commercial/{main,variables,outputs}.tf`, test
harness `platform/_validate_module.sh` (+ `.validate_args.hcl` in the three
modules with required inputs).

**NEXT (for greg / a follow-up session):**
1. `terraform plan` the live root against 675405875014 (SoD) — validate ≠ plan;
   this is the first real AWS check. Consider a fresh `build-crypto-layer.sh` run
   so the crypto layer wheels match the deploy runtime (the built tree was
   vendored from the POC).
2. Decide if the test harness (`_validate_module.sh` + `.validate_args.hcl`)
   stays at `platform/` or moves to a `platform/tests/` dir.
3. Still open from before: two orphaned Windows accounts on `i-018bd775b286ff1b1`
   (us-east-2): `greg-racker-2eed`, `-6428` — manual reap.
4. Optional future: split standalone Class 3 `mfa`/`portal-runtime`/`edge-dns`
   modules behind the same inputs if adopters want them swappable.
5. `git init` still deferred (no repo home yet).

### 2026-09-08 — Platform (contract-first, brandable, modular, org-based) — PAPER DONE, building now

Strategic pivot captured and papered: turn the proven POC mechanism into a
PRODUCTIZABLE PLATFORM an adopter tailors (branding, front end, IdP, MFA, target
clouds, DevOps) WITHOUT re-solving 800-53. Pitch: "You're buried under the
800-53 mountain — our contract carries that weight so you don't have to."

**Two-tree repo model (decided; POC stays untouched + running):**
- Root `cli/ portal/ scripts/ terraform/` = the POC ("try it, see it run"). FROZEN
  as-deployed; do NOT move it or `terraform apply` it during platform work
  (ADR-0032).
- New sibling `platform/` = the contract-first product ("build your own"). Pure
  new scaffold; no POC files moved, no infra touched.
- Docs stay at repo root (no duplication). ADRs shared in `.kiro/steering/`.

**DONE this session (paper + scaffold):**
- `docs/TARGET-ARCHITECTURE.md` — north star: one core / many authorization
  boundaries / many compliance profiles; the four contracts; phased delivery.
- ADR cluster 0026–0032: 0026 contract-first platform (portal = reference client,
  not privileged; async-by-default); 0027 provider abstraction (connection is
  provider-DEFINED, nothing SSM-shaped in the contract; per-provider boundary);
  0028 identity by ASSURANCE not mechanism (Cognito is one impl; vCenter AD-trust
  is `authn_method:ad-trust` transitionally); 0029 boundaries + compliance
  profiles (800-53 Moderate/IL4/800-171 = profiles NOT forks; multi-cloud does
  NOT enter the IL4 boundary); 0030 layer coupling (HYBRID — remote-state for
  stable core, published SSM/manifest contract at provider/portal seams;
  reconciles ADR-0009); 0031 phased delivery (contracts PROVISIONAL until 2nd
  implementation — vCenter — proves them); 0032 non-disruptive parallel deploy +
  module-first (author modules FRESH from POC patterns, never move POC state;
  platform/live/poc-commercial stands up BESIDE the POC, own state/distinct names).
- `platform/` scaffold: README (the POC-vs-platform hinge + the 800-53 promise);
  `contracts/openapi/consumer-api.v1.yaml` skeleton mapped to the REAL POC
  endpoints; `contracts/schemas/resource-model.md` + `identity-assertion.md` +
  `contracts/provider-contract.md`; `modules/README.md` (REQUIRED vs CUSTOMIZABLE
  split) + `modules/_baseline/README.md` (non-optional 800-53 baseline);
  `live/README.md` (profiles compose modules).

**The four contracts (the product surface — everything else is impl behind them):**
  1. Consumer/Portal API (versioned OpenAPI) — any front end/mobile/ServiceNow/
     auditor tool is a client; RGS portal is a REFERENCE client.
  2. Canonical Resource + Capability model — UI renders from `capabilities`, never
     provider semantics.
  3. Identity assertion — assurance + attribution, not mechanism.
  4. Provider contract — List/Get/Start/Stop/Connect/GetCompliance/...; Connect is
     abstract (AWS=SSM, vCenter=own broker, Azure=Bastion/Arc).

**Compliance-inheritance guarantee (the whole value prop):** `modules/_baseline/`
is composed into EVERY profile (no opt-out); contracts refuse control-weakening
configs; each deploy emits an inheritance manifest (inherited vs customer-
responsibility, ADR-0020). Adopters customize CAPABILITY layers, never bypass the
SECURITY/800-53 baseline.

**NEXT (building now, Phase 1 — contract extraction, no new providers/IdPs):**
  1. Flesh out `platform/contracts/openapi/consumer-api.v1.yaml` against the ACTUAL
     request/response shapes of the current endpoints (auth, /resources ex
     list_instances/list_accounts, /resources/{id}/connect, /sessions incl
     operator scope, /sessions/{id}/terminate w/ reason, /jobs, /audit,
     /compliance). Generate real request/response schemas.
  2. Real machine-readable JSON Schemas for resource + identity-assertion (the
     write tool blocked self-declared remote `*.schema.json` in this mode —
     currently `.md` descriptors; regenerate as proper schemas during impl).
  3. Begin extracting `platform/modules/` FRESH from POC patterns (api-edge,
     workflow-engine=conductor, audit-logging, identity-cognito, _baseline).
  4. `platform/live/poc-commercial/` root that COMPOSES the modules (own state,
     distinct names) — stands up beside the POC.

**Carried-over open threads (unchanged):** ADR-0024 attribution retrofit (reads
too); deferred TTL/audit-retention 800-53 decision (AU-9/AU-11); automated test
harness (seeded-TOTP, no bypass — now framed as "prove the contracts hold");
two orphaned Windows accounts on i-018bd775b286ff1b1 (2eed/6428, manual reap);
git init deferred (no repo home yet).

---

### 2026-09-04 — [prior] session lifecycle + operator lens + compliance reassessment

### 2026-09-04 — One session record per connect + operator lens (ADR-0025): FIX-READY, needs one deploy + test

Live testing of the ADR-0023 fixes exposed a deeper structural bug: portal End
could act on the WRONG record. The portal Connect minted its OWN access request
+ ephemeral user (just to show the `passport connect` command), and the CLI then
minted a SECOND request + user — two records, two orphan-prone privileged
accounts, for one intended session. End hit the portal's record; the CLI's tunnel
lived on. Separately, a Racker had NO way to see/revoke another user's sessions.
Resolved as one coherent change per **ADR-0025** (session model + operator lens),
with **ADR-0024** recording the broader "attributed command-and-control plane"
principle. NOTE: the plane-wide ADR-0024 attribution retrofit (attribute+log
EVERY action incl. reads, via a shared helper) is a SEPARATE follow-up change,
deliberately NOT bundled here (kept the two ideas from conflating).

**WHAT CHANGED (all code + docs; ADR-0018 SoD — greg deploys/tests):**
1. `create_access_request` — stamps the target instance's `Customer` tag as
   `customer_id` on the record (region-aware, fail-open + logged) so the operator
   lens is tenant-scopable server-side.
2. Portal Connect provisions NOTHING (ADR-0025 §1) — it opens an instructions
   drawer with the install + `passport connect` command. The CLI's authenticated
   request is the SINGLE session record. (`ConnectButton.tsx` no longer calls
   POST /api/connect; `SessionDrawer.tsx` has instructions-mode vs live-mode.)
3. `list_sessions` — operator mode `GET /api/sessions?scope=all` (Rackers only,
   fail-closed 403 otherwise; optional `&customer_id=` tenant scope) via the
   status-index GSI; full detail, NO session secret (least privilege). Self mode
   unchanged.
4. `terminate_session` — parses a body; persists `ended_by` / `end_source` /
   `end_reason`; OPERATOR revoke (Racker ending another user's session) REQUIRES
   a reason, fail-closed 400 (ADR-0024). Self/CLI auto-attributed.
5. New `OperatorSessions.tsx` "Active Sessions (All Users)" console in the Racker
   dashboard: table (user/customer/instance/region/type/OS user/started/status),
   per-session End with a MANDATORY-reason dialog, tenant filter, 5s poll.
6. CLI: `client.go` Terminate sends `{reason, source}`; `connect.go` passes
   `source:"cli:exit"` on local-exit terminate. (CLI already created the single
   request — that part was already correct.)

Status vocabulary unchanged from ADR-0023. New record attrs: `customer_id`,
`ended_by`, `ended_by_id`, `end_source`, `end_reason`, `end_requested_at`.

**VERIFIED (Kiro, code-level):** py_compile (create_access_request,
list_sessions, terminate_session); `terraform validate` 03-api SUCCESS +
fmt-clean; SPA `npm run build` (tsc -b + vite) PASSED (bundle index-DOzYWFcV.js,
includes the operator console); CLI `go vet` + linux/windows/darwin builds PASSED.
No new API routes (reused GET /api/sessions?scope=all; terminate route now takes
a body). IAM: `ec2:DescribeTags` already present for the create Lambda (no change).

**ORDERED DEPLOY + TEST RUNBOOK (greg, SoD):**
1. **[DEPLOY] 03-api** (3 Lambdas: create_access_request, list_sessions,
   terminate_session):
   `cd terraform/03-api && AWS_PROFILE=personal-faws terraform apply`
2. **[DEPLOY] SPA** then HARD-RELOAD the browser (Empty Cache and Hard Reload):
   `AWS_PROFILE=personal-faws ./scripts/deploy-portal.sh`
3. **[DEPLOY] CLI** publish + reinstall `passport`:
   `cd cli && ./_make.sh cli && AWS_PROFILE=personal-faws ./publish.sh`
4. **[TEST] No phantom session / one record:** click Connect (RDP or SSH) in the
   portal → the drawer shows the command but NO card appears and NO ephemeral
   user is created yet. Run the `passport connect` command → NOW a single Active
   card appears (the CLI's session). Confirm only ONE `greg-racker-*` user exists
   on the box (not two).
5. **[TEST] One-click End still works (ADR-0023 regression check):** End that
   session once → it converges, access drops on the first click (SSH shell dies /
   RDP disconnects), execution shows `tunnels_terminated: 1`.
6. **[TEST] Operator lens:** as a Racker, the dashboard shows "Active Sessions
   (All Users)". Start a session as one user; confirm a Racker sees it with the
   correct user/customer/instance. Optionally filter by `customer_id`.
7. **[TEST] Operator revoke + mandatory reason:** click End on another user's
   session → the reason dialog appears; try submitting empty → blocked
   (client) and, if forced, 400 (server). Enter a ticket # → the session ends;
   confirm the record carries `ended_by` (the Racker), `end_source=operator:portal`,
   and `end_reason`.
8. **[TEST] Tenant isolation:** confirm the operator list, when filtered to
   Customer1, never shows Customer2's sessions (ADR-0021).

**AFTER THIS VERIFIES:** the next change is the ADR-0024 plane-wide attribution
retrofit (shared audit-emit helper on EVERY endpoint incl. reads). And `git init`
a baseline once both ADR-0023 and ADR-0025 are confirmed live.

### 2026-09-03 (later #3) — Session lifecycle "conductor" redesign (ADR-0023): FIX-READY, needs one coherent deploy + test

The incremental terminate fixes (I1/I2/I5/I6) were treating symptoms. Live
testing still showed sessions stranded at `CLEANING_UP` and 81 Step Function
executions `Aborted`. Root cause was structural: `terminate_session` called
`states:StopExecution`, which **aborted the conductor (the Step Function) before
it could write a terminal state** — so records never converged. Rather than
patch again, this is the ONE coherent redesign per **ADR-0023** (auto-included).
All code + docs edited (ADR-0018 SoD); greg runs the single deploy + test below.

**THE MODEL (ADR-0023):** the Step Function is the SOLE conductor — it verifies
each worker's actual result before advancing and owns all four teardown concerns.
DynamoDB is the score (records position, drives nothing). Every end-trigger
(portal End, operator revoke, CLI local exit, TTL) submits the SAME end-demand;
none performs its own teardown; `states:StopExecution` is forbidden.

**WHAT CHANGED (all in code, verified):**
1. `terminate_session/handler.py` — pure END DEMAND. Writes `END_REQUESTED`
   (ConditionExpression `#s IN (ACTIVE,PENDING,PROVISIONING)`; ConditionalCheck
   fail = already-ending, idempotent). Owner-or-Racker check kept. NO inline SSM
   cleanup, NO stop_execution.
2. `state-machine/access-lifecycle.asl.json` — verifying conductor (21 states).
   Both end paths route through `CLEANING_UP`; `CleanupUser` uses ResultSelector
   to read the cleanup Lambda's `verified`; `CheckCleanupResult` branches
   `OK -> COMPLETED`, else bounded retry (3x, 10s waits, States.MathAdd counter)
   `-> CLEANUP_FAILED` (NEW terminal state, writes error_detail). Removed the old
   silent `Catch -> COMPLETED`. Poll `Wait` 30s -> 10s.
3. `cleanup_user/handler.py` — owns tunnel teardown (concern d): `teardown_tunnels`
   paginates `ssm:DescribeSessions` (State=Active), matches Target==instance_id +
   DocumentName startswith `AWS-StartPortForwarding` + username in Owner, calls
   `ssm:TerminateSession` (best-effort, does NOT gate `verified`). `verified`
   now defaults to `INCOMPLETE` (never silent success).
4. `cli/internal/command/connect.go` — after `Connect` returns (ANY local end:
   Ctrl-C, shell exit, RDP exit, poll-detected server end), best-effort
   `client.Terminate` (fresh 10s ctx) so the server tears down the OS
   user/profile too. Fixes orphaned-user-on-CLI-exit.
5. Portal honesty: `list_sessions` now returns ending states
   (`END_REQUESTED`/`CLEANING_UP`) as well as live; `types.ts` union +2 states;
   `SessionsContext.tsx` simplified (removed the `pendingTerminations` hack —
   backend is authoritative now — maps truth 1:1, adaptive poll 3s/15s,
   `removeSession`->`markEnding`); `ConnectButton.tsx` shows non-actionable
   "Ending…" (two-click impossible by construction); `SessionDrawer.tsx` badge
   styles for the two new states.
6. `main.tf` IAM: removed `StepFunctionsExecutionControl` (StopExecution +
   DescribeExecution); added `ssm:DescribeSessions` + `ssm:TerminateSession`;
   kept `states:StartExecution`.
7. `scripts/purge-stranded-sessions.py` — one-time sweep for the pre-existing
   stranded rows (their executions were aborted, will never converge). Dry-run
   by default; `--apply` marks them `COMPLETED` + audit note; condition-guarded,
   idempotent, `--older-than-minutes` guard (default 15).

Status vocabulary now: `PENDING, PROVISIONING, ACTIVE, END_REQUESTED,
CLEANING_UP, COMPLETED, CLEANUP_FAILED, FAILED`.

**VERIFIED (Kiro, code-level):** all 4 Python handlers + purge script
`py_compile` OK; ASL valid JSON (21 states), no `StopExecution` action;
`terraform validate` (03-api) SUCCESS + `fmt`-clean; SPA `npm run build`
(tsc -b + vite) PASSED (also regenerates `portal/dist`, clearing the old
diagnostic build); CLI `go vet` + linux/windows/darwin builds PASSED.
Backup before the redesign: `FedRAMP-Portal-Idea-backup-20260903-153213.tar.gz`.

**ORDERED DEPLOY + TEST RUNBOOK (greg, SoD — one coherent pass):**
1. **[DEPLOY] Apply 03-api** (Lambdas + state machine + IAM). NOTE: no need to
   pre-stop RUNNING executions this time — the new conductor is compatible; but
   if a state-machine replace hangs on an in-flight execution, stop that one
   execution and re-apply.
   `cd terraform/03-api && AWS_PROFILE=personal-faws terraform apply`
2. **[DEPLOY] Rebuild + deploy the SPA**, then HARD-RELOAD the browser
   (DevTools > Empty Cache and Hard Reload) — `deploy-portal.sh` sets index.html
   `no-cache` but the tab may hold the old JS:
   `AWS_PROFILE=personal-faws ./scripts/deploy-portal.sh`
3. **[DEPLOY] Rebuild + publish the CLI**, then re-install `passport`:
   `cd cli && ./_make.sh cli && AWS_PROFILE=personal-faws ./publish.sh`
   Verify the new binary carries the teardown code:
   `strings "$(command -v passport)" | grep -c "closing connection"` (>0 = good);
   `passport version` shows a fresh build timestamp.
4. **[DEPLOY] Purge the pre-existing stranded rows** — dry-run first, then apply:
   `AWS_PROFILE=personal-faws python3 scripts/purge-stranded-sessions.py`
   `AWS_PROFILE=personal-faws python3 scripts/purge-stranded-sessions.py --apply`
5. **[TEST] SSH:** connect, then End Session ONCE in the portal → the pill shows
   "Ending…" (non-actionable) → the row disappears when the conductor reaches
   `COMPLETED` (~10-30s). SSH into the box after and confirm there is NO leftover
   `greg-racker-*` OS user and no lingering `/home/greg-racker-*`.
6. **[TEST] RDP:** same — End once → "Ending…" → gone; confirm no leftover local
   Windows user/profile and the SSM tunnel is torn down (server-driven, even if
   you didn't Ctrl-C the CLI).
7. **[TEST] CLI local exit:** connect, then just exit the shell / close the RDP
   client (do NOT press End in the portal). Confirm the session converges to
   `COMPLETED` on its own (the CLI submitted the end-demand) and the OS user is
   gone. This is the orphaned-user-on-CLI-exit fix.
8. If any session lands in `CLEANING_UP` for more than ~1 min, check the Step
   Function execution: it should be RUNNING (converging), not `Aborted`. A
   `CLEANUP_FAILED` terminal is the HONEST outcome when the instance couldn't be
   cleaned (e.g. SSM offline) — investigate the instance, it's not a conductor
   bug.

**Recommend `git init` after this verifies** — the repo is still not under
version control; this redesign is a good baseline commit (do it once, don't do
it mid-work).

### 2026-09-01 — Show-and-tell hardening: DEPLOYED + VERIFIED (removed WAF + Identity Center, fixed test users, added §8 compliance matrix)

Aligned the artifacts with reality before a broader demo (security engineers /
PM / leadership). Kiro edited code + docs (ADR-0018 SoD); greg ran the deploy +
the destroy of orphaned resources. All redeploy steps COMPLETE and verified by
ground truth; only the live browser logins remain (SoD).

**STATUS: DEPLOYED + VERIFIED 2026-09-01.** See "VERIFICATION RESULTS" below.

WHAT CHANGED (all committed to code/docs):
1. **WAF removed.** Deleted `terraform/03-api/waf.tf` (the WAFv2 ACL could never
   attach to HTTP API v2 — it was shelfware). Cleaned WAF wording in
   `front-door.tf`. SC-7 edge-WAF is now an explicit Needs-development gap
   (ALB or REST-v1 edge) in `docs/ARCHITECTURE.md` §8 + ARCHITECTURE-WEAKNESSES.
2. **Identity Center layer removed.** Deleted `terraform/01-identity-center/`
   (orphaned — portal auth is Cognito). Removed its remote_state + locals from
   `03-api/remote-state.tf`, the `VITE_IDENTITY_CENTER_START_URL` output from
   `03-api/outputs.tf`, and the SPA `ConsoleAccessButton` (it opened the dead
   start URL). IdP federation is now a documented Needs-development item
   (Cognito standalone today; ADR-0016 IdentityProvider seam exists).
3. **create-test-users.sh fixed.** Root bug: the pool uses
   `username_attributes=[email]`, so the old bare usernames (`greg-racker`)
   FAILED, and the errors were swallowed (`|| true` / `2>/dev/null`) — that's why
   only `greg-racker@rgs-test.local` ever existed. Now uses the email as the
   username, makes failures loud, standardized customer emails to
   `@rgs-test.local`. Customer IDs `customer1`/`customer2` confirmed to match the
   layer-04 EC2 `Customer` tags.
4. **Tenant isolation verified (code).** list_instances is fail-closed (empty
   customer_id -> zero instances) and filters `CustomerAccess=true AND
   Customer==customer_id`; SPA routes a Customers-group user to CustomerDashboard
   ("My Instances", no Racker framing). NOT yet proven by a LIVE customer login.
5. **ARCHITECTURE.md §8 replaced** — the old per-resource inherited/customer
   matrix is gone; §8 is now the single design-scoped control compliance-status
   matrix (Compliant / Inherited / Traded-off / Needs-development). §9 collapsed
   to a pointer. README + weaknesses doc reconciled; no competing control tables.
6. **drawio reconciled** — `docs/fedramp-portal-architecture.drawio`: removed the
   WAF node (widened API Gateway box, noted "no edge WAF — SC-7 gap"); added a
   dashed "Racker-only instances (negative control)" box (see below). XML
   validated well-formed.

VERIFICATION RESULTS (2026-09-01, ground truth):
- **Identity Center torn down (CLI path, Option B).** Deleted the Identity Store
  groups + removed the `01-identity-center/terraform.tfstate` object. Dir already
  gone. Confirmed clean.
- **Layer 03 applied:** `Apply complete! 0 added, 0 changed, 1 destroyed` —
  destroyed `aws_wafv2_web_acl.api`; `portal_env_config` output no longer has
  `VITE_IDENTITY_CENTER_START_URL` (now 5 keys). Cognito pool
  `us-east-1_Ud7Zxuvw0`, session-broker role, SSH CA, DynamoDB, state machine all
  intact.
- **SPA rebuilt + deployed:** `tsc -b` PASSED (confirms the ConsoleAccessButton
  removal compiles — the check that couldn't finish locally over the slow mount);
  new assets synced with `cli/*` preserved; verify = portal 200 / cli install 302
  (302 is correct — installer 302-redirects to the presigned S3 URL; the script's
  trailing "200 means intact" text is a stale echo, ignore it).
- **Cognito users created (all 4).** `custom:customer_id` CONFIRMED via
  admin-get-user: customer-user-1@rgs-test.local -> `customer1`,
  customer-user-2@rgs-test.local -> `customer2`. Both in Customers group (group
  membership does NOT scope tenants; the customer_id attribute does).
- **Instance tags CONFIRMED (live describe-instances):**
  - us-east-2: `i-018bd775b286ff1b1` + `i-0ad49105c83d2b748` = Customer=customer1 / CustomerAccess=true (the two customer1 tenant boxes).
  - us-west-1: `i-01129bff2d2c4ac40` + `i-0c9db6a0ce35ccb03` = Customer=customer2 / CustomerAccess=true (the two customer2 tenant boxes).
  - **Racker-only negative-control instances (INTENTIONAL, greg-deployed):**
    `i-094c23980efd3c633` (us-east-2, Customer=`customer-us-east-2`) and
    `i-0d803e7a9c4bc7072` (us-west-1, Customer=`customer-us-west-1`), both
    CustomerAccess=true. Their `Customer` value matches NO customer's customer_id,
    so `list_instances` (exact match) hides them from EVERY customer, while
    Rackers bypass the filter and see all six. This is a stronger isolation demo
    than the clean four — it proves exact-match tenant scoping, not just
    show-all/hide-nothing. NOTE (cosmetic, optional): the `customer-us-east-2` /
    `customer-us-west-1` tag scheme reads oddly next to `customer1`/`customer2`;
    consider retagging to something intentional (e.g. `rackspace-mgmt`) so the
    Racker view tells a clean story. Isolation math is identical as long as the
    value never equals a customer_id.

REMAINING (SoD — greg, live browser):
- **PROVE tenant isolation (the credibility demo):** log in as
  `customer-user-1@rgs-test.local` (first login = password change + MFA enroll
  in the browser). Confirm: lands on "My Instances" (NOT the Racker view),
  sees ONLY the two us-east-2 customer1 instances — NOT customer2, NOT the
  Racker-only `customer-us-east-2` box. Then log in as
  `greg-racker@rgs-test.local` and confirm the Racker view shows ALL SIX
  (both tenants + both Racker-only boxes). Config/attributes/tags are verified by
  ground truth (above); this final step is the live end-to-end proof of the
  isolation claim.

### 2026-08-31 (later #8) — Authoritative session termination: poll-loop state machine (AC-12), needs deploy

Fixed the "sessions don't reliably end / orphan RUNNING executions" concern
(greg's call — ending must be AUTHORITATIVE, not best-effort). Root issue: the
old machine did a single `Wait ttl_seconds` and relied on terminate_session's
best-effort `stop_execution`; if that call was skipped (missing execution_arn)
or failed, or if a session ended by client-TTL/operator-revoke (which don't call
that handler), the execution sat RUNNING until TTL — an orphan class.

NEW DESIGN (interruptible poll-loop), applying ADR-0022: Passport prior art =
Wait-for-TTL; 800-53 AC-12 wants reliable session termination; lowest-risk =
make the machine DETECT the end demand rather than hope an external call reaches
it. `access-lifecycle.asl.json`: after Active, loop
PollWait(30s) -> CheckEndDemand(dynamodb:getItem, ConsistentRead) ->
RouteEndDemand(Choice): status != ACTIVE -> cleanup (end demand);
$$.State.EnteredTime >= expires_at_iso -> cleanup (TTL); else keep polling.
`terminate_session` now WRITES status=CLEANING_UP (authoritative — poll-loop
acts within ~30s) + keeps the immediate SSM cleanup (instant user drop);
stop_execution demoted to best-effort fast-path (harmless if missing/failed).
`create_access_request` adds `expires_at_iso` (RFC3339) for the Choice.
sfn_app IAM already had dynamodb:GetItem. Verified: ASL well-formed (14 states,
no orphan/unreachable), handlers py_compile, all 3 end-paths (TTL / terminate /
operator-revoke) converge to cleanup+COMPLETED. Max orphan/latency window now =
1 poll interval (~30s), regardless of stop_execution.

DEPLOY (greg, SoD): (1) STOP existing RUNNING executions (they're on the OLD
single-Wait machine; a state-machine replace hangs otherwise). (2)
`cd terraform/03-api && AWS_PROFILE=personal-faws terraform apply` — replaces the
state machine + updates create_access_request & terminate_session Lambdas. Cost:
1 getItem per 30s per ACTIVE session (~1440 reads for a 12h session — negligible,
PAY_PER_REQUEST). E2E: start a session, hit End Session -> execution should reach
COMPLETED within ~30s (not sit RUNNING); and a session left alone should
self-COMPLETE right at its TTL, not linger.

### 2026-08-31 (later #7) — Windows/RDP added to CLI + drawer SSH/RDP instructions fixed (ADR-0022)

RDP is now first-class in the Go CLI, following the Passport V2 pattern (SSM
tunnel to 3389 + native RDP client), per ADR-0022 (Passport prior art ->
800-53 -> lowest-risk).
- CLI: `passport connect <win-instance> --region <r> --rdp`. RequestAccess
  access_type=rdp; AwaitReady captures the short-lived password + 3389 port;
  NO SSH cert issued (RDP uses the provisioned password, not a cert); vend SSM
  creds; open the 3389 SSM tunnel (same isolated-creds tunnel code); then
  holdForRDP() prints Host localhost:<port> / Username .\<user> / Password and
  BLOCKS until Ctrl-C (keeps the tunnel up for mstsc / Microsoft Remote
  Desktop). SSH path unchanged (cert -> shell).
  Files: cli/internal/command/connect.go (--rdp flag, skip cert for rdp),
  connection.go (Target.AccessType, Session.AccessType/Password),
  awsec2/awsec2.go (rdp in RequestAccess/AwaitReady), awsec2/tunnel.go
  (Connect branches; holdForRDP), api/client.go (SessionConnection.TemporaryPassword).
  Build+vet green; --rdp help verified.
- SPA drawer: BOTH instruction sets now reflect the CLI. SSH already showed
  `passport connect`; RDP REPLACED the stale raw `aws ssm` + mstsc dance with
  install-once + `passport connect <id> --region <r> --rdp` + the paste-into-
  RDP-client block (Host/Username .\user/Password printed by CLI). tsc type-check
  passed.
- CREDENTIAL SOURCE (ADR-0022 clause 3): today the CLI reads the Windows
  password from get_session_status (connection.temporary_password), which the
  Step Function currently provisions and stores (the known SC-28 gap). The
  RESIDUAL is unchanged from before — the CLI just surfaces it cleanly instead
  of the old UI. The clean close (vend-on-demand, generated per session, never
  stored) is the next backend step; documented as residual, not silently
  shipped. SSH remains the passwordless/cert gold path.

**PROVEN END-TO-END 2026-08-31:** `passport connect i-018bd775b286ff1b1
--region us-east-2 --rdp` in a scrubbed shell → MFA login → tunnel
localhost:33674 -> :3389 → pasted Host/`.\greg-racker-ca38`/password into RDP
client → interactive Windows desktop. `whoami` = ec2amaz-sl0n5tm\greg-racker-ca38
(identity-named local account = ADR-0011 attribution on Windows). Credential-less
+ MFA-authenticated + attributed, same as SSH.

STATE-MACHINE "RUNNING EXECUTIONS" INVESTIGATED 2026-08-31 — NOT a bug (corrected):
Investigated "many RUNNING executions despite sessions timed out/stopped."
Pulled execution history for a long-standing one (access-0551f116...): input
was correct (ttl_minutes 60 / ttl_seconds 3600); history shows Provision ->
Active -> WaitForSessionExpiry entered, then ExecutionAborted ~51 min later
(under the 60-min TTL) — i.e. it was still LEGITIMATELY waiting and got manually
stopped, not stuck. CORRECTION to my earlier read: I computed "age" as
wall-clock-since-start-until-NOW (~1359 min), which conflated "started long ago"
with "ran long"; actual runtime (WaitEntered->Aborted) was ~51 min. So:
- By design a session holds a RUNNING execution for its FULL TTL (up to 12h) —
  WaitForSessionExpiry. Many concurrent RUNNING = many active sessions, expected.
- Portal terminate DOES abort the execution (stop_execution) — that's why they
  show ABORTED not orphaned-RUNNING. Working.
REAL findings (observability/ops, not correctness):
  (a) A healthy long-waiter is indistinguishable at a glance from a stuck one;
      no tag/alarm to tell them apart. Add per-execution identity/tag + a
      CloudWatch alarm on executions running > their own TTL+grace.
  (b) No cap / no orphan sweeper: if stop_execution ever failed (e.g.
      execution_arn not stored), an execution would sit until TTL then self-
      clean — confirm execution_arn is ALWAYS persisted by create_access_request
      (it is written in a follow-up update_item; if THAT update fails, terminate
      can't stop it — minor hardening: store execution_arn in the same put or
      handle the missing-arn case).
  (c) The deploy runbook's "stop RUNNING executions before state-machine
      replace" step is the source of the manual stops that produced the ABORTED
      pile — expected operational noise, not a defect.

OPERATOR RUNBOOK + AC-2 FINDINGS 2026-08-31: wrote docs/OPERATOR-RUNBOOK.md
covering the 3 distinct user-lifecycle events (onboard / revoke / delete). Key
verified facts baked in:
- Onboard = Cognito admin-create-user + group (Rackers|Customers) + (Customers
  only) custom:customer_id matching the instance Customer tag + USER's browser
  first-login (password change + TOTP enroll — the CLI SRP flow CANNOT do first-
  login MFA enrollment, only answer an existing challenge).
- REVOKE and DELETE must HARD-KILL active sessions FIRST (terminate SSM session
  + remove ephemeral OS user = what drops a live RDP/SSH; same teardown as the
  portal "End Session"/terminate_session handler; Rackers exempt from ownership
  so an operator can terminate anyone's session). Enumerate a user's sessions
  via the user-index GSI keyed on Cognito sub (= user_id). THEN admin-disable-
  user (revoke, reversible) or admin-delete-user (delete, not reversible).
- REVOCATION-LATENCY caveat (auditor-relevant, documented): admin-disable-user
  blocks new logins + revokes tokens, but an already-minted access token stays
  valid <=1h against OUR API GW JWT authorizer (validates locally, doesn't call
  Cognito). With sessions killed + account disabled, residual = read-API only
  for <=1h, cannot open a NEW connection. Ties to the existing IA-2/SC-23
  bearer-token gap.

PRODUCT GAP IDENTIFIED (log for AC-2(1)): revoke/delete are currently a MANUAL
multi-step operator sequence (runbook-driven). Automated account management
wants a SINGLE portal admin action ("Revoke user" -> enumerate sessions -> hard-
kill each -> disable Cognito, in one call), and an IR-4 "kill ALL sessions"
break-glass (already a listed gap). Not built; runbook is the interim. An
assessor will note the manual nature.

RDP DRAWER CREDENTIAL MISMATCH FIXED 2026-08-31: the drawer's "Then in your RDP
client" block showed Host/Username/Password from the DRAWER's bound session
record (e.g. .\greg-racker-bb4c), which NEVER matches what `passport connect
--rdp` returns — the CLI creates a NEW access request with its OWN username/
port/short-lived password (e.g. .\greg-racker-6428). So the drawer values were
actively WRONG for the CLI flow, not just redundant. FIX: removed the specific
Host/Username/Password from the RDP drawer; it now says "use the values the CLI
prints (authoritative; each connect gets a fresh username/port/password)" and
keeps only the non-session-specific `.\` local-login tip. SSH prose likewise no
longer promises a specific username. tsc -b clean. NEEDS SPA redeploy
(./scripts/deploy-portal.sh).

DRAWER CREDENTIALS SECTION REMOVED 2026-08-31: the Active Session drawer no
longer renders username/password. Rationale (small SC-28/attack-surface win, not
just cosmetic): SSH is passwordless (cert); for RDP the passport CLI prints the
short-lived password in-context when it opens the tunnel, so showing it in the
browser DOM too was a redundant exposure surface (screenshot/shoulder-surf).
Now the session secret lives in exactly one place (CLI output) at connect time,
never in the portal UI. Removed the Credentials <section> + dead `password`
const + `CopyableField` component. tsc -b clean. NEEDS SPA redeploy
(./scripts/deploy-portal.sh) to go live.

CONCURRENT MULTI-OS PROVEN 2026-08-31: two simultaneous sessions via the one
CLI — RDP to Windows (greg-racker-ca38, localhost:33674->3389) AND SSH to Amazon
Linux 2023 (greg-racker-4160, localhost:2476->22) at the same time. Per-session
random local ports (no collision) + distinct identity-derived usernames per
request (independent attribution) both confirmed under concurrent use.

NIT (cosmetic, log for later): the RDP profile-loading screen shows display name
"Portal Temp User" — the provision script sets a generic full-name on the local
user. Security principal is correct (greg-racker-ca38 in whoami/CloudTrail/SSM
logs); only the Windows *display name* is generic. Fix: set the local user's
full name to the identity in the Windows provision script. Not urgent.

DEPLOY (greg): rebuild+publish CLI (`cd cli && ./_make.sh cli && AWS_PROFILE=personal-faws ./publish.sh`)
+ portal via the SAFE script (`AWS_PROFILE=personal-faws ./scripts/deploy-portal.sh` — syncs with `--exclude "cli/*"` so the SPA sync does NOT delete the CLI artifacts; a bare `s3 sync --delete` WILL wipe cli/releases/ and 500 the installer — this bit us).
E2E: `passport connect <Windows i-... SSM-Online> --region us-west-1 --rdp` ->
MFA -> tunnel + printed values -> paste into mstsc. (Windows test instances
exist in us-east-2 + us-west-1.)

### 2026-08-31 (later #6) — Go CLI PROVEN END-TO-END ✅ (ADR-0015/0016/0012)

Published + verified live. In a SCRUBBED shell (`aws sts get-caller-identity`
FAILED with ExpiredToken — no usable ambient creds), ran:
`passport connect i-0d803e7a9c4bc7072 --region us-west-1`
→ CLI prompted username + password + MFA code (its OWN Cognito SRP+MFA, no token
pasted) → Authenticated as greg-racker@rgs-test.local → request → active as
greg-racker-b46b → cert → vend → tunnel (localhost:2390 -> instance:22) → SHELL
as greg-racker-b46b on Amazon Linux 2023. All four properties proven at once:
credential-less (no AWS creds), replay-resistant (token EARNED via MFA, none to
lift), attributed (greg-racker-b46b in OS user + SSM SessionId), instance-scoped.

Two fixes made during publish (both deployed):
1. Binary download 500 -> the ~8.5MB binary exceeded the 6 MiB Lambda response
   cap (base64 ~11MB). serve_spa now 302-redirects cli/releases/ keys to a
   presigned S3 URL (direct download, bucket stays private).
2. Presigned URL 400 (InvalidArgument: SSE-KMS requires SigV4) -> the default
   presigner emitted SigV2. Added a dedicated presign client pinned to
   signature_version=s3v4 + regional endpoint. Verified: redirect now
   X-Amz-Algorithm=AWS4-HMAC-SHA256, binary downloads, sha256 matches.

The interim scripts/passport-connect.sh + prove-credential-less.sh remain as
test tools; the Go CLI is the product path. Bearer-replay ORIGIN closed for the
CLI (DPoP/mTLS still the future residual — ARCHITECTURE-WEAKNESSES §2).

### 2026-08-31 (later #5) — PRODUCTION Go CLI `passport` BUILT (ADR-0015/0016/0012), published + PROVEN (see #6)

Bit off the big lift: a real cross-platform Go CLI that replaces the interim
shell script AND does its OWN Cognito auth+MFA (no handed-over bearer token).
All code written + built + vetted + smoke-tested locally. NOT published/e2e'd
(SoD, ADR-0018: greg publishes artifacts + runs the live MFA connect).

**Where it lives:** `cli/` (new Go module `github.com/rackspace/fedramp-portal/cli`),
structured per ADR-0016:
- `internal/identity` — IdentityProvider iface; `internal/identity/cognito` =
  real USER_SRP_AUTH + SOFTWARE_TOKEN_MFA (SRP via vetted
  github.com/alexrudd/cognito-srp/v4; hidden password via x/term; TOTP prompt).
  The CLI EARNS its token — no browser token handoff.
- `internal/connection` — ConnectionProvider iface; `internal/connection/awsec2`
  ports ssmtransport.go: RequestAccess -> AwaitReady(poll) -> IssueCredential
  (ephemeral ed25519 + /api/sign) -> VendCredential (.../ssm-credentials) ->
  Connect (SSM StartSession using ONLY vended static creds — never
  LoadDefaultConfig; ADR-0018 isolation — session-manager-plugin exec + ssh
  cert PTY) -> Cleanup (TerminateSession + shred).
- `internal/api` typed client; `internal/command` cobra (`passport connect
  <instance> --region [--ttl]`, version); `cmd/passport`; `internal/version`.

**Toolchain:** Go 1.24.5 user-local ~/.local/go-sdk/go (scripts/_install-go.sh).
GOTOOLCHAIN=local pinned (no silent upgrade — reproducible/audited). Helpers:
cli/_goenv.sh, _build.sh, _reset_deps.sh (pins x/term 0.27 / x/sys 0.28 /
x/crypto 0.31 for 1.24), _make.sh, _smoke.sh, _verify_artifacts.sh,
_verify_install.sh.

**Cross-compile + distribute:** `cli/Makefile` `make cli` -> linux amd64/arm64,
darwin amd64/arm64, windows amd64 into build/<os>-<arch>/passport(.exe) +
build/SHA256SUMS. Verified: correct formats, static+stripped, checksums verify,
host binary runs. `cli/dist/install.sh` + `install.ps1` = download + sha256
verify + place on PATH (download-verify-install, NOT curl|bash-of-logic;
CM-5/SI-7/SA-10). `cli/publish.sh` uploads to
s3://fedramp-portal-static-675405875014/cli/releases/LATEST/ (served by the
existing serve_spa $default route — NO Terraform change; serve_spa serves any
bucket key).

**SPA:** SessionDrawer SSH section now = one-time install block (OS toggle) +
`passport connect <instance> --region <region>`. "Copy access token" button
GONE (CLI logs in itself). `npm run build` passes.

**PUBLISH + VERIFY RUNBOOK (greg, SoD):**
1. `cd cli && ./_make.sh cli`
2. `AWS_PROFILE=personal-faws ./publish.sh`
3. `cd ../portal && npm run build && /home/greg/.local/bin/aws s3 sync dist/ \
   s3://fedramp-portal-static-675405875014/ --delete`
4. install: `curl -fsSL https://portal.takahe.click/cli/releases/LATEST/install.sh \
   -o /tmp/install.sh && bash /tmp/install.sh`
5. E2E in a SCRUBBED shell (no AWS creds; confirm `aws sts get-caller-identity`
   FAILS): `passport connect <i-... Linux SSM-Online> --region us-east-2` ->
   prompts portal user + password + MFA (the CLI's OWN auth, no token pasted) ->
   shell as greg-racker-<suffix>. Proves credential-less AND replay-resistant
   auth. Needs the SSM Session Manager plugin installed.

**FIX during publish (2026-08-31 later #5): binary download 500 -> presigned
redirect.** serve_spa proxies bucket objects as base64 through Lambda, but the
~8.5MB passport binary exceeds the 6 MiB Lambda/API-GW response cap (base64
~11MB) -> 500 (verified: install.sh text served 200, binary 500). FIX: serve_spa
now, for keys under `cli/releases/` that exist, returns a 302 to a 5-min
PRESIGNED S3 URL (client downloads directly from S3; bucket stays private; no
size limit). install.sh/.ps1 + drawer one-liner already follow redirects
(curl -L / Invoke-WebRequest). REQUIRES a `terraform apply` of layer 03 to
deploy the serve_spa change (greg). Small assets/scripts still proxied normally.

**Bearer-replay gap (IA-2/SC-23): CLI path closes the ORIGIN.** No browser token
to lift — the CLI does SRP+MFA itself. Residual (tracked): the minted access
token is still bearer for ~1h; DPoP/mTLS proof-of-possession is future work.
See ARCHITECTURE-WEAKNESSES §2 + ADR-0012/0016.

### 2026-08-31 (later) — Credential-vending endpoint BUILT in code (ADR-0012), needs deploy + scrubbed-shell proof

Built the credential-vending endpoint so the SSM tunnel is credential-less for
the user (customer or Racker with no AWS account). Mirrored production Passport
(`ssmtransport.go` / `heimdall.go` / `credentials.go`) before writing code; the
scoping is COPIED from `passportCLIPolicyDocument`, not invented. All code
written + structurally verified (bash -n, py_compile, terraform fmt). NOT
deployed — SoD (ADR-0018): greg runs terraform + the proof.

**What was written (all in `terraform/03-api` + `scripts/`):**
- `session-broker.tf` — `aws_iam_role.session_broker` assumable ONLY by
  `lambda_exec` (max_session_duration 3600). Its identity policy is the full
  SSM-connect capability; each vend is NARROWED at AssumeRole time by an inline
  session policy (STS intersection semantics — verified against AWS docs).
  `lambda_assume_broker` grants `lambda_exec` `sts:AssumeRole` on the broker
  role ONLY (the single AssumeRole edge). Output `session_broker_role_arn`.
- `lambda/ssm_credentials/handler.py` + wiring in `main.tf` — new route
  **`POST /api/session/{requestId}/ssm-credentials`** (JWT-authorized). authN
  via Cognito JWT; authZ = ownership (caller `user_id` == request owner, or
  Racker) else 403 (tenant isolation, fail-closed, ADR-0021); status must be
  ACTIVE else 409. `_session_policy_document` copies `passportCLIPolicyDocument`
  EXACTLY: `ssm:StartSession` on ONLY the two AWS session-doc ARNs (empty
  account id `::`) + the ONE target instance ARN (i- → ec2 namespace, mi- → ssm
  managed-instance; any other prefix rejected), plus tag-conditioned
  Terminate/Resume. `sts:AssumeRole` with that inline `Policy`,
  `RoleSessionName` = identity-derived username (CloudTrail attribution,
  AU-2/AU-3/AU-12), `DurationSeconds` = min(remaining TTL, 3600) with a 900s STS
  floor. Vend is audit-logged (no secrets). Env: `TABLE_NAME`,
  `SESSION_BROKER_ROLE_ARN`, `PORTAL_PARTITION` (own key — AWS_ prefix is not
  blanket-reserved but PORTAL_ is unambiguous).
- `scripts/passport-connect.sh` — interim credential-less CLI (pre Go rewrite).
  One command: /api/connect → poll /api/session/{id} → ephemeral ed25519 keygen
  in a mktemp dir (trap-shred on exit) → /api/sign → **ssm-credentials vend** →
  `aws ssm start-session` using ONLY the vended creds → ssh with the cert (no
  password). The tunnel subshell scrubs `AWS_*` AND repoints
  `AWS_SHARED_CREDENTIALS_FILE`/`AWS_CONFIG_FILE` at empty files so no ambient
  profile can mask a bad vend.
- `scripts/prove-credential-less.sh` — the ADR-0018 proof harness. Builds a
  genuinely credential-less env (env scrub + empty `~/.aws` files), ASSERTS
  `aws sts get-caller-identity` FAILS (aborts if it succeeds = invalid proof),
  then runs passport-connect.sh in that env.

**CRITICAL FINDING (baked into both scripts):** env-only scrubbing is NOT
sufficient — this box's `~/.aws/credentials` has a `[default]` profile the CLI
falls back to. It is currently ExpiredToken (so it leaks through as a failure
today), but a refresh would make an env-only-scrubbed test FALSE-PASS on the
default profile — the exact ADR-0018 trap. Fix: also neutralize the shared
credential/config files. Verified: scrubbed+isolated env →
"Unable to locate credentials" (a real credential-less failure).

**DEPLOY + PROVE RUNBOOK (greg runs; ADR-0018 SoD):**
1. [DEPLOY, personal-faws] `cd terraform/03-api && terraform init &&
   terraform validate && terraform apply` — adds the session-broker role +
   ssm_credentials Lambda + the new route. (No portal rebuild needed unless you
   also wire the endpoint into the SPA; the CLI path stands alone.)
2. Get a Cognito JWT (identity only): log into the portal, copy the access
   token from the session (or use an org-approved issuer). MFA is required, so
   there is no scriptable password path here yet — the Go CLI (ADR-0016) will
   own real device auth.
3. [BROKER-TEST, profile ABSENT] run the proof — do NOT re-add personal-faws:
   ```
   PORTAL_TOKEN=<jwt> ./scripts/prove-credential-less.sh \
     --instance <i-... a Linux SSM-Online test instance> --region us-east-2
   ```
   Expect: Step 1 confirms `get-caller-identity` FAILS; Step 2 still tunnels +
   sshs. THAT is the credential-less proof. If it only works with personal-faws
   present, it is NOT done.
4. Negative checks worth doing while you have a token: (a) call ssm-credentials
   for a request you don't own → expect 403; (b) with a vended cred, try
   `aws ssm start-session` against a DIFFERENT instance → expect AccessDenied
   (proves the inline scoping restricts as intended, closing task #4's loop
   at runtime).

Known gaps still open: no WAF on the HTTP API v2 front door (SC-7); interim
browser key-download UX (the CLI supersedes it for SSH).

### 2026-08-31 (later #4) — ATTRIBUTION FIX DEPLOYED & VERIFIED ✅ (ADR-0011)

DEPLOYED (plan: 3 add / 9 change / 1 destroy — the "destroy" was just the
immutable shared layer version :3 superseded by :4 after the portal_utils edit;
pool updated IN-PLACE, no user loss). Re-logged in → new access token now
carries `email` (confirmed in the decoded token). Re-ran the proof: provisioned
user is now **greg-racker-9b21** (was unknown-XXXX) — OS user, SSM SessionId
(greg-racker-9b21-...), and CloudTrail RoleSessionName all name the real person.
ADR-0011 attribution CLOSED for the vend path.

STILL OPEN (unchanged by this): bearer-token replay (IA-2/SC-23). Re-observed in
this run — pasting the token into a WSL shell granted access from anywhere with
no MFA re-challenge. Attribution now correctly says greg-racker, but a STOLEN
token would also say greg-racker (honest, not thief-detecting). Fix = proof-of-
possession tokens (DPoP/mTLS) + short TTL + anomalous-use monitoring + the Go CLI
(ADR-0016) doing its own Cognito+MFA instead of accepting a handed-over token.

Was: needs deploy. Details below (kept for the build record).

### (build record) ATTRIBUTION FIX built (ADR-0011)

Fixes the `unknown-9656` username bug: the access token had no `email` claim, so
username derivation fell back to "unknown".
- `lambda/pre_token_generation/handler.py` — Cognito Pre Token Generation trigger
  (V2_0) that injects `email` (+ custom:customer_id) INTO the access token at
  issuance. V2_0 is required for access-token claim customization (V1_0 = ID
  token only). Fail-open (never blocks login).
- `cognito-triggers.tf` — the trigger Lambda + `aws_lambda_permission` for
  cognito-idp to invoke it (scoped to this pool). `main.tf`: added
  `lambda_config { pre_token_generation_config { lambda_version = "V2_0" } }` to
  aws_cognito_user_pool.portal.
- `portal_utils.get_user_from_event` — hardened fallback so attribution NEVER
  lands on literal "unknown": email -> custom:email -> cognito:username (if not
  the UUID sub) -> sub. Defense in depth if the trigger is ever absent.
Verified: py_compile, tf fmt, unit tests (post-trigger -> greg-racker-*; bug
case -> sub not "unknown"; trigger injects email+customer_id).

DEPLOY: `cd terraform/03-api && AWS_PROFILE=personal-faws terraform apply`
(adds pre_token_generation Lambda + permission; MODIFIES the user pool to add
lambda_config — expect 1 change + 2 adds). Then RE-LOGIN to the portal to mint a
NEW token (old tokens predate the trigger and still say nothing/unknown), grab
the fresh access_token, and re-run prove-credential-less.sh — the provisioned
user should now be greg-racker-<suffix>, not unknown-<suffix>.

NOTE: this does NOT address the bearer-token replay threat (separate gap,
IA-2/SC-23) — that needs proof-of-possession tokens + the Go CLI doing real auth.

### 2026-08-31 (later #3) — CREDENTIAL-VENDING PROVEN END-TO-END ✅ (ADR-0012)

Deployed layer 03-api (7 resources added, 0 changed) and PROVED it in a scrubbed
shell: `prove-credential-less.sh` confirmed `aws sts get-caller-identity` FAILS
(no ambient creds — env scrubbed + ~/.aws isolated), then the connect flow still
vended scoped STS creds, opened the SSM tunnel, and dropped into a shell on
i-094c23980efd3c633 (us-east-2) with NO password and NO user AWS creds. This is
the real credential-less proof. Gap #2 (tunnel needed AWS creds) is CLOSED.

**SCOPE OF THE PROOF — read this before claiming "done".** We tested the whole
thing from a WSL shell by REPLAYING a bearer `access_token` lifted from the
browser session — we did NOT perform the Cognito login/MFA ceremony in the CLI.
So we proved the AUTHORIZATION / VENDING half (creds come from the endpoint,
scoped to one instance) using a STUB for AUTHENTICATION. The "portal login =
authentication" half was assumed, not exercised. Implications (now tracked):
- The token is a BEARER token: whoever holds it (devtools, proxy, leaked log,
  XSS) can replay it from any shell for its full ~1h life, no MFA re-challenge,
  no proof-of-possession. This is inherent to bearer tokens, not a flaw in the
  vend endpoint — but it is a real threat we had not written down (IA-2, SC-8,
  SC-23, AC-12). See ARCHITECTURE-WEAKNESSES §2 (new row) + ADR-0012.
- The interim `passport-connect.sh` deliberately punts auth (takes --token). The
  REAL client (Go CLI, ADR-0016) must do Cognito device/SRP + MFA itself and
  never accept a pre-obtained token. Until then, "credential-less" means "no AWS
  creds"; the portal identity token is still a secret the user must protect.
- Reinforces the attribution gap below: a replayed token attributes to the
  original human — correct if it's them, silently wrong if stolen.

Fixed during the run: `passport-connect.sh` api() set HTTP_STATUS as a global but
is called via $(...) (subshell) — under `set -u` the parent read aborted
("unbound variable"). Reworked so api() prints HTTP status as the first stdout
line; callers split via api_status/api_body. No globals across subshells.

**Negative checks — one conclusive, one inconclusive (re-test pending):**
- (b) INSTANCE SCOPING: PROVEN. Vended creds for i-094c... were DENIED
  StartSession on a different instance i-0ad4...: "An error occurred (403) ...
  Server authentication failed / Forbidden". The inline session policy scopes
  the creds to exactly one instance (AC-6/AC-6(1) confirmed at runtime).
- (a) OWNERSHIP: INCONCLUSIVE. The all-zeros-request-id call returned 401, not
  the expected 404/403 — 401 comes from the API GW JWT AUTHORIZER (token), not
  the handler, so it tested the authenticator, not the ownership logic (likely
  token expiry between commands). To properly test: re-run with a FRESH token +
  a well-formed non-owned request id. Expect 404 (auth passed, request not
  found = handler ran) for a bogus id, 401 only when NO/expired token. Truly
  proving the 403 ownership branch needs a SECOND user's real request id (do
  with a customer test user later). Not a code concern — the handler returns
  404/403/409 by design; 401 is upstream.

**NEW BUG FOUND (attribution, ADR-0011 — not yet fixed):** the provisioned user
came back as `unknown-9656`, not `greg-racker-9656`. Root cause: the ACCESS token
(what the SPA/curl sends, validated by the API GW JWT authorizer) has NO `email`
claim — only the ID token does. `get_user_from_event` falls back to "unknown",
so `derive_username` builds `unknown-<suffix>`. Vend/tunnel work (everything keys
off provisioned_username consistently), but OS-user / CloudTrail attribution says
"unknown" — an AU-3/AC-2 regression in VISIBLE behavior. Predates the vend
endpoint (lives in create_access_request + get_user_from_event). FIX OPTIONS
(decide deliberately): (a) Cognito pre-token-generation trigger to add `email` to
the access token [most robust; fixes at source]; (b) get_user_from_event falls
back to cognito:username [but here that's the sub, not human-readable]; (c) SPA
sends id token [must re-check authorizer audience/scope]. Leaning (a). Track
before calling ADR-0011 "done" for the vend path.

### 2026-08-31 — DEPLOYED & VERIFIED END-TO-END on takahe.click ✅

The full stack is DEPLOYED to account 675405875014 and the passwordless SSH-cert
flow was proven end-to-end. Domain: **takahe.click** (portal.takahe.click).
This SUPERSEDES all earlier "NEXT SESSION" runbooks below (they were the
pre-deploy plan; keep for history).

**What is live and confirmed working:**
- Layers 00–05 all applied. Front door = single same-origin API Gateway
  (REGIONAL) + ACM cert (ISSUED) + Route 53 (single TF-managed zone
  Z08318621LMM3I7AB5J2J; registrar NS repointed to it) serving SPA + API.
  CloudFront fully removed (ADR-0019).
- SSH CA initialized (`init-ssh-ca.sh` run once; CA key in Secrets Manager,
  pubkey in SSM param). `sign_key` + `serve_spa` Lambdas live.
- Portal loads at https://portal.takahe.click; Cognito login (same-origin
  callback) works; `/api/*` returns 401 unauth (auth correct).
- **Passwordless SSH cert login CONFIRMED**: browser gen keypair → /api/sign →
  ssh -i <key> -o CertificateFile=<cert> greg-racker-8836@localhost -p <port>
  → shell, NO password. Server accepted ED25519-CERT, rejected ambient keys.
  Identity-named user (greg-racker-8836) = ADR-0011 working.
- 4 test instances (us-east-2 + us-west-1, Linux+Windows) running, SSM Online.
- Cognito test users exist (greg-racker, greg-readonly, customer-user-1/2).

**KNOWN GAPS carried forward (see ARCHITECTURE-WEAKNESSES.md):**
1. **NO WAF at the front door (SC-7).** WAFv2 canNOT attach to HTTP API v2
   (verified at deploy: only REST API v1 / ALB / etc. are WAF targets). The
   ACL exists but is UNASSOCIATED. My earlier "WAF works on v2" claim was WRONG.
   Remediation options recorded; likely reopens ALB-vs-API-GW for the IL4 tier.
2. **Tunnel still needs AWS creds (the NEXT BUILD — see below).** The SSM
   tunnel used AWS_PROFILE=personal-faws. Cert issuance is credential-less;
   the transport is not — yet. Fixed by the credential-vending endpoint below.
3. Key-download UX: browser downloads key/cert as files (POC placeholder);
   the connect script/CLI below replaces it with in-memory/ephemeral handling.
4. temp `us_east_1` provider block was REMOVED from 02/main.tf post-deploy (02
   re-planned clean = No changes). Do not re-add.

---

### ⭐ THE NEXT BUILD — Credential-vending endpoint (ADR-0012, mechanism RESOLVED)

**Goal:** make access credential-less for the USER (customer or Racker with NO
AWS account), matching production Passport. Login = authentication; the portal
then VENDS scoped, short-lived AWS authorization for the specific session. This
closes gap #2 and #3 above and is the ADR-0012 payoff.

**We READ production Passport source and the mechanism is now PROVEN (not a
research task).** Reference files (mirror these — ADR-0003/0013):
- `Chappies-Tools/passport/passport/cli/connect/ssmtransport.go`
  → `getSSMCreds()` + `GetSSMAPI()`: client gets STS creds from the backend,
    builds the SSM client via `NewStaticCredentialsProvider`. No user AWS creds.
- `Chappies-Tools/passport/passport/internal/heimdall/heimdall.go`
  → `passportCLIPolicyDocument()`: THE scoping template to copy. Vends STS
    scoped to `ssm:StartSession` on ONLY the target instance ARN(s) +
    StartPortForwarding/StartSSHSession documents, `DurationSeconds=3600`,
    STS session name = the identity (CloudTrail attribution).
- `Chappies-Tools/passport/passport/server/middleware/credentials.go`
  → how the backend wires the JWT identity → scoped creds.

**Build plan (order):**
1. **Terraform (layer 03): an assumable "session broker" role** the API can
   `sts:AssumeRole` into, whose trust allows the lambda_exec role. Keep the
   role's own permissions minimal; the SCOPING happens via the inline session
   policy passed at AssumeRole time (like heimdall's policy document).
2. **New Lambda + route: `POST /api/session/{requestId}/ssm-credentials`**
   (JWT-authorized). Handler:
   - get_user_from_event (Cognito JWT) — authN.
   - load the access request from DynamoDB; verify caller owns it (or is
     Racker) AND status==ACTIVE; read instance_id + region — authZ + tenant
     isolation (ADR-0021: Customer1 never sees Customer2 — fail closed).
   - `sts:AssumeRole` with an inline `Policy` scoped EXACTLY like
     passportCLIPolicyDocument (ssm:StartSession on that one instance ARN,
     the port-forward doc, 3600s), `RoleSessionName` = provisioned_username.
   - return {AccessKeyId, SecretAccessKey, SessionToken, Expiration}.
   - log the vend (AU-2/AU-12).
   - IAM: grant lambda_exec `sts:AssumeRole` on the broker role only.
3. **Client: `scripts/passport-connect.sh`** (interim, pre-Go-CLI) — one command
   in the user's WSL shell that: authenticates to Cognito (or takes a token),
   calls /api/connect → polls /api/session/{id} → calls /api/sign (in-memory
   keypair, NO browser download; write to a mktemp dir, trap-shred on exit) →
   calls /api/session/{id}/ssm-credentials → exports those temp creds ONLY for
   the tunnel → opens `aws ssm start-session` → sshs. Folds cert-fetch + tunnel
   into one step (kills gaps #2 and #3).
4. **PROVE IT (ADR-0018):** run passport-connect.sh in a SCRUBBED shell
   (`env -u AWS_PROFILE -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY
   -u AWS_SESSION_TOKEN bash`); confirm `aws sts get-caller-identity` FAILS
   first, THEN the connect still tunnels+sshs — because creds come from the
   endpoint, not the environment. This is the real credential-less proof. If it
   only works with personal-faws present, it is NOT done (that's the trap).

**Then / later (unchanged priorities):** the WAF/SC-7 remediation (ALB-fronted
or REST edge — gap #1); Go rewrite per ADR-0016 (IdentityProvider/
ConnectionProvider interfaces, port signer.go); the automated 800-53 test
system; Windows/RDP passwordless.

---

### 2026-08-28 (later) — Front-door rebuild COMPLETE in code (CloudFront removed, ADR-0019/0020)

CloudFront is GONE. Layers 02 + 03 rebuilt so the portal is fronted by a single
same-origin **API Gateway (REGIONAL) + REGIONAL WAF + ACM + Route 53**, serving
BOTH the SPA and the API. The SSH CA (prior work) rides along in the same 03
apply. All code written + structurally verified; NOT deployed (SoD: greg runs
terraform). This SUPERSEDES the SSH-CA-only sequence further down.

**What changed (all committed to code):**
- Layer 02 = private SPA bucket + Route 53 public zone + regional ACM cert
  (DNS/CNAME validation) with `manage_dns`/`manage_certificate` create-vs-consume
  toggles (POC creates; prod consumes agency domain + imported cert). CloudFront/
  OAC/WAF-CLOUDFRONT deleted. New outputs: spa_bucket_name/arn, hosted_zone_id,
  hosted_zone_name_servers, acm_certificate_arn, portal_domain, portal_url.
- New Lambda `serve_spa` (03) on the `$default` route (authorization_type=NONE)
  serves the PUBLIC app shell from the private bucket; SPA fallback = index.html
  200 for extensionless non-asset paths. `/api/*` stay JWT.
- Layer 03 front-door.tf: custom domain (REGIONAL, TLS_1_2, cert from 02), api
  mapping, Route 53 A-alias into 02's zone, WAFv2 REGIONAL association to the
  stage (prior "can't attach WAF to HTTP API v2" belief was WRONG — corrected).
  CORS removed (same-origin). remote-state rewired cloudfront_* -> 02 new outputs.
- Portal SPA same-origin: apiUrl uses `??` (empty VITE_API_URL => relative /api);
  Amplify already uses window.location.origin (no change). collect-outputs.sh
  writes VITE_API_URL= (empty) and reads portal_url.

**DEPLOY RUNBOOK (greg runs; all steps DEPLOY = personal-faws, except final BROKER-TEST).**
Hard ordering: register domain -> apply 02 (cert must ISSUE) -> apply 03 -> upload SPA.
0. **Register `takahe.click`** (one-time, ~$3). Route 53 Domains is easiest
   (auto-delegates to the zone 02 creates). **Set registrar AUTO-RENEW = OFF**
   (wallet: this is the only recurring charge — ADR-0019).
1. **Apply layer 02**: `cd terraform/02-portal-hosting && terraform init && terraform apply`.
   Creates zone + SPA bucket + ACM cert + validation CNAME. If the domain was
   registered OUTSIDE Route 53, first point the registrar NS at the
   `hosted_zone_name_servers` output, THEN apply (cert validation blocks on NS
   delegation). Cert should reach ISSUED within minutes (same-account zone).
2. **Build crypto layer** (SSH CA prerequisite; already built this session, only
   re-run if cleaned): `./terraform/03-api/lambda/layers/build-crypto-layer.sh`.
3. **Stop any RUNNING Step Function executions** (state-machine replace hangs
   otherwise — they hold in WaitForSessionExpiry).
4. **Apply layer 03**: `cd terraform/03-api && terraform init && terraform apply`.
   Deploys: SSH CA (KMS/secret/param/sign Lambda/route), state-machine auth_method
   fix, serve_spa Lambda + $default route, custom domain + mapping + Route 53
   alias + WAF association, Cognito URL repoint, CORS removal.
   ORDERING GUARD: the custom-domain/mapping/alias are count-gated on
   `portal_domain != "" && acm_certificate_arn != ""` — if you apply 03 BEFORE 02,
   they SILENTLY SKIP (no error, but no front door). Always apply 02 first.
5. **Populate CA keys** (one-time, never run before):
   `AWS_PROFILE=personal-faws ./scripts/init-ssh-ca.sh`.
6. **Build + upload the SPA** to the private bucket (NOT public; no CloudFront
   invalidation anymore):
   `cd portal && npm run build`
   `/home/greg/.local/bin/aws s3 sync dist/ s3://fedramp-portal-static-675405875014/ --delete`
   (regenerate `.env.local` first via `./scripts/collect-outputs.sh` so
   VITE_API_URL is empty = same-origin).
7. **Verify the front door**: browse `https://portal.takahe.click` — SPA loads
   (serve_spa Lambda), login via Cognito (callback = same origin), `/api/*` calls
   work same-origin (no CORS).
8. **BROKER-TEST the SSH cert flow in a SCRUBBED shell** (ADR-0018):
   `env -u AWS_PROFILE -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY -u AWS_SESSION_TOKEN bash`
   confirm `aws sts get-caller-identity` FAILS first, THEN Connect SSH -> Generate
   SSH Certificate -> `ssh -i` with cert (no password).

Layers 00/01/04/05: no changes, no re-apply. (01 previously had stale-tfvars
drift between the anonymized customer_users list and older deployed user names;
convention is anonymized customer1/customer2 only — no real customer names.)

---

### 2026-08-28 — Full layer audit + one code fix (Kiro edits, greg deploys)

Audited ALL SIX terraform layers (00–05) against todo.md + ADRs before redeploy.
Separation of duties in force (ADR-0018): Kiro edits code ONLY; greg runs every
terraform/deploy command. Result: the stack is in far better shape than expected.

**Audit outcome — what needs deploying vs. what's already correct:**

| Layer | State | Changes made | Needs re-apply? |
|-------|-------|--------------|-----------------|
| 00-backend | Correct, portable, deployed | none | NO |
| 01-identity-center | Correct (mode-aware, partition-safe), deployed ACCOUNT mode | none | NO |
| 02-portal-hosting | Correct (OAC, TLS1.2_2021, WAF, SPA) | none | NO |
| 03-api | SSH CA already fully wired; ONE state-machine fix applied | **auth_method fix** | **YES** |
| 04-test-environment | Correct (SSM endpoints, zero-inbound, IMDSv2, encrypted) | none | NO |
| 05-security-baseline | Correct (CloudTrail + SSM logging; GD/SH/Config org-managed) | none | NO |

**The one code change (already applied + validated):**
`terraform/03-api/state-machine/access-lifecycle.asl.json` — split
`UpdateStatusActive` into a `RouteByAuthMethod` Choice on `$.access_type`:
- SSH → `UpdateStatusActiveSSH`: `auth_method = "ssh-cert"`, NO password stored
  (login authorized by the short-lived CA cert — ADR-0014).
- RDP → `UpdateStatusActiveRDP`: `auth_method = "password"`, carries the
  provisioned password (Windows passwordless still pending directory-join).
Before this, SSH sessions recorded `auth_method="password"` with an empty
password, which `get_session_status` surfaced to the portal — misleading audit
state. Validated: JSON well-formed, 12 states, no missing/orphan transitions,
all Lambda handlers `py_compile` OK. UI keys off `access_type` not `auth_method`,
so the change is purely corrective (no portal change needed).

**Portability (ADR-0017):** re-confirmed NO `arn:aws:` literals in any `.tf`
(WSL grep, authoritative — `grep_search` still false-zeros on `c:\`). The
Step Functions service-integration ARNs `arn:aws:states:::...` in the .asl.json
are a FIXED namespace (not partition-specific) — verified against AWS docs, leave
as-is. Account-ID in `backend.tf` + `remote-state.tf` locals still deferred to
the deploy.sh/per-env-.hcl work (does NOT block single-account deploy).

**DEPLOY RUNBOOK (greg runs; only layer 03-api is in scope this round):**
All of steps 1–5 are DEPLOY context and REQUIRE `AWS_PROFILE=personal-faws`.
Step 6 is BROKER-TEST and MUST have the profile scrubbed (ADR-0018).
1. **Build crypto layer** (creates the missing `lambda/layers/crypto/`, else
   `terraform plan` fails on the archive_file):
   `./terraform/03-api/lambda/layers/build-crypto-layer.sh`
2. **Stop any RUNNING Step Function executions** (they hold in
   WaitForSessionExpiry; a state-machine replace hangs otherwise):
   list with `aws stepfunctions list-executions --state-machine-arn <arn> --status-filter RUNNING`,
   then `aws stepfunctions stop-execution --execution-arn <each>`.
3. **Apply 03-api** (deploys the state-machine fix + the already-wired SSH CA
   infra, sign Lambda, POST /api/sign, passwordless provision):
   `cd terraform/03-api && terraform init && terraform validate && terraform apply`
   (this is where `terraform fmt`/`validate` run — Kiro did not, per SoD).
4. **Populate the CA keys — REQUIRED, never run before (confirmed 2026-08-28).**
   The SSM param currently holds the literal `PLACEHOLDER-run-init-ssh-ca.sh`
   and the secret is empty. This MUST run AFTER step 3's apply and BEFORE the
   first SSH connect, or provision_user will inject the placeholder string as
   the trusted CA key and sign_key will have no private key to load:
   `AWS_PROFILE=personal-faws ./scripts/init-ssh-ca.sh`
5. **Rebuild + redeploy portal** (proven commands from shell history; run from
   repo root with `AWS_PROFILE=personal-faws`; `/home/greg/.local/bin/aws`
   avoids the venv CRT bug):
   ```
   cd portal && npm run build
   /home/greg/.local/bin/aws s3 sync dist/ s3://fedramp-portal-static-675405875014/ --delete
   /home/greg/.local/bin/aws cloudfront create-invalidation \
     --distribution-id $(cd ../terraform/02-portal-hosting && terraform output -raw cloudfront_distribution_id) \
     --paths "/*"
   ```
6. **BROKER-TEST the cert flow in a SCRUBBED shell** (ADR-0018):
   `env -u AWS_PROFILE -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY -u AWS_SESSION_TOKEN bash`
   confirm `aws sts get-caller-identity` FAILS first, THEN Connect SSH →
   Generate SSH Certificate → `ssh -i` with cert (no password). Do NOT re-add
   the profile to make it pass.

Layers 00/01/02/04/05: leave untouched — no re-apply.

---

### Prior context (2026-08-27) — architecture session

This session (2026-08-27) was heavy on architecture. Net outcome: the deployed
POC still works; we designed the production direction (ADRs 0011–0017); and we
built (but did NOT deploy) the SSH Certificate Authority.

**ADR-0017 remediation: DONE (2026-08-27).** Code is now partition/region
portable. What was fixed and verified:
- **Partition:** every `arn:aws:` literal in `.tf` replaced with
  `arn:${local.partition}:` (added `data "aws_partition" "current"` +
  `local.partition` to layers 01, 03, 04, 05). `grep -rn 'arn:aws' --include=*.tf`
  now returns NONE. `terraform validate` = Success on 01, 03, 04 (05 validate
  timed out on init/backend, not a config error — changes are identical-form swaps).
- **Region (Lambdas):** dropped `region_name="us-east-1"` from ALL control-plane
  boto3 clients (secretsmanager, dynamodb, stepfunctions, kms, ssm param store,
  organizations) across 8 handlers → they now use ambient `AWS_REGION`.
  Region-aware `boto3.client("ssm"/"ec2", region_name=region)` (instance region)
  deliberately KEPT. All handlers `py_compile` OK. Found+fixed a bonus violation:
  `list_accounts` organizations client (global svc, partition-specific endpoint).
- **STILL OPEN — account ID in backend.** `675405875014` remains hard-coded in
  every layer's `backend.tf` (bucket name `fedramp-portal-tfstate-675405875014`)
  and in `remote-state.tf` locals. Terraform backend blocks CANNOT use variables/
  interpolation, so the portable pattern is `-backend-config=<env>.hcl` passed at
  `terraform init` time, NOT data sources. `remote-state.tf` locals CAN be
  variabilized. This is a deploy-time-config change, deferred (doesn't block the
  single-account model; only matters when standing up a NEW backend in another
  account/partition). Tackle when building deploy.sh + per-env tfvars.
- NOTE: `grep_search` tool is BROKEN for `c:\` paths (returns false zero). Use
  WSL `grep -rn` against `/mnt/c/...` — that is authoritative.

**Now do: deploy the SSH CA (ADR-0014) — additive, no teardown needed.** Sequence:
   a. `./terraform/03-api/lambda/layers/build-crypto-layer.sh` (build crypto layer)
   b. Stop RUNNING Step Function executions (or state-machine replace hangs)
   c. `cd terraform/03-api && terraform apply` (creates CA infra, sign Lambda,
      route; updates provision_user to passwordless)
   d. `AWS_PROFILE=personal-faws ./scripts/init-ssh-ca.sh` (populate CA keys — one-time)
   e. Rebuild + redeploy portal (npm build + s3 sync + CF invalidation)
   f. Test cert flow — BROKER-TEST, run in a SCRUBBED shell (NO personal-faws;
      see ADR-0018). `env -u AWS_PROFILE -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY
      -u AWS_SESSION_TOKEN bash`; confirm `aws sts get-caller-identity` FAILS first,
      THEN Connect SSH → Generate SSH Certificate → ssh -i with cert (no password).
      Steps a–e are DEPLOY and REQUIRE personal-faws. (ADR-0018)

**Then (larger, later):** the Go rewrite structured per ADR-0016 (provider/
adapter interfaces), Go `passport connect` CLI (ADR-0012/0015), Windows
passwordless (directory-join), deploy/cleanup scripts + DEPLOYMENT.md.

---

## In Progress

**Session lifecycle conductor (ADR-0023): FIX-READY, awaiting greg's one deploy +
test.** The whole redesign is coded + verified (see the top "NEXT SESSION — START
HERE" entry for the change inventory + the ordered deploy/test runbook). This
supersedes the incremental terminate fixes (I2/I5/I6 in issues.md) — they were
symptoms of a missing conductor. On successful verify it closes I2/I4/I5/I6 and
the AC-12/AC-2 stranding class. Nothing left for Kiro here until greg reports the
test results; then `git init` a baseline commit.

---

Front-door rebuild (ADR-0019/0020) + SSH CA (ADR-0014): **DEPLOYED & VERIFIED
2026-08-31** on takahe.click — passwordless SSH-cert login confirmed end-to-end.
DONE.

**PRIOR ACTIVE WORK (done):** the **credential-vending endpoint** (ADR-0012) —
`POST /api/session/{id}/ssm-credentials` + a scoped assume-role +
`scripts/passport-connect.sh` — so the SSM tunnel is credential-less for the
user (customer or Racker, no AWS account needed). **BUILT IN CODE 2026-08-31
(later); needs deploy + scrubbed-shell proof (greg, SoD).** See the top
"NEXT SESSION — START HERE" entry for the full inventory + deploy/prove runbook.
Files: `terraform/03-api/session-broker.tf`, `lambda/ssm_credentials/handler.py`
(+ route/permission in `main.tf`), `scripts/passport-connect.sh`,
`scripts/prove-credential-less.sh`. Scoping copied from Passport
`passportCLIPolicyDocument`. STS intersection + ssm:StartSession scoping +
AWS-doc empty-account-id ARN all verified against AWS docs. Remaining: greg
`terraform apply` 03-api, then run `prove-credential-less.sh` with the profile
ABSENT (confirm `get-caller-identity` FAILS first). Also carry the two known
gaps: no WAF on the HTTP API v2 front door (SC-7), and the interim browser
key-download UX (the CLI supersedes it for SSH).

**Refinements 2026-08-31 (later #2):** (1) Validity — confirmed against Passport
source: access request = 1-12h authorization; vended STS creds always <=1h. Our
1h vend is a HARD ceiling because Lambda->broker AssumeRole is role chaining
(AWS caps chained sessions at 1h; requesting more THROWS). Long windows are
served by re-vending. Do not raise the cap. (2) 800-53 — no new gaps; PARTIALLY
CLOSED AC-6(5): the vend now re-validates caller customer_id vs the instance's
live `Customer` tag at connect time, fail-closed (independent second check on
the real-access path). One new Low residual logged (broker role account-wide
StartSession, narrowed per-vend, assumable only by the Lambda). See
ARCHITECTURE-WEAKNESSES §1/§2 + ADR-0012. (3) Two-partition — endpoint derives
ARN partition from the target instance region (us-gov-* -> aws-us-gov, else aws),
so it works in Commercial (FedRAMP Moderate, CONUS) AND GovCloud; verified via
unit checks (GovCloud policy renders arn:aws-us-gov:...). No arn:aws: literals in
the new TF or handler.

### SSH CA — built this session (ADR-0014), needs deploy + test
Ported production Passport's SSH CA so Linux access is passwordless + attributed.
- `terraform/03-api/ssh-ca.tf` — KMS key, Secrets Manager secret (CA private key),
  SSM param (CA public key), lambda_exec grants.
- `scripts/init-ssh-ca.sh` — one-time: generate ed25519 CA, upload priv→SecretsManager,
  pub→SSM, shred local. RUN THIS after apply, before first connect.
- `lambda/sign_key/handler.py` — signs OpenSSH user certs via cryptography
  SSHCertificateBuilder. Cert capped at 1h, KeyId=passport_<user>_<epoch>,
  ValidPrincipals=[username, request_id]. Needs the crypto layer.
- `lambda/layers/build-crypto-layer.sh` — RUN before apply (builds manylinux
  cryptography wheel into lambda/layers/crypto/python/).
- `POST /api/sign` route added.
- `provision_user` Linux script now passwordless: creates identity-named user,
  locks password, installs CA pubkey, sets TrustedUserCAKeys. RDP unchanged.
- Portal: `sshkeys.ts` (in-browser ed25519 keygen + OpenSSH serialization),
  SessionDrawer "Generate SSH Certificate" + "Generate a new certificate"
  (reconnect within access window). SSH password field removed (RDP keeps it).

### Deploy sequence for the SSH CA
CREDENTIAL CONTEXT (ADR-0018): steps 1–4 are DEPLOY — they REQUIRE
`AWS_PROFILE=personal-faws`. Step 5 is a BROKER-TEST — it MUST run in a shell
with NO ambient AWS creds, or it will pass for the wrong reason.
1. `./scripts/... build-crypto-layer.sh` (build the layer) [DEPLOY]
2. `terraform apply` layer 03-api (creates CA secret/param, sign Lambda, route) [DEPLOY]
3. `AWS_PROFILE=personal-faws ./scripts/init-ssh-ca.sh` (populate CA keys) [DEPLOY]
4. Rebuild + redeploy portal (npm build + s3 sync + CF invalidation) [DEPLOY]
5. Test: connect SSH → Generate SSH Certificate → ssh -i with cert (no password)
   [BROKER-TEST] Run in a scrubbed shell:
   `env -u AWS_PROFILE -u AWS_ACCESS_KEY_ID -u AWS_SECRET_ACCESS_KEY -u AWS_SESSION_TOKEN bash`
   Confirm `aws sts get-caller-identity` FAILS first — only then does success
   prove the credential-less broker path actually works. Do NOT re-add the
   profile to make the test pass; that re-hides the bug (this is exactly the
   trap that fooled us before — personal-faws never expires, so it silently
   satisfied the SSM calls).

### Authorization vs. authenticator (reconnect model)
Access request TTL = 1/4/8/12h (authorization window, clamp now 15min–12h).
SSH cert = max 1h (authenticator). User reconnects by re-signing within the
window. Long-lived authorization, short-lived authenticators.

---

## Remaining Work (Next Session)

1. **scripts/deploy.sh** — automated sequential deployment of all 6 layers + portal build + S3 sync + CloudFront invalidation
2. **scripts/cleanup.sh** — destroy everything in reverse order (05 → 04 → 03 → 02 → 01 → 00)
3. **docs/DEPLOYMENT.md** — wrench-turner guide capturing the learnings above
4. **Deploy + test the SSH CA** (built this session, not deployed — see deploy sequence above).
5. **Go rewrite, structured per ADR-0016** — this is the big one. Define the
   `IdentityProvider` and `ConnectionProvider` interfaces FIRST, then implement:
   - aws-ec2 ConnectionProvider (port signer.go for SSH-CA + SSM; ADR-0014/0015)
   - Cognito IdentityProvider
   The Python sign_key is INTERIM until this lands. Structuring for providers
   now is what makes GCP/Azure/VCenter/AD/Entra additive later — do NOT hard-code
   AWS assumptions into the core.
6. **`passport connect` CLI in Go** (ADR-0012 + ADR-0015 + ADR-0016) — cloud-
   agnostic front door; dispatches to the right ConnectionProvider by target
   metadata (mirrors production Passport's AccessRequest.Type fork).
7. **Stale record handling** — get_session_status/list_sessions filter FAILED
   records from prior (deleted) state machines, or add a cleanup sweep.
8. **Medium-complexity deferred items:**
   - Windows/RDP passwordless (directory-join or Fleet Manager) — SSH CA doesn't apply to RDP
   - Inline scripts → versioned SSM Documents
   - Dead-letter queue + cleanup Lambda for failed Step Function executions

9. **Observability — SPoG dashboard BUILT (POC); production cross-account view is the next step.**
   - **DONE (2026-09-02): layer `06-observability`** — an `aws_cloudwatch_dashboard`
     (`fedramp-portal-operations`) with a unified Logs Insights "all portal
     actions, all users" timeline widget (stitches the 9 Lambda groups + Step
     Functions + API GW access logs via SOURCE clauses, newest-first) + metric
     widgets: Step Functions started/succeeded/failed/aborted, API GW
     count/4xx/5xx/latency (ApiId read from 03-api remote state), Lambda
     errors/invocations. Additive + read-only (off the access path). Deploy:
     `cd terraform/06-observability && AWS_PROFILE=personal-faws terraform apply`
     (plan = 1 add). `collect-outputs.sh` now includes the layer + prints the
     dashboard URL. Interim CloudTrail EXCLUDED from the live widget (CW delivery
     lags); the caveat is on the dashboard's own header text widget.
   - **POC CEILING (known):** a CloudWatch dashboard log widget is
     account- AND region-scoped, so this POC view only reaches the us-east-1
     management plane. It cannot show all users across all accounts/regions.
   - **PRODUCTION EVOLUTION (design decision, greg 2026-09-02):** build the
     observability plane at the **org level**, because prod provisions to
     customers with **Account as the base boundary, Region next**. Pattern:
     a dedicated **monitoring account** using CloudWatch **cross-account
     observability** (a single Logs Insights query in the monitoring account can
     span log groups in many source accounts/regions), fed by the org CloudTrail
     (already lands in the log-archive account) + a subscription-filter fan-in
     (or OpenSearch) for the durable, machine-readable 20x evidence pipeline.
     Add CloudWatch Alarms + SNS (failed auth / anomalous API / unexpected-
     instance sessions) for the AU-6 alerting half. This is the real demi-god
     view; the POC `06-observability` dashboard is the proof-of-concept of the
     widget mechanics, re-hosted in the monitoring account for prod.

10. **AD-controller (Domain Controller on EC2) access — KNOWN NOT to work with
    the current flow; separate design track.** Two reasons, confirmed against
    the code:
    - `provision_user` Windows path uses `New-LocalUser` + `Add-LocalGroupMember
      Administrators`. A Domain Controller has **no local SAM accounts** — every
      principal is a domain account. `New-LocalUser` fails on a DC, so the RDP
      flow as built cannot provision there at all.
    - Even if it could, ephemeral **domain** admin creation on a DC is Domain-
      Admin / forest-wide blast radius — a fundamentally different, more
      sensitive operation than a local user on a member server.
    Correct home for this is a distinct `ConnectionProvider` (ADR-0016) doing
    Kerberos/AD-native or smartcard/PIV auth, aligned with ADR-0011's
    directory-join staging note — NOT a patch to the local-user path. Gate this
    AFTER Linux + Windows *member-server* connects verify working. Until then,
    document "DCs unsupported" as an explicit scope boundary.

    **CONTROL-LEVEL PROHIBITION (not just a technical gap).** Auto-minting an
    ephemeral **domain admin** on a DC on request is a security-control
    violation, not a feature to build casually. It lets the access broker
    manufacture the highest privilege in the forest on demand. 800-53 impact:
    - AC-6 / AC-6(1) / AC-6(5) — antithesis of least privilege for privileged
      accounts.
    - AC-5 — separation of duties: broker would both authorize AND create the
      most powerful identity in the domain, no second party.
    - IA-2 / IA-4 — synthetic ephemeral DA undermines unique ID / identifier
      management at the tier where attribution matters most.
    - AU-9(4) — a DA can alter/purge the very audit logs meant to prove what it
      did. This is the MITM-grade concern: the audited entity can rewrite the
      audit trail. Whoever owns the DC owns Kerberos (TGT issuance, golden/
      silver ticket forgery, impersonation of any principal) — blast radius is
      the entire trust fabric, not one host.
    - CM-5 / SC-3 — the DC IS the security function; programmatic provisioning
      into it breaks change-access restriction and security-function isolation.
    Posture: **DENY BY DEFAULT.** If DC access is ever in scope, it requires a
    separately-designed, human-in-the-loop path (PIM/JIT with explicit
    approval, PAW-originated, tiered-admin model, session recording the DA
    cannot reach) — a design conversation WITH security, never an
    auto-provisioned provider. Record "DCs explicitly out of scope / prohibited
    via the auto-provisioning path" as a stated control decision (candidate
    ADR).

11. **Re-author layer 02 internet-facing tier per ADR-0019 (IL4 boundary fix).**
    Current 02 = CloudFront + S3 + WAF(CLOUDFRONT) — POC-only, commercial-only,
    NOT IL4-compliant (CloudFront isn't in GovCloud + is global/non-CONUS →
    SC-7/SC-8/SA-9/AU/PE). Replace with the partition-intersection pattern that
    runs identically in commercial AND GovCloud (DECIDED — API Gateway, ADR-0019):
    - **API Gateway, endpoint type = REGIONAL** as the single front door for the
      SPA + API (unifies with the existing HTTP API v2 → one boundary, one WAF,
      one TLS point, one log stream). NEVER edge-optimized (that's CloudFront
      under the hood). Regional custom domain only.
    - WAFv2 `scope="REGIONAL"` on the API Gateway stage (not CLOUDFRONT scope).
    - ACM (regional) cert on the regional custom domain.
    - Route 53 public hosted zone (GovCloud public DNS available since 2025-04).
    - AWS Shield (Standard automatic; Advanced opt-in for L7 auto-mitigation +
      SRT) — in-boundary DDoS posture replacing the "global edge" instinct.
    - SPA served via API GW (proxy integration to S3 origin, or static via API);
      drop CloudFront OAC — origin protection moves to the regional front door.
      NOTE: SPA-through-API-GW is the one detail to prototype early (less
      conventional than SPA-on-CloudFront/S3).
    - REJECTED: Global Accelerator / any "global" fronting — commercial-only
      global edge, fails intersection test (same as CloudFront).
    Carry over existing posture: TLS1.2_2021 floor, WAF managed rule groups, US
    geo-restriction, access logging — re-expressed on the regional front door.
    This is net-new work (the acknowledged exception to ADR-0017 port-by-config).
    STATUS (2026-08-28): CODE COMPLETE for the POC (API Gateway path chosen +
    built; serve_spa Lambda; layer 02 rebuilt with create/consume toggles;
    same-origin SPA). Deployed via the front-door runbook in "NEXT SESSION —
    START HERE". Remaining for PRODUCTION/IL4: exercise the consume-mode toggles
    against a real .gov/agency domain + imported cert; add DNSSEC (deferred for
    POC); confirm the whole pattern applies unchanged in GovCloud.

12. **Automated testing system (AFTER we have working, 800-53-compliant code).**
   Build an automated test engine covering three dimensions:
   - **Operational testing** — infra is deployed and healthy (endpoints reachable,
     Lambdas invokable, Step Function executes, SSM tunnels establish, CA signs).
   - **Functional testing** — end-to-end user flows through the portal UI
     (login + MFA → list instances → Connect → cert issue → SSH/RDP → End Session).
     Browser-driven, Selenium-style — evaluate the current best option
     (e.g. Playwright is the modern successor; also consider Cypress). Pick the
     most current/maintained engine at build time.
   - **800-53 / FedRAMP analysis** — automated control-evidence checks (tie test
     results and config state back to specific 800-53 controls: AC-6, AU-2/3/12,
     IA-5, SC-28, etc.). Consider AWS Config conformance packs, Security Hub
     standards, and/or a custom evidence collector as inputs.
   MUST honor ADR-0018: functional/broker-path tests run in a credential-scrubbed
   context so they validate the real broker path, not ambient admin creds.
   Rationale: manual verification does not scale and is exactly where testing-
   integrity assumptions creep in; automate it once the system is stable.

### Already resolved (do NOT re-add)
- SSH certificate auth for Linux — DONE (ADR-0014)
- UI session persistence across reload — DONE (SessionsContext + polling)
- Identity-named users / attribution — DONE (ADR-0011)
- Per-session ports, concurrent sessions, End Session — DONE

---

## Build Order

### 1. Terraform: 00-backend
- S3 state bucket + DynamoDB lock table
- Region: us-east-1

### 2. Terraform: 01-identity-center
- Enable IAM Identity Center (if not already)
- Create permission sets:
  - `RGS-Admin` (full access, for Racker engineers)
  - `RGS-ReadOnly` (read + SSM, for junior Rackers)
  - `Customer-VMAccess` (SSM StartSession only, tag-scoped)
  - `Customer-Console` (broader, for future expansion)
- Create groups in Identity Center built-in directory (for testing)
- Assign permission sets to groups

### 3. Terraform: 02-portal-hosting
- S3 bucket (portal static files)
- CloudFront distribution (HTTPS, TLS 1.2+)
- WAF WebACL (rate limiting, geo-restrict US only)
- Origin Access Control (OAC)

### 4. Terraform: 03-api
- HTTP API Gateway v2 with JWT authorizer + regional WAF
- Cognito User Pool (MFA required, Rackers/Customers groups)
- Lambda functions:
  - list-accounts (calls organizations:ListAccounts, simulated in dev)
  - list-instances (calls ssm:DescribeInstanceInformation, parallel, customer_id enforced)
  - create-access-request (initiates Passport-style flow via Step Functions)
  - get-session-status (checks DynamoDB, decrypts credentials via KMS)
- DynamoDB table for access requests (GSIs, TTL)
- KMS CMK for credential encryption
- Step Functions state machine (provision → session → cleanup)
- IAM roles for Lambda + Step Functions

### 5. Terraform: 04-test-environment
- us-east-2: VPC + public/private subnets + NAT + VPC Endpoints (SSM) + 2 EC2 (Linux + Windows)
- us-west-1: VPC + public/private subnets + NAT + VPC Endpoints (SSM) + 2 EC2 (Linux + Windows)
- Instances tagged: Customer, CustomerAccess=true, OS, Platform
- SSM agent configured (instance profile with AmazonSSMManagedInstanceCore)
- No inbound SSH/RDP security group rules
- IMDSv2 required, EBS encrypted

### 6. Terraform: 05-security-baseline
- GuardDuty (us-east-1 + customer regions)
- Security Hub + NIST 800-53 v5 + AWS Foundational standards
- AWS Config recorder + rules (required-tags, ec2-managed-by-ssm, restricted-ssh)
- CloudTrail (multi-region, S3 + CloudWatch, log validation, 365d retention)
- SSM Session Manager logging (SSM-SessionManagerRunShell document, S3 + CloudWatch)

### 7. Portal: React SPA
- Vite 5 + React 18 + TypeScript
- Auth: AWS Amplify 6 with Cognito (federated to Identity Center)
- Routing: /login, /callback, /racker (multi-account view), /customer (single-account view)
- Components:
  - Layout (header/footer with RGS branding)
  - InstanceTable (filterable by name, ID, platform, region)
  - ConnectButton (initiates access request, polls for ACTIVE)
  - SessionDrawer (slide-over panel with countdown, copyable credentials)
  - ConsoleAccessButton (opens Identity Center console URL)
- API client: authenticated fetch with JWT Bearer token
- Styling: Tailwind CSS, dark navy (#1B2838) + white + red (#C8102E) accent
- Responsive, accessible (WCAG 2.1 AA)

### 8. Passport Integration
See \\wsl.localhost\Ubuntu-20.04\home\greg\Chappies-Tools\passport for all required passport, Janus and resources code. Copy, don't reference github.
- Adapt Step Function from passport repo for our use
- SSM documents for:
  - Linux: create user, add to sudoers, inject SSH cert, cleanup
  - Windows: create local admin, set password, cleanup
- DynamoDB schema matching Passport's AccessRequests pattern
- API endpoint that triggers the Step Function

### 9. Deployment Scripts
- `scripts/collect-outputs.sh` — consolidates terraform outputs into outputs.json ✓ EXISTS
- `scripts/verify-deployment.sh` — post-deploy smoke tests ✓ EXISTS
- `scripts/deploy.sh` — sequential deployment of all layers (TODO)
- `scripts/cleanup.sh` — destroy everything in reverse order (TODO)
- `docs/DEPLOYMENT.md` — step-by-step for a wrench-turner (TODO)

---

## Design Decisions (ADRs)

| ADR | Decision | Rationale |
|-----|----------|-----------|
| 0001 | AWS-native over third-party (Teleport, AppGate) | 20x compliance native, zero vendor cost, own the roadmap |
| 0002 | Regions as test boundaries (single account POC) | One engineer, one account, proves access model without org complexity |
| 0003 | Adopt Passport V2 patterns for access lifecycle | Step Functions + SSM + DynamoDB, proven at scale inside Rackspace |
| 0004 | Serverless backend (API Gateway + Lambda) | Scales to zero, no servers to patch, WAF integration built-in |
| 0005 | Portal auth via Cognito (federated to IdP) | SAML → JWT bridge, Cognito authorizer on API GW, no custom auth |
| 0006 | Zero inbound ports on customer instances | SSM outbound only, attack surface eliminated, auditors love it |
| 0007 | RGS Government branding (navy + white + red) | Professional federal look, Tailwind CSS, WCAG 2.1 AA compliant |
| 0008 | Self-documenting terraform.tfvars per layer | Every value visible and explained, auditor-friendly, no mystery defaults |
| 0009 | Cross-layer deps via terraform_remote_state | Auto-reads outputs from prior layers, eliminates manual copy-paste errors |
| 0010 | Security baseline as dedicated layer (05) | GuardDuty + Security Hub + Config + CloudTrail + SSM logging in one place, deploy-once |
| 0011 | Govern the local principal (don't eliminate it) | Privilege requires a local OS user; make it identity-named, role-scoped, cert-auth, ephemeral, correlated |
| 0012 | CLI-broker access pattern (no user AWS creds) | Ship a `passport connect`-style CLI that brokers SSM via portal identity; users need no AWS credentials file. Mirrors production Passport. |
| 0013 | Build a gov-specific Passport | Don't reuse commercial Passport (partition/boundary isolation). Build in-boundary, mirror proven patterns, target GovCloud. |
| 0014 | SSH Certificate Authority for Linux | Port Passport's SSH CA: client sends pubkey, backend signs short-lived cert (KeyId=identity). Passwordless, attributed, kills SC-28/IA-5 for Linux. |
| 0015 | Language: Go for crypto/CLI, Python for CRUD | Go for sign_key Lambda + `passport connect` CLI (parity w/ prod Passport, mature x/crypto/ssh, RSA-SHA1 solved). Python for glue. Rust deferred. |
| 0016 | Provider/adapter architecture (multi-target/identity) | Two cloud-agnostic planes + pluggable IdentityProvider & ConnectionProvider interfaces. AWS-EC2/SSH-CA is provider #1. GCP/Azure/VCenter/AD/Entra additive later. THE strategic direction. |
| 0017 | Environment portability by config, not code | Move model→commercial-org→GovCloud by changing tfvars ONLY. No hard-coded account/region/partition/ARN. Partition-safe ARNs. Provider selection is config. |
| 0018 | Credential context: deploy WITH profile, test WITHOUT | `personal-faws` = long-lived keys, never expire. Deploy REQUIRES it; broker-path testing MUST scrub it (else tests pass for the wrong reason — the trap that fooled us). |
| 0019 | Partition-intersection palette + no CloudFront/Global Accelerator for IL4 | Use ONLY services in the commercial∩GovCloud intersection so one pattern serves both partitions. CloudFront AND Global Accelerator are commercial-only global edge (non-CONUS) → violate SC-7/SC-8/SA-9/AU/PE for IL4. Internet front door = **API Gateway (REGIONAL endpoint — NOT edge-optimized, which is CloudFront under the hood) + REGIONAL WAF + ACM + Shield + Route53**, all in-boundary. Shield replaces the "global/anycast" DDoS instinct. Layer 02 (CloudFront) is POC-only, must be REPLACED not ported — the one exception to ADR-0017's port-by-config. |
| 0020 | Prefer AWS-managed services to inherit control coverage | DEFAULT to managed AWS services so we inherit their FedRAMP/IL4 control coverage — don't hesitate. Only deliberate IF (1) two genuinely valid options exist, OR (2) inheriting moves posture NEGATIVE vs 800-53/Moderate/IL4. Order: intersection test (0019) first, then inheritance preference. Inheritance is NEVER total — always implement the customer-responsibility side (no false assurance). Inherit plumbing; keep provider layer abstracted (0016). |
| 0021 | Product vision, users, and scope | The "north star." RGS-org-exclusive gov evolution of Passport V2. Three first-class users: ATO auditors (machine-readable evidence), Rackspace engineers/operators (via ServiceNow), customers (secure EC2 access). ATO-ADDITIVE + built for Rev5→20x. Expansion (console/other services) via SCN. Multi-cloud + private cloud (vCenter/OpenStack) via ADR-0016 providers. Tenant isolation (Cust1 never sees Cust2) is an INVIOLABLE invariant. Replaces AD+VPN+jumphost model which fails 20x + devalues cloud. |
| 0022 | Design decision hierarchy (Passport → 800-53 → lowest-risk tiebreak) | Ordered rule for every access/architecture choice: (1) Passport V2 prior art is the default guide (mirror, don't invent); (2) adapt it to satisfy 800-53 (extend to meet controls, never ship the gap); (3) on conflict choose the lowest-security-risk option and DOCUMENT the residual (ARCHITECTURE-WEAKNESSES/ADR). Later rule overrides earlier. Makes the tacit rule explicit; worked example = Windows RDP vends a short-lived password (not stored) to keep Passport's tunnel+client pattern while satisfying SC-28/IA-5(1). |
| 0023 | Session lifecycle — one conductor, one convergent teardown | The Step Function is the SOLE conductor: it verifies each worker's actual result before advancing and owns all four teardown concerns (connection, OS user, profile, SSM tunnel). Every end-trigger submits the SAME end-demand to the score (DynamoDB); no caller performs its own teardown; `states:StopExecution` is FORBIDDEN (aborting the conductor stranded 81 executions). A cleanup that can't be verified becomes terminal `CLEANUP_FAILED`, never a silent `COMPLETED`. Extends ADR-0022 §5.2 (keeps the poll-loop mechanism, adds the conductor invariants). |
| 0024 | Attributed command-and-control plane | Every action (state-changing, and per the retrofit reads too) is attributed + logged: who, what, when, on-behalf-of, justification. Privileged on-behalf-of actions (operator acting on another user/tenant) carry a fail-closed mandatory reason. The permanent record also lands in CloudTrail/CloudWatch. |
| 0025 | One session record per connect + operator lens | The CLI's authenticated request is the SINGLE session record (portal Connect provisions nothing — shows the command). Adds operator mode `GET /api/sessions?scope=all` (Rackers only, fail-closed 403, optional tenant filter), operator revoke with mandatory reason, and end attribution (ended_by/end_source/end_reason). Fixed the two-records/two-orphan-users bug. |
| 0026 | Contract-first platform (portal = reference client) | `platform/` publishes four contracts; ANY consumer (customer SPA, mobile, ServiceNow, auditor tool) is a client with no privilege the reference RGS portal lacks. Every state change is async (202 + job). The security/800-53 baseline is inherited, not the consumer's concern. |
| 0027 | Provider abstraction (connection is provider-defined) | Nothing SSM-shaped is in the contract surface. `connect` is abstract (establish an attributed, verifiably-terminable session); AWS satisfies it via SSM tunnel + vended STS + SSH cert, vCenter via its own broker, Azure via Bastion/Arc. Per-provider boundary; the consumer never assembles provider transport. |
| 0028 | Identity by ASSURANCE, not mechanism | The platform authorizes on `authn_assurance` + tenant + groups, NEVER on `authn_method`. Cognito is one impl; SAML/OIDC/PIV/FIDO2/(transitional) AD-trust normalize to the same assertion below the contract. This is what makes "not married to Cognito" real. |
| 0029 | Boundaries + compliance profiles (not forks) | 800-53 Moderate / IL4 / 800-171 are PROFILES over the shared core + `_baseline`, not code forks. 800-53 is the umbrella subsuming IRS-1075/PCI/HIPAA/PII concerns. "Graded against, not certified under." Multi-cloud does NOT enter the IL4 boundary. |
| 0030 | Layer coupling — HYBRID | Remote-state for the stable core (foundation/identity/security); a published SSM/manifest contract at the provider/portal seams. Reconciles ADR-0009 (remote_state) with the contract-first direction. |
| 0031 | Phased delivery — contracts provisional until 2nd impl | The four contracts stay PROVISIONAL until a second implementation (vCenter, Phase 3) pressure-tests them. Prevents freezing a contract shaped by one provider. |
| 0032 | Non-disruptive parallel deploy + module-first | Author modules FRESH from POC patterns (reuse code + bug fixes verbatim; re-author only packaging); NEVER move/apply the POC state. `platform/live/*` stands up BESIDE the POC (own state, distinct `name_prefix`). |
| 0033 | Organization deployment model (control plane vs member accounts) | Target = control-plane account (portal/API/IdP/score/keys/conductor/broker) + a per-member-account "target-access role" the control plane assumes (the AWS-provider data-plane contract). Single-account/regions-as-tenants retained as the getting-started profile. Cross-account retrofit (assume-and-fan-out in 4 handlers, StackSet role rollout, customer_id→account_id) is DEFERRED and documented, not faked. |
| 0034 | Information sensitivity (Green/Yellow/Red + fixed-pair aggregation rule) | Classify all info Green/Yellow/Red; default Yellow-unless-clearly-Green, escalate when unsure. **The POC and platform CODE are Green** (a solution path to the general problem; only Rackspace coupling is consuming Passport V2 / Resources / Janus as prior art). DEPLOYMENT VALUES (real account/region/instance/domain/customer footprint) are Yellow/Red. Aggregation rule: the recon vector is rebuilt by CORRELATION across conversations, so **choose the same fixed PAIR of elements and never reveal a third anywhere** — consistency is the control, not per-artifact counting. Secrets by reference, never value. |
| 0035 | StackSets deployment topology + template separation | Org managers need the PUSH model (StackSets, service-managed, OU-targeted, auto-enroll), not DevOps-shaped Terraform. **Two planes/two tools:** data plane (wide, replicated: target-access role + log wiring per member acct) via CFN StackSets from mgmt/delegated-admin; control plane (deep, singular: API/conductor/Lambdas/score/KMS/Cognito/SPA) deployed ONCE into the control account (TF or CFN/CDK). **Four template families** = {single-stack control acct, StackSet member accts} × {IAM, resources}; nothing spans cells. **IAM NEVER in the same template as resources** — primary reason: StackSets + named IAM → "already exists" failures on IAM/permission/service-API changes, non-transactional across accounts, painful to chase per failed operation instance; isolate so the fragile create-surface is touched rarely + blast radius is a thin importable StackSet. Deterministic target-access role name (no CFN suffix; ADR-0033 ARN construction) makes the discipline mandatory. CloudTrail consolidation = inherit by reference (org trail / Control Tower), don't rebuild (ADR-0020). BAKE ourselves: CloudWatch Logs consolidation + cross-account aggregation + unified dashboard (C2-plane features). Sequenced deploy order (member-IAM → member-resources → control-IAM → control-resources → log-aggregation) is IN the ADR as principle; literal runbook in ADOPTER-GUIDE. |

| 0036 | IaC consolidation to CloudFormation (supersedes TF-first packaging) | Whole delivery = CloudFormation; Terraform RETIRED for new work (cattle not a prized cow — it met demand + proved the decomposition). Enterprise/Org manager is the paramount operator (governance posture); one substrate native to StackSets/Control Tower/delegated-admin beats a two-tool split. Supersedes-in-part ADR-0032 (module-first-in-TF) + ADR-0035 §1 (control-plane IaC). Only TF PACKAGING is discarded — reused ASSETS (handlers w/ I8/I10/ADR-0023, ASL, contracts, IAM policy shapes, KMS/Cognito config) are IaC-agnostic and port verbatim (ADR-0032 already called packaging the disposable layer). Existing TF left in place, marked superseded, NOT deleted (validated reference for the port). Contract-first thesis + 3-class taxonomy + ADR-0033/0035 structure UNCHANGED. Raw CFN YAML default; CDK-synth allowed for control plane. |

ADR files: `.kiro/steering/adr-0001-*.md` through `adr-0036-*.md` (auto-included in all sessions). ADRs 0001–0025 = the POC; 0026–0033 = the platform; 0034 = information-sensitivity policy; 0035 = StackSets deployment topology; 0036 = IaC consolidation to CloudFormation (TF retired).

---

## Session Pickup Instructions

Read the "Current State (as of 2026-09-08)" block near the top, then the newest
entry under "NEXT SESSION — START HERE" (newest-first). Both tracks (frozen POC +
active platform) are summarized there.

The POC build is DONE and deployed (the old "2-3 session build" plan below is
historical). Active work is the `platform/` product. If resuming platform work,
the immediate items are in the newest START HERE entry: the cross-account Org
retrofit (needs a real AWS Organization — see ADR-0033 + platform/ADOPTER-GUIDE.md)
and, if the tool block is lifted, moving the finished JSON Schemas from
platform/contracts/schemas/*.md into real .schema.json files.

### Historical POC build plan (all DONE — kept for provenance)

| Session | Layers | Deliverable | Status |
|---------|--------|-------------|--------|
| 1 | 00-backend + 02-portal-hosting | Terraform infra written | DONE |
| 1 (cont) | 03-api + 04-test-environment + portal skeleton | All code written | DONE |
| 1 (cont) | Security hardening + 05-security-baseline | MFA, KMS, VPC endpoints, GuardDuty, Config, CloudTrail, SSM logging | DONE |
| 2 | Deploy + test + scripts + docs | End-to-end working + verified | DONE |
| — | Rebuild to same-origin front door (ADR-0019) | CloudFront + WAF + Identity Center REMOVED; API GW REGIONAL + ACM + R53 | DONE |
| — | Platform extraction (`platform/`, 8 modules + contracts) | Authored + validated, not applied | DONE |

Note: 01-identity-center, CloudFront/layer-02-CDN, and WAF appear in old entries
but were REMOVED (see ADR-0019 + the 2026-09-01 entry). Do not re-add them.

### Tech Stack Summary (current)

| Layer | Tech |
|-------|------|
| IaC | Terraform >= 1.5, HCL (POC: layered 00–05; platform: modules + live roots) |
| Backend | API Gateway **HTTP API v2** + Lambda (Python 3.12) + Step Functions |
| State | DynamoDB (access-request "score") |
| Auth | Cognito User Pool (JWT authorizer); IdP swappable behind the identity assertion (ADR-0028) |
| Frontend | React 18 + TypeScript + Vite + Tailwind CSS (the reference client) |
| Hosting | S3 (private) + same-origin serve_spa via the API; REGIONAL custom domain + ACM + Route 53 (ADR-0019; NO CloudFront/WAF) |
| Access | SSM Session Manager only (no bastions/VPN); SSH CA for passwordless Linux; credential-vending broker (ADR-0012) |
| CLI | Go `passport connect` (brokers SSM; no user AWS creds, ADR-0012) |
| Testing | POC: single account, regions as boundaries. Platform target: AWS Organization, multi-account (ADR-0033) |

### Branding Specs (quick reference)

- Primary: `#1B2838` (dark navy)
- Accent: `#C8102E` (red)
- Text: white on navy, dark on light surfaces
- Font: system stack (Inter if available)
- Tone: clean, minimal, federal/government professional
- Reference: rackspace.com/industry/government
